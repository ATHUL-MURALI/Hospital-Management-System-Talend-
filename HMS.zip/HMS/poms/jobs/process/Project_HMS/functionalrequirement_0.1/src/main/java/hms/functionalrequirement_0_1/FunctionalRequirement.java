
package hms.functionalrequirement_0_1;

import routines.Numeric;
import routines.DataOperation;
import routines.TalendDataGenerator;
import routines.TalendStringUtil;
import routines.TalendString;
import routines.MDM;
import routines.StringHandling;
import routines.Relational;
import routines.TalendDate;
import routines.Mathematical;
import routines.SQLike;
import routines.system.*;
import routines.system.api.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.Comparator;

@SuppressWarnings("unused")

/**
 * Job: FunctionalRequirement Purpose: <br>
 * Description: <br>
 * 
 * @author student@qlik.com
 * @version 8.0.1.20240524_0800-patch
 * @status
 */
public class FunctionalRequirement implements TalendJob {
	static {
		System.setProperty("TalendJob.log", "FunctionalRequirement.log");
	}

	private static org.apache.logging.log4j.Logger log = org.apache.logging.log4j.LogManager
			.getLogger(FunctionalRequirement.class);

	protected static void logIgnoredError(String message, Throwable cause) {
		log.error(message, cause);

	}

	public final Object obj = new Object();

	// for transmiting parameters purpose
	private Object valueObject = null;

	public Object getValueObject() {
		return this.valueObject;
	}

	public void setValueObject(Object valueObject) {
		this.valueObject = valueObject;
	}

	private final static String defaultCharset = java.nio.charset.Charset.defaultCharset().name();

	private final static String utf8Charset = "UTF-8";

	// contains type for every context property
	public class PropertiesWithType extends java.util.Properties {
		private static final long serialVersionUID = 1L;
		private java.util.Map<String, String> propertyTypes = new java.util.HashMap<>();

		public PropertiesWithType(java.util.Properties properties) {
			super(properties);
		}

		public PropertiesWithType() {
			super();
		}

		public void setContextType(String key, String type) {
			propertyTypes.put(key, type);
		}

		public String getContextType(String key) {
			return propertyTypes.get(key);
		}
	}

	// create and load default properties
	private java.util.Properties defaultProps = new java.util.Properties();

	// create application properties with default
	public class ContextProperties extends PropertiesWithType {

		private static final long serialVersionUID = 1L;

		public ContextProperties(java.util.Properties properties) {
			super(properties);
		}

		public ContextProperties() {
			super();
		}

		public void synchronizeContext() {

		}

		// if the stored or passed value is "<TALEND_NULL>" string, it mean null
		public String getStringValue(String key) {
			String origin_value = this.getProperty(key);
			if (NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY.equals(origin_value)) {
				return null;
			}
			return origin_value;
		}

	}

	protected ContextProperties context = new ContextProperties(); // will be instanciated by MS.

	public ContextProperties getContext() {
		return this.context;
	}

	protected java.util.Map<String, String> defaultProperties = new java.util.HashMap<String, String>();
	protected java.util.Map<String, String> additionalProperties = new java.util.HashMap<String, String>();

	public java.util.Map<String, String> getDefaultProperties() {
		return this.defaultProperties;
	}

	public java.util.Map<String, String> getAdditionalProperties() {
		return this.additionalProperties;
	}

	private final String jobVersion = "0.1";
	private final String jobName = "FunctionalRequirement";
	private final String projectName = "HMS";
	public Integer errorCode = null;
	private String currentComponent = "";
	public static boolean isStandaloneMS = Boolean.valueOf("false");

	private String cLabel = null;

	private final java.util.Map<String, Object> globalMap = new java.util.HashMap<String, Object>();
	private final static java.util.Map<String, Object> junitGlobalMap = new java.util.HashMap<String, Object>();

	private final java.util.Map<String, Long> start_Hash = new java.util.HashMap<String, Long>();
	private final java.util.Map<String, Long> end_Hash = new java.util.HashMap<String, Long>();
	private final java.util.Map<String, Boolean> ok_Hash = new java.util.HashMap<String, Boolean>();
	public final java.util.List<String[]> globalBuffer = new java.util.ArrayList<String[]>();

	private final JobStructureCatcherUtils talendJobLog = new JobStructureCatcherUtils(jobName,
			"_mc7mYOqIEe-S2IUjnYFGbA", "0.1");
	private org.talend.job.audit.JobAuditLogger auditLogger_talendJobLog = null;

	private RunStat runStat = new RunStat(talendJobLog, System.getProperty("audit.interval"));

	// OSGi DataSource
	private final static String KEY_DB_DATASOURCES = "KEY_DB_DATASOURCES";

	private final static String KEY_DB_DATASOURCES_RAW = "KEY_DB_DATASOURCES_RAW";

	public void setDataSources(java.util.Map<String, javax.sql.DataSource> dataSources) {
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		for (java.util.Map.Entry<String, javax.sql.DataSource> dataSourceEntry : dataSources.entrySet()) {
			talendDataSources.put(dataSourceEntry.getKey(),
					new routines.system.TalendDataSource(dataSourceEntry.getValue()));
		}
		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}

	public void setDataSourceReferences(List serviceReferences) throws Exception {

		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		java.util.Map<String, javax.sql.DataSource> dataSources = new java.util.HashMap<String, javax.sql.DataSource>();

		for (java.util.Map.Entry<String, javax.sql.DataSource> entry : BundleUtils
				.getServices(serviceReferences, javax.sql.DataSource.class).entrySet()) {
			dataSources.put(entry.getKey(), entry.getValue());
			talendDataSources.put(entry.getKey(), new routines.system.TalendDataSource(entry.getValue()));
		}

		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}

	private final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
	private final java.io.PrintStream errorMessagePS = new java.io.PrintStream(new java.io.BufferedOutputStream(baos));

	public String getExceptionStackTrace() {
		if ("failure".equals(this.getStatus())) {
			errorMessagePS.flush();
			return baos.toString();
		}
		return null;
	}

	private Exception exception;

	public Exception getException() {
		if ("failure".equals(this.getStatus())) {
			return this.exception;
		}
		return null;
	}

	private class TalendException extends Exception {

		private static final long serialVersionUID = 1L;

		private java.util.Map<String, Object> globalMap = null;
		private Exception e = null;

		private String currentComponent = null;
		private String cLabel = null;

		private String virtualComponentName = null;

		public void setVirtualComponentName(String virtualComponentName) {
			this.virtualComponentName = virtualComponentName;
		}

		private TalendException(Exception e, String errorComponent, final java.util.Map<String, Object> globalMap) {
			this.currentComponent = errorComponent;
			this.globalMap = globalMap;
			this.e = e;
		}

		private TalendException(Exception e, String errorComponent, String errorComponentLabel,
				final java.util.Map<String, Object> globalMap) {
			this(e, errorComponent, globalMap);
			this.cLabel = errorComponentLabel;
		}

		public Exception getException() {
			return this.e;
		}

		public String getCurrentComponent() {
			return this.currentComponent;
		}

		public String getExceptionCauseMessage(Exception e) {
			Throwable cause = e;
			String message = null;
			int i = 10;
			while (null != cause && 0 < i--) {
				message = cause.getMessage();
				if (null == message) {
					cause = cause.getCause();
				} else {
					break;
				}
			}
			if (null == message) {
				message = e.getClass().getName();
			}
			return message;
		}

		@Override
		public void printStackTrace() {
			if (!(e instanceof TalendException || e instanceof TDieException)) {
				if (virtualComponentName != null && currentComponent.indexOf(virtualComponentName + "_") == 0) {
					globalMap.put(virtualComponentName + "_ERROR_MESSAGE", getExceptionCauseMessage(e));
				}
				globalMap.put(currentComponent + "_ERROR_MESSAGE", getExceptionCauseMessage(e));
				System.err.println("Exception in component " + currentComponent + " (" + jobName + ")");
			}
			if (!(e instanceof TDieException)) {
				if (e instanceof TalendException) {
					e.printStackTrace();
				} else {
					e.printStackTrace();
					e.printStackTrace(errorMessagePS);
					FunctionalRequirement.this.exception = e;
				}
			}
			if (!(e instanceof TalendException)) {
				try {
					for (java.lang.reflect.Method m : this.getClass().getEnclosingClass().getMethods()) {
						if (m.getName().compareTo(currentComponent + "_error") == 0) {
							m.invoke(FunctionalRequirement.this, new Object[] { e, currentComponent, globalMap });
							break;
						}
					}

					if (!(e instanceof TDieException)) {
						if (enableLogStash) {
							talendJobLog.addJobExceptionMessage(currentComponent, cLabel, null, e);
							talendJobLogProcess(globalMap);
						}
					}
				} catch (Exception e) {
					this.e.printStackTrace();
				}
			}
		}
	}

	public void tDBInput_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMap_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFileOutputExcel_2_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFileOutputExcel_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBInput_2_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_2_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMap_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_2_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFileOutputExcel_3_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_2_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFileOutputExcel_4_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_2_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFileOutputExcel_5_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_2_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBInput_3_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_3_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMap_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_3_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFileOutputExcel_6_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_3_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFileOutputExcel_7_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_3_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFileOutputExcel_8_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_3_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBInput_4_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_4_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMap_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_4_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFileOutputExcel_9_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_4_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFileOutputExcel_10_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_4_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBInput_5_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_5_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMap_5_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_5_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFileOutputExcel_11_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_5_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tSampleRow_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_5_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tJoin_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_5_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tLogRow_2_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_5_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tLogRow_3_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_5_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tLogRow_4_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_5_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBInput_6_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_5_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tHash_row12_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_5_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tSortRow_1_SortOut_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		tSortRow_1_SortIn_error(exception, errorComponent, globalMap);

	}

	public void tSortRow_1_SortIn_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_2_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tSortRow_2_SortOut_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		tSortRow_2_SortIn_error(exception, errorComponent, globalMap);

	}

	public void tSortRow_2_SortIn_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_3_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tAggregateRow_1_AGGOUT_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		tAggregateRow_1_AGGIN_error(exception, errorComponent, globalMap);

	}

	public void tAggregateRow_1_AGGIN_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_4_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tAggregateRow_2_AGGOUT_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		tAggregateRow_2_AGGIN_error(exception, errorComponent, globalMap);

	}

	public void tAggregateRow_2_AGGIN_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_5_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tSortRow_3_SortOut_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		tSortRow_3_SortIn_error(exception, errorComponent, globalMap);

	}

	public void tSortRow_3_SortIn_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_5_onSubJobError(exception, errorComponent, globalMap);
	}

	public void talendJobLog_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		talendJobLog_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBInput_1_onSubJobError(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tDBInput_2_onSubJobError(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tDBInput_3_onSubJobError(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tDBInput_4_onSubJobError(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tDBInput_5_onSubJobError(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void talendJobLog_onSubJobError(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public static class OutsideIndiaStruct implements routines.system.IPersistableRow<OutsideIndiaStruct> {
		final static byte[] commonByteArrayLock_HMS_FunctionalRequirement = new byte[0];
		static byte[] commonByteArray_HMS_FunctionalRequirement = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public int PatientID;

		public int getPatientID() {
			return this.PatientID;
		}

		public Boolean PatientIDIsNullable() {
			return false;
		}

		public Boolean PatientIDIsKey() {
			return true;
		}

		public Integer PatientIDLength() {
			return 10;
		}

		public Integer PatientIDPrecision() {
			return 0;
		}

		public String PatientIDDefault() {

			return null;

		}

		public String PatientIDComment() {

			return "";

		}

		public String PatientIDPattern() {

			return "";

		}

		public String PatientIDOriginalDbColumnName() {

			return "PatientID";

		}

		public String Name;

		public String getName() {
			return this.Name;
		}

		public Boolean NameIsNullable() {
			return true;
		}

		public Boolean NameIsKey() {
			return false;
		}

		public Integer NameLength() {
			return 30;
		}

		public Integer NamePrecision() {
			return 0;
		}

		public String NameDefault() {

			return null;

		}

		public String NameComment() {

			return "";

		}

		public String NamePattern() {

			return "";

		}

		public String NameOriginalDbColumnName() {

			return "Name";

		}

		public java.util.Date DOB;

		public java.util.Date getDOB() {
			return this.DOB;
		}

		public Boolean DOBIsNullable() {
			return true;
		}

		public Boolean DOBIsKey() {
			return false;
		}

		public Integer DOBLength() {
			return 19;
		}

		public Integer DOBPrecision() {
			return 0;
		}

		public String DOBDefault() {

			return null;

		}

		public String DOBComment() {

			return "";

		}

		public String DOBPattern() {

			return "dd-MM-yyyy";

		}

		public String DOBOriginalDbColumnName() {

			return "DOB";

		}

		public String Gender;

		public String getGender() {
			return this.Gender;
		}

		public Boolean GenderIsNullable() {
			return true;
		}

		public Boolean GenderIsKey() {
			return false;
		}

		public Integer GenderLength() {
			return 6;
		}

		public Integer GenderPrecision() {
			return 0;
		}

		public String GenderDefault() {

			return null;

		}

		public String GenderComment() {

			return "";

		}

		public String GenderPattern() {

			return "";

		}

		public String GenderOriginalDbColumnName() {

			return "Gender";

		}

		public String Address;

		public String getAddress() {
			return this.Address;
		}

		public Boolean AddressIsNullable() {
			return true;
		}

		public Boolean AddressIsKey() {
			return false;
		}

		public Integer AddressLength() {
			return 50;
		}

		public Integer AddressPrecision() {
			return 0;
		}

		public String AddressDefault() {

			return null;

		}

		public String AddressComment() {

			return "";

		}

		public String AddressPattern() {

			return "";

		}

		public String AddressOriginalDbColumnName() {

			return "Address";

		}

		public String City;

		public String getCity() {
			return this.City;
		}

		public Boolean CityIsNullable() {
			return true;
		}

		public Boolean CityIsKey() {
			return false;
		}

		public Integer CityLength() {
			return 30;
		}

		public Integer CityPrecision() {
			return 0;
		}

		public String CityDefault() {

			return null;

		}

		public String CityComment() {

			return "";

		}

		public String CityPattern() {

			return "";

		}

		public String CityOriginalDbColumnName() {

			return "City";

		}

		public String Country;

		public String getCountry() {
			return this.Country;
		}

		public Boolean CountryIsNullable() {
			return true;
		}

		public Boolean CountryIsKey() {
			return false;
		}

		public Integer CountryLength() {
			return 30;
		}

		public Integer CountryPrecision() {
			return 0;
		}

		public String CountryDefault() {

			return null;

		}

		public String CountryComment() {

			return "";

		}

		public String CountryPattern() {

			return "";

		}

		public String CountryOriginalDbColumnName() {

			return "Country";

		}

		public String Phone;

		public String getPhone() {
			return this.Phone;
		}

		public Boolean PhoneIsNullable() {
			return true;
		}

		public Boolean PhoneIsKey() {
			return false;
		}

		public Integer PhoneLength() {
			return 15;
		}

		public Integer PhonePrecision() {
			return 0;
		}

		public String PhoneDefault() {

			return null;

		}

		public String PhoneComment() {

			return "";

		}

		public String PhonePattern() {

			return "";

		}

		public String PhoneOriginalDbColumnName() {

			return "Phone";

		}

		public String InsuranceID;

		public String getInsuranceID() {
			return this.InsuranceID;
		}

		public Boolean InsuranceIDIsNullable() {
			return true;
		}

		public Boolean InsuranceIDIsKey() {
			return false;
		}

		public Integer InsuranceIDLength() {
			return 20;
		}

		public Integer InsuranceIDPrecision() {
			return 0;
		}

		public String InsuranceIDDefault() {

			return null;

		}

		public String InsuranceIDComment() {

			return "";

		}

		public String InsuranceIDPattern() {

			return "";

		}

		public String InsuranceIDOriginalDbColumnName() {

			return "InsuranceID";

		}

		public Integer Age;

		public Integer getAge() {
			return this.Age;
		}

		public Boolean AgeIsNullable() {
			return true;
		}

		public Boolean AgeIsKey() {
			return false;
		}

		public Integer AgeLength() {
			return 10;
		}

		public Integer AgePrecision() {
			return 0;
		}

		public String AgeDefault() {

			return null;

		}

		public String AgeComment() {

			return "";

		}

		public String AgePattern() {

			return "";

		}

		public String AgeOriginalDbColumnName() {

			return "Age";

		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + (int) this.PatientID;

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final OutsideIndiaStruct other = (OutsideIndiaStruct) obj;

			if (this.PatientID != other.PatientID)
				return false;

			return true;
		}

		public void copyDataTo(OutsideIndiaStruct other) {

			other.PatientID = this.PatientID;
			other.Name = this.Name;
			other.DOB = this.DOB;
			other.Gender = this.Gender;
			other.Address = this.Address;
			other.City = this.City;
			other.Country = this.Country;
			other.Phone = this.Phone;
			other.InsuranceID = this.InsuranceID;
			other.Age = this.Age;

		}

		public void copyKeysDataTo(OutsideIndiaStruct other) {

			other.PatientID = this.PatientID;

		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_HMS_FunctionalRequirement.length) {
					if (length < 1024 && commonByteArray_HMS_FunctionalRequirement.length == 0) {
						commonByteArray_HMS_FunctionalRequirement = new byte[1024];
					} else {
						commonByteArray_HMS_FunctionalRequirement = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_HMS_FunctionalRequirement, 0, length);
				strReturn = new String(commonByteArray_HMS_FunctionalRequirement, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_HMS_FunctionalRequirement.length) {
					if (length < 1024 && commonByteArray_HMS_FunctionalRequirement.length == 0) {
						commonByteArray_HMS_FunctionalRequirement = new byte[1024];
					} else {
						commonByteArray_HMS_FunctionalRequirement = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_HMS_FunctionalRequirement, 0, length);
				strReturn = new String(commonByteArray_HMS_FunctionalRequirement, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_HMS_FunctionalRequirement) {

				try {

					int length = 0;

					this.PatientID = dis.readInt();

					this.Name = readString(dis);

					this.DOB = readDate(dis);

					this.Gender = readString(dis);

					this.Address = readString(dis);

					this.City = readString(dis);

					this.Country = readString(dis);

					this.Phone = readString(dis);

					this.InsuranceID = readString(dis);

					this.Age = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_HMS_FunctionalRequirement) {

				try {

					int length = 0;

					this.PatientID = dis.readInt();

					this.Name = readString(dis);

					this.DOB = readDate(dis);

					this.Gender = readString(dis);

					this.Address = readString(dis);

					this.City = readString(dis);

					this.Country = readString(dis);

					this.Phone = readString(dis);

					this.InsuranceID = readString(dis);

					this.Age = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// int

				dos.writeInt(this.PatientID);

				// String

				writeString(this.Name, dos);

				// java.util.Date

				writeDate(this.DOB, dos);

				// String

				writeString(this.Gender, dos);

				// String

				writeString(this.Address, dos);

				// String

				writeString(this.City, dos);

				// String

				writeString(this.Country, dos);

				// String

				writeString(this.Phone, dos);

				// String

				writeString(this.InsuranceID, dos);

				// Integer

				writeInteger(this.Age, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// int

				dos.writeInt(this.PatientID);

				// String

				writeString(this.Name, dos);

				// java.util.Date

				writeDate(this.DOB, dos);

				// String

				writeString(this.Gender, dos);

				// String

				writeString(this.Address, dos);

				// String

				writeString(this.City, dos);

				// String

				writeString(this.Country, dos);

				// String

				writeString(this.Phone, dos);

				// String

				writeString(this.InsuranceID, dos);

				// Integer

				writeInteger(this.Age, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("PatientID=" + String.valueOf(PatientID));
			sb.append(",Name=" + Name);
			sb.append(",DOB=" + String.valueOf(DOB));
			sb.append(",Gender=" + Gender);
			sb.append(",Address=" + Address);
			sb.append(",City=" + City);
			sb.append(",Country=" + Country);
			sb.append(",Phone=" + Phone);
			sb.append(",InsuranceID=" + InsuranceID);
			sb.append(",Age=" + String.valueOf(Age));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			sb.append(PatientID);

			sb.append("|");

			if (Name == null) {
				sb.append("<null>");
			} else {
				sb.append(Name);
			}

			sb.append("|");

			if (DOB == null) {
				sb.append("<null>");
			} else {
				sb.append(DOB);
			}

			sb.append("|");

			if (Gender == null) {
				sb.append("<null>");
			} else {
				sb.append(Gender);
			}

			sb.append("|");

			if (Address == null) {
				sb.append("<null>");
			} else {
				sb.append(Address);
			}

			sb.append("|");

			if (City == null) {
				sb.append("<null>");
			} else {
				sb.append(City);
			}

			sb.append("|");

			if (Country == null) {
				sb.append("<null>");
			} else {
				sb.append(Country);
			}

			sb.append("|");

			if (Phone == null) {
				sb.append("<null>");
			} else {
				sb.append(Phone);
			}

			sb.append("|");

			if (InsuranceID == null) {
				sb.append("<null>");
			} else {
				sb.append(InsuranceID);
			}

			sb.append("|");

			if (Age == null) {
				sb.append("<null>");
			} else {
				sb.append(Age);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(OutsideIndiaStruct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.PatientID, other.PatientID);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class Above50Struct implements routines.system.IPersistableRow<Above50Struct> {
		final static byte[] commonByteArrayLock_HMS_FunctionalRequirement = new byte[0];
		static byte[] commonByteArray_HMS_FunctionalRequirement = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public int PatientID;

		public int getPatientID() {
			return this.PatientID;
		}

		public Boolean PatientIDIsNullable() {
			return false;
		}

		public Boolean PatientIDIsKey() {
			return true;
		}

		public Integer PatientIDLength() {
			return 10;
		}

		public Integer PatientIDPrecision() {
			return 0;
		}

		public String PatientIDDefault() {

			return null;

		}

		public String PatientIDComment() {

			return "";

		}

		public String PatientIDPattern() {

			return "";

		}

		public String PatientIDOriginalDbColumnName() {

			return "PatientID";

		}

		public String Name;

		public String getName() {
			return this.Name;
		}

		public Boolean NameIsNullable() {
			return true;
		}

		public Boolean NameIsKey() {
			return false;
		}

		public Integer NameLength() {
			return 30;
		}

		public Integer NamePrecision() {
			return 0;
		}

		public String NameDefault() {

			return null;

		}

		public String NameComment() {

			return "";

		}

		public String NamePattern() {

			return "";

		}

		public String NameOriginalDbColumnName() {

			return "Name";

		}

		public java.util.Date DOB;

		public java.util.Date getDOB() {
			return this.DOB;
		}

		public Boolean DOBIsNullable() {
			return true;
		}

		public Boolean DOBIsKey() {
			return false;
		}

		public Integer DOBLength() {
			return 19;
		}

		public Integer DOBPrecision() {
			return 0;
		}

		public String DOBDefault() {

			return null;

		}

		public String DOBComment() {

			return "";

		}

		public String DOBPattern() {

			return "dd-MM-yyyy";

		}

		public String DOBOriginalDbColumnName() {

			return "DOB";

		}

		public String Gender;

		public String getGender() {
			return this.Gender;
		}

		public Boolean GenderIsNullable() {
			return true;
		}

		public Boolean GenderIsKey() {
			return false;
		}

		public Integer GenderLength() {
			return 6;
		}

		public Integer GenderPrecision() {
			return 0;
		}

		public String GenderDefault() {

			return null;

		}

		public String GenderComment() {

			return "";

		}

		public String GenderPattern() {

			return "";

		}

		public String GenderOriginalDbColumnName() {

			return "Gender";

		}

		public String Address;

		public String getAddress() {
			return this.Address;
		}

		public Boolean AddressIsNullable() {
			return true;
		}

		public Boolean AddressIsKey() {
			return false;
		}

		public Integer AddressLength() {
			return 50;
		}

		public Integer AddressPrecision() {
			return 0;
		}

		public String AddressDefault() {

			return null;

		}

		public String AddressComment() {

			return "";

		}

		public String AddressPattern() {

			return "";

		}

		public String AddressOriginalDbColumnName() {

			return "Address";

		}

		public String City;

		public String getCity() {
			return this.City;
		}

		public Boolean CityIsNullable() {
			return true;
		}

		public Boolean CityIsKey() {
			return false;
		}

		public Integer CityLength() {
			return 30;
		}

		public Integer CityPrecision() {
			return 0;
		}

		public String CityDefault() {

			return null;

		}

		public String CityComment() {

			return "";

		}

		public String CityPattern() {

			return "";

		}

		public String CityOriginalDbColumnName() {

			return "City";

		}

		public String Country;

		public String getCountry() {
			return this.Country;
		}

		public Boolean CountryIsNullable() {
			return true;
		}

		public Boolean CountryIsKey() {
			return false;
		}

		public Integer CountryLength() {
			return 30;
		}

		public Integer CountryPrecision() {
			return 0;
		}

		public String CountryDefault() {

			return null;

		}

		public String CountryComment() {

			return "";

		}

		public String CountryPattern() {

			return "";

		}

		public String CountryOriginalDbColumnName() {

			return "Country";

		}

		public String Phone;

		public String getPhone() {
			return this.Phone;
		}

		public Boolean PhoneIsNullable() {
			return true;
		}

		public Boolean PhoneIsKey() {
			return false;
		}

		public Integer PhoneLength() {
			return 15;
		}

		public Integer PhonePrecision() {
			return 0;
		}

		public String PhoneDefault() {

			return null;

		}

		public String PhoneComment() {

			return "";

		}

		public String PhonePattern() {

			return "";

		}

		public String PhoneOriginalDbColumnName() {

			return "Phone";

		}

		public String InsuranceID;

		public String getInsuranceID() {
			return this.InsuranceID;
		}

		public Boolean InsuranceIDIsNullable() {
			return true;
		}

		public Boolean InsuranceIDIsKey() {
			return false;
		}

		public Integer InsuranceIDLength() {
			return 20;
		}

		public Integer InsuranceIDPrecision() {
			return 0;
		}

		public String InsuranceIDDefault() {

			return null;

		}

		public String InsuranceIDComment() {

			return "";

		}

		public String InsuranceIDPattern() {

			return "";

		}

		public String InsuranceIDOriginalDbColumnName() {

			return "InsuranceID";

		}

		public Integer Age;

		public Integer getAge() {
			return this.Age;
		}

		public Boolean AgeIsNullable() {
			return true;
		}

		public Boolean AgeIsKey() {
			return false;
		}

		public Integer AgeLength() {
			return 10;
		}

		public Integer AgePrecision() {
			return 0;
		}

		public String AgeDefault() {

			return null;

		}

		public String AgeComment() {

			return "";

		}

		public String AgePattern() {

			return "";

		}

		public String AgeOriginalDbColumnName() {

			return "Age";

		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + (int) this.PatientID;

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final Above50Struct other = (Above50Struct) obj;

			if (this.PatientID != other.PatientID)
				return false;

			return true;
		}

		public void copyDataTo(Above50Struct other) {

			other.PatientID = this.PatientID;
			other.Name = this.Name;
			other.DOB = this.DOB;
			other.Gender = this.Gender;
			other.Address = this.Address;
			other.City = this.City;
			other.Country = this.Country;
			other.Phone = this.Phone;
			other.InsuranceID = this.InsuranceID;
			other.Age = this.Age;

		}

		public void copyKeysDataTo(Above50Struct other) {

			other.PatientID = this.PatientID;

		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_HMS_FunctionalRequirement.length) {
					if (length < 1024 && commonByteArray_HMS_FunctionalRequirement.length == 0) {
						commonByteArray_HMS_FunctionalRequirement = new byte[1024];
					} else {
						commonByteArray_HMS_FunctionalRequirement = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_HMS_FunctionalRequirement, 0, length);
				strReturn = new String(commonByteArray_HMS_FunctionalRequirement, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_HMS_FunctionalRequirement.length) {
					if (length < 1024 && commonByteArray_HMS_FunctionalRequirement.length == 0) {
						commonByteArray_HMS_FunctionalRequirement = new byte[1024];
					} else {
						commonByteArray_HMS_FunctionalRequirement = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_HMS_FunctionalRequirement, 0, length);
				strReturn = new String(commonByteArray_HMS_FunctionalRequirement, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_HMS_FunctionalRequirement) {

				try {

					int length = 0;

					this.PatientID = dis.readInt();

					this.Name = readString(dis);

					this.DOB = readDate(dis);

					this.Gender = readString(dis);

					this.Address = readString(dis);

					this.City = readString(dis);

					this.Country = readString(dis);

					this.Phone = readString(dis);

					this.InsuranceID = readString(dis);

					this.Age = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_HMS_FunctionalRequirement) {

				try {

					int length = 0;

					this.PatientID = dis.readInt();

					this.Name = readString(dis);

					this.DOB = readDate(dis);

					this.Gender = readString(dis);

					this.Address = readString(dis);

					this.City = readString(dis);

					this.Country = readString(dis);

					this.Phone = readString(dis);

					this.InsuranceID = readString(dis);

					this.Age = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// int

				dos.writeInt(this.PatientID);

				// String

				writeString(this.Name, dos);

				// java.util.Date

				writeDate(this.DOB, dos);

				// String

				writeString(this.Gender, dos);

				// String

				writeString(this.Address, dos);

				// String

				writeString(this.City, dos);

				// String

				writeString(this.Country, dos);

				// String

				writeString(this.Phone, dos);

				// String

				writeString(this.InsuranceID, dos);

				// Integer

				writeInteger(this.Age, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// int

				dos.writeInt(this.PatientID);

				// String

				writeString(this.Name, dos);

				// java.util.Date

				writeDate(this.DOB, dos);

				// String

				writeString(this.Gender, dos);

				// String

				writeString(this.Address, dos);

				// String

				writeString(this.City, dos);

				// String

				writeString(this.Country, dos);

				// String

				writeString(this.Phone, dos);

				// String

				writeString(this.InsuranceID, dos);

				// Integer

				writeInteger(this.Age, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("PatientID=" + String.valueOf(PatientID));
			sb.append(",Name=" + Name);
			sb.append(",DOB=" + String.valueOf(DOB));
			sb.append(",Gender=" + Gender);
			sb.append(",Address=" + Address);
			sb.append(",City=" + City);
			sb.append(",Country=" + Country);
			sb.append(",Phone=" + Phone);
			sb.append(",InsuranceID=" + InsuranceID);
			sb.append(",Age=" + String.valueOf(Age));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			sb.append(PatientID);

			sb.append("|");

			if (Name == null) {
				sb.append("<null>");
			} else {
				sb.append(Name);
			}

			sb.append("|");

			if (DOB == null) {
				sb.append("<null>");
			} else {
				sb.append(DOB);
			}

			sb.append("|");

			if (Gender == null) {
				sb.append("<null>");
			} else {
				sb.append(Gender);
			}

			sb.append("|");

			if (Address == null) {
				sb.append("<null>");
			} else {
				sb.append(Address);
			}

			sb.append("|");

			if (City == null) {
				sb.append("<null>");
			} else {
				sb.append(City);
			}

			sb.append("|");

			if (Country == null) {
				sb.append("<null>");
			} else {
				sb.append(Country);
			}

			sb.append("|");

			if (Phone == null) {
				sb.append("<null>");
			} else {
				sb.append(Phone);
			}

			sb.append("|");

			if (InsuranceID == null) {
				sb.append("<null>");
			} else {
				sb.append(InsuranceID);
			}

			sb.append("|");

			if (Age == null) {
				sb.append("<null>");
			} else {
				sb.append(Age);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(Above50Struct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.PatientID, other.PatientID);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row1Struct implements routines.system.IPersistableRow<row1Struct> {
		final static byte[] commonByteArrayLock_HMS_FunctionalRequirement = new byte[0];
		static byte[] commonByteArray_HMS_FunctionalRequirement = new byte[0];

		public int PatientID;

		public int getPatientID() {
			return this.PatientID;
		}

		public Boolean PatientIDIsNullable() {
			return false;
		}

		public Boolean PatientIDIsKey() {
			return true;
		}

		public Integer PatientIDLength() {
			return 10;
		}

		public Integer PatientIDPrecision() {
			return 0;
		}

		public String PatientIDDefault() {

			return null;

		}

		public String PatientIDComment() {

			return "";

		}

		public String PatientIDPattern() {

			return "";

		}

		public String PatientIDOriginalDbColumnName() {

			return "PatientID";

		}

		public String Name;

		public String getName() {
			return this.Name;
		}

		public Boolean NameIsNullable() {
			return true;
		}

		public Boolean NameIsKey() {
			return false;
		}

		public Integer NameLength() {
			return 30;
		}

		public Integer NamePrecision() {
			return 0;
		}

		public String NameDefault() {

			return null;

		}

		public String NameComment() {

			return "";

		}

		public String NamePattern() {

			return "";

		}

		public String NameOriginalDbColumnName() {

			return "Name";

		}

		public java.util.Date DOB;

		public java.util.Date getDOB() {
			return this.DOB;
		}

		public Boolean DOBIsNullable() {
			return true;
		}

		public Boolean DOBIsKey() {
			return false;
		}

		public Integer DOBLength() {
			return 19;
		}

		public Integer DOBPrecision() {
			return 0;
		}

		public String DOBDefault() {

			return null;

		}

		public String DOBComment() {

			return "";

		}

		public String DOBPattern() {

			return "dd-MM-yyyy";

		}

		public String DOBOriginalDbColumnName() {

			return "DOB";

		}

		public String Gender;

		public String getGender() {
			return this.Gender;
		}

		public Boolean GenderIsNullable() {
			return true;
		}

		public Boolean GenderIsKey() {
			return false;
		}

		public Integer GenderLength() {
			return 6;
		}

		public Integer GenderPrecision() {
			return 0;
		}

		public String GenderDefault() {

			return null;

		}

		public String GenderComment() {

			return "";

		}

		public String GenderPattern() {

			return "";

		}

		public String GenderOriginalDbColumnName() {

			return "Gender";

		}

		public String Address;

		public String getAddress() {
			return this.Address;
		}

		public Boolean AddressIsNullable() {
			return true;
		}

		public Boolean AddressIsKey() {
			return false;
		}

		public Integer AddressLength() {
			return 50;
		}

		public Integer AddressPrecision() {
			return 0;
		}

		public String AddressDefault() {

			return null;

		}

		public String AddressComment() {

			return "";

		}

		public String AddressPattern() {

			return "";

		}

		public String AddressOriginalDbColumnName() {

			return "Address";

		}

		public String City;

		public String getCity() {
			return this.City;
		}

		public Boolean CityIsNullable() {
			return true;
		}

		public Boolean CityIsKey() {
			return false;
		}

		public Integer CityLength() {
			return 30;
		}

		public Integer CityPrecision() {
			return 0;
		}

		public String CityDefault() {

			return null;

		}

		public String CityComment() {

			return "";

		}

		public String CityPattern() {

			return "";

		}

		public String CityOriginalDbColumnName() {

			return "City";

		}

		public String Country;

		public String getCountry() {
			return this.Country;
		}

		public Boolean CountryIsNullable() {
			return true;
		}

		public Boolean CountryIsKey() {
			return false;
		}

		public Integer CountryLength() {
			return 30;
		}

		public Integer CountryPrecision() {
			return 0;
		}

		public String CountryDefault() {

			return null;

		}

		public String CountryComment() {

			return "";

		}

		public String CountryPattern() {

			return "";

		}

		public String CountryOriginalDbColumnName() {

			return "Country";

		}

		public String Phone;

		public String getPhone() {
			return this.Phone;
		}

		public Boolean PhoneIsNullable() {
			return true;
		}

		public Boolean PhoneIsKey() {
			return false;
		}

		public Integer PhoneLength() {
			return 15;
		}

		public Integer PhonePrecision() {
			return 0;
		}

		public String PhoneDefault() {

			return null;

		}

		public String PhoneComment() {

			return "";

		}

		public String PhonePattern() {

			return "";

		}

		public String PhoneOriginalDbColumnName() {

			return "Phone";

		}

		public String InsuranceID;

		public String getInsuranceID() {
			return this.InsuranceID;
		}

		public Boolean InsuranceIDIsNullable() {
			return true;
		}

		public Boolean InsuranceIDIsKey() {
			return false;
		}

		public Integer InsuranceIDLength() {
			return 20;
		}

		public Integer InsuranceIDPrecision() {
			return 0;
		}

		public String InsuranceIDDefault() {

			return null;

		}

		public String InsuranceIDComment() {

			return "";

		}

		public String InsuranceIDPattern() {

			return "";

		}

		public String InsuranceIDOriginalDbColumnName() {

			return "InsuranceID";

		}

		public Integer Age;

		public Integer getAge() {
			return this.Age;
		}

		public Boolean AgeIsNullable() {
			return true;
		}

		public Boolean AgeIsKey() {
			return false;
		}

		public Integer AgeLength() {
			return 10;
		}

		public Integer AgePrecision() {
			return 0;
		}

		public String AgeDefault() {

			return null;

		}

		public String AgeComment() {

			return "";

		}

		public String AgePattern() {

			return "";

		}

		public String AgeOriginalDbColumnName() {

			return "Age";

		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_HMS_FunctionalRequirement.length) {
					if (length < 1024 && commonByteArray_HMS_FunctionalRequirement.length == 0) {
						commonByteArray_HMS_FunctionalRequirement = new byte[1024];
					} else {
						commonByteArray_HMS_FunctionalRequirement = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_HMS_FunctionalRequirement, 0, length);
				strReturn = new String(commonByteArray_HMS_FunctionalRequirement, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_HMS_FunctionalRequirement.length) {
					if (length < 1024 && commonByteArray_HMS_FunctionalRequirement.length == 0) {
						commonByteArray_HMS_FunctionalRequirement = new byte[1024];
					} else {
						commonByteArray_HMS_FunctionalRequirement = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_HMS_FunctionalRequirement, 0, length);
				strReturn = new String(commonByteArray_HMS_FunctionalRequirement, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_HMS_FunctionalRequirement) {

				try {

					int length = 0;

					this.PatientID = dis.readInt();

					this.Name = readString(dis);

					this.DOB = readDate(dis);

					this.Gender = readString(dis);

					this.Address = readString(dis);

					this.City = readString(dis);

					this.Country = readString(dis);

					this.Phone = readString(dis);

					this.InsuranceID = readString(dis);

					this.Age = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_HMS_FunctionalRequirement) {

				try {

					int length = 0;

					this.PatientID = dis.readInt();

					this.Name = readString(dis);

					this.DOB = readDate(dis);

					this.Gender = readString(dis);

					this.Address = readString(dis);

					this.City = readString(dis);

					this.Country = readString(dis);

					this.Phone = readString(dis);

					this.InsuranceID = readString(dis);

					this.Age = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// int

				dos.writeInt(this.PatientID);

				// String

				writeString(this.Name, dos);

				// java.util.Date

				writeDate(this.DOB, dos);

				// String

				writeString(this.Gender, dos);

				// String

				writeString(this.Address, dos);

				// String

				writeString(this.City, dos);

				// String

				writeString(this.Country, dos);

				// String

				writeString(this.Phone, dos);

				// String

				writeString(this.InsuranceID, dos);

				// Integer

				writeInteger(this.Age, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// int

				dos.writeInt(this.PatientID);

				// String

				writeString(this.Name, dos);

				// java.util.Date

				writeDate(this.DOB, dos);

				// String

				writeString(this.Gender, dos);

				// String

				writeString(this.Address, dos);

				// String

				writeString(this.City, dos);

				// String

				writeString(this.Country, dos);

				// String

				writeString(this.Phone, dos);

				// String

				writeString(this.InsuranceID, dos);

				// Integer

				writeInteger(this.Age, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("PatientID=" + String.valueOf(PatientID));
			sb.append(",Name=" + Name);
			sb.append(",DOB=" + String.valueOf(DOB));
			sb.append(",Gender=" + Gender);
			sb.append(",Address=" + Address);
			sb.append(",City=" + City);
			sb.append(",Country=" + Country);
			sb.append(",Phone=" + Phone);
			sb.append(",InsuranceID=" + InsuranceID);
			sb.append(",Age=" + String.valueOf(Age));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			sb.append(PatientID);

			sb.append("|");

			if (Name == null) {
				sb.append("<null>");
			} else {
				sb.append(Name);
			}

			sb.append("|");

			if (DOB == null) {
				sb.append("<null>");
			} else {
				sb.append(DOB);
			}

			sb.append("|");

			if (Gender == null) {
				sb.append("<null>");
			} else {
				sb.append(Gender);
			}

			sb.append("|");

			if (Address == null) {
				sb.append("<null>");
			} else {
				sb.append(Address);
			}

			sb.append("|");

			if (City == null) {
				sb.append("<null>");
			} else {
				sb.append(City);
			}

			sb.append("|");

			if (Country == null) {
				sb.append("<null>");
			} else {
				sb.append(Country);
			}

			sb.append("|");

			if (Phone == null) {
				sb.append("<null>");
			} else {
				sb.append(Phone);
			}

			sb.append("|");

			if (InsuranceID == null) {
				sb.append("<null>");
			} else {
				sb.append(InsuranceID);
			}

			sb.append("|");

			if (Age == null) {
				sb.append("<null>");
			} else {
				sb.append(Age);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row1Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tDBInput_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tDBInput_1_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tDBInput_1");
		org.slf4j.MDC.put("_subJobPid", "Xx8cyn_" + subJobPidCounter.getAndIncrement());

		String iterateId = "";

		String currentComponent = "";
		String cLabel = null;
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				row1Struct row1 = new row1Struct();
				OutsideIndiaStruct OutsideIndia = new OutsideIndiaStruct();
				Above50Struct Above50 = new Above50Struct();

				/**
				 * [tFileOutputExcel_2 begin ] start
				 */

				ok_Hash.put("tFileOutputExcel_2", false);
				start_Hash.put("tFileOutputExcel_2", System.currentTimeMillis());

				currentComponent = "tFileOutputExcel_2";

				cLabel = "OutsideIndia";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "OutsideIndia");

				int tos_count_tFileOutputExcel_2 = 0;

				if (log.isDebugEnabled())
					log.debug("tFileOutputExcel_2 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tFileOutputExcel_2 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tFileOutputExcel_2 = new StringBuilder();
							log4jParamters_tFileOutputExcel_2.append("Parameters:");
							log4jParamters_tFileOutputExcel_2.append("VERSION_2007" + " = " + "false");
							log4jParamters_tFileOutputExcel_2.append(" | ");
							log4jParamters_tFileOutputExcel_2.append("USESTREAM" + " = " + "false");
							log4jParamters_tFileOutputExcel_2.append(" | ");
							log4jParamters_tFileOutputExcel_2.append(
									"FILENAME" + " = " + "\"C:/Users/2382187/Downloads/FR/paientOutsideIndia.xls\"");
							log4jParamters_tFileOutputExcel_2.append(" | ");
							log4jParamters_tFileOutputExcel_2.append("SHEETNAME" + " = " + "\"Above50\"");
							log4jParamters_tFileOutputExcel_2.append(" | ");
							log4jParamters_tFileOutputExcel_2.append("INCLUDEHEADER" + " = " + "true");
							log4jParamters_tFileOutputExcel_2.append(" | ");
							log4jParamters_tFileOutputExcel_2.append("APPEND_FILE" + " = " + "false");
							log4jParamters_tFileOutputExcel_2.append(" | ");
							log4jParamters_tFileOutputExcel_2.append("FIRST_CELL_Y_ABSOLUTE" + " = " + "false");
							log4jParamters_tFileOutputExcel_2.append(" | ");
							log4jParamters_tFileOutputExcel_2.append("FONT" + " = " + "");
							log4jParamters_tFileOutputExcel_2.append(" | ");
							log4jParamters_tFileOutputExcel_2.append("IS_ALL_AUTO_SZIE" + " = " + "true");
							log4jParamters_tFileOutputExcel_2.append(" | ");
							log4jParamters_tFileOutputExcel_2.append("CREATE" + " = " + "true");
							log4jParamters_tFileOutputExcel_2.append(" | ");
							log4jParamters_tFileOutputExcel_2.append("ADVANCED_SEPARATOR" + " = " + "false");
							log4jParamters_tFileOutputExcel_2.append(" | ");
							log4jParamters_tFileOutputExcel_2.append("ENCODING" + " = " + "\"ISO-8859-15\"");
							log4jParamters_tFileOutputExcel_2.append(" | ");
							log4jParamters_tFileOutputExcel_2.append("DELETE_EMPTYFILE" + " = " + "false");
							log4jParamters_tFileOutputExcel_2.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tFileOutputExcel_2 - " + (log4jParamters_tFileOutputExcel_2));
						}
					}
					new BytesLimit65535_tFileOutputExcel_2().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tFileOutputExcel_2", "OutsideIndia", "tFileOutputExcel");
					talendJobLogProcess(globalMap);
				}

				int columnIndex_tFileOutputExcel_2 = 0;
				boolean headerIsInserted_tFileOutputExcel_2 = false;

				int nb_line_tFileOutputExcel_2 = 0;

				String fileName_tFileOutputExcel_2 = "C:/Users/2382187/Downloads/FR/paientOutsideIndia.xls";
				java.io.File file_tFileOutputExcel_2 = new java.io.File(fileName_tFileOutputExcel_2);
				boolean isFileGenerated_tFileOutputExcel_2 = true;
//create directory only if not exists
				java.io.File parentFile_tFileOutputExcel_2 = file_tFileOutputExcel_2.getParentFile();
				if (parentFile_tFileOutputExcel_2 != null && !parentFile_tFileOutputExcel_2.exists()) {

					log.info("tFileOutputExcel_2 - Creating directory '"
							+ parentFile_tFileOutputExcel_2.getCanonicalPath() + "'.");

					parentFile_tFileOutputExcel_2.mkdirs();

					log.info("tFileOutputExcel_2 - Create directory '"
							+ parentFile_tFileOutputExcel_2.getCanonicalPath() + "' has succeeded.");

				}

				jxl.write.WritableWorkbook writeableWorkbook_tFileOutputExcel_2 = null;
				jxl.write.WritableSheet writableSheet_tFileOutputExcel_2 = null;

				jxl.WorkbookSettings workbookSettings_tFileOutputExcel_2 = new jxl.WorkbookSettings();
				workbookSettings_tFileOutputExcel_2.setEncoding("ISO-8859-15");
				writeableWorkbook_tFileOutputExcel_2 = new jxl.write.biff.WritableWorkbookImpl(
						new java.io.BufferedOutputStream(new java.io.FileOutputStream(fileName_tFileOutputExcel_2)),
						true, workbookSettings_tFileOutputExcel_2);

				writableSheet_tFileOutputExcel_2 = writeableWorkbook_tFileOutputExcel_2.getSheet("Above50");
				if (writableSheet_tFileOutputExcel_2 == null) {
					writableSheet_tFileOutputExcel_2 = writeableWorkbook_tFileOutputExcel_2.createSheet("Above50",
							writeableWorkbook_tFileOutputExcel_2.getNumberOfSheets());
				}

				// modif start
				int startRowNum_tFileOutputExcel_2 = writableSheet_tFileOutputExcel_2.getRows();
				// modif end

				int[] fitWidth_tFileOutputExcel_2 = new int[10];
				for (int i_tFileOutputExcel_2 = 0; i_tFileOutputExcel_2 < 10; i_tFileOutputExcel_2++) {
					int fitCellViewSize_tFileOutputExcel_2 = writableSheet_tFileOutputExcel_2
							.getColumnView(i_tFileOutputExcel_2).getSize();
					fitWidth_tFileOutputExcel_2[i_tFileOutputExcel_2] = fitCellViewSize_tFileOutputExcel_2 / 256;
					if (fitCellViewSize_tFileOutputExcel_2 % 256 != 0) {
						fitWidth_tFileOutputExcel_2[i_tFileOutputExcel_2] += 1;
					}
				}

				final jxl.write.WritableCellFormat cell_format_DOB_tFileOutputExcel_2 = new jxl.write.WritableCellFormat(
						new jxl.write.DateFormat("dd-MM-yyyy"));

				if (startRowNum_tFileOutputExcel_2 == 0) {
					// modif end
					// modif start
					writableSheet_tFileOutputExcel_2
							.addCell(new jxl.write.Label(0, nb_line_tFileOutputExcel_2, "PatientID"));
					// modif end
					fitWidth_tFileOutputExcel_2[0] = fitWidth_tFileOutputExcel_2[0] > 9 ? fitWidth_tFileOutputExcel_2[0]
							: 9;
					// modif start
					writableSheet_tFileOutputExcel_2
							.addCell(new jxl.write.Label(1, nb_line_tFileOutputExcel_2, "Name"));
					// modif end
					fitWidth_tFileOutputExcel_2[1] = fitWidth_tFileOutputExcel_2[1] > 4 ? fitWidth_tFileOutputExcel_2[1]
							: 4;
					// modif start
					writableSheet_tFileOutputExcel_2.addCell(new jxl.write.Label(2, nb_line_tFileOutputExcel_2, "DOB"));
					// modif end
					fitWidth_tFileOutputExcel_2[2] = fitWidth_tFileOutputExcel_2[2] > 3 ? fitWidth_tFileOutputExcel_2[2]
							: 3;
					// modif start
					writableSheet_tFileOutputExcel_2
							.addCell(new jxl.write.Label(3, nb_line_tFileOutputExcel_2, "Gender"));
					// modif end
					fitWidth_tFileOutputExcel_2[3] = fitWidth_tFileOutputExcel_2[3] > 6 ? fitWidth_tFileOutputExcel_2[3]
							: 6;
					// modif start
					writableSheet_tFileOutputExcel_2
							.addCell(new jxl.write.Label(4, nb_line_tFileOutputExcel_2, "Address"));
					// modif end
					fitWidth_tFileOutputExcel_2[4] = fitWidth_tFileOutputExcel_2[4] > 7 ? fitWidth_tFileOutputExcel_2[4]
							: 7;
					// modif start
					writableSheet_tFileOutputExcel_2
							.addCell(new jxl.write.Label(5, nb_line_tFileOutputExcel_2, "City"));
					// modif end
					fitWidth_tFileOutputExcel_2[5] = fitWidth_tFileOutputExcel_2[5] > 4 ? fitWidth_tFileOutputExcel_2[5]
							: 4;
					// modif start
					writableSheet_tFileOutputExcel_2
							.addCell(new jxl.write.Label(6, nb_line_tFileOutputExcel_2, "Country"));
					// modif end
					fitWidth_tFileOutputExcel_2[6] = fitWidth_tFileOutputExcel_2[6] > 7 ? fitWidth_tFileOutputExcel_2[6]
							: 7;
					// modif start
					writableSheet_tFileOutputExcel_2
							.addCell(new jxl.write.Label(7, nb_line_tFileOutputExcel_2, "Phone"));
					// modif end
					fitWidth_tFileOutputExcel_2[7] = fitWidth_tFileOutputExcel_2[7] > 5 ? fitWidth_tFileOutputExcel_2[7]
							: 5;
					// modif start
					writableSheet_tFileOutputExcel_2
							.addCell(new jxl.write.Label(8, nb_line_tFileOutputExcel_2, "InsuranceID"));
					// modif end
					fitWidth_tFileOutputExcel_2[8] = fitWidth_tFileOutputExcel_2[8] > 11
							? fitWidth_tFileOutputExcel_2[8]
							: 11;
					// modif start
					writableSheet_tFileOutputExcel_2.addCell(new jxl.write.Label(9, nb_line_tFileOutputExcel_2, "Age"));
					// modif end
					fitWidth_tFileOutputExcel_2[9] = fitWidth_tFileOutputExcel_2[9] > 3 ? fitWidth_tFileOutputExcel_2[9]
							: 3;
					nb_line_tFileOutputExcel_2++;
					headerIsInserted_tFileOutputExcel_2 = true;
				}

				/**
				 * [tFileOutputExcel_2 begin ] stop
				 */

				/**
				 * [tFileOutputExcel_1 begin ] start
				 */

				ok_Hash.put("tFileOutputExcel_1", false);
				start_Hash.put("tFileOutputExcel_1", System.currentTimeMillis());

				currentComponent = "tFileOutputExcel_1";

				cLabel = "Above50";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "Above50");

				int tos_count_tFileOutputExcel_1 = 0;

				if (log.isDebugEnabled())
					log.debug("tFileOutputExcel_1 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tFileOutputExcel_1 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tFileOutputExcel_1 = new StringBuilder();
							log4jParamters_tFileOutputExcel_1.append("Parameters:");
							log4jParamters_tFileOutputExcel_1.append("VERSION_2007" + " = " + "false");
							log4jParamters_tFileOutputExcel_1.append(" | ");
							log4jParamters_tFileOutputExcel_1.append("USESTREAM" + " = " + "false");
							log4jParamters_tFileOutputExcel_1.append(" | ");
							log4jParamters_tFileOutputExcel_1.append(
									"FILENAME" + " = " + "\"C:/Users/2382187/Downloads/FR/PatientAbove50.xls\"");
							log4jParamters_tFileOutputExcel_1.append(" | ");
							log4jParamters_tFileOutputExcel_1.append("SHEETNAME" + " = " + "\"OutsideInida\"");
							log4jParamters_tFileOutputExcel_1.append(" | ");
							log4jParamters_tFileOutputExcel_1.append("INCLUDEHEADER" + " = " + "true");
							log4jParamters_tFileOutputExcel_1.append(" | ");
							log4jParamters_tFileOutputExcel_1.append("APPEND_FILE" + " = " + "false");
							log4jParamters_tFileOutputExcel_1.append(" | ");
							log4jParamters_tFileOutputExcel_1.append("FIRST_CELL_Y_ABSOLUTE" + " = " + "false");
							log4jParamters_tFileOutputExcel_1.append(" | ");
							log4jParamters_tFileOutputExcel_1.append("FONT" + " = " + "");
							log4jParamters_tFileOutputExcel_1.append(" | ");
							log4jParamters_tFileOutputExcel_1.append("IS_ALL_AUTO_SZIE" + " = " + "true");
							log4jParamters_tFileOutputExcel_1.append(" | ");
							log4jParamters_tFileOutputExcel_1.append("CREATE" + " = " + "true");
							log4jParamters_tFileOutputExcel_1.append(" | ");
							log4jParamters_tFileOutputExcel_1.append("ADVANCED_SEPARATOR" + " = " + "false");
							log4jParamters_tFileOutputExcel_1.append(" | ");
							log4jParamters_tFileOutputExcel_1.append("ENCODING" + " = " + "\"ISO-8859-15\"");
							log4jParamters_tFileOutputExcel_1.append(" | ");
							log4jParamters_tFileOutputExcel_1.append("DELETE_EMPTYFILE" + " = " + "false");
							log4jParamters_tFileOutputExcel_1.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tFileOutputExcel_1 - " + (log4jParamters_tFileOutputExcel_1));
						}
					}
					new BytesLimit65535_tFileOutputExcel_1().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tFileOutputExcel_1", "Above50", "tFileOutputExcel");
					talendJobLogProcess(globalMap);
				}

				int columnIndex_tFileOutputExcel_1 = 0;
				boolean headerIsInserted_tFileOutputExcel_1 = false;

				int nb_line_tFileOutputExcel_1 = 0;

				String fileName_tFileOutputExcel_1 = "C:/Users/2382187/Downloads/FR/PatientAbove50.xls";
				java.io.File file_tFileOutputExcel_1 = new java.io.File(fileName_tFileOutputExcel_1);
				boolean isFileGenerated_tFileOutputExcel_1 = true;
//create directory only if not exists
				java.io.File parentFile_tFileOutputExcel_1 = file_tFileOutputExcel_1.getParentFile();
				if (parentFile_tFileOutputExcel_1 != null && !parentFile_tFileOutputExcel_1.exists()) {

					log.info("tFileOutputExcel_1 - Creating directory '"
							+ parentFile_tFileOutputExcel_1.getCanonicalPath() + "'.");

					parentFile_tFileOutputExcel_1.mkdirs();

					log.info("tFileOutputExcel_1 - Create directory '"
							+ parentFile_tFileOutputExcel_1.getCanonicalPath() + "' has succeeded.");

				}

				jxl.write.WritableWorkbook writeableWorkbook_tFileOutputExcel_1 = null;
				jxl.write.WritableSheet writableSheet_tFileOutputExcel_1 = null;

				jxl.WorkbookSettings workbookSettings_tFileOutputExcel_1 = new jxl.WorkbookSettings();
				workbookSettings_tFileOutputExcel_1.setEncoding("ISO-8859-15");
				writeableWorkbook_tFileOutputExcel_1 = new jxl.write.biff.WritableWorkbookImpl(
						new java.io.BufferedOutputStream(new java.io.FileOutputStream(fileName_tFileOutputExcel_1)),
						true, workbookSettings_tFileOutputExcel_1);

				writableSheet_tFileOutputExcel_1 = writeableWorkbook_tFileOutputExcel_1.getSheet("OutsideInida");
				if (writableSheet_tFileOutputExcel_1 == null) {
					writableSheet_tFileOutputExcel_1 = writeableWorkbook_tFileOutputExcel_1.createSheet("OutsideInida",
							writeableWorkbook_tFileOutputExcel_1.getNumberOfSheets());
				}

				// modif start
				int startRowNum_tFileOutputExcel_1 = writableSheet_tFileOutputExcel_1.getRows();
				// modif end

				int[] fitWidth_tFileOutputExcel_1 = new int[10];
				for (int i_tFileOutputExcel_1 = 0; i_tFileOutputExcel_1 < 10; i_tFileOutputExcel_1++) {
					int fitCellViewSize_tFileOutputExcel_1 = writableSheet_tFileOutputExcel_1
							.getColumnView(i_tFileOutputExcel_1).getSize();
					fitWidth_tFileOutputExcel_1[i_tFileOutputExcel_1] = fitCellViewSize_tFileOutputExcel_1 / 256;
					if (fitCellViewSize_tFileOutputExcel_1 % 256 != 0) {
						fitWidth_tFileOutputExcel_1[i_tFileOutputExcel_1] += 1;
					}
				}

				final jxl.write.WritableCellFormat cell_format_DOB_tFileOutputExcel_1 = new jxl.write.WritableCellFormat(
						new jxl.write.DateFormat("dd-MM-yyyy"));

				if (startRowNum_tFileOutputExcel_1 == 0) {
					// modif end
					// modif start
					writableSheet_tFileOutputExcel_1
							.addCell(new jxl.write.Label(0, nb_line_tFileOutputExcel_1, "PatientID"));
					// modif end
					fitWidth_tFileOutputExcel_1[0] = fitWidth_tFileOutputExcel_1[0] > 9 ? fitWidth_tFileOutputExcel_1[0]
							: 9;
					// modif start
					writableSheet_tFileOutputExcel_1
							.addCell(new jxl.write.Label(1, nb_line_tFileOutputExcel_1, "Name"));
					// modif end
					fitWidth_tFileOutputExcel_1[1] = fitWidth_tFileOutputExcel_1[1] > 4 ? fitWidth_tFileOutputExcel_1[1]
							: 4;
					// modif start
					writableSheet_tFileOutputExcel_1.addCell(new jxl.write.Label(2, nb_line_tFileOutputExcel_1, "DOB"));
					// modif end
					fitWidth_tFileOutputExcel_1[2] = fitWidth_tFileOutputExcel_1[2] > 3 ? fitWidth_tFileOutputExcel_1[2]
							: 3;
					// modif start
					writableSheet_tFileOutputExcel_1
							.addCell(new jxl.write.Label(3, nb_line_tFileOutputExcel_1, "Gender"));
					// modif end
					fitWidth_tFileOutputExcel_1[3] = fitWidth_tFileOutputExcel_1[3] > 6 ? fitWidth_tFileOutputExcel_1[3]
							: 6;
					// modif start
					writableSheet_tFileOutputExcel_1
							.addCell(new jxl.write.Label(4, nb_line_tFileOutputExcel_1, "Address"));
					// modif end
					fitWidth_tFileOutputExcel_1[4] = fitWidth_tFileOutputExcel_1[4] > 7 ? fitWidth_tFileOutputExcel_1[4]
							: 7;
					// modif start
					writableSheet_tFileOutputExcel_1
							.addCell(new jxl.write.Label(5, nb_line_tFileOutputExcel_1, "City"));
					// modif end
					fitWidth_tFileOutputExcel_1[5] = fitWidth_tFileOutputExcel_1[5] > 4 ? fitWidth_tFileOutputExcel_1[5]
							: 4;
					// modif start
					writableSheet_tFileOutputExcel_1
							.addCell(new jxl.write.Label(6, nb_line_tFileOutputExcel_1, "Country"));
					// modif end
					fitWidth_tFileOutputExcel_1[6] = fitWidth_tFileOutputExcel_1[6] > 7 ? fitWidth_tFileOutputExcel_1[6]
							: 7;
					// modif start
					writableSheet_tFileOutputExcel_1
							.addCell(new jxl.write.Label(7, nb_line_tFileOutputExcel_1, "Phone"));
					// modif end
					fitWidth_tFileOutputExcel_1[7] = fitWidth_tFileOutputExcel_1[7] > 5 ? fitWidth_tFileOutputExcel_1[7]
							: 5;
					// modif start
					writableSheet_tFileOutputExcel_1
							.addCell(new jxl.write.Label(8, nb_line_tFileOutputExcel_1, "InsuranceID"));
					// modif end
					fitWidth_tFileOutputExcel_1[8] = fitWidth_tFileOutputExcel_1[8] > 11
							? fitWidth_tFileOutputExcel_1[8]
							: 11;
					// modif start
					writableSheet_tFileOutputExcel_1.addCell(new jxl.write.Label(9, nb_line_tFileOutputExcel_1, "Age"));
					// modif end
					fitWidth_tFileOutputExcel_1[9] = fitWidth_tFileOutputExcel_1[9] > 3 ? fitWidth_tFileOutputExcel_1[9]
							: 3;
					nb_line_tFileOutputExcel_1++;
					headerIsInserted_tFileOutputExcel_1 = true;
				}

				/**
				 * [tFileOutputExcel_1 begin ] stop
				 */

				/**
				 * [tMap_1 begin ] start
				 */

				ok_Hash.put("tMap_1", false);
				start_Hash.put("tMap_1", System.currentTimeMillis());

				currentComponent = "tMap_1";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "row1");

				int tos_count_tMap_1 = 0;

				if (log.isDebugEnabled())
					log.debug("tMap_1 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tMap_1 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tMap_1 = new StringBuilder();
							log4jParamters_tMap_1.append("Parameters:");
							log4jParamters_tMap_1.append("LINK_STYLE" + " = " + "AUTO");
							log4jParamters_tMap_1.append(" | ");
							log4jParamters_tMap_1.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
							log4jParamters_tMap_1.append(" | ");
							log4jParamters_tMap_1.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
							log4jParamters_tMap_1.append(" | ");
							log4jParamters_tMap_1.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "true");
							log4jParamters_tMap_1.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tMap_1 - " + (log4jParamters_tMap_1));
						}
					}
					new BytesLimit65535_tMap_1().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tMap_1", "tMap_1", "tMap");
					talendJobLogProcess(globalMap);
				}

// ###############################
// # Lookup's keys initialization
				int count_row1_tMap_1 = 0;

// ###############################        

// ###############################
// # Vars initialization
				class Var__tMap_1__Struct {
				}
				Var__tMap_1__Struct Var__tMap_1 = new Var__tMap_1__Struct();
// ###############################

// ###############################
// # Outputs initialization
				int count_OutsideIndia_tMap_1 = 0;

				OutsideIndiaStruct OutsideIndia_tmp = new OutsideIndiaStruct();
				int count_Above50_tMap_1 = 0;

				Above50Struct Above50_tmp = new Above50Struct();
// ###############################

				/**
				 * [tMap_1 begin ] stop
				 */

				/**
				 * [tDBInput_1 begin ] start
				 */

				ok_Hash.put("tDBInput_1", false);
				start_Hash.put("tDBInput_1", System.currentTimeMillis());

				currentComponent = "tDBInput_1";

				cLabel = "Patient";

				int tos_count_tDBInput_1 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBInput_1 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tDBInput_1 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tDBInput_1 = new StringBuilder();
							log4jParamters_tDBInput_1.append("Parameters:");
							log4jParamters_tDBInput_1.append("DB_VERSION" + " = " + "MYSQL_8");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("USE_EXISTING_CONNECTION" + " = " + "false");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("HOST" + " = " + "\"localhost\"");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("PORT" + " = " + "\"3306\"");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("DBNAME" + " = " + "\"Warehouse\"");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("USER" + " = " + "\"root\"");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("PASS" + " = " + String.valueOf(
									"enc:routine.encryption.key.v1:DpVjKCPwZWRlHNp/Y7DSQKmdtsrXVE4MgVV97FMwfuo=")
									.substring(0, 4) + "...");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("TABLE" + " = " + "\"patientdim\"");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("QUERYSTORE" + " = " + "\"\"");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("QUERY" + " = "
									+ "\"SELECT    `patientdim`.`PatientID`,    `patientdim`.`Name`,    `patientdim`.`DOB`,    `patientdim`.`Gender`,    `patientdim`.`Address`,    `patientdim`.`City`,    `patientdim`.`Country`,    `patientdim`.`Phone`,    `patientdim`.`InsuranceID`,    `patientdim`.`Age` FROM `patientdim`\"");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("PROPERTIES" + " = "
									+ "\"noDatetimeStringSync=true&enabledTLSProtocols=TLSv1.2,TLSv1.1,TLSv1\"");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("ENABLE_STREAM" + " = " + "false");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("TRIM_ALL_COLUMN" + " = " + "false");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("TRIM_COLUMN" + " = " + "[{TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("PatientID") + "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN="
									+ ("Name") + "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN=" + ("DOB") + "}, {TRIM="
									+ ("false") + ", SCHEMA_COLUMN=" + ("Gender") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("Address") + "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN="
									+ ("City") + "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN=" + ("Country")
									+ "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN=" + ("Phone") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("InsuranceID") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("Age") + "}]");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("UNIFIED_COMPONENTS" + " = " + "tMysqlInput");
							log4jParamters_tDBInput_1.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tDBInput_1 - " + (log4jParamters_tDBInput_1));
						}
					}
					new BytesLimit65535_tDBInput_1().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tDBInput_1", "Patient", "tMysqlInput");
					talendJobLogProcess(globalMap);
				}

				java.util.Calendar calendar_tDBInput_1 = java.util.Calendar.getInstance();
				calendar_tDBInput_1.set(0, 0, 0, 0, 0, 0);
				java.util.Date year0_tDBInput_1 = calendar_tDBInput_1.getTime();
				int nb_line_tDBInput_1 = 0;
				java.sql.Connection conn_tDBInput_1 = null;
				String driverClass_tDBInput_1 = "com.mysql.cj.jdbc.Driver";
				java.lang.Class jdbcclazz_tDBInput_1 = java.lang.Class.forName(driverClass_tDBInput_1);
				String dbUser_tDBInput_1 = "root";

				final String decryptedPassword_tDBInput_1 = routines.system.PasswordEncryptUtil
						.decryptPassword("enc:routine.encryption.key.v1:A+OB7wPHSmFnAI4is9hHtU2fTyuZ31Cwe/MK95FYj1o=");

				String dbPwd_tDBInput_1 = decryptedPassword_tDBInput_1;

				String properties_tDBInput_1 = "noDatetimeStringSync=true&enabledTLSProtocols=TLSv1.2,TLSv1.1,TLSv1";
				if (properties_tDBInput_1 == null || properties_tDBInput_1.trim().length() == 0) {
					properties_tDBInput_1 = "";
				}
				String url_tDBInput_1 = "jdbc:mysql://" + "localhost" + ":" + "3306" + "/" + "Warehouse" + "?"
						+ properties_tDBInput_1;

				log.debug("tDBInput_1 - Driver ClassName: " + driverClass_tDBInput_1 + ".");

				log.debug("tDBInput_1 - Connection attempt to '" + url_tDBInput_1 + "' with the username '"
						+ dbUser_tDBInput_1 + "'.");

				conn_tDBInput_1 = java.sql.DriverManager.getConnection(url_tDBInput_1, dbUser_tDBInput_1,
						dbPwd_tDBInput_1);
				log.debug("tDBInput_1 - Connection to '" + url_tDBInput_1 + "' has succeeded.");

				java.sql.Statement stmt_tDBInput_1 = conn_tDBInput_1.createStatement();

				String dbquery_tDBInput_1 = "SELECT \n  `patientdim`.`PatientID`, \n  `patientdim`.`Name`, \n  `patientdim`.`DOB`, \n  `patientdim`.`Gender`, \n  `patien"
						+ "tdim`.`Address`, \n  `patientdim`.`City`, \n  `patientdim`.`Country`, \n  `patientdim`.`Phone`, \n  `patientdim`.`InsuranceI"
						+ "D`, \n  `patientdim`.`Age`\nFROM `patientdim`";

				log.debug("tDBInput_1 - Executing the query: '" + dbquery_tDBInput_1 + "'.");

				globalMap.put("tDBInput_1_QUERY", dbquery_tDBInput_1);

				java.sql.ResultSet rs_tDBInput_1 = null;

				try {
					rs_tDBInput_1 = stmt_tDBInput_1.executeQuery(dbquery_tDBInput_1);
					java.sql.ResultSetMetaData rsmd_tDBInput_1 = rs_tDBInput_1.getMetaData();
					int colQtyInRs_tDBInput_1 = rsmd_tDBInput_1.getColumnCount();

					String tmpContent_tDBInput_1 = null;

					log.debug("tDBInput_1 - Retrieving records from the database.");

					while (rs_tDBInput_1.next()) {
						nb_line_tDBInput_1++;

						if (colQtyInRs_tDBInput_1 < 1) {
							row1.PatientID = 0;
						} else {

							row1.PatientID = rs_tDBInput_1.getInt(1);
							if (rs_tDBInput_1.wasNull()) {
								throw new RuntimeException("Null value in non-Nullable column");
							}
						}
						if (colQtyInRs_tDBInput_1 < 2) {
							row1.Name = null;
						} else {

							row1.Name = routines.system.JDBCUtil.getString(rs_tDBInput_1, 2, false);
						}
						if (colQtyInRs_tDBInput_1 < 3) {
							row1.DOB = null;
						} else {

							if (rs_tDBInput_1.getString(3) != null) {
								String dateString_tDBInput_1 = rs_tDBInput_1.getString(3);
								if (!("0000-00-00").equals(dateString_tDBInput_1)
										&& !("0000-00-00 00:00:00").equals(dateString_tDBInput_1)) {
									row1.DOB = rs_tDBInput_1.getTimestamp(3);
								} else {
									row1.DOB = (java.util.Date) year0_tDBInput_1.clone();
								}
							} else {
								row1.DOB = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 4) {
							row1.Gender = null;
						} else {

							row1.Gender = routines.system.JDBCUtil.getString(rs_tDBInput_1, 4, false);
						}
						if (colQtyInRs_tDBInput_1 < 5) {
							row1.Address = null;
						} else {

							row1.Address = routines.system.JDBCUtil.getString(rs_tDBInput_1, 5, false);
						}
						if (colQtyInRs_tDBInput_1 < 6) {
							row1.City = null;
						} else {

							row1.City = routines.system.JDBCUtil.getString(rs_tDBInput_1, 6, false);
						}
						if (colQtyInRs_tDBInput_1 < 7) {
							row1.Country = null;
						} else {

							row1.Country = routines.system.JDBCUtil.getString(rs_tDBInput_1, 7, false);
						}
						if (colQtyInRs_tDBInput_1 < 8) {
							row1.Phone = null;
						} else {

							row1.Phone = routines.system.JDBCUtil.getString(rs_tDBInput_1, 8, false);
						}
						if (colQtyInRs_tDBInput_1 < 9) {
							row1.InsuranceID = null;
						} else {

							row1.InsuranceID = routines.system.JDBCUtil.getString(rs_tDBInput_1, 9, false);
						}
						if (colQtyInRs_tDBInput_1 < 10) {
							row1.Age = null;
						} else {

							row1.Age = rs_tDBInput_1.getInt(10);
							if (rs_tDBInput_1.wasNull()) {
								row1.Age = null;
							}
						}

						log.debug("tDBInput_1 - Retrieving the record " + nb_line_tDBInput_1 + ".");

						/**
						 * [tDBInput_1 begin ] stop
						 */

						/**
						 * [tDBInput_1 main ] start
						 */

						currentComponent = "tDBInput_1";

						cLabel = "Patient";

						tos_count_tDBInput_1++;

						/**
						 * [tDBInput_1 main ] stop
						 */

						/**
						 * [tDBInput_1 process_data_begin ] start
						 */

						currentComponent = "tDBInput_1";

						cLabel = "Patient";

						/**
						 * [tDBInput_1 process_data_begin ] stop
						 */

						/**
						 * [tMap_1 main ] start
						 */

						currentComponent = "tMap_1";

						if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

								, "row1", "tDBInput_1", "Patient", "tMysqlInput", "tMap_1", "tMap_1", "tMap"

						)) {
							talendJobLogProcess(globalMap);
						}

						if (log.isTraceEnabled()) {
							log.trace("row1 - " + (row1 == null ? "" : row1.toLogString()));
						}

						boolean hasCasePrimitiveKeyWithNull_tMap_1 = false;

						// ###############################
						// # Input tables (lookups)

						boolean rejectedInnerJoin_tMap_1 = false;
						boolean mainRowRejected_tMap_1 = false;
						// ###############################
						{ // start of Var scope

							// ###############################
							// # Vars tables

							Var__tMap_1__Struct Var = Var__tMap_1;// ###############################
							// ###############################
							// # Output tables

							OutsideIndia = null;
							Above50 = null;

// # Output table : 'OutsideIndia'
// # Filter conditions 
							if (

							row1.Country.equals("India") && row1.InsuranceID != null

							) {
								count_OutsideIndia_tMap_1++;

								OutsideIndia_tmp.PatientID = row1.PatientID;
								OutsideIndia_tmp.Name = row1.Name;
								OutsideIndia_tmp.DOB = row1.DOB;
								OutsideIndia_tmp.Gender = row1.Gender;
								OutsideIndia_tmp.Address = row1.Address;
								OutsideIndia_tmp.City = row1.City;
								OutsideIndia_tmp.Country = row1.Country;
								OutsideIndia_tmp.Phone = row1.Phone;
								OutsideIndia_tmp.InsuranceID = row1.InsuranceID;
								OutsideIndia_tmp.Age = row1.Age;
								OutsideIndia = OutsideIndia_tmp;
								log.debug("tMap_1 - Outputting the record " + count_OutsideIndia_tMap_1
										+ " of the output table 'OutsideIndia'.");

							} // closing filter/reject

// # Output table : 'Above50'
// # Filter conditions 
							if (

							row1.Age > 50

							) {
								count_Above50_tMap_1++;

								Above50_tmp.PatientID = row1.PatientID;
								Above50_tmp.Name = row1.Name;
								Above50_tmp.DOB = row1.DOB;
								Above50_tmp.Gender = row1.Gender;
								Above50_tmp.Address = row1.Address;
								Above50_tmp.City = row1.City;
								Above50_tmp.Country = row1.Country;
								Above50_tmp.Phone = row1.Phone;
								Above50_tmp.InsuranceID = row1.InsuranceID;
								Above50_tmp.Age = row1.Age;
								Above50 = Above50_tmp;
								log.debug("tMap_1 - Outputting the record " + count_Above50_tMap_1
										+ " of the output table 'Above50'.");

							} // closing filter/reject
// ###############################

						} // end of Var scope

						rejectedInnerJoin_tMap_1 = false;

						tos_count_tMap_1++;

						/**
						 * [tMap_1 main ] stop
						 */

						/**
						 * [tMap_1 process_data_begin ] start
						 */

						currentComponent = "tMap_1";

						/**
						 * [tMap_1 process_data_begin ] stop
						 */
// Start of branch "OutsideIndia"
						if (OutsideIndia != null) {

							/**
							 * [tFileOutputExcel_2 main ] start
							 */

							currentComponent = "tFileOutputExcel_2";

							cLabel = "OutsideIndia";

							if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

									, "OutsideIndia", "tMap_1", "tMap_1", "tMap", "tFileOutputExcel_2", "OutsideIndia",
									"tFileOutputExcel"

							)) {
								talendJobLogProcess(globalMap);
							}

							if (log.isTraceEnabled()) {
								log.trace("OutsideIndia - " + (OutsideIndia == null ? "" : OutsideIndia.toLogString()));
							}

//modif start

							columnIndex_tFileOutputExcel_2 = 0;

							jxl.write.WritableCell cell_0_tFileOutputExcel_2 = new jxl.write.Number(
									columnIndex_tFileOutputExcel_2,
									startRowNum_tFileOutputExcel_2 + nb_line_tFileOutputExcel_2,

//modif end
									OutsideIndia.PatientID);
//modif start					
							// If we keep the cell format from the existing cell in sheet

//modif ends							
							writableSheet_tFileOutputExcel_2.addCell(cell_0_tFileOutputExcel_2);
							int currentWith_0_tFileOutputExcel_2 = String
									.valueOf(((jxl.write.Number) cell_0_tFileOutputExcel_2).getValue()).trim().length();
							currentWith_0_tFileOutputExcel_2 = currentWith_0_tFileOutputExcel_2 > 10 ? 10
									: currentWith_0_tFileOutputExcel_2;
							fitWidth_tFileOutputExcel_2[0] = fitWidth_tFileOutputExcel_2[0] > currentWith_0_tFileOutputExcel_2
									? fitWidth_tFileOutputExcel_2[0]
									: currentWith_0_tFileOutputExcel_2 + 2;

							if (OutsideIndia.Name != null) {

//modif start

								columnIndex_tFileOutputExcel_2 = 1;

								jxl.write.WritableCell cell_1_tFileOutputExcel_2 = new jxl.write.Label(
										columnIndex_tFileOutputExcel_2,
										startRowNum_tFileOutputExcel_2 + nb_line_tFileOutputExcel_2,

//modif end
										OutsideIndia.Name);
//modif start					
								// If we keep the cell format from the existing cell in sheet

//modif ends							
								writableSheet_tFileOutputExcel_2.addCell(cell_1_tFileOutputExcel_2);
								int currentWith_1_tFileOutputExcel_2 = cell_1_tFileOutputExcel_2.getContents().trim()
										.length();
								fitWidth_tFileOutputExcel_2[1] = fitWidth_tFileOutputExcel_2[1] > currentWith_1_tFileOutputExcel_2
										? fitWidth_tFileOutputExcel_2[1]
										: currentWith_1_tFileOutputExcel_2 + 2;
							}

							if (OutsideIndia.DOB != null) {

//modif start

								columnIndex_tFileOutputExcel_2 = 2;

								jxl.write.WritableCell cell_2_tFileOutputExcel_2 = new jxl.write.DateTime(
										columnIndex_tFileOutputExcel_2,
										startRowNum_tFileOutputExcel_2 + nb_line_tFileOutputExcel_2,

//modif end
										OutsideIndia.DOB, cell_format_DOB_tFileOutputExcel_2);
//modif start					
								// If we keep the cell format from the existing cell in sheet

//modif ends							
								writableSheet_tFileOutputExcel_2.addCell(cell_2_tFileOutputExcel_2);
								int currentWith_2_tFileOutputExcel_2 = cell_2_tFileOutputExcel_2.getContents().trim()
										.length();
								currentWith_2_tFileOutputExcel_2 = 12;
								fitWidth_tFileOutputExcel_2[2] = fitWidth_tFileOutputExcel_2[2] > currentWith_2_tFileOutputExcel_2
										? fitWidth_tFileOutputExcel_2[2]
										: currentWith_2_tFileOutputExcel_2 + 2;
							}

							if (OutsideIndia.Gender != null) {

//modif start

								columnIndex_tFileOutputExcel_2 = 3;

								jxl.write.WritableCell cell_3_tFileOutputExcel_2 = new jxl.write.Label(
										columnIndex_tFileOutputExcel_2,
										startRowNum_tFileOutputExcel_2 + nb_line_tFileOutputExcel_2,

//modif end
										OutsideIndia.Gender);
//modif start					
								// If we keep the cell format from the existing cell in sheet

//modif ends							
								writableSheet_tFileOutputExcel_2.addCell(cell_3_tFileOutputExcel_2);
								int currentWith_3_tFileOutputExcel_2 = cell_3_tFileOutputExcel_2.getContents().trim()
										.length();
								fitWidth_tFileOutputExcel_2[3] = fitWidth_tFileOutputExcel_2[3] > currentWith_3_tFileOutputExcel_2
										? fitWidth_tFileOutputExcel_2[3]
										: currentWith_3_tFileOutputExcel_2 + 2;
							}

							if (OutsideIndia.Address != null) {

//modif start

								columnIndex_tFileOutputExcel_2 = 4;

								jxl.write.WritableCell cell_4_tFileOutputExcel_2 = new jxl.write.Label(
										columnIndex_tFileOutputExcel_2,
										startRowNum_tFileOutputExcel_2 + nb_line_tFileOutputExcel_2,

//modif end
										OutsideIndia.Address);
//modif start					
								// If we keep the cell format from the existing cell in sheet

//modif ends							
								writableSheet_tFileOutputExcel_2.addCell(cell_4_tFileOutputExcel_2);
								int currentWith_4_tFileOutputExcel_2 = cell_4_tFileOutputExcel_2.getContents().trim()
										.length();
								fitWidth_tFileOutputExcel_2[4] = fitWidth_tFileOutputExcel_2[4] > currentWith_4_tFileOutputExcel_2
										? fitWidth_tFileOutputExcel_2[4]
										: currentWith_4_tFileOutputExcel_2 + 2;
							}

							if (OutsideIndia.City != null) {

//modif start

								columnIndex_tFileOutputExcel_2 = 5;

								jxl.write.WritableCell cell_5_tFileOutputExcel_2 = new jxl.write.Label(
										columnIndex_tFileOutputExcel_2,
										startRowNum_tFileOutputExcel_2 + nb_line_tFileOutputExcel_2,

//modif end
										OutsideIndia.City);
//modif start					
								// If we keep the cell format from the existing cell in sheet

//modif ends							
								writableSheet_tFileOutputExcel_2.addCell(cell_5_tFileOutputExcel_2);
								int currentWith_5_tFileOutputExcel_2 = cell_5_tFileOutputExcel_2.getContents().trim()
										.length();
								fitWidth_tFileOutputExcel_2[5] = fitWidth_tFileOutputExcel_2[5] > currentWith_5_tFileOutputExcel_2
										? fitWidth_tFileOutputExcel_2[5]
										: currentWith_5_tFileOutputExcel_2 + 2;
							}

							if (OutsideIndia.Country != null) {

//modif start

								columnIndex_tFileOutputExcel_2 = 6;

								jxl.write.WritableCell cell_6_tFileOutputExcel_2 = new jxl.write.Label(
										columnIndex_tFileOutputExcel_2,
										startRowNum_tFileOutputExcel_2 + nb_line_tFileOutputExcel_2,

//modif end
										OutsideIndia.Country);
//modif start					
								// If we keep the cell format from the existing cell in sheet

//modif ends							
								writableSheet_tFileOutputExcel_2.addCell(cell_6_tFileOutputExcel_2);
								int currentWith_6_tFileOutputExcel_2 = cell_6_tFileOutputExcel_2.getContents().trim()
										.length();
								fitWidth_tFileOutputExcel_2[6] = fitWidth_tFileOutputExcel_2[6] > currentWith_6_tFileOutputExcel_2
										? fitWidth_tFileOutputExcel_2[6]
										: currentWith_6_tFileOutputExcel_2 + 2;
							}

							if (OutsideIndia.Phone != null) {

//modif start

								columnIndex_tFileOutputExcel_2 = 7;

								jxl.write.WritableCell cell_7_tFileOutputExcel_2 = new jxl.write.Label(
										columnIndex_tFileOutputExcel_2,
										startRowNum_tFileOutputExcel_2 + nb_line_tFileOutputExcel_2,

//modif end
										OutsideIndia.Phone);
//modif start					
								// If we keep the cell format from the existing cell in sheet

//modif ends							
								writableSheet_tFileOutputExcel_2.addCell(cell_7_tFileOutputExcel_2);
								int currentWith_7_tFileOutputExcel_2 = cell_7_tFileOutputExcel_2.getContents().trim()
										.length();
								fitWidth_tFileOutputExcel_2[7] = fitWidth_tFileOutputExcel_2[7] > currentWith_7_tFileOutputExcel_2
										? fitWidth_tFileOutputExcel_2[7]
										: currentWith_7_tFileOutputExcel_2 + 2;
							}

							if (OutsideIndia.InsuranceID != null) {

//modif start

								columnIndex_tFileOutputExcel_2 = 8;

								jxl.write.WritableCell cell_8_tFileOutputExcel_2 = new jxl.write.Label(
										columnIndex_tFileOutputExcel_2,
										startRowNum_tFileOutputExcel_2 + nb_line_tFileOutputExcel_2,

//modif end
										OutsideIndia.InsuranceID);
//modif start					
								// If we keep the cell format from the existing cell in sheet

//modif ends							
								writableSheet_tFileOutputExcel_2.addCell(cell_8_tFileOutputExcel_2);
								int currentWith_8_tFileOutputExcel_2 = cell_8_tFileOutputExcel_2.getContents().trim()
										.length();
								fitWidth_tFileOutputExcel_2[8] = fitWidth_tFileOutputExcel_2[8] > currentWith_8_tFileOutputExcel_2
										? fitWidth_tFileOutputExcel_2[8]
										: currentWith_8_tFileOutputExcel_2 + 2;
							}

							if (OutsideIndia.Age != null) {

//modif start

								columnIndex_tFileOutputExcel_2 = 9;

								jxl.write.WritableCell cell_9_tFileOutputExcel_2 = new jxl.write.Number(
										columnIndex_tFileOutputExcel_2,
										startRowNum_tFileOutputExcel_2 + nb_line_tFileOutputExcel_2,

//modif end
										OutsideIndia.Age);
//modif start					
								// If we keep the cell format from the existing cell in sheet

//modif ends							
								writableSheet_tFileOutputExcel_2.addCell(cell_9_tFileOutputExcel_2);
								int currentWith_9_tFileOutputExcel_2 = String
										.valueOf(((jxl.write.Number) cell_9_tFileOutputExcel_2).getValue()).trim()
										.length();
								currentWith_9_tFileOutputExcel_2 = currentWith_9_tFileOutputExcel_2 > 10 ? 10
										: currentWith_9_tFileOutputExcel_2;
								fitWidth_tFileOutputExcel_2[9] = fitWidth_tFileOutputExcel_2[9] > currentWith_9_tFileOutputExcel_2
										? fitWidth_tFileOutputExcel_2[9]
										: currentWith_9_tFileOutputExcel_2 + 2;
							}

							nb_line_tFileOutputExcel_2++;

							log.debug("tFileOutputExcel_2 - Writing the record " + nb_line_tFileOutputExcel_2
									+ " to the file.");

							tos_count_tFileOutputExcel_2++;

							/**
							 * [tFileOutputExcel_2 main ] stop
							 */

							/**
							 * [tFileOutputExcel_2 process_data_begin ] start
							 */

							currentComponent = "tFileOutputExcel_2";

							cLabel = "OutsideIndia";

							/**
							 * [tFileOutputExcel_2 process_data_begin ] stop
							 */

							/**
							 * [tFileOutputExcel_2 process_data_end ] start
							 */

							currentComponent = "tFileOutputExcel_2";

							cLabel = "OutsideIndia";

							/**
							 * [tFileOutputExcel_2 process_data_end ] stop
							 */

						} // End of branch "OutsideIndia"

// Start of branch "Above50"
						if (Above50 != null) {

							/**
							 * [tFileOutputExcel_1 main ] start
							 */

							currentComponent = "tFileOutputExcel_1";

							cLabel = "Above50";

							if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

									, "Above50", "tMap_1", "tMap_1", "tMap", "tFileOutputExcel_1", "Above50",
									"tFileOutputExcel"

							)) {
								talendJobLogProcess(globalMap);
							}

							if (log.isTraceEnabled()) {
								log.trace("Above50 - " + (Above50 == null ? "" : Above50.toLogString()));
							}

//modif start

							columnIndex_tFileOutputExcel_1 = 0;

							jxl.write.WritableCell cell_0_tFileOutputExcel_1 = new jxl.write.Number(
									columnIndex_tFileOutputExcel_1,
									startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,

//modif end
									Above50.PatientID);
//modif start					
							// If we keep the cell format from the existing cell in sheet

//modif ends							
							writableSheet_tFileOutputExcel_1.addCell(cell_0_tFileOutputExcel_1);
							int currentWith_0_tFileOutputExcel_1 = String
									.valueOf(((jxl.write.Number) cell_0_tFileOutputExcel_1).getValue()).trim().length();
							currentWith_0_tFileOutputExcel_1 = currentWith_0_tFileOutputExcel_1 > 10 ? 10
									: currentWith_0_tFileOutputExcel_1;
							fitWidth_tFileOutputExcel_1[0] = fitWidth_tFileOutputExcel_1[0] > currentWith_0_tFileOutputExcel_1
									? fitWidth_tFileOutputExcel_1[0]
									: currentWith_0_tFileOutputExcel_1 + 2;

							if (Above50.Name != null) {

//modif start

								columnIndex_tFileOutputExcel_1 = 1;

								jxl.write.WritableCell cell_1_tFileOutputExcel_1 = new jxl.write.Label(
										columnIndex_tFileOutputExcel_1,
										startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,

//modif end
										Above50.Name);
//modif start					
								// If we keep the cell format from the existing cell in sheet

//modif ends							
								writableSheet_tFileOutputExcel_1.addCell(cell_1_tFileOutputExcel_1);
								int currentWith_1_tFileOutputExcel_1 = cell_1_tFileOutputExcel_1.getContents().trim()
										.length();
								fitWidth_tFileOutputExcel_1[1] = fitWidth_tFileOutputExcel_1[1] > currentWith_1_tFileOutputExcel_1
										? fitWidth_tFileOutputExcel_1[1]
										: currentWith_1_tFileOutputExcel_1 + 2;
							}

							if (Above50.DOB != null) {

//modif start

								columnIndex_tFileOutputExcel_1 = 2;

								jxl.write.WritableCell cell_2_tFileOutputExcel_1 = new jxl.write.DateTime(
										columnIndex_tFileOutputExcel_1,
										startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,

//modif end
										Above50.DOB, cell_format_DOB_tFileOutputExcel_1);
//modif start					
								// If we keep the cell format from the existing cell in sheet

//modif ends							
								writableSheet_tFileOutputExcel_1.addCell(cell_2_tFileOutputExcel_1);
								int currentWith_2_tFileOutputExcel_1 = cell_2_tFileOutputExcel_1.getContents().trim()
										.length();
								currentWith_2_tFileOutputExcel_1 = 12;
								fitWidth_tFileOutputExcel_1[2] = fitWidth_tFileOutputExcel_1[2] > currentWith_2_tFileOutputExcel_1
										? fitWidth_tFileOutputExcel_1[2]
										: currentWith_2_tFileOutputExcel_1 + 2;
							}

							if (Above50.Gender != null) {

//modif start

								columnIndex_tFileOutputExcel_1 = 3;

								jxl.write.WritableCell cell_3_tFileOutputExcel_1 = new jxl.write.Label(
										columnIndex_tFileOutputExcel_1,
										startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,

//modif end
										Above50.Gender);
//modif start					
								// If we keep the cell format from the existing cell in sheet

//modif ends							
								writableSheet_tFileOutputExcel_1.addCell(cell_3_tFileOutputExcel_1);
								int currentWith_3_tFileOutputExcel_1 = cell_3_tFileOutputExcel_1.getContents().trim()
										.length();
								fitWidth_tFileOutputExcel_1[3] = fitWidth_tFileOutputExcel_1[3] > currentWith_3_tFileOutputExcel_1
										? fitWidth_tFileOutputExcel_1[3]
										: currentWith_3_tFileOutputExcel_1 + 2;
							}

							if (Above50.Address != null) {

//modif start

								columnIndex_tFileOutputExcel_1 = 4;

								jxl.write.WritableCell cell_4_tFileOutputExcel_1 = new jxl.write.Label(
										columnIndex_tFileOutputExcel_1,
										startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,

//modif end
										Above50.Address);
//modif start					
								// If we keep the cell format from the existing cell in sheet

//modif ends							
								writableSheet_tFileOutputExcel_1.addCell(cell_4_tFileOutputExcel_1);
								int currentWith_4_tFileOutputExcel_1 = cell_4_tFileOutputExcel_1.getContents().trim()
										.length();
								fitWidth_tFileOutputExcel_1[4] = fitWidth_tFileOutputExcel_1[4] > currentWith_4_tFileOutputExcel_1
										? fitWidth_tFileOutputExcel_1[4]
										: currentWith_4_tFileOutputExcel_1 + 2;
							}

							if (Above50.City != null) {

//modif start

								columnIndex_tFileOutputExcel_1 = 5;

								jxl.write.WritableCell cell_5_tFileOutputExcel_1 = new jxl.write.Label(
										columnIndex_tFileOutputExcel_1,
										startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,

//modif end
										Above50.City);
//modif start					
								// If we keep the cell format from the existing cell in sheet

//modif ends							
								writableSheet_tFileOutputExcel_1.addCell(cell_5_tFileOutputExcel_1);
								int currentWith_5_tFileOutputExcel_1 = cell_5_tFileOutputExcel_1.getContents().trim()
										.length();
								fitWidth_tFileOutputExcel_1[5] = fitWidth_tFileOutputExcel_1[5] > currentWith_5_tFileOutputExcel_1
										? fitWidth_tFileOutputExcel_1[5]
										: currentWith_5_tFileOutputExcel_1 + 2;
							}

							if (Above50.Country != null) {

//modif start

								columnIndex_tFileOutputExcel_1 = 6;

								jxl.write.WritableCell cell_6_tFileOutputExcel_1 = new jxl.write.Label(
										columnIndex_tFileOutputExcel_1,
										startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,

//modif end
										Above50.Country);
//modif start					
								// If we keep the cell format from the existing cell in sheet

//modif ends							
								writableSheet_tFileOutputExcel_1.addCell(cell_6_tFileOutputExcel_1);
								int currentWith_6_tFileOutputExcel_1 = cell_6_tFileOutputExcel_1.getContents().trim()
										.length();
								fitWidth_tFileOutputExcel_1[6] = fitWidth_tFileOutputExcel_1[6] > currentWith_6_tFileOutputExcel_1
										? fitWidth_tFileOutputExcel_1[6]
										: currentWith_6_tFileOutputExcel_1 + 2;
							}

							if (Above50.Phone != null) {

//modif start

								columnIndex_tFileOutputExcel_1 = 7;

								jxl.write.WritableCell cell_7_tFileOutputExcel_1 = new jxl.write.Label(
										columnIndex_tFileOutputExcel_1,
										startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,

//modif end
										Above50.Phone);
//modif start					
								// If we keep the cell format from the existing cell in sheet

//modif ends							
								writableSheet_tFileOutputExcel_1.addCell(cell_7_tFileOutputExcel_1);
								int currentWith_7_tFileOutputExcel_1 = cell_7_tFileOutputExcel_1.getContents().trim()
										.length();
								fitWidth_tFileOutputExcel_1[7] = fitWidth_tFileOutputExcel_1[7] > currentWith_7_tFileOutputExcel_1
										? fitWidth_tFileOutputExcel_1[7]
										: currentWith_7_tFileOutputExcel_1 + 2;
							}

							if (Above50.InsuranceID != null) {

//modif start

								columnIndex_tFileOutputExcel_1 = 8;

								jxl.write.WritableCell cell_8_tFileOutputExcel_1 = new jxl.write.Label(
										columnIndex_tFileOutputExcel_1,
										startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,

//modif end
										Above50.InsuranceID);
//modif start					
								// If we keep the cell format from the existing cell in sheet

//modif ends							
								writableSheet_tFileOutputExcel_1.addCell(cell_8_tFileOutputExcel_1);
								int currentWith_8_tFileOutputExcel_1 = cell_8_tFileOutputExcel_1.getContents().trim()
										.length();
								fitWidth_tFileOutputExcel_1[8] = fitWidth_tFileOutputExcel_1[8] > currentWith_8_tFileOutputExcel_1
										? fitWidth_tFileOutputExcel_1[8]
										: currentWith_8_tFileOutputExcel_1 + 2;
							}

							if (Above50.Age != null) {

//modif start

								columnIndex_tFileOutputExcel_1 = 9;

								jxl.write.WritableCell cell_9_tFileOutputExcel_1 = new jxl.write.Number(
										columnIndex_tFileOutputExcel_1,
										startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,

//modif end
										Above50.Age);
//modif start					
								// If we keep the cell format from the existing cell in sheet

//modif ends							
								writableSheet_tFileOutputExcel_1.addCell(cell_9_tFileOutputExcel_1);
								int currentWith_9_tFileOutputExcel_1 = String
										.valueOf(((jxl.write.Number) cell_9_tFileOutputExcel_1).getValue()).trim()
										.length();
								currentWith_9_tFileOutputExcel_1 = currentWith_9_tFileOutputExcel_1 > 10 ? 10
										: currentWith_9_tFileOutputExcel_1;
								fitWidth_tFileOutputExcel_1[9] = fitWidth_tFileOutputExcel_1[9] > currentWith_9_tFileOutputExcel_1
										? fitWidth_tFileOutputExcel_1[9]
										: currentWith_9_tFileOutputExcel_1 + 2;
							}

							nb_line_tFileOutputExcel_1++;

							log.debug("tFileOutputExcel_1 - Writing the record " + nb_line_tFileOutputExcel_1
									+ " to the file.");

							tos_count_tFileOutputExcel_1++;

							/**
							 * [tFileOutputExcel_1 main ] stop
							 */

							/**
							 * [tFileOutputExcel_1 process_data_begin ] start
							 */

							currentComponent = "tFileOutputExcel_1";

							cLabel = "Above50";

							/**
							 * [tFileOutputExcel_1 process_data_begin ] stop
							 */

							/**
							 * [tFileOutputExcel_1 process_data_end ] start
							 */

							currentComponent = "tFileOutputExcel_1";

							cLabel = "Above50";

							/**
							 * [tFileOutputExcel_1 process_data_end ] stop
							 */

						} // End of branch "Above50"

						/**
						 * [tMap_1 process_data_end ] start
						 */

						currentComponent = "tMap_1";

						/**
						 * [tMap_1 process_data_end ] stop
						 */

						/**
						 * [tDBInput_1 process_data_end ] start
						 */

						currentComponent = "tDBInput_1";

						cLabel = "Patient";

						/**
						 * [tDBInput_1 process_data_end ] stop
						 */

						/**
						 * [tDBInput_1 end ] start
						 */

						currentComponent = "tDBInput_1";

						cLabel = "Patient";

					}
				} finally {
					if (rs_tDBInput_1 != null) {
						rs_tDBInput_1.close();
					}
					if (stmt_tDBInput_1 != null) {
						stmt_tDBInput_1.close();
					}
					if (conn_tDBInput_1 != null && !conn_tDBInput_1.isClosed()) {

						log.debug("tDBInput_1 - Closing the connection to the database.");

						conn_tDBInput_1.close();

						if ("com.mysql.cj.jdbc.Driver".equals((String) globalMap.get("driverClass_"))
								&& routines.system.BundleUtils.inOSGi()) {
							Class.forName("com.mysql.cj.jdbc.AbandonedConnectionCleanupThread")
									.getMethod("checkedShutdown").invoke(null, (Object[]) null);
						}

						log.debug("tDBInput_1 - Connection to the database closed.");

					}

				}
				globalMap.put("tDBInput_1_NB_LINE", nb_line_tDBInput_1);
				log.debug("tDBInput_1 - Retrieved records count: " + nb_line_tDBInput_1 + " .");

				if (log.isDebugEnabled())
					log.debug("tDBInput_1 - " + ("Done."));

				ok_Hash.put("tDBInput_1", true);
				end_Hash.put("tDBInput_1", System.currentTimeMillis());

				/**
				 * [tDBInput_1 end ] stop
				 */

				/**
				 * [tMap_1 end ] start
				 */

				currentComponent = "tMap_1";

// ###############################
// # Lookup hashes releasing
// ###############################      
				log.debug("tMap_1 - Written records count in the table 'OutsideIndia': " + count_OutsideIndia_tMap_1
						+ ".");
				log.debug("tMap_1 - Written records count in the table 'Above50': " + count_Above50_tMap_1 + ".");

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "row1", 2, 0,
						"tDBInput_1", "Patient", "tMysqlInput", "tMap_1", "tMap_1", "tMap", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tMap_1 - " + ("Done."));

				ok_Hash.put("tMap_1", true);
				end_Hash.put("tMap_1", System.currentTimeMillis());

				/**
				 * [tMap_1 end ] stop
				 */

				/**
				 * [tFileOutputExcel_2 end ] start
				 */

				currentComponent = "tFileOutputExcel_2";

				cLabel = "OutsideIndia";

				columnIndex_tFileOutputExcel_2 = 0;

				// modif start

				writableSheet_tFileOutputExcel_2.setColumnView(columnIndex_tFileOutputExcel_2,
						fitWidth_tFileOutputExcel_2[0]);

				// modif end

				columnIndex_tFileOutputExcel_2 = 1;

				// modif start

				writableSheet_tFileOutputExcel_2.setColumnView(columnIndex_tFileOutputExcel_2,
						fitWidth_tFileOutputExcel_2[1]);

				// modif end

				columnIndex_tFileOutputExcel_2 = 2;

				// modif start

				writableSheet_tFileOutputExcel_2.setColumnView(columnIndex_tFileOutputExcel_2,
						fitWidth_tFileOutputExcel_2[2]);

				// modif end

				columnIndex_tFileOutputExcel_2 = 3;

				// modif start

				writableSheet_tFileOutputExcel_2.setColumnView(columnIndex_tFileOutputExcel_2,
						fitWidth_tFileOutputExcel_2[3]);

				// modif end

				columnIndex_tFileOutputExcel_2 = 4;

				// modif start

				writableSheet_tFileOutputExcel_2.setColumnView(columnIndex_tFileOutputExcel_2,
						fitWidth_tFileOutputExcel_2[4]);

				// modif end

				columnIndex_tFileOutputExcel_2 = 5;

				// modif start

				writableSheet_tFileOutputExcel_2.setColumnView(columnIndex_tFileOutputExcel_2,
						fitWidth_tFileOutputExcel_2[5]);

				// modif end

				columnIndex_tFileOutputExcel_2 = 6;

				// modif start

				writableSheet_tFileOutputExcel_2.setColumnView(columnIndex_tFileOutputExcel_2,
						fitWidth_tFileOutputExcel_2[6]);

				// modif end

				columnIndex_tFileOutputExcel_2 = 7;

				// modif start

				writableSheet_tFileOutputExcel_2.setColumnView(columnIndex_tFileOutputExcel_2,
						fitWidth_tFileOutputExcel_2[7]);

				// modif end

				columnIndex_tFileOutputExcel_2 = 8;

				// modif start

				writableSheet_tFileOutputExcel_2.setColumnView(columnIndex_tFileOutputExcel_2,
						fitWidth_tFileOutputExcel_2[8]);

				// modif end

				columnIndex_tFileOutputExcel_2 = 9;

				// modif start

				writableSheet_tFileOutputExcel_2.setColumnView(columnIndex_tFileOutputExcel_2,
						fitWidth_tFileOutputExcel_2[9]);

				// modif end

				writeableWorkbook_tFileOutputExcel_2.write();
				writeableWorkbook_tFileOutputExcel_2.close();
				if (headerIsInserted_tFileOutputExcel_2 && nb_line_tFileOutputExcel_2 > 0) {
					nb_line_tFileOutputExcel_2 = nb_line_tFileOutputExcel_2 - 1;
				}
				globalMap.put("tFileOutputExcel_2_NB_LINE", nb_line_tFileOutputExcel_2);

				log.debug("tFileOutputExcel_2 - Written records count: " + nb_line_tFileOutputExcel_2 + " .");

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "OutsideIndia", 2, 0,
						"tMap_1", "tMap_1", "tMap", "tFileOutputExcel_2", "OutsideIndia", "tFileOutputExcel",
						"output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tFileOutputExcel_2 - " + ("Done."));

				ok_Hash.put("tFileOutputExcel_2", true);
				end_Hash.put("tFileOutputExcel_2", System.currentTimeMillis());

				/**
				 * [tFileOutputExcel_2 end ] stop
				 */

				/**
				 * [tFileOutputExcel_1 end ] start
				 */

				currentComponent = "tFileOutputExcel_1";

				cLabel = "Above50";

				columnIndex_tFileOutputExcel_1 = 0;

				// modif start

				writableSheet_tFileOutputExcel_1.setColumnView(columnIndex_tFileOutputExcel_1,
						fitWidth_tFileOutputExcel_1[0]);

				// modif end

				columnIndex_tFileOutputExcel_1 = 1;

				// modif start

				writableSheet_tFileOutputExcel_1.setColumnView(columnIndex_tFileOutputExcel_1,
						fitWidth_tFileOutputExcel_1[1]);

				// modif end

				columnIndex_tFileOutputExcel_1 = 2;

				// modif start

				writableSheet_tFileOutputExcel_1.setColumnView(columnIndex_tFileOutputExcel_1,
						fitWidth_tFileOutputExcel_1[2]);

				// modif end

				columnIndex_tFileOutputExcel_1 = 3;

				// modif start

				writableSheet_tFileOutputExcel_1.setColumnView(columnIndex_tFileOutputExcel_1,
						fitWidth_tFileOutputExcel_1[3]);

				// modif end

				columnIndex_tFileOutputExcel_1 = 4;

				// modif start

				writableSheet_tFileOutputExcel_1.setColumnView(columnIndex_tFileOutputExcel_1,
						fitWidth_tFileOutputExcel_1[4]);

				// modif end

				columnIndex_tFileOutputExcel_1 = 5;

				// modif start

				writableSheet_tFileOutputExcel_1.setColumnView(columnIndex_tFileOutputExcel_1,
						fitWidth_tFileOutputExcel_1[5]);

				// modif end

				columnIndex_tFileOutputExcel_1 = 6;

				// modif start

				writableSheet_tFileOutputExcel_1.setColumnView(columnIndex_tFileOutputExcel_1,
						fitWidth_tFileOutputExcel_1[6]);

				// modif end

				columnIndex_tFileOutputExcel_1 = 7;

				// modif start

				writableSheet_tFileOutputExcel_1.setColumnView(columnIndex_tFileOutputExcel_1,
						fitWidth_tFileOutputExcel_1[7]);

				// modif end

				columnIndex_tFileOutputExcel_1 = 8;

				// modif start

				writableSheet_tFileOutputExcel_1.setColumnView(columnIndex_tFileOutputExcel_1,
						fitWidth_tFileOutputExcel_1[8]);

				// modif end

				columnIndex_tFileOutputExcel_1 = 9;

				// modif start

				writableSheet_tFileOutputExcel_1.setColumnView(columnIndex_tFileOutputExcel_1,
						fitWidth_tFileOutputExcel_1[9]);

				// modif end

				writeableWorkbook_tFileOutputExcel_1.write();
				writeableWorkbook_tFileOutputExcel_1.close();
				if (headerIsInserted_tFileOutputExcel_1 && nb_line_tFileOutputExcel_1 > 0) {
					nb_line_tFileOutputExcel_1 = nb_line_tFileOutputExcel_1 - 1;
				}
				globalMap.put("tFileOutputExcel_1_NB_LINE", nb_line_tFileOutputExcel_1);

				log.debug("tFileOutputExcel_1 - Written records count: " + nb_line_tFileOutputExcel_1 + " .");

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "Above50", 2, 0,
						"tMap_1", "tMap_1", "tMap", "tFileOutputExcel_1", "Above50", "tFileOutputExcel", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tFileOutputExcel_1 - " + ("Done."));

				ok_Hash.put("tFileOutputExcel_1", true);
				end_Hash.put("tFileOutputExcel_1", System.currentTimeMillis());

				/**
				 * [tFileOutputExcel_1 end ] stop
				 */

			} // end the resume

			if (resumeEntryMethodName == null || globalResumeTicket) {
				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tDBInput_1:OnSubjobOk", "",
						Thread.currentThread().getId() + "", "", "", "", "", "");
			}

			if (execStat) {
				runStat.updateStatOnConnection("OnSubjobOk1", 0, "ok");
			}

			tDBInput_2Process(globalMap);

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage(), e);
			}

			TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			try {

				/**
				 * [tDBInput_1 finally ] start
				 */

				currentComponent = "tDBInput_1";

				cLabel = "Patient";

				/**
				 * [tDBInput_1 finally ] stop
				 */

				/**
				 * [tMap_1 finally ] start
				 */

				currentComponent = "tMap_1";

				/**
				 * [tMap_1 finally ] stop
				 */

				/**
				 * [tFileOutputExcel_2 finally ] start
				 */

				currentComponent = "tFileOutputExcel_2";

				cLabel = "OutsideIndia";

				/**
				 * [tFileOutputExcel_2 finally ] stop
				 */

				/**
				 * [tFileOutputExcel_1 finally ] start
				 */

				currentComponent = "tFileOutputExcel_1";

				cLabel = "Above50";

				/**
				 * [tFileOutputExcel_1 finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tDBInput_1_SUBPROCESS_STATE", 1);
	}

	public static class row3Struct implements routines.system.IPersistableRow<row3Struct> {
		final static byte[] commonByteArrayLock_HMS_FunctionalRequirement = new byte[0];
		static byte[] commonByteArray_HMS_FunctionalRequirement = new byte[0];

		public int PhysicianID;

		public int getPhysicianID() {
			return this.PhysicianID;
		}

		public Boolean PhysicianIDIsNullable() {
			return false;
		}

		public Boolean PhysicianIDIsKey() {
			return false;
		}

		public Integer PhysicianIDLength() {
			return 10;
		}

		public Integer PhysicianIDPrecision() {
			return 0;
		}

		public String PhysicianIDDefault() {

			return null;

		}

		public String PhysicianIDComment() {

			return "";

		}

		public String PhysicianIDPattern() {

			return "";

		}

		public String PhysicianIDOriginalDbColumnName() {

			return "PhysicianID";

		}

		public String Name;

		public String getName() {
			return this.Name;
		}

		public Boolean NameIsNullable() {
			return true;
		}

		public Boolean NameIsKey() {
			return false;
		}

		public Integer NameLength() {
			return 50;
		}

		public Integer NamePrecision() {
			return 0;
		}

		public String NameDefault() {

			return null;

		}

		public String NameComment() {

			return "";

		}

		public String NamePattern() {

			return "";

		}

		public String NameOriginalDbColumnName() {

			return "Name";

		}

		public java.util.Date DateOfJoining;

		public java.util.Date getDateOfJoining() {
			return this.DateOfJoining;
		}

		public Boolean DateOfJoiningIsNullable() {
			return true;
		}

		public Boolean DateOfJoiningIsKey() {
			return false;
		}

		public Integer DateOfJoiningLength() {
			return 19;
		}

		public Integer DateOfJoiningPrecision() {
			return 0;
		}

		public String DateOfJoiningDefault() {

			return null;

		}

		public String DateOfJoiningComment() {

			return "";

		}

		public String DateOfJoiningPattern() {

			return "dd-MM-yyyy";

		}

		public String DateOfJoiningOriginalDbColumnName() {

			return "DateOfJoining";

		}

		public String Specialty;

		public String getSpecialty() {
			return this.Specialty;
		}

		public Boolean SpecialtyIsNullable() {
			return true;
		}

		public Boolean SpecialtyIsKey() {
			return false;
		}

		public Integer SpecialtyLength() {
			return 60;
		}

		public Integer SpecialtyPrecision() {
			return 0;
		}

		public String SpecialtyDefault() {

			return null;

		}

		public String SpecialtyComment() {

			return "";

		}

		public String SpecialtyPattern() {

			return "";

		}

		public String SpecialtyOriginalDbColumnName() {

			return "Specialty";

		}

		public String Designation;

		public String getDesignation() {
			return this.Designation;
		}

		public Boolean DesignationIsNullable() {
			return true;
		}

		public Boolean DesignationIsKey() {
			return false;
		}

		public Integer DesignationLength() {
			return 50;
		}

		public Integer DesignationPrecision() {
			return 0;
		}

		public String DesignationDefault() {

			return null;

		}

		public String DesignationComment() {

			return "";

		}

		public String DesignationPattern() {

			return "";

		}

		public String DesignationOriginalDbColumnName() {

			return "Designation";

		}

		public Integer Experience;

		public Integer getExperience() {
			return this.Experience;
		}

		public Boolean ExperienceIsNullable() {
			return true;
		}

		public Boolean ExperienceIsKey() {
			return false;
		}

		public Integer ExperienceLength() {
			return 10;
		}

		public Integer ExperiencePrecision() {
			return 0;
		}

		public String ExperienceDefault() {

			return null;

		}

		public String ExperienceComment() {

			return "";

		}

		public String ExperiencePattern() {

			return "";

		}

		public String ExperienceOriginalDbColumnName() {

			return "Experience";

		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_HMS_FunctionalRequirement.length) {
					if (length < 1024 && commonByteArray_HMS_FunctionalRequirement.length == 0) {
						commonByteArray_HMS_FunctionalRequirement = new byte[1024];
					} else {
						commonByteArray_HMS_FunctionalRequirement = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_HMS_FunctionalRequirement, 0, length);
				strReturn = new String(commonByteArray_HMS_FunctionalRequirement, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_HMS_FunctionalRequirement.length) {
					if (length < 1024 && commonByteArray_HMS_FunctionalRequirement.length == 0) {
						commonByteArray_HMS_FunctionalRequirement = new byte[1024];
					} else {
						commonByteArray_HMS_FunctionalRequirement = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_HMS_FunctionalRequirement, 0, length);
				strReturn = new String(commonByteArray_HMS_FunctionalRequirement, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_HMS_FunctionalRequirement) {

				try {

					int length = 0;

					this.PhysicianID = dis.readInt();

					this.Name = readString(dis);

					this.DateOfJoining = readDate(dis);

					this.Specialty = readString(dis);

					this.Designation = readString(dis);

					this.Experience = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_HMS_FunctionalRequirement) {

				try {

					int length = 0;

					this.PhysicianID = dis.readInt();

					this.Name = readString(dis);

					this.DateOfJoining = readDate(dis);

					this.Specialty = readString(dis);

					this.Designation = readString(dis);

					this.Experience = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// int

				dos.writeInt(this.PhysicianID);

				// String

				writeString(this.Name, dos);

				// java.util.Date

				writeDate(this.DateOfJoining, dos);

				// String

				writeString(this.Specialty, dos);

				// String

				writeString(this.Designation, dos);

				// Integer

				writeInteger(this.Experience, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// int

				dos.writeInt(this.PhysicianID);

				// String

				writeString(this.Name, dos);

				// java.util.Date

				writeDate(this.DateOfJoining, dos);

				// String

				writeString(this.Specialty, dos);

				// String

				writeString(this.Designation, dos);

				// Integer

				writeInteger(this.Experience, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("PhysicianID=" + String.valueOf(PhysicianID));
			sb.append(",Name=" + Name);
			sb.append(",DateOfJoining=" + String.valueOf(DateOfJoining));
			sb.append(",Specialty=" + Specialty);
			sb.append(",Designation=" + Designation);
			sb.append(",Experience=" + String.valueOf(Experience));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			sb.append(PhysicianID);

			sb.append("|");

			if (Name == null) {
				sb.append("<null>");
			} else {
				sb.append(Name);
			}

			sb.append("|");

			if (DateOfJoining == null) {
				sb.append("<null>");
			} else {
				sb.append(DateOfJoining);
			}

			sb.append("|");

			if (Specialty == null) {
				sb.append("<null>");
			} else {
				sb.append(Specialty);
			}

			sb.append("|");

			if (Designation == null) {
				sb.append("<null>");
			} else {
				sb.append(Designation);
			}

			sb.append("|");

			if (Experience == null) {
				sb.append("<null>");
			} else {
				sb.append(Experience);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row3Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class OnRowsEndStructtSortRow_1
			implements routines.system.IPersistableRow<OnRowsEndStructtSortRow_1> {
		final static byte[] commonByteArrayLock_HMS_FunctionalRequirement = new byte[0];
		static byte[] commonByteArray_HMS_FunctionalRequirement = new byte[0];

		public int PhysicianID;

		public int getPhysicianID() {
			return this.PhysicianID;
		}

		public Boolean PhysicianIDIsNullable() {
			return false;
		}

		public Boolean PhysicianIDIsKey() {
			return false;
		}

		public Integer PhysicianIDLength() {
			return 10;
		}

		public Integer PhysicianIDPrecision() {
			return 0;
		}

		public String PhysicianIDDefault() {

			return null;

		}

		public String PhysicianIDComment() {

			return "";

		}

		public String PhysicianIDPattern() {

			return "";

		}

		public String PhysicianIDOriginalDbColumnName() {

			return "PhysicianID";

		}

		public String Name;

		public String getName() {
			return this.Name;
		}

		public Boolean NameIsNullable() {
			return true;
		}

		public Boolean NameIsKey() {
			return false;
		}

		public Integer NameLength() {
			return 50;
		}

		public Integer NamePrecision() {
			return 0;
		}

		public String NameDefault() {

			return null;

		}

		public String NameComment() {

			return "";

		}

		public String NamePattern() {

			return "";

		}

		public String NameOriginalDbColumnName() {

			return "Name";

		}

		public java.util.Date DateOfJoining;

		public java.util.Date getDateOfJoining() {
			return this.DateOfJoining;
		}

		public Boolean DateOfJoiningIsNullable() {
			return true;
		}

		public Boolean DateOfJoiningIsKey() {
			return false;
		}

		public Integer DateOfJoiningLength() {
			return 19;
		}

		public Integer DateOfJoiningPrecision() {
			return 0;
		}

		public String DateOfJoiningDefault() {

			return null;

		}

		public String DateOfJoiningComment() {

			return "";

		}

		public String DateOfJoiningPattern() {

			return "dd-MM-yyyy";

		}

		public String DateOfJoiningOriginalDbColumnName() {

			return "DateOfJoining";

		}

		public String Specialty;

		public String getSpecialty() {
			return this.Specialty;
		}

		public Boolean SpecialtyIsNullable() {
			return true;
		}

		public Boolean SpecialtyIsKey() {
			return false;
		}

		public Integer SpecialtyLength() {
			return 60;
		}

		public Integer SpecialtyPrecision() {
			return 0;
		}

		public String SpecialtyDefault() {

			return null;

		}

		public String SpecialtyComment() {

			return "";

		}

		public String SpecialtyPattern() {

			return "";

		}

		public String SpecialtyOriginalDbColumnName() {

			return "Specialty";

		}

		public String Designation;

		public String getDesignation() {
			return this.Designation;
		}

		public Boolean DesignationIsNullable() {
			return true;
		}

		public Boolean DesignationIsKey() {
			return false;
		}

		public Integer DesignationLength() {
			return 50;
		}

		public Integer DesignationPrecision() {
			return 0;
		}

		public String DesignationDefault() {

			return null;

		}

		public String DesignationComment() {

			return "";

		}

		public String DesignationPattern() {

			return "";

		}

		public String DesignationOriginalDbColumnName() {

			return "Designation";

		}

		public Integer Experience;

		public Integer getExperience() {
			return this.Experience;
		}

		public Boolean ExperienceIsNullable() {
			return true;
		}

		public Boolean ExperienceIsKey() {
			return false;
		}

		public Integer ExperienceLength() {
			return 10;
		}

		public Integer ExperiencePrecision() {
			return 0;
		}

		public String ExperienceDefault() {

			return null;

		}

		public String ExperienceComment() {

			return "";

		}

		public String ExperiencePattern() {

			return "";

		}

		public String ExperienceOriginalDbColumnName() {

			return "Experience";

		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_HMS_FunctionalRequirement.length) {
					if (length < 1024 && commonByteArray_HMS_FunctionalRequirement.length == 0) {
						commonByteArray_HMS_FunctionalRequirement = new byte[1024];
					} else {
						commonByteArray_HMS_FunctionalRequirement = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_HMS_FunctionalRequirement, 0, length);
				strReturn = new String(commonByteArray_HMS_FunctionalRequirement, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_HMS_FunctionalRequirement.length) {
					if (length < 1024 && commonByteArray_HMS_FunctionalRequirement.length == 0) {
						commonByteArray_HMS_FunctionalRequirement = new byte[1024];
					} else {
						commonByteArray_HMS_FunctionalRequirement = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_HMS_FunctionalRequirement, 0, length);
				strReturn = new String(commonByteArray_HMS_FunctionalRequirement, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_HMS_FunctionalRequirement) {

				try {

					int length = 0;

					this.PhysicianID = dis.readInt();

					this.Name = readString(dis);

					this.DateOfJoining = readDate(dis);

					this.Specialty = readString(dis);

					this.Designation = readString(dis);

					this.Experience = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_HMS_FunctionalRequirement) {

				try {

					int length = 0;

					this.PhysicianID = dis.readInt();

					this.Name = readString(dis);

					this.DateOfJoining = readDate(dis);

					this.Specialty = readString(dis);

					this.Designation = readString(dis);

					this.Experience = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// int

				dos.writeInt(this.PhysicianID);

				// String

				writeString(this.Name, dos);

				// java.util.Date

				writeDate(this.DateOfJoining, dos);

				// String

				writeString(this.Specialty, dos);

				// String

				writeString(this.Designation, dos);

				// Integer

				writeInteger(this.Experience, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// int

				dos.writeInt(this.PhysicianID);

				// String

				writeString(this.Name, dos);

				// java.util.Date

				writeDate(this.DateOfJoining, dos);

				// String

				writeString(this.Specialty, dos);

				// String

				writeString(this.Designation, dos);

				// Integer

				writeInteger(this.Experience, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("PhysicianID=" + String.valueOf(PhysicianID));
			sb.append(",Name=" + Name);
			sb.append(",DateOfJoining=" + String.valueOf(DateOfJoining));
			sb.append(",Specialty=" + Specialty);
			sb.append(",Designation=" + Designation);
			sb.append(",Experience=" + String.valueOf(Experience));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			sb.append(PhysicianID);

			sb.append("|");

			if (Name == null) {
				sb.append("<null>");
			} else {
				sb.append(Name);
			}

			sb.append("|");

			if (DateOfJoining == null) {
				sb.append("<null>");
			} else {
				sb.append(DateOfJoining);
			}

			sb.append("|");

			if (Specialty == null) {
				sb.append("<null>");
			} else {
				sb.append(Specialty);
			}

			sb.append("|");

			if (Designation == null) {
				sb.append("<null>");
			} else {
				sb.append(Designation);
			}

			sb.append("|");

			if (Experience == null) {
				sb.append("<null>");
			} else {
				sb.append(Experience);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(OnRowsEndStructtSortRow_1 other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class SurgeonDetailsStruct implements routines.system.IPersistableRow<SurgeonDetailsStruct> {
		final static byte[] commonByteArrayLock_HMS_FunctionalRequirement = new byte[0];
		static byte[] commonByteArray_HMS_FunctionalRequirement = new byte[0];

		public int PhysicianID;

		public int getPhysicianID() {
			return this.PhysicianID;
		}

		public Boolean PhysicianIDIsNullable() {
			return false;
		}

		public Boolean PhysicianIDIsKey() {
			return false;
		}

		public Integer PhysicianIDLength() {
			return 10;
		}

		public Integer PhysicianIDPrecision() {
			return 0;
		}

		public String PhysicianIDDefault() {

			return null;

		}

		public String PhysicianIDComment() {

			return "";

		}

		public String PhysicianIDPattern() {

			return "";

		}

		public String PhysicianIDOriginalDbColumnName() {

			return "PhysicianID";

		}

		public String Name;

		public String getName() {
			return this.Name;
		}

		public Boolean NameIsNullable() {
			return true;
		}

		public Boolean NameIsKey() {
			return false;
		}

		public Integer NameLength() {
			return 50;
		}

		public Integer NamePrecision() {
			return 0;
		}

		public String NameDefault() {

			return null;

		}

		public String NameComment() {

			return "";

		}

		public String NamePattern() {

			return "";

		}

		public String NameOriginalDbColumnName() {

			return "Name";

		}

		public java.util.Date DateOfJoining;

		public java.util.Date getDateOfJoining() {
			return this.DateOfJoining;
		}

		public Boolean DateOfJoiningIsNullable() {
			return true;
		}

		public Boolean DateOfJoiningIsKey() {
			return false;
		}

		public Integer DateOfJoiningLength() {
			return 19;
		}

		public Integer DateOfJoiningPrecision() {
			return 0;
		}

		public String DateOfJoiningDefault() {

			return null;

		}

		public String DateOfJoiningComment() {

			return "";

		}

		public String DateOfJoiningPattern() {

			return "dd-MM-yyyy";

		}

		public String DateOfJoiningOriginalDbColumnName() {

			return "DateOfJoining";

		}

		public String Specialty;

		public String getSpecialty() {
			return this.Specialty;
		}

		public Boolean SpecialtyIsNullable() {
			return true;
		}

		public Boolean SpecialtyIsKey() {
			return false;
		}

		public Integer SpecialtyLength() {
			return 60;
		}

		public Integer SpecialtyPrecision() {
			return 0;
		}

		public String SpecialtyDefault() {

			return null;

		}

		public String SpecialtyComment() {

			return "";

		}

		public String SpecialtyPattern() {

			return "";

		}

		public String SpecialtyOriginalDbColumnName() {

			return "Specialty";

		}

		public String Designation;

		public String getDesignation() {
			return this.Designation;
		}

		public Boolean DesignationIsNullable() {
			return true;
		}

		public Boolean DesignationIsKey() {
			return false;
		}

		public Integer DesignationLength() {
			return 50;
		}

		public Integer DesignationPrecision() {
			return 0;
		}

		public String DesignationDefault() {

			return null;

		}

		public String DesignationComment() {

			return "";

		}

		public String DesignationPattern() {

			return "";

		}

		public String DesignationOriginalDbColumnName() {

			return "Designation";

		}

		public Integer Experience;

		public Integer getExperience() {
			return this.Experience;
		}

		public Boolean ExperienceIsNullable() {
			return true;
		}

		public Boolean ExperienceIsKey() {
			return false;
		}

		public Integer ExperienceLength() {
			return 10;
		}

		public Integer ExperiencePrecision() {
			return 0;
		}

		public String ExperienceDefault() {

			return null;

		}

		public String ExperienceComment() {

			return "";

		}

		public String ExperiencePattern() {

			return "";

		}

		public String ExperienceOriginalDbColumnName() {

			return "Experience";

		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_HMS_FunctionalRequirement.length) {
					if (length < 1024 && commonByteArray_HMS_FunctionalRequirement.length == 0) {
						commonByteArray_HMS_FunctionalRequirement = new byte[1024];
					} else {
						commonByteArray_HMS_FunctionalRequirement = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_HMS_FunctionalRequirement, 0, length);
				strReturn = new String(commonByteArray_HMS_FunctionalRequirement, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_HMS_FunctionalRequirement.length) {
					if (length < 1024 && commonByteArray_HMS_FunctionalRequirement.length == 0) {
						commonByteArray_HMS_FunctionalRequirement = new byte[1024];
					} else {
						commonByteArray_HMS_FunctionalRequirement = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_HMS_FunctionalRequirement, 0, length);
				strReturn = new String(commonByteArray_HMS_FunctionalRequirement, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_HMS_FunctionalRequirement) {

				try {

					int length = 0;

					this.PhysicianID = dis.readInt();

					this.Name = readString(dis);

					this.DateOfJoining = readDate(dis);

					this.Specialty = readString(dis);

					this.Designation = readString(dis);

					this.Experience = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_HMS_FunctionalRequirement) {

				try {

					int length = 0;

					this.PhysicianID = dis.readInt();

					this.Name = readString(dis);

					this.DateOfJoining = readDate(dis);

					this.Specialty = readString(dis);

					this.Designation = readString(dis);

					this.Experience = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// int

				dos.writeInt(this.PhysicianID);

				// String

				writeString(this.Name, dos);

				// java.util.Date

				writeDate(this.DateOfJoining, dos);

				// String

				writeString(this.Specialty, dos);

				// String

				writeString(this.Designation, dos);

				// Integer

				writeInteger(this.Experience, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// int

				dos.writeInt(this.PhysicianID);

				// String

				writeString(this.Name, dos);

				// java.util.Date

				writeDate(this.DateOfJoining, dos);

				// String

				writeString(this.Specialty, dos);

				// String

				writeString(this.Designation, dos);

				// Integer

				writeInteger(this.Experience, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("PhysicianID=" + String.valueOf(PhysicianID));
			sb.append(",Name=" + Name);
			sb.append(",DateOfJoining=" + String.valueOf(DateOfJoining));
			sb.append(",Specialty=" + Specialty);
			sb.append(",Designation=" + Designation);
			sb.append(",Experience=" + String.valueOf(Experience));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			sb.append(PhysicianID);

			sb.append("|");

			if (Name == null) {
				sb.append("<null>");
			} else {
				sb.append(Name);
			}

			sb.append("|");

			if (DateOfJoining == null) {
				sb.append("<null>");
			} else {
				sb.append(DateOfJoining);
			}

			sb.append("|");

			if (Specialty == null) {
				sb.append("<null>");
			} else {
				sb.append(Specialty);
			}

			sb.append("|");

			if (Designation == null) {
				sb.append("<null>");
			} else {
				sb.append(Designation);
			}

			sb.append("|");

			if (Experience == null) {
				sb.append("<null>");
			} else {
				sb.append(Experience);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(SurgeonDetailsStruct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class SortDataStruct implements routines.system.IPersistableRow<SortDataStruct> {
		final static byte[] commonByteArrayLock_HMS_FunctionalRequirement = new byte[0];
		static byte[] commonByteArray_HMS_FunctionalRequirement = new byte[0];

		public int PhysicianID;

		public int getPhysicianID() {
			return this.PhysicianID;
		}

		public Boolean PhysicianIDIsNullable() {
			return false;
		}

		public Boolean PhysicianIDIsKey() {
			return false;
		}

		public Integer PhysicianIDLength() {
			return 10;
		}

		public Integer PhysicianIDPrecision() {
			return 0;
		}

		public String PhysicianIDDefault() {

			return null;

		}

		public String PhysicianIDComment() {

			return "";

		}

		public String PhysicianIDPattern() {

			return "";

		}

		public String PhysicianIDOriginalDbColumnName() {

			return "PhysicianID";

		}

		public String Name;

		public String getName() {
			return this.Name;
		}

		public Boolean NameIsNullable() {
			return true;
		}

		public Boolean NameIsKey() {
			return false;
		}

		public Integer NameLength() {
			return 50;
		}

		public Integer NamePrecision() {
			return 0;
		}

		public String NameDefault() {

			return null;

		}

		public String NameComment() {

			return "";

		}

		public String NamePattern() {

			return "";

		}

		public String NameOriginalDbColumnName() {

			return "Name";

		}

		public java.util.Date DateOfJoining;

		public java.util.Date getDateOfJoining() {
			return this.DateOfJoining;
		}

		public Boolean DateOfJoiningIsNullable() {
			return true;
		}

		public Boolean DateOfJoiningIsKey() {
			return false;
		}

		public Integer DateOfJoiningLength() {
			return 19;
		}

		public Integer DateOfJoiningPrecision() {
			return 0;
		}

		public String DateOfJoiningDefault() {

			return null;

		}

		public String DateOfJoiningComment() {

			return "";

		}

		public String DateOfJoiningPattern() {

			return "dd-MM-yyyy";

		}

		public String DateOfJoiningOriginalDbColumnName() {

			return "DateOfJoining";

		}

		public String Specialty;

		public String getSpecialty() {
			return this.Specialty;
		}

		public Boolean SpecialtyIsNullable() {
			return true;
		}

		public Boolean SpecialtyIsKey() {
			return false;
		}

		public Integer SpecialtyLength() {
			return 60;
		}

		public Integer SpecialtyPrecision() {
			return 0;
		}

		public String SpecialtyDefault() {

			return null;

		}

		public String SpecialtyComment() {

			return "";

		}

		public String SpecialtyPattern() {

			return "";

		}

		public String SpecialtyOriginalDbColumnName() {

			return "Specialty";

		}

		public String Designation;

		public String getDesignation() {
			return this.Designation;
		}

		public Boolean DesignationIsNullable() {
			return true;
		}

		public Boolean DesignationIsKey() {
			return false;
		}

		public Integer DesignationLength() {
			return 50;
		}

		public Integer DesignationPrecision() {
			return 0;
		}

		public String DesignationDefault() {

			return null;

		}

		public String DesignationComment() {

			return "";

		}

		public String DesignationPattern() {

			return "";

		}

		public String DesignationOriginalDbColumnName() {

			return "Designation";

		}

		public Integer Experience;

		public Integer getExperience() {
			return this.Experience;
		}

		public Boolean ExperienceIsNullable() {
			return true;
		}

		public Boolean ExperienceIsKey() {
			return false;
		}

		public Integer ExperienceLength() {
			return 10;
		}

		public Integer ExperiencePrecision() {
			return 0;
		}

		public String ExperienceDefault() {

			return null;

		}

		public String ExperienceComment() {

			return "";

		}

		public String ExperiencePattern() {

			return "";

		}

		public String ExperienceOriginalDbColumnName() {

			return "Experience";

		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_HMS_FunctionalRequirement.length) {
					if (length < 1024 && commonByteArray_HMS_FunctionalRequirement.length == 0) {
						commonByteArray_HMS_FunctionalRequirement = new byte[1024];
					} else {
						commonByteArray_HMS_FunctionalRequirement = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_HMS_FunctionalRequirement, 0, length);
				strReturn = new String(commonByteArray_HMS_FunctionalRequirement, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_HMS_FunctionalRequirement.length) {
					if (length < 1024 && commonByteArray_HMS_FunctionalRequirement.length == 0) {
						commonByteArray_HMS_FunctionalRequirement = new byte[1024];
					} else {
						commonByteArray_HMS_FunctionalRequirement = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_HMS_FunctionalRequirement, 0, length);
				strReturn = new String(commonByteArray_HMS_FunctionalRequirement, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_HMS_FunctionalRequirement) {

				try {

					int length = 0;

					this.PhysicianID = dis.readInt();

					this.Name = readString(dis);

					this.DateOfJoining = readDate(dis);

					this.Specialty = readString(dis);

					this.Designation = readString(dis);

					this.Experience = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_HMS_FunctionalRequirement) {

				try {

					int length = 0;

					this.PhysicianID = dis.readInt();

					this.Name = readString(dis);

					this.DateOfJoining = readDate(dis);

					this.Specialty = readString(dis);

					this.Designation = readString(dis);

					this.Experience = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// int

				dos.writeInt(this.PhysicianID);

				// String

				writeString(this.Name, dos);

				// java.util.Date

				writeDate(this.DateOfJoining, dos);

				// String

				writeString(this.Specialty, dos);

				// String

				writeString(this.Designation, dos);

				// Integer

				writeInteger(this.Experience, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// int

				dos.writeInt(this.PhysicianID);

				// String

				writeString(this.Name, dos);

				// java.util.Date

				writeDate(this.DateOfJoining, dos);

				// String

				writeString(this.Specialty, dos);

				// String

				writeString(this.Designation, dos);

				// Integer

				writeInteger(this.Experience, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("PhysicianID=" + String.valueOf(PhysicianID));
			sb.append(",Name=" + Name);
			sb.append(",DateOfJoining=" + String.valueOf(DateOfJoining));
			sb.append(",Specialty=" + Specialty);
			sb.append(",Designation=" + Designation);
			sb.append(",Experience=" + String.valueOf(Experience));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			sb.append(PhysicianID);

			sb.append("|");

			if (Name == null) {
				sb.append("<null>");
			} else {
				sb.append(Name);
			}

			sb.append("|");

			if (DateOfJoining == null) {
				sb.append("<null>");
			} else {
				sb.append(DateOfJoining);
			}

			sb.append("|");

			if (Specialty == null) {
				sb.append("<null>");
			} else {
				sb.append(Specialty);
			}

			sb.append("|");

			if (Designation == null) {
				sb.append("<null>");
			} else {
				sb.append(Designation);
			}

			sb.append("|");

			if (Experience == null) {
				sb.append("<null>");
			} else {
				sb.append(Experience);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(SortDataStruct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class HODStruct implements routines.system.IPersistableRow<HODStruct> {
		final static byte[] commonByteArrayLock_HMS_FunctionalRequirement = new byte[0];
		static byte[] commonByteArray_HMS_FunctionalRequirement = new byte[0];

		public int PhysicianID;

		public int getPhysicianID() {
			return this.PhysicianID;
		}

		public Boolean PhysicianIDIsNullable() {
			return false;
		}

		public Boolean PhysicianIDIsKey() {
			return false;
		}

		public Integer PhysicianIDLength() {
			return 10;
		}

		public Integer PhysicianIDPrecision() {
			return 0;
		}

		public String PhysicianIDDefault() {

			return null;

		}

		public String PhysicianIDComment() {

			return "";

		}

		public String PhysicianIDPattern() {

			return "";

		}

		public String PhysicianIDOriginalDbColumnName() {

			return "PhysicianID";

		}

		public String Name;

		public String getName() {
			return this.Name;
		}

		public Boolean NameIsNullable() {
			return true;
		}

		public Boolean NameIsKey() {
			return false;
		}

		public Integer NameLength() {
			return 50;
		}

		public Integer NamePrecision() {
			return 0;
		}

		public String NameDefault() {

			return null;

		}

		public String NameComment() {

			return "";

		}

		public String NamePattern() {

			return "";

		}

		public String NameOriginalDbColumnName() {

			return "Name";

		}

		public java.util.Date DateOfJoining;

		public java.util.Date getDateOfJoining() {
			return this.DateOfJoining;
		}

		public Boolean DateOfJoiningIsNullable() {
			return true;
		}

		public Boolean DateOfJoiningIsKey() {
			return false;
		}

		public Integer DateOfJoiningLength() {
			return 19;
		}

		public Integer DateOfJoiningPrecision() {
			return 0;
		}

		public String DateOfJoiningDefault() {

			return null;

		}

		public String DateOfJoiningComment() {

			return "";

		}

		public String DateOfJoiningPattern() {

			return "dd-MM-yyyy";

		}

		public String DateOfJoiningOriginalDbColumnName() {

			return "DateOfJoining";

		}

		public String Specialty;

		public String getSpecialty() {
			return this.Specialty;
		}

		public Boolean SpecialtyIsNullable() {
			return true;
		}

		public Boolean SpecialtyIsKey() {
			return false;
		}

		public Integer SpecialtyLength() {
			return 60;
		}

		public Integer SpecialtyPrecision() {
			return 0;
		}

		public String SpecialtyDefault() {

			return null;

		}

		public String SpecialtyComment() {

			return "";

		}

		public String SpecialtyPattern() {

			return "";

		}

		public String SpecialtyOriginalDbColumnName() {

			return "Specialty";

		}

		public String Designation;

		public String getDesignation() {
			return this.Designation;
		}

		public Boolean DesignationIsNullable() {
			return true;
		}

		public Boolean DesignationIsKey() {
			return false;
		}

		public Integer DesignationLength() {
			return 50;
		}

		public Integer DesignationPrecision() {
			return 0;
		}

		public String DesignationDefault() {

			return null;

		}

		public String DesignationComment() {

			return "";

		}

		public String DesignationPattern() {

			return "";

		}

		public String DesignationOriginalDbColumnName() {

			return "Designation";

		}

		public Integer Experience;

		public Integer getExperience() {
			return this.Experience;
		}

		public Boolean ExperienceIsNullable() {
			return true;
		}

		public Boolean ExperienceIsKey() {
			return false;
		}

		public Integer ExperienceLength() {
			return 10;
		}

		public Integer ExperiencePrecision() {
			return 0;
		}

		public String ExperienceDefault() {

			return null;

		}

		public String ExperienceComment() {

			return "";

		}

		public String ExperiencePattern() {

			return "";

		}

		public String ExperienceOriginalDbColumnName() {

			return "Experience";

		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_HMS_FunctionalRequirement.length) {
					if (length < 1024 && commonByteArray_HMS_FunctionalRequirement.length == 0) {
						commonByteArray_HMS_FunctionalRequirement = new byte[1024];
					} else {
						commonByteArray_HMS_FunctionalRequirement = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_HMS_FunctionalRequirement, 0, length);
				strReturn = new String(commonByteArray_HMS_FunctionalRequirement, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_HMS_FunctionalRequirement.length) {
					if (length < 1024 && commonByteArray_HMS_FunctionalRequirement.length == 0) {
						commonByteArray_HMS_FunctionalRequirement = new byte[1024];
					} else {
						commonByteArray_HMS_FunctionalRequirement = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_HMS_FunctionalRequirement, 0, length);
				strReturn = new String(commonByteArray_HMS_FunctionalRequirement, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_HMS_FunctionalRequirement) {

				try {

					int length = 0;

					this.PhysicianID = dis.readInt();

					this.Name = readString(dis);

					this.DateOfJoining = readDate(dis);

					this.Specialty = readString(dis);

					this.Designation = readString(dis);

					this.Experience = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_HMS_FunctionalRequirement) {

				try {

					int length = 0;

					this.PhysicianID = dis.readInt();

					this.Name = readString(dis);

					this.DateOfJoining = readDate(dis);

					this.Specialty = readString(dis);

					this.Designation = readString(dis);

					this.Experience = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// int

				dos.writeInt(this.PhysicianID);

				// String

				writeString(this.Name, dos);

				// java.util.Date

				writeDate(this.DateOfJoining, dos);

				// String

				writeString(this.Specialty, dos);

				// String

				writeString(this.Designation, dos);

				// Integer

				writeInteger(this.Experience, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// int

				dos.writeInt(this.PhysicianID);

				// String

				writeString(this.Name, dos);

				// java.util.Date

				writeDate(this.DateOfJoining, dos);

				// String

				writeString(this.Specialty, dos);

				// String

				writeString(this.Designation, dos);

				// Integer

				writeInteger(this.Experience, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("PhysicianID=" + String.valueOf(PhysicianID));
			sb.append(",Name=" + Name);
			sb.append(",DateOfJoining=" + String.valueOf(DateOfJoining));
			sb.append(",Specialty=" + Specialty);
			sb.append(",Designation=" + Designation);
			sb.append(",Experience=" + String.valueOf(Experience));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			sb.append(PhysicianID);

			sb.append("|");

			if (Name == null) {
				sb.append("<null>");
			} else {
				sb.append(Name);
			}

			sb.append("|");

			if (DateOfJoining == null) {
				sb.append("<null>");
			} else {
				sb.append(DateOfJoining);
			}

			sb.append("|");

			if (Specialty == null) {
				sb.append("<null>");
			} else {
				sb.append(Specialty);
			}

			sb.append("|");

			if (Designation == null) {
				sb.append("<null>");
			} else {
				sb.append(Designation);
			}

			sb.append("|");

			if (Experience == null) {
				sb.append("<null>");
			} else {
				sb.append(Experience);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(HODStruct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row2Struct implements routines.system.IPersistableRow<row2Struct> {
		final static byte[] commonByteArrayLock_HMS_FunctionalRequirement = new byte[0];
		static byte[] commonByteArray_HMS_FunctionalRequirement = new byte[0];

		public int PhysicianID;

		public int getPhysicianID() {
			return this.PhysicianID;
		}

		public Boolean PhysicianIDIsNullable() {
			return false;
		}

		public Boolean PhysicianIDIsKey() {
			return false;
		}

		public Integer PhysicianIDLength() {
			return 10;
		}

		public Integer PhysicianIDPrecision() {
			return 0;
		}

		public String PhysicianIDDefault() {

			return null;

		}

		public String PhysicianIDComment() {

			return "";

		}

		public String PhysicianIDPattern() {

			return "";

		}

		public String PhysicianIDOriginalDbColumnName() {

			return "PhysicianID";

		}

		public String Name;

		public String getName() {
			return this.Name;
		}

		public Boolean NameIsNullable() {
			return true;
		}

		public Boolean NameIsKey() {
			return false;
		}

		public Integer NameLength() {
			return 50;
		}

		public Integer NamePrecision() {
			return 0;
		}

		public String NameDefault() {

			return null;

		}

		public String NameComment() {

			return "";

		}

		public String NamePattern() {

			return "";

		}

		public String NameOriginalDbColumnName() {

			return "Name";

		}

		public java.util.Date DateOfJoining;

		public java.util.Date getDateOfJoining() {
			return this.DateOfJoining;
		}

		public Boolean DateOfJoiningIsNullable() {
			return true;
		}

		public Boolean DateOfJoiningIsKey() {
			return false;
		}

		public Integer DateOfJoiningLength() {
			return 19;
		}

		public Integer DateOfJoiningPrecision() {
			return 0;
		}

		public String DateOfJoiningDefault() {

			return null;

		}

		public String DateOfJoiningComment() {

			return "";

		}

		public String DateOfJoiningPattern() {

			return "dd-MM-yyyy";

		}

		public String DateOfJoiningOriginalDbColumnName() {

			return "DateOfJoining";

		}

		public String Specialty;

		public String getSpecialty() {
			return this.Specialty;
		}

		public Boolean SpecialtyIsNullable() {
			return true;
		}

		public Boolean SpecialtyIsKey() {
			return false;
		}

		public Integer SpecialtyLength() {
			return 60;
		}

		public Integer SpecialtyPrecision() {
			return 0;
		}

		public String SpecialtyDefault() {

			return null;

		}

		public String SpecialtyComment() {

			return "";

		}

		public String SpecialtyPattern() {

			return "";

		}

		public String SpecialtyOriginalDbColumnName() {

			return "Specialty";

		}

		public String Designation;

		public String getDesignation() {
			return this.Designation;
		}

		public Boolean DesignationIsNullable() {
			return true;
		}

		public Boolean DesignationIsKey() {
			return false;
		}

		public Integer DesignationLength() {
			return 50;
		}

		public Integer DesignationPrecision() {
			return 0;
		}

		public String DesignationDefault() {

			return null;

		}

		public String DesignationComment() {

			return "";

		}

		public String DesignationPattern() {

			return "";

		}

		public String DesignationOriginalDbColumnName() {

			return "Designation";

		}

		public Integer Experience;

		public Integer getExperience() {
			return this.Experience;
		}

		public Boolean ExperienceIsNullable() {
			return true;
		}

		public Boolean ExperienceIsKey() {
			return false;
		}

		public Integer ExperienceLength() {
			return 10;
		}

		public Integer ExperiencePrecision() {
			return 0;
		}

		public String ExperienceDefault() {

			return null;

		}

		public String ExperienceComment() {

			return "";

		}

		public String ExperiencePattern() {

			return "";

		}

		public String ExperienceOriginalDbColumnName() {

			return "Experience";

		}

		public int PhysicianSK;

		public int getPhysicianSK() {
			return this.PhysicianSK;
		}

		public Boolean PhysicianSKIsNullable() {
			return false;
		}

		public Boolean PhysicianSKIsKey() {
			return true;
		}

		public Integer PhysicianSKLength() {
			return 10;
		}

		public Integer PhysicianSKPrecision() {
			return 0;
		}

		public String PhysicianSKDefault() {

			return null;

		}

		public String PhysicianSKComment() {

			return "";

		}

		public String PhysicianSKPattern() {

			return "";

		}

		public String PhysicianSKOriginalDbColumnName() {

			return "PhysicianSK";

		}

		public java.util.Date StartDate;

		public java.util.Date getStartDate() {
			return this.StartDate;
		}

		public Boolean StartDateIsNullable() {
			return false;
		}

		public Boolean StartDateIsKey() {
			return false;
		}

		public Integer StartDateLength() {
			return 19;
		}

		public Integer StartDatePrecision() {
			return 0;
		}

		public String StartDateDefault() {

			return null;

		}

		public String StartDateComment() {

			return "";

		}

		public String StartDatePattern() {

			return "dd-MM-yyyy";

		}

		public String StartDateOriginalDbColumnName() {

			return "StartDate";

		}

		public java.util.Date EndDate;

		public java.util.Date getEndDate() {
			return this.EndDate;
		}

		public Boolean EndDateIsNullable() {
			return true;
		}

		public Boolean EndDateIsKey() {
			return false;
		}

		public Integer EndDateLength() {
			return 19;
		}

		public Integer EndDatePrecision() {
			return 0;
		}

		public String EndDateDefault() {

			return null;

		}

		public String EndDateComment() {

			return "";

		}

		public String EndDatePattern() {

			return "dd-MM-yyyy";

		}

		public String EndDateOriginalDbColumnName() {

			return "EndDate";

		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_HMS_FunctionalRequirement.length) {
					if (length < 1024 && commonByteArray_HMS_FunctionalRequirement.length == 0) {
						commonByteArray_HMS_FunctionalRequirement = new byte[1024];
					} else {
						commonByteArray_HMS_FunctionalRequirement = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_HMS_FunctionalRequirement, 0, length);
				strReturn = new String(commonByteArray_HMS_FunctionalRequirement, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_HMS_FunctionalRequirement.length) {
					if (length < 1024 && commonByteArray_HMS_FunctionalRequirement.length == 0) {
						commonByteArray_HMS_FunctionalRequirement = new byte[1024];
					} else {
						commonByteArray_HMS_FunctionalRequirement = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_HMS_FunctionalRequirement, 0, length);
				strReturn = new String(commonByteArray_HMS_FunctionalRequirement, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_HMS_FunctionalRequirement) {

				try {

					int length = 0;

					this.PhysicianID = dis.readInt();

					this.Name = readString(dis);

					this.DateOfJoining = readDate(dis);

					this.Specialty = readString(dis);

					this.Designation = readString(dis);

					this.Experience = readInteger(dis);

					this.PhysicianSK = dis.readInt();

					this.StartDate = readDate(dis);

					this.EndDate = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_HMS_FunctionalRequirement) {

				try {

					int length = 0;

					this.PhysicianID = dis.readInt();

					this.Name = readString(dis);

					this.DateOfJoining = readDate(dis);

					this.Specialty = readString(dis);

					this.Designation = readString(dis);

					this.Experience = readInteger(dis);

					this.PhysicianSK = dis.readInt();

					this.StartDate = readDate(dis);

					this.EndDate = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// int

				dos.writeInt(this.PhysicianID);

				// String

				writeString(this.Name, dos);

				// java.util.Date

				writeDate(this.DateOfJoining, dos);

				// String

				writeString(this.Specialty, dos);

				// String

				writeString(this.Designation, dos);

				// Integer

				writeInteger(this.Experience, dos);

				// int

				dos.writeInt(this.PhysicianSK);

				// java.util.Date

				writeDate(this.StartDate, dos);

				// java.util.Date

				writeDate(this.EndDate, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// int

				dos.writeInt(this.PhysicianID);

				// String

				writeString(this.Name, dos);

				// java.util.Date

				writeDate(this.DateOfJoining, dos);

				// String

				writeString(this.Specialty, dos);

				// String

				writeString(this.Designation, dos);

				// Integer

				writeInteger(this.Experience, dos);

				// int

				dos.writeInt(this.PhysicianSK);

				// java.util.Date

				writeDate(this.StartDate, dos);

				// java.util.Date

				writeDate(this.EndDate, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("PhysicianID=" + String.valueOf(PhysicianID));
			sb.append(",Name=" + Name);
			sb.append(",DateOfJoining=" + String.valueOf(DateOfJoining));
			sb.append(",Specialty=" + Specialty);
			sb.append(",Designation=" + Designation);
			sb.append(",Experience=" + String.valueOf(Experience));
			sb.append(",PhysicianSK=" + String.valueOf(PhysicianSK));
			sb.append(",StartDate=" + String.valueOf(StartDate));
			sb.append(",EndDate=" + String.valueOf(EndDate));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			sb.append(PhysicianID);

			sb.append("|");

			if (Name == null) {
				sb.append("<null>");
			} else {
				sb.append(Name);
			}

			sb.append("|");

			if (DateOfJoining == null) {
				sb.append("<null>");
			} else {
				sb.append(DateOfJoining);
			}

			sb.append("|");

			if (Specialty == null) {
				sb.append("<null>");
			} else {
				sb.append(Specialty);
			}

			sb.append("|");

			if (Designation == null) {
				sb.append("<null>");
			} else {
				sb.append(Designation);
			}

			sb.append("|");

			if (Experience == null) {
				sb.append("<null>");
			} else {
				sb.append(Experience);
			}

			sb.append("|");

			sb.append(PhysicianSK);

			sb.append("|");

			if (StartDate == null) {
				sb.append("<null>");
			} else {
				sb.append(StartDate);
			}

			sb.append("|");

			if (EndDate == null) {
				sb.append("<null>");
			} else {
				sb.append(EndDate);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row2Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tDBInput_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tDBInput_2_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tDBInput_2");
		org.slf4j.MDC.put("_subJobPid", "Pt56ly_" + subJobPidCounter.getAndIncrement());

		String currentVirtualComponent = null;

		String iterateId = "";

		String currentComponent = "";
		String cLabel = null;
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				row2Struct row2 = new row2Struct();
				SurgeonDetailsStruct SurgeonDetails = new SurgeonDetailsStruct();
				SortDataStruct SortData = new SortDataStruct();
				row3Struct row3 = new row3Struct();
				HODStruct HOD = new HODStruct();

				/**
				 * [tFileOutputExcel_3 begin ] start
				 */

				ok_Hash.put("tFileOutputExcel_3", false);
				start_Hash.put("tFileOutputExcel_3", System.currentTimeMillis());

				currentComponent = "tFileOutputExcel_3";

				cLabel = "SurgeonDetails";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "SurgeonDetails");

				int tos_count_tFileOutputExcel_3 = 0;

				if (log.isDebugEnabled())
					log.debug("tFileOutputExcel_3 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tFileOutputExcel_3 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tFileOutputExcel_3 = new StringBuilder();
							log4jParamters_tFileOutputExcel_3.append("Parameters:");
							log4jParamters_tFileOutputExcel_3.append("VERSION_2007" + " = " + "false");
							log4jParamters_tFileOutputExcel_3.append(" | ");
							log4jParamters_tFileOutputExcel_3.append("USESTREAM" + " = " + "false");
							log4jParamters_tFileOutputExcel_3.append(" | ");
							log4jParamters_tFileOutputExcel_3.append(
									"FILENAME" + " = " + "\"C:/Users/2382187/Downloads/FR/SurgeonDetails.xls\"");
							log4jParamters_tFileOutputExcel_3.append(" | ");
							log4jParamters_tFileOutputExcel_3.append("SHEETNAME" + " = " + "\"Surgeon\"");
							log4jParamters_tFileOutputExcel_3.append(" | ");
							log4jParamters_tFileOutputExcel_3.append("INCLUDEHEADER" + " = " + "true");
							log4jParamters_tFileOutputExcel_3.append(" | ");
							log4jParamters_tFileOutputExcel_3.append("APPEND_FILE" + " = " + "false");
							log4jParamters_tFileOutputExcel_3.append(" | ");
							log4jParamters_tFileOutputExcel_3.append("FIRST_CELL_Y_ABSOLUTE" + " = " + "false");
							log4jParamters_tFileOutputExcel_3.append(" | ");
							log4jParamters_tFileOutputExcel_3.append("FONT" + " = " + "");
							log4jParamters_tFileOutputExcel_3.append(" | ");
							log4jParamters_tFileOutputExcel_3.append("IS_ALL_AUTO_SZIE" + " = " + "true");
							log4jParamters_tFileOutputExcel_3.append(" | ");
							log4jParamters_tFileOutputExcel_3.append("CREATE" + " = " + "true");
							log4jParamters_tFileOutputExcel_3.append(" | ");
							log4jParamters_tFileOutputExcel_3.append("ADVANCED_SEPARATOR" + " = " + "false");
							log4jParamters_tFileOutputExcel_3.append(" | ");
							log4jParamters_tFileOutputExcel_3.append("ENCODING" + " = " + "\"ISO-8859-15\"");
							log4jParamters_tFileOutputExcel_3.append(" | ");
							log4jParamters_tFileOutputExcel_3.append("DELETE_EMPTYFILE" + " = " + "false");
							log4jParamters_tFileOutputExcel_3.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tFileOutputExcel_3 - " + (log4jParamters_tFileOutputExcel_3));
						}
					}
					new BytesLimit65535_tFileOutputExcel_3().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tFileOutputExcel_3", "SurgeonDetails", "tFileOutputExcel");
					talendJobLogProcess(globalMap);
				}

				int columnIndex_tFileOutputExcel_3 = 0;
				boolean headerIsInserted_tFileOutputExcel_3 = false;

				int nb_line_tFileOutputExcel_3 = 0;

				String fileName_tFileOutputExcel_3 = "C:/Users/2382187/Downloads/FR/SurgeonDetails.xls";
				java.io.File file_tFileOutputExcel_3 = new java.io.File(fileName_tFileOutputExcel_3);
				boolean isFileGenerated_tFileOutputExcel_3 = true;
//create directory only if not exists
				java.io.File parentFile_tFileOutputExcel_3 = file_tFileOutputExcel_3.getParentFile();
				if (parentFile_tFileOutputExcel_3 != null && !parentFile_tFileOutputExcel_3.exists()) {

					log.info("tFileOutputExcel_3 - Creating directory '"
							+ parentFile_tFileOutputExcel_3.getCanonicalPath() + "'.");

					parentFile_tFileOutputExcel_3.mkdirs();

					log.info("tFileOutputExcel_3 - Create directory '"
							+ parentFile_tFileOutputExcel_3.getCanonicalPath() + "' has succeeded.");

				}

				jxl.write.WritableWorkbook writeableWorkbook_tFileOutputExcel_3 = null;
				jxl.write.WritableSheet writableSheet_tFileOutputExcel_3 = null;

				jxl.WorkbookSettings workbookSettings_tFileOutputExcel_3 = new jxl.WorkbookSettings();
				workbookSettings_tFileOutputExcel_3.setEncoding("ISO-8859-15");
				writeableWorkbook_tFileOutputExcel_3 = new jxl.write.biff.WritableWorkbookImpl(
						new java.io.BufferedOutputStream(new java.io.FileOutputStream(fileName_tFileOutputExcel_3)),
						true, workbookSettings_tFileOutputExcel_3);

				writableSheet_tFileOutputExcel_3 = writeableWorkbook_tFileOutputExcel_3.getSheet("Surgeon");
				if (writableSheet_tFileOutputExcel_3 == null) {
					writableSheet_tFileOutputExcel_3 = writeableWorkbook_tFileOutputExcel_3.createSheet("Surgeon",
							writeableWorkbook_tFileOutputExcel_3.getNumberOfSheets());
				}

				// modif start
				int startRowNum_tFileOutputExcel_3 = writableSheet_tFileOutputExcel_3.getRows();
				// modif end

				int[] fitWidth_tFileOutputExcel_3 = new int[6];
				for (int i_tFileOutputExcel_3 = 0; i_tFileOutputExcel_3 < 6; i_tFileOutputExcel_3++) {
					int fitCellViewSize_tFileOutputExcel_3 = writableSheet_tFileOutputExcel_3
							.getColumnView(i_tFileOutputExcel_3).getSize();
					fitWidth_tFileOutputExcel_3[i_tFileOutputExcel_3] = fitCellViewSize_tFileOutputExcel_3 / 256;
					if (fitCellViewSize_tFileOutputExcel_3 % 256 != 0) {
						fitWidth_tFileOutputExcel_3[i_tFileOutputExcel_3] += 1;
					}
				}

				final jxl.write.WritableCellFormat cell_format_DateOfJoining_tFileOutputExcel_3 = new jxl.write.WritableCellFormat(
						new jxl.write.DateFormat("dd-MM-yyyy"));

				if (startRowNum_tFileOutputExcel_3 == 0) {
					// modif end
					// modif start
					writableSheet_tFileOutputExcel_3
							.addCell(new jxl.write.Label(0, nb_line_tFileOutputExcel_3, "PhysicianID"));
					// modif end
					fitWidth_tFileOutputExcel_3[0] = fitWidth_tFileOutputExcel_3[0] > 11
							? fitWidth_tFileOutputExcel_3[0]
							: 11;
					// modif start
					writableSheet_tFileOutputExcel_3
							.addCell(new jxl.write.Label(1, nb_line_tFileOutputExcel_3, "Name"));
					// modif end
					fitWidth_tFileOutputExcel_3[1] = fitWidth_tFileOutputExcel_3[1] > 4 ? fitWidth_tFileOutputExcel_3[1]
							: 4;
					// modif start
					writableSheet_tFileOutputExcel_3
							.addCell(new jxl.write.Label(2, nb_line_tFileOutputExcel_3, "DateOfJoining"));
					// modif end
					fitWidth_tFileOutputExcel_3[2] = fitWidth_tFileOutputExcel_3[2] > 13
							? fitWidth_tFileOutputExcel_3[2]
							: 13;
					// modif start
					writableSheet_tFileOutputExcel_3
							.addCell(new jxl.write.Label(3, nb_line_tFileOutputExcel_3, "Specialty"));
					// modif end
					fitWidth_tFileOutputExcel_3[3] = fitWidth_tFileOutputExcel_3[3] > 9 ? fitWidth_tFileOutputExcel_3[3]
							: 9;
					// modif start
					writableSheet_tFileOutputExcel_3
							.addCell(new jxl.write.Label(4, nb_line_tFileOutputExcel_3, "Designation"));
					// modif end
					fitWidth_tFileOutputExcel_3[4] = fitWidth_tFileOutputExcel_3[4] > 11
							? fitWidth_tFileOutputExcel_3[4]
							: 11;
					// modif start
					writableSheet_tFileOutputExcel_3
							.addCell(new jxl.write.Label(5, nb_line_tFileOutputExcel_3, "Experience"));
					// modif end
					fitWidth_tFileOutputExcel_3[5] = fitWidth_tFileOutputExcel_3[5] > 10
							? fitWidth_tFileOutputExcel_3[5]
							: 10;
					nb_line_tFileOutputExcel_3++;
					headerIsInserted_tFileOutputExcel_3 = true;
				}

				/**
				 * [tFileOutputExcel_3 begin ] stop
				 */

				/**
				 * [tSortRow_1_SortOut begin ] start
				 */

				ok_Hash.put("tSortRow_1_SortOut", false);
				start_Hash.put("tSortRow_1_SortOut", System.currentTimeMillis());

				currentVirtualComponent = "tSortRow_1";

				currentComponent = "tSortRow_1_SortOut";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "SortData");

				int tos_count_tSortRow_1_SortOut = 0;

				if (log.isDebugEnabled())
					log.debug("tSortRow_1_SortOut - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tSortRow_1_SortOut {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tSortRow_1_SortOut = new StringBuilder();
							log4jParamters_tSortRow_1_SortOut.append("Parameters:");
							log4jParamters_tSortRow_1_SortOut.append("DESTINATION" + " = " + "tSortRow_1");
							log4jParamters_tSortRow_1_SortOut.append(" | ");
							log4jParamters_tSortRow_1_SortOut.append("EXTERNAL" + " = " + "false");
							log4jParamters_tSortRow_1_SortOut.append(" | ");
							log4jParamters_tSortRow_1_SortOut.append("CRITERIA" + " = " + "[{ORDER=" + ("asc")
									+ ", COLNAME=" + ("Name") + ", SORT=" + ("alpha") + "}, {ORDER=" + ("desc")
									+ ", COLNAME=" + ("Experience") + ", SORT=" + ("num") + "}]");
							log4jParamters_tSortRow_1_SortOut.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tSortRow_1_SortOut - " + (log4jParamters_tSortRow_1_SortOut));
						}
					}
					new BytesLimit65535_tSortRow_1_SortOut().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tSortRow_1_SortOut", "tSortRow_1_SortOut", "tSortOut");
					talendJobLogProcess(globalMap);
				}

				class ComparableSortDataStruct extends SortDataStruct implements Comparable<ComparableSortDataStruct> {

					public int compareTo(ComparableSortDataStruct other) {

						if (this.Name == null && other.Name != null) {
							return -1;

						} else if (this.Name != null && other.Name == null) {
							return 1;

						} else if (this.Name != null && other.Name != null) {
							if (!this.Name.equals(other.Name)) {
								return this.Name.compareTo(other.Name);
							}
						}
						if (this.Experience == null && other.Experience != null) {
							return 1;

						} else if (this.Experience != null && other.Experience == null) {
							return -1;

						} else if (this.Experience != null && other.Experience != null) {
							if (!this.Experience.equals(other.Experience)) {
								return other.Experience.compareTo(this.Experience);
							}
						}
						return 0;
					}
				}

				java.util.List<ComparableSortDataStruct> list_tSortRow_1_SortOut = new java.util.ArrayList<ComparableSortDataStruct>();

				/**
				 * [tSortRow_1_SortOut begin ] stop
				 */

				/**
				 * [tFileOutputExcel_5 begin ] start
				 */

				ok_Hash.put("tFileOutputExcel_5", false);
				start_Hash.put("tFileOutputExcel_5", System.currentTimeMillis());

				currentComponent = "tFileOutputExcel_5";

				cLabel = "HOD";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "HOD");

				int tos_count_tFileOutputExcel_5 = 0;

				if (log.isDebugEnabled())
					log.debug("tFileOutputExcel_5 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tFileOutputExcel_5 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tFileOutputExcel_5 = new StringBuilder();
							log4jParamters_tFileOutputExcel_5.append("Parameters:");
							log4jParamters_tFileOutputExcel_5.append("VERSION_2007" + " = " + "false");
							log4jParamters_tFileOutputExcel_5.append(" | ");
							log4jParamters_tFileOutputExcel_5.append("USESTREAM" + " = " + "false");
							log4jParamters_tFileOutputExcel_5.append(" | ");
							log4jParamters_tFileOutputExcel_5
									.append("FILENAME" + " = " + "\"C:/Users/2382187/Downloads/FR/HOD.xls\"");
							log4jParamters_tFileOutputExcel_5.append(" | ");
							log4jParamters_tFileOutputExcel_5.append("SHEETNAME" + " = " + "\"HOD\"");
							log4jParamters_tFileOutputExcel_5.append(" | ");
							log4jParamters_tFileOutputExcel_5.append("INCLUDEHEADER" + " = " + "true");
							log4jParamters_tFileOutputExcel_5.append(" | ");
							log4jParamters_tFileOutputExcel_5.append("APPEND_FILE" + " = " + "false");
							log4jParamters_tFileOutputExcel_5.append(" | ");
							log4jParamters_tFileOutputExcel_5.append("FIRST_CELL_Y_ABSOLUTE" + " = " + "false");
							log4jParamters_tFileOutputExcel_5.append(" | ");
							log4jParamters_tFileOutputExcel_5.append("FONT" + " = " + "");
							log4jParamters_tFileOutputExcel_5.append(" | ");
							log4jParamters_tFileOutputExcel_5.append("IS_ALL_AUTO_SZIE" + " = " + "true");
							log4jParamters_tFileOutputExcel_5.append(" | ");
							log4jParamters_tFileOutputExcel_5.append("CREATE" + " = " + "true");
							log4jParamters_tFileOutputExcel_5.append(" | ");
							log4jParamters_tFileOutputExcel_5.append("ADVANCED_SEPARATOR" + " = " + "false");
							log4jParamters_tFileOutputExcel_5.append(" | ");
							log4jParamters_tFileOutputExcel_5.append("ENCODING" + " = " + "\"ISO-8859-15\"");
							log4jParamters_tFileOutputExcel_5.append(" | ");
							log4jParamters_tFileOutputExcel_5.append("DELETE_EMPTYFILE" + " = " + "false");
							log4jParamters_tFileOutputExcel_5.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tFileOutputExcel_5 - " + (log4jParamters_tFileOutputExcel_5));
						}
					}
					new BytesLimit65535_tFileOutputExcel_5().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tFileOutputExcel_5", "HOD", "tFileOutputExcel");
					talendJobLogProcess(globalMap);
				}

				int columnIndex_tFileOutputExcel_5 = 0;
				boolean headerIsInserted_tFileOutputExcel_5 = false;

				int nb_line_tFileOutputExcel_5 = 0;

				String fileName_tFileOutputExcel_5 = "C:/Users/2382187/Downloads/FR/HOD.xls";
				java.io.File file_tFileOutputExcel_5 = new java.io.File(fileName_tFileOutputExcel_5);
				boolean isFileGenerated_tFileOutputExcel_5 = true;
//create directory only if not exists
				java.io.File parentFile_tFileOutputExcel_5 = file_tFileOutputExcel_5.getParentFile();
				if (parentFile_tFileOutputExcel_5 != null && !parentFile_tFileOutputExcel_5.exists()) {

					log.info("tFileOutputExcel_5 - Creating directory '"
							+ parentFile_tFileOutputExcel_5.getCanonicalPath() + "'.");

					parentFile_tFileOutputExcel_5.mkdirs();

					log.info("tFileOutputExcel_5 - Create directory '"
							+ parentFile_tFileOutputExcel_5.getCanonicalPath() + "' has succeeded.");

				}

				jxl.write.WritableWorkbook writeableWorkbook_tFileOutputExcel_5 = null;
				jxl.write.WritableSheet writableSheet_tFileOutputExcel_5 = null;

				jxl.WorkbookSettings workbookSettings_tFileOutputExcel_5 = new jxl.WorkbookSettings();
				workbookSettings_tFileOutputExcel_5.setEncoding("ISO-8859-15");
				writeableWorkbook_tFileOutputExcel_5 = new jxl.write.biff.WritableWorkbookImpl(
						new java.io.BufferedOutputStream(new java.io.FileOutputStream(fileName_tFileOutputExcel_5)),
						true, workbookSettings_tFileOutputExcel_5);

				writableSheet_tFileOutputExcel_5 = writeableWorkbook_tFileOutputExcel_5.getSheet("HOD");
				if (writableSheet_tFileOutputExcel_5 == null) {
					writableSheet_tFileOutputExcel_5 = writeableWorkbook_tFileOutputExcel_5.createSheet("HOD",
							writeableWorkbook_tFileOutputExcel_5.getNumberOfSheets());
				}

				// modif start
				int startRowNum_tFileOutputExcel_5 = writableSheet_tFileOutputExcel_5.getRows();
				// modif end

				int[] fitWidth_tFileOutputExcel_5 = new int[6];
				for (int i_tFileOutputExcel_5 = 0; i_tFileOutputExcel_5 < 6; i_tFileOutputExcel_5++) {
					int fitCellViewSize_tFileOutputExcel_5 = writableSheet_tFileOutputExcel_5
							.getColumnView(i_tFileOutputExcel_5).getSize();
					fitWidth_tFileOutputExcel_5[i_tFileOutputExcel_5] = fitCellViewSize_tFileOutputExcel_5 / 256;
					if (fitCellViewSize_tFileOutputExcel_5 % 256 != 0) {
						fitWidth_tFileOutputExcel_5[i_tFileOutputExcel_5] += 1;
					}
				}

				final jxl.write.WritableCellFormat cell_format_DateOfJoining_tFileOutputExcel_5 = new jxl.write.WritableCellFormat(
						new jxl.write.DateFormat("dd-MM-yyyy"));

				if (startRowNum_tFileOutputExcel_5 == 0) {
					// modif end
					// modif start
					writableSheet_tFileOutputExcel_5
							.addCell(new jxl.write.Label(0, nb_line_tFileOutputExcel_5, "PhysicianID"));
					// modif end
					fitWidth_tFileOutputExcel_5[0] = fitWidth_tFileOutputExcel_5[0] > 11
							? fitWidth_tFileOutputExcel_5[0]
							: 11;
					// modif start
					writableSheet_tFileOutputExcel_5
							.addCell(new jxl.write.Label(1, nb_line_tFileOutputExcel_5, "Name"));
					// modif end
					fitWidth_tFileOutputExcel_5[1] = fitWidth_tFileOutputExcel_5[1] > 4 ? fitWidth_tFileOutputExcel_5[1]
							: 4;
					// modif start
					writableSheet_tFileOutputExcel_5
							.addCell(new jxl.write.Label(2, nb_line_tFileOutputExcel_5, "DateOfJoining"));
					// modif end
					fitWidth_tFileOutputExcel_5[2] = fitWidth_tFileOutputExcel_5[2] > 13
							? fitWidth_tFileOutputExcel_5[2]
							: 13;
					// modif start
					writableSheet_tFileOutputExcel_5
							.addCell(new jxl.write.Label(3, nb_line_tFileOutputExcel_5, "Specialty"));
					// modif end
					fitWidth_tFileOutputExcel_5[3] = fitWidth_tFileOutputExcel_5[3] > 9 ? fitWidth_tFileOutputExcel_5[3]
							: 9;
					// modif start
					writableSheet_tFileOutputExcel_5
							.addCell(new jxl.write.Label(4, nb_line_tFileOutputExcel_5, "Designation"));
					// modif end
					fitWidth_tFileOutputExcel_5[4] = fitWidth_tFileOutputExcel_5[4] > 11
							? fitWidth_tFileOutputExcel_5[4]
							: 11;
					// modif start
					writableSheet_tFileOutputExcel_5
							.addCell(new jxl.write.Label(5, nb_line_tFileOutputExcel_5, "Experience"));
					// modif end
					fitWidth_tFileOutputExcel_5[5] = fitWidth_tFileOutputExcel_5[5] > 10
							? fitWidth_tFileOutputExcel_5[5]
							: 10;
					nb_line_tFileOutputExcel_5++;
					headerIsInserted_tFileOutputExcel_5 = true;
				}

				/**
				 * [tFileOutputExcel_5 begin ] stop
				 */

				/**
				 * [tMap_2 begin ] start
				 */

				ok_Hash.put("tMap_2", false);
				start_Hash.put("tMap_2", System.currentTimeMillis());

				currentComponent = "tMap_2";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "row2");

				int tos_count_tMap_2 = 0;

				if (log.isDebugEnabled())
					log.debug("tMap_2 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tMap_2 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tMap_2 = new StringBuilder();
							log4jParamters_tMap_2.append("Parameters:");
							log4jParamters_tMap_2.append("LINK_STYLE" + " = " + "AUTO");
							log4jParamters_tMap_2.append(" | ");
							log4jParamters_tMap_2.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
							log4jParamters_tMap_2.append(" | ");
							log4jParamters_tMap_2.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
							log4jParamters_tMap_2.append(" | ");
							log4jParamters_tMap_2.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "true");
							log4jParamters_tMap_2.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tMap_2 - " + (log4jParamters_tMap_2));
						}
					}
					new BytesLimit65535_tMap_2().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tMap_2", "tMap_2", "tMap");
					talendJobLogProcess(globalMap);
				}

// ###############################
// # Lookup's keys initialization
				int count_row2_tMap_2 = 0;

// ###############################        

// ###############################
// # Vars initialization
				class Var__tMap_2__Struct {
				}
				Var__tMap_2__Struct Var__tMap_2 = new Var__tMap_2__Struct();
// ###############################

// ###############################
// # Outputs initialization
				int count_SurgeonDetails_tMap_2 = 0;

				SurgeonDetailsStruct SurgeonDetails_tmp = new SurgeonDetailsStruct();
				int count_SortData_tMap_2 = 0;

				SortDataStruct SortData_tmp = new SortDataStruct();
				int count_HOD_tMap_2 = 0;

				HODStruct HOD_tmp = new HODStruct();
// ###############################

				/**
				 * [tMap_2 begin ] stop
				 */

				/**
				 * [tDBInput_2 begin ] start
				 */

				ok_Hash.put("tDBInput_2", false);
				start_Hash.put("tDBInput_2", System.currentTimeMillis());

				currentComponent = "tDBInput_2";

				cLabel = "Physician";

				int tos_count_tDBInput_2 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBInput_2 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tDBInput_2 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tDBInput_2 = new StringBuilder();
							log4jParamters_tDBInput_2.append("Parameters:");
							log4jParamters_tDBInput_2.append("DB_VERSION" + " = " + "MYSQL_8");
							log4jParamters_tDBInput_2.append(" | ");
							log4jParamters_tDBInput_2.append("USE_EXISTING_CONNECTION" + " = " + "false");
							log4jParamters_tDBInput_2.append(" | ");
							log4jParamters_tDBInput_2.append("HOST" + " = " + "\"localhost\"");
							log4jParamters_tDBInput_2.append(" | ");
							log4jParamters_tDBInput_2.append("PORT" + " = " + "\"3306\"");
							log4jParamters_tDBInput_2.append(" | ");
							log4jParamters_tDBInput_2.append("DBNAME" + " = " + "\"Warehouse\"");
							log4jParamters_tDBInput_2.append(" | ");
							log4jParamters_tDBInput_2.append("USER" + " = " + "\"root\"");
							log4jParamters_tDBInput_2.append(" | ");
							log4jParamters_tDBInput_2.append("PASS" + " = " + String.valueOf(
									"enc:routine.encryption.key.v1:aJablON3G9mUB8z/YxBbvNpwxLBWk9ypx4ieR6bIBJ8=")
									.substring(0, 4) + "...");
							log4jParamters_tDBInput_2.append(" | ");
							log4jParamters_tDBInput_2.append("TABLE" + " = " + "\"physiciandim\"");
							log4jParamters_tDBInput_2.append(" | ");
							log4jParamters_tDBInput_2.append("QUERYSTORE" + " = " + "\"\"");
							log4jParamters_tDBInput_2.append(" | ");
							log4jParamters_tDBInput_2.append("QUERY" + " = "
									+ "\"SELECT    `physiciandim`.`PhysicianID`,    `physiciandim`.`Name`,    `physiciandim`.`DateOfJoining`,    `physiciandim`.`Specialty`,    `physiciandim`.`Designation`,    `physiciandim`.`Experience`,    `physiciandim`.`PhysicianSK`,    `physiciandim`.`StartDate`,    `physiciandim`.`EndDate` FROM `physiciandim`\"");
							log4jParamters_tDBInput_2.append(" | ");
							log4jParamters_tDBInput_2.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
							log4jParamters_tDBInput_2.append(" | ");
							log4jParamters_tDBInput_2.append("PROPERTIES" + " = "
									+ "\"noDatetimeStringSync=true&enabledTLSProtocols=TLSv1.2,TLSv1.1,TLSv1\"");
							log4jParamters_tDBInput_2.append(" | ");
							log4jParamters_tDBInput_2.append("ENABLE_STREAM" + " = " + "false");
							log4jParamters_tDBInput_2.append(" | ");
							log4jParamters_tDBInput_2.append("TRIM_ALL_COLUMN" + " = " + "false");
							log4jParamters_tDBInput_2.append(" | ");
							log4jParamters_tDBInput_2.append("TRIM_COLUMN" + " = " + "[{TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("PhysicianID") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("Name") + "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN="
									+ ("DateOfJoining") + "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN=" + ("Specialty")
									+ "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN=" + ("Designation") + "}, {TRIM="
									+ ("false") + ", SCHEMA_COLUMN=" + ("Experience") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("PhysicianSK") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("StartDate") + "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN="
									+ ("EndDate") + "}]");
							log4jParamters_tDBInput_2.append(" | ");
							log4jParamters_tDBInput_2.append("UNIFIED_COMPONENTS" + " = " + "tMysqlInput");
							log4jParamters_tDBInput_2.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tDBInput_2 - " + (log4jParamters_tDBInput_2));
						}
					}
					new BytesLimit65535_tDBInput_2().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tDBInput_2", "Physician", "tMysqlInput");
					talendJobLogProcess(globalMap);
				}

				java.util.Calendar calendar_tDBInput_2 = java.util.Calendar.getInstance();
				calendar_tDBInput_2.set(0, 0, 0, 0, 0, 0);
				java.util.Date year0_tDBInput_2 = calendar_tDBInput_2.getTime();
				int nb_line_tDBInput_2 = 0;
				java.sql.Connection conn_tDBInput_2 = null;
				String driverClass_tDBInput_2 = "com.mysql.cj.jdbc.Driver";
				java.lang.Class jdbcclazz_tDBInput_2 = java.lang.Class.forName(driverClass_tDBInput_2);
				String dbUser_tDBInput_2 = "root";

				final String decryptedPassword_tDBInput_2 = routines.system.PasswordEncryptUtil
						.decryptPassword("enc:routine.encryption.key.v1:JTtF1AlVRCAphPoVvw0TjdXsvbE6M52pUIeA7A97p6s=");

				String dbPwd_tDBInput_2 = decryptedPassword_tDBInput_2;

				String properties_tDBInput_2 = "noDatetimeStringSync=true&enabledTLSProtocols=TLSv1.2,TLSv1.1,TLSv1";
				if (properties_tDBInput_2 == null || properties_tDBInput_2.trim().length() == 0) {
					properties_tDBInput_2 = "";
				}
				String url_tDBInput_2 = "jdbc:mysql://" + "localhost" + ":" + "3306" + "/" + "Warehouse" + "?"
						+ properties_tDBInput_2;

				log.debug("tDBInput_2 - Driver ClassName: " + driverClass_tDBInput_2 + ".");

				log.debug("tDBInput_2 - Connection attempt to '" + url_tDBInput_2 + "' with the username '"
						+ dbUser_tDBInput_2 + "'.");

				conn_tDBInput_2 = java.sql.DriverManager.getConnection(url_tDBInput_2, dbUser_tDBInput_2,
						dbPwd_tDBInput_2);
				log.debug("tDBInput_2 - Connection to '" + url_tDBInput_2 + "' has succeeded.");

				java.sql.Statement stmt_tDBInput_2 = conn_tDBInput_2.createStatement();

				String dbquery_tDBInput_2 = "SELECT \n  `physiciandim`.`PhysicianID`, \n  `physiciandim`.`Name`, \n  `physiciandim`.`DateOfJoining`, \n  `physiciandim`."
						+ "`Specialty`, \n  `physiciandim`.`Designation`, \n  `physiciandim`.`Experience`, \n  `physiciandim`.`PhysicianSK`, \n  `physi"
						+ "ciandim`.`StartDate`, \n  `physiciandim`.`EndDate`\nFROM `physiciandim`";

				log.debug("tDBInput_2 - Executing the query: '" + dbquery_tDBInput_2 + "'.");

				globalMap.put("tDBInput_2_QUERY", dbquery_tDBInput_2);

				java.sql.ResultSet rs_tDBInput_2 = null;

				try {
					rs_tDBInput_2 = stmt_tDBInput_2.executeQuery(dbquery_tDBInput_2);
					java.sql.ResultSetMetaData rsmd_tDBInput_2 = rs_tDBInput_2.getMetaData();
					int colQtyInRs_tDBInput_2 = rsmd_tDBInput_2.getColumnCount();

					String tmpContent_tDBInput_2 = null;

					log.debug("tDBInput_2 - Retrieving records from the database.");

					while (rs_tDBInput_2.next()) {
						nb_line_tDBInput_2++;

						if (colQtyInRs_tDBInput_2 < 1) {
							row2.PhysicianID = 0;
						} else {

							row2.PhysicianID = rs_tDBInput_2.getInt(1);
							if (rs_tDBInput_2.wasNull()) {
								throw new RuntimeException("Null value in non-Nullable column");
							}
						}
						if (colQtyInRs_tDBInput_2 < 2) {
							row2.Name = null;
						} else {

							row2.Name = routines.system.JDBCUtil.getString(rs_tDBInput_2, 2, false);
						}
						if (colQtyInRs_tDBInput_2 < 3) {
							row2.DateOfJoining = null;
						} else {

							if (rs_tDBInput_2.getString(3) != null) {
								String dateString_tDBInput_2 = rs_tDBInput_2.getString(3);
								if (!("0000-00-00").equals(dateString_tDBInput_2)
										&& !("0000-00-00 00:00:00").equals(dateString_tDBInput_2)) {
									row2.DateOfJoining = rs_tDBInput_2.getTimestamp(3);
								} else {
									row2.DateOfJoining = (java.util.Date) year0_tDBInput_2.clone();
								}
							} else {
								row2.DateOfJoining = null;
							}
						}
						if (colQtyInRs_tDBInput_2 < 4) {
							row2.Specialty = null;
						} else {

							row2.Specialty = routines.system.JDBCUtil.getString(rs_tDBInput_2, 4, false);
						}
						if (colQtyInRs_tDBInput_2 < 5) {
							row2.Designation = null;
						} else {

							row2.Designation = routines.system.JDBCUtil.getString(rs_tDBInput_2, 5, false);
						}
						if (colQtyInRs_tDBInput_2 < 6) {
							row2.Experience = null;
						} else {

							row2.Experience = rs_tDBInput_2.getInt(6);
							if (rs_tDBInput_2.wasNull()) {
								row2.Experience = null;
							}
						}
						if (colQtyInRs_tDBInput_2 < 7) {
							row2.PhysicianSK = 0;
						} else {

							row2.PhysicianSK = rs_tDBInput_2.getInt(7);
							if (rs_tDBInput_2.wasNull()) {
								throw new RuntimeException("Null value in non-Nullable column");
							}
						}
						if (colQtyInRs_tDBInput_2 < 8) {
							row2.StartDate = null;
						} else {

							if (rs_tDBInput_2.getString(8) != null) {
								String dateString_tDBInput_2 = rs_tDBInput_2.getString(8);
								if (!("0000-00-00").equals(dateString_tDBInput_2)
										&& !("0000-00-00 00:00:00").equals(dateString_tDBInput_2)) {
									row2.StartDate = rs_tDBInput_2.getTimestamp(8);
								} else {
									row2.StartDate = (java.util.Date) year0_tDBInput_2.clone();
								}
							} else {
								row2.StartDate = null;
							}
						}
						if (colQtyInRs_tDBInput_2 < 9) {
							row2.EndDate = null;
						} else {

							if (rs_tDBInput_2.getString(9) != null) {
								String dateString_tDBInput_2 = rs_tDBInput_2.getString(9);
								if (!("0000-00-00").equals(dateString_tDBInput_2)
										&& !("0000-00-00 00:00:00").equals(dateString_tDBInput_2)) {
									row2.EndDate = rs_tDBInput_2.getTimestamp(9);
								} else {
									row2.EndDate = (java.util.Date) year0_tDBInput_2.clone();
								}
							} else {
								row2.EndDate = null;
							}
						}

						log.debug("tDBInput_2 - Retrieving the record " + nb_line_tDBInput_2 + ".");

						/**
						 * [tDBInput_2 begin ] stop
						 */

						/**
						 * [tDBInput_2 main ] start
						 */

						currentComponent = "tDBInput_2";

						cLabel = "Physician";

						tos_count_tDBInput_2++;

						/**
						 * [tDBInput_2 main ] stop
						 */

						/**
						 * [tDBInput_2 process_data_begin ] start
						 */

						currentComponent = "tDBInput_2";

						cLabel = "Physician";

						/**
						 * [tDBInput_2 process_data_begin ] stop
						 */

						/**
						 * [tMap_2 main ] start
						 */

						currentComponent = "tMap_2";

						if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

								, "row2", "tDBInput_2", "Physician", "tMysqlInput", "tMap_2", "tMap_2", "tMap"

						)) {
							talendJobLogProcess(globalMap);
						}

						if (log.isTraceEnabled()) {
							log.trace("row2 - " + (row2 == null ? "" : row2.toLogString()));
						}

						boolean hasCasePrimitiveKeyWithNull_tMap_2 = false;

						// ###############################
						// # Input tables (lookups)

						boolean rejectedInnerJoin_tMap_2 = false;
						boolean mainRowRejected_tMap_2 = false;
						// ###############################
						{ // start of Var scope

							// ###############################
							// # Vars tables

							Var__tMap_2__Struct Var = Var__tMap_2;// ###############################
							// ###############################
							// # Output tables

							SurgeonDetails = null;
							SortData = null;
							HOD = null;

// # Output table : 'SurgeonDetails'
// # Filter conditions 
							if (

							(row2.Specialty.equalsIgnoreCase("Surgeon"))
									&& (row2.DateOfJoining.getYear() >= 2000 && row2.DateOfJoining.getYear() <= 2010)

							) {
								count_SurgeonDetails_tMap_2++;

								SurgeonDetails_tmp.PhysicianID = row2.PhysicianID;
								SurgeonDetails_tmp.Name = row2.Name;
								SurgeonDetails_tmp.DateOfJoining = row2.DateOfJoining;
								SurgeonDetails_tmp.Specialty = row2.Specialty;
								SurgeonDetails_tmp.Designation = row2.Designation;
								SurgeonDetails_tmp.Experience = row2.Experience;
								SurgeonDetails = SurgeonDetails_tmp;
								log.debug("tMap_2 - Outputting the record " + count_SurgeonDetails_tMap_2
										+ " of the output table 'SurgeonDetails'.");

							} // closing filter/reject

// # Output table : 'SortData'
							count_SortData_tMap_2++;

							SortData_tmp.PhysicianID = row2.PhysicianID;
							SortData_tmp.Name = row2.Name;
							SortData_tmp.DateOfJoining = row2.DateOfJoining;
							SortData_tmp.Specialty = row2.Specialty;
							SortData_tmp.Designation = row2.Designation;
							SortData_tmp.Experience = row2.Experience;
							SortData = SortData_tmp;
							log.debug("tMap_2 - Outputting the record " + count_SortData_tMap_2
									+ " of the output table 'SortData'.");

// # Output table : 'HOD'
// # Filter conditions 
							if (

							row2.Designation.equalsIgnoreCase("Head of Department")

							) {
								count_HOD_tMap_2++;

								HOD_tmp.PhysicianID = row2.PhysicianID;
								HOD_tmp.Name = row2.Name;
								HOD_tmp.DateOfJoining = row2.DateOfJoining;
								HOD_tmp.Specialty = row2.Specialty;
								HOD_tmp.Designation = row2.Designation;
								HOD_tmp.Experience = row2.Experience;
								HOD = HOD_tmp;
								log.debug("tMap_2 - Outputting the record " + count_HOD_tMap_2
										+ " of the output table 'HOD'.");

							} // closing filter/reject
// ###############################

						} // end of Var scope

						rejectedInnerJoin_tMap_2 = false;

						tos_count_tMap_2++;

						/**
						 * [tMap_2 main ] stop
						 */

						/**
						 * [tMap_2 process_data_begin ] start
						 */

						currentComponent = "tMap_2";

						/**
						 * [tMap_2 process_data_begin ] stop
						 */
// Start of branch "SurgeonDetails"
						if (SurgeonDetails != null) {

							/**
							 * [tFileOutputExcel_3 main ] start
							 */

							currentComponent = "tFileOutputExcel_3";

							cLabel = "SurgeonDetails";

							if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

									, "SurgeonDetails", "tMap_2", "tMap_2", "tMap", "tFileOutputExcel_3",
									"SurgeonDetails", "tFileOutputExcel"

							)) {
								talendJobLogProcess(globalMap);
							}

							if (log.isTraceEnabled()) {
								log.trace("SurgeonDetails - "
										+ (SurgeonDetails == null ? "" : SurgeonDetails.toLogString()));
							}

//modif start

							columnIndex_tFileOutputExcel_3 = 0;

							jxl.write.WritableCell cell_0_tFileOutputExcel_3 = new jxl.write.Number(
									columnIndex_tFileOutputExcel_3,
									startRowNum_tFileOutputExcel_3 + nb_line_tFileOutputExcel_3,

//modif end
									SurgeonDetails.PhysicianID);
//modif start					
							// If we keep the cell format from the existing cell in sheet

//modif ends							
							writableSheet_tFileOutputExcel_3.addCell(cell_0_tFileOutputExcel_3);
							int currentWith_0_tFileOutputExcel_3 = String
									.valueOf(((jxl.write.Number) cell_0_tFileOutputExcel_3).getValue()).trim().length();
							currentWith_0_tFileOutputExcel_3 = currentWith_0_tFileOutputExcel_3 > 10 ? 10
									: currentWith_0_tFileOutputExcel_3;
							fitWidth_tFileOutputExcel_3[0] = fitWidth_tFileOutputExcel_3[0] > currentWith_0_tFileOutputExcel_3
									? fitWidth_tFileOutputExcel_3[0]
									: currentWith_0_tFileOutputExcel_3 + 2;

							if (SurgeonDetails.Name != null) {

//modif start

								columnIndex_tFileOutputExcel_3 = 1;

								jxl.write.WritableCell cell_1_tFileOutputExcel_3 = new jxl.write.Label(
										columnIndex_tFileOutputExcel_3,
										startRowNum_tFileOutputExcel_3 + nb_line_tFileOutputExcel_3,

//modif end
										SurgeonDetails.Name);
//modif start					
								// If we keep the cell format from the existing cell in sheet

//modif ends							
								writableSheet_tFileOutputExcel_3.addCell(cell_1_tFileOutputExcel_3);
								int currentWith_1_tFileOutputExcel_3 = cell_1_tFileOutputExcel_3.getContents().trim()
										.length();
								fitWidth_tFileOutputExcel_3[1] = fitWidth_tFileOutputExcel_3[1] > currentWith_1_tFileOutputExcel_3
										? fitWidth_tFileOutputExcel_3[1]
										: currentWith_1_tFileOutputExcel_3 + 2;
							}

							if (SurgeonDetails.DateOfJoining != null) {

//modif start

								columnIndex_tFileOutputExcel_3 = 2;

								jxl.write.WritableCell cell_2_tFileOutputExcel_3 = new jxl.write.DateTime(
										columnIndex_tFileOutputExcel_3,
										startRowNum_tFileOutputExcel_3 + nb_line_tFileOutputExcel_3,

//modif end
										SurgeonDetails.DateOfJoining, cell_format_DateOfJoining_tFileOutputExcel_3);
//modif start					
								// If we keep the cell format from the existing cell in sheet

//modif ends							
								writableSheet_tFileOutputExcel_3.addCell(cell_2_tFileOutputExcel_3);
								int currentWith_2_tFileOutputExcel_3 = cell_2_tFileOutputExcel_3.getContents().trim()
										.length();
								currentWith_2_tFileOutputExcel_3 = 12;
								fitWidth_tFileOutputExcel_3[2] = fitWidth_tFileOutputExcel_3[2] > currentWith_2_tFileOutputExcel_3
										? fitWidth_tFileOutputExcel_3[2]
										: currentWith_2_tFileOutputExcel_3 + 2;
							}

							if (SurgeonDetails.Specialty != null) {

//modif start

								columnIndex_tFileOutputExcel_3 = 3;

								jxl.write.WritableCell cell_3_tFileOutputExcel_3 = new jxl.write.Label(
										columnIndex_tFileOutputExcel_3,
										startRowNum_tFileOutputExcel_3 + nb_line_tFileOutputExcel_3,

//modif end
										SurgeonDetails.Specialty);
//modif start					
								// If we keep the cell format from the existing cell in sheet

//modif ends							
								writableSheet_tFileOutputExcel_3.addCell(cell_3_tFileOutputExcel_3);
								int currentWith_3_tFileOutputExcel_3 = cell_3_tFileOutputExcel_3.getContents().trim()
										.length();
								fitWidth_tFileOutputExcel_3[3] = fitWidth_tFileOutputExcel_3[3] > currentWith_3_tFileOutputExcel_3
										? fitWidth_tFileOutputExcel_3[3]
										: currentWith_3_tFileOutputExcel_3 + 2;
							}

							if (SurgeonDetails.Designation != null) {

//modif start

								columnIndex_tFileOutputExcel_3 = 4;

								jxl.write.WritableCell cell_4_tFileOutputExcel_3 = new jxl.write.Label(
										columnIndex_tFileOutputExcel_3,
										startRowNum_tFileOutputExcel_3 + nb_line_tFileOutputExcel_3,

//modif end
										SurgeonDetails.Designation);
//modif start					
								// If we keep the cell format from the existing cell in sheet

//modif ends							
								writableSheet_tFileOutputExcel_3.addCell(cell_4_tFileOutputExcel_3);
								int currentWith_4_tFileOutputExcel_3 = cell_4_tFileOutputExcel_3.getContents().trim()
										.length();
								fitWidth_tFileOutputExcel_3[4] = fitWidth_tFileOutputExcel_3[4] > currentWith_4_tFileOutputExcel_3
										? fitWidth_tFileOutputExcel_3[4]
										: currentWith_4_tFileOutputExcel_3 + 2;
							}

							if (SurgeonDetails.Experience != null) {

//modif start

								columnIndex_tFileOutputExcel_3 = 5;

								jxl.write.WritableCell cell_5_tFileOutputExcel_3 = new jxl.write.Number(
										columnIndex_tFileOutputExcel_3,
										startRowNum_tFileOutputExcel_3 + nb_line_tFileOutputExcel_3,

//modif end
										SurgeonDetails.Experience);
//modif start					
								// If we keep the cell format from the existing cell in sheet

//modif ends							
								writableSheet_tFileOutputExcel_3.addCell(cell_5_tFileOutputExcel_3);
								int currentWith_5_tFileOutputExcel_3 = String
										.valueOf(((jxl.write.Number) cell_5_tFileOutputExcel_3).getValue()).trim()
										.length();
								currentWith_5_tFileOutputExcel_3 = currentWith_5_tFileOutputExcel_3 > 10 ? 10
										: currentWith_5_tFileOutputExcel_3;
								fitWidth_tFileOutputExcel_3[5] = fitWidth_tFileOutputExcel_3[5] > currentWith_5_tFileOutputExcel_3
										? fitWidth_tFileOutputExcel_3[5]
										: currentWith_5_tFileOutputExcel_3 + 2;
							}

							nb_line_tFileOutputExcel_3++;

							log.debug("tFileOutputExcel_3 - Writing the record " + nb_line_tFileOutputExcel_3
									+ " to the file.");

							tos_count_tFileOutputExcel_3++;

							/**
							 * [tFileOutputExcel_3 main ] stop
							 */

							/**
							 * [tFileOutputExcel_3 process_data_begin ] start
							 */

							currentComponent = "tFileOutputExcel_3";

							cLabel = "SurgeonDetails";

							/**
							 * [tFileOutputExcel_3 process_data_begin ] stop
							 */

							/**
							 * [tFileOutputExcel_3 process_data_end ] start
							 */

							currentComponent = "tFileOutputExcel_3";

							cLabel = "SurgeonDetails";

							/**
							 * [tFileOutputExcel_3 process_data_end ] stop
							 */

						} // End of branch "SurgeonDetails"

// Start of branch "SortData"
						if (SortData != null) {

							/**
							 * [tSortRow_1_SortOut main ] start
							 */

							currentVirtualComponent = "tSortRow_1";

							currentComponent = "tSortRow_1_SortOut";

							if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

									, "SortData", "tMap_2", "tMap_2", "tMap", "tSortRow_1_SortOut",
									"tSortRow_1_SortOut", "tSortOut"

							)) {
								talendJobLogProcess(globalMap);
							}

							if (log.isTraceEnabled()) {
								log.trace("SortData - " + (SortData == null ? "" : SortData.toLogString()));
							}

							ComparableSortDataStruct arrayRowtSortRow_1_SortOut = new ComparableSortDataStruct();

							arrayRowtSortRow_1_SortOut.PhysicianID = SortData.PhysicianID;
							arrayRowtSortRow_1_SortOut.Name = SortData.Name;
							arrayRowtSortRow_1_SortOut.DateOfJoining = SortData.DateOfJoining;
							arrayRowtSortRow_1_SortOut.Specialty = SortData.Specialty;
							arrayRowtSortRow_1_SortOut.Designation = SortData.Designation;
							arrayRowtSortRow_1_SortOut.Experience = SortData.Experience;
							list_tSortRow_1_SortOut.add(arrayRowtSortRow_1_SortOut);

							tos_count_tSortRow_1_SortOut++;

							/**
							 * [tSortRow_1_SortOut main ] stop
							 */

							/**
							 * [tSortRow_1_SortOut process_data_begin ] start
							 */

							currentVirtualComponent = "tSortRow_1";

							currentComponent = "tSortRow_1_SortOut";

							/**
							 * [tSortRow_1_SortOut process_data_begin ] stop
							 */

							/**
							 * [tSortRow_1_SortOut process_data_end ] start
							 */

							currentVirtualComponent = "tSortRow_1";

							currentComponent = "tSortRow_1_SortOut";

							/**
							 * [tSortRow_1_SortOut process_data_end ] stop
							 */

						} // End of branch "SortData"

// Start of branch "HOD"
						if (HOD != null) {

							/**
							 * [tFileOutputExcel_5 main ] start
							 */

							currentComponent = "tFileOutputExcel_5";

							cLabel = "HOD";

							if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

									, "HOD", "tMap_2", "tMap_2", "tMap", "tFileOutputExcel_5", "HOD", "tFileOutputExcel"

							)) {
								talendJobLogProcess(globalMap);
							}

							if (log.isTraceEnabled()) {
								log.trace("HOD - " + (HOD == null ? "" : HOD.toLogString()));
							}

//modif start

							columnIndex_tFileOutputExcel_5 = 0;

							jxl.write.WritableCell cell_0_tFileOutputExcel_5 = new jxl.write.Number(
									columnIndex_tFileOutputExcel_5,
									startRowNum_tFileOutputExcel_5 + nb_line_tFileOutputExcel_5,

//modif end
									HOD.PhysicianID);
//modif start					
							// If we keep the cell format from the existing cell in sheet

//modif ends							
							writableSheet_tFileOutputExcel_5.addCell(cell_0_tFileOutputExcel_5);
							int currentWith_0_tFileOutputExcel_5 = String
									.valueOf(((jxl.write.Number) cell_0_tFileOutputExcel_5).getValue()).trim().length();
							currentWith_0_tFileOutputExcel_5 = currentWith_0_tFileOutputExcel_5 > 10 ? 10
									: currentWith_0_tFileOutputExcel_5;
							fitWidth_tFileOutputExcel_5[0] = fitWidth_tFileOutputExcel_5[0] > currentWith_0_tFileOutputExcel_5
									? fitWidth_tFileOutputExcel_5[0]
									: currentWith_0_tFileOutputExcel_5 + 2;

							if (HOD.Name != null) {

//modif start

								columnIndex_tFileOutputExcel_5 = 1;

								jxl.write.WritableCell cell_1_tFileOutputExcel_5 = new jxl.write.Label(
										columnIndex_tFileOutputExcel_5,
										startRowNum_tFileOutputExcel_5 + nb_line_tFileOutputExcel_5,

//modif end
										HOD.Name);
//modif start					
								// If we keep the cell format from the existing cell in sheet

//modif ends							
								writableSheet_tFileOutputExcel_5.addCell(cell_1_tFileOutputExcel_5);
								int currentWith_1_tFileOutputExcel_5 = cell_1_tFileOutputExcel_5.getContents().trim()
										.length();
								fitWidth_tFileOutputExcel_5[1] = fitWidth_tFileOutputExcel_5[1] > currentWith_1_tFileOutputExcel_5
										? fitWidth_tFileOutputExcel_5[1]
										: currentWith_1_tFileOutputExcel_5 + 2;
							}

							if (HOD.DateOfJoining != null) {

//modif start

								columnIndex_tFileOutputExcel_5 = 2;

								jxl.write.WritableCell cell_2_tFileOutputExcel_5 = new jxl.write.DateTime(
										columnIndex_tFileOutputExcel_5,
										startRowNum_tFileOutputExcel_5 + nb_line_tFileOutputExcel_5,

//modif end
										HOD.DateOfJoining, cell_format_DateOfJoining_tFileOutputExcel_5);
//modif start					
								// If we keep the cell format from the existing cell in sheet

//modif ends							
								writableSheet_tFileOutputExcel_5.addCell(cell_2_tFileOutputExcel_5);
								int currentWith_2_tFileOutputExcel_5 = cell_2_tFileOutputExcel_5.getContents().trim()
										.length();
								currentWith_2_tFileOutputExcel_5 = 12;
								fitWidth_tFileOutputExcel_5[2] = fitWidth_tFileOutputExcel_5[2] > currentWith_2_tFileOutputExcel_5
										? fitWidth_tFileOutputExcel_5[2]
										: currentWith_2_tFileOutputExcel_5 + 2;
							}

							if (HOD.Specialty != null) {

//modif start

								columnIndex_tFileOutputExcel_5 = 3;

								jxl.write.WritableCell cell_3_tFileOutputExcel_5 = new jxl.write.Label(
										columnIndex_tFileOutputExcel_5,
										startRowNum_tFileOutputExcel_5 + nb_line_tFileOutputExcel_5,

//modif end
										HOD.Specialty);
//modif start					
								// If we keep the cell format from the existing cell in sheet

//modif ends							
								writableSheet_tFileOutputExcel_5.addCell(cell_3_tFileOutputExcel_5);
								int currentWith_3_tFileOutputExcel_5 = cell_3_tFileOutputExcel_5.getContents().trim()
										.length();
								fitWidth_tFileOutputExcel_5[3] = fitWidth_tFileOutputExcel_5[3] > currentWith_3_tFileOutputExcel_5
										? fitWidth_tFileOutputExcel_5[3]
										: currentWith_3_tFileOutputExcel_5 + 2;
							}

							if (HOD.Designation != null) {

//modif start

								columnIndex_tFileOutputExcel_5 = 4;

								jxl.write.WritableCell cell_4_tFileOutputExcel_5 = new jxl.write.Label(
										columnIndex_tFileOutputExcel_5,
										startRowNum_tFileOutputExcel_5 + nb_line_tFileOutputExcel_5,

//modif end
										HOD.Designation);
//modif start					
								// If we keep the cell format from the existing cell in sheet

//modif ends							
								writableSheet_tFileOutputExcel_5.addCell(cell_4_tFileOutputExcel_5);
								int currentWith_4_tFileOutputExcel_5 = cell_4_tFileOutputExcel_5.getContents().trim()
										.length();
								fitWidth_tFileOutputExcel_5[4] = fitWidth_tFileOutputExcel_5[4] > currentWith_4_tFileOutputExcel_5
										? fitWidth_tFileOutputExcel_5[4]
										: currentWith_4_tFileOutputExcel_5 + 2;
							}

							if (HOD.Experience != null) {

//modif start

								columnIndex_tFileOutputExcel_5 = 5;

								jxl.write.WritableCell cell_5_tFileOutputExcel_5 = new jxl.write.Number(
										columnIndex_tFileOutputExcel_5,
										startRowNum_tFileOutputExcel_5 + nb_line_tFileOutputExcel_5,

//modif end
										HOD.Experience);
//modif start					
								// If we keep the cell format from the existing cell in sheet

//modif ends							
								writableSheet_tFileOutputExcel_5.addCell(cell_5_tFileOutputExcel_5);
								int currentWith_5_tFileOutputExcel_5 = String
										.valueOf(((jxl.write.Number) cell_5_tFileOutputExcel_5).getValue()).trim()
										.length();
								currentWith_5_tFileOutputExcel_5 = currentWith_5_tFileOutputExcel_5 > 10 ? 10
										: currentWith_5_tFileOutputExcel_5;
								fitWidth_tFileOutputExcel_5[5] = fitWidth_tFileOutputExcel_5[5] > currentWith_5_tFileOutputExcel_5
										? fitWidth_tFileOutputExcel_5[5]
										: currentWith_5_tFileOutputExcel_5 + 2;
							}

							nb_line_tFileOutputExcel_5++;

							log.debug("tFileOutputExcel_5 - Writing the record " + nb_line_tFileOutputExcel_5
									+ " to the file.");

							tos_count_tFileOutputExcel_5++;

							/**
							 * [tFileOutputExcel_5 main ] stop
							 */

							/**
							 * [tFileOutputExcel_5 process_data_begin ] start
							 */

							currentComponent = "tFileOutputExcel_5";

							cLabel = "HOD";

							/**
							 * [tFileOutputExcel_5 process_data_begin ] stop
							 */

							/**
							 * [tFileOutputExcel_5 process_data_end ] start
							 */

							currentComponent = "tFileOutputExcel_5";

							cLabel = "HOD";

							/**
							 * [tFileOutputExcel_5 process_data_end ] stop
							 */

						} // End of branch "HOD"

						/**
						 * [tMap_2 process_data_end ] start
						 */

						currentComponent = "tMap_2";

						/**
						 * [tMap_2 process_data_end ] stop
						 */

						/**
						 * [tDBInput_2 process_data_end ] start
						 */

						currentComponent = "tDBInput_2";

						cLabel = "Physician";

						/**
						 * [tDBInput_2 process_data_end ] stop
						 */

						/**
						 * [tDBInput_2 end ] start
						 */

						currentComponent = "tDBInput_2";

						cLabel = "Physician";

					}
				} finally {
					if (rs_tDBInput_2 != null) {
						rs_tDBInput_2.close();
					}
					if (stmt_tDBInput_2 != null) {
						stmt_tDBInput_2.close();
					}
					if (conn_tDBInput_2 != null && !conn_tDBInput_2.isClosed()) {

						log.debug("tDBInput_2 - Closing the connection to the database.");

						conn_tDBInput_2.close();

						if ("com.mysql.cj.jdbc.Driver".equals((String) globalMap.get("driverClass_"))
								&& routines.system.BundleUtils.inOSGi()) {
							Class.forName("com.mysql.cj.jdbc.AbandonedConnectionCleanupThread")
									.getMethod("checkedShutdown").invoke(null, (Object[]) null);
						}

						log.debug("tDBInput_2 - Connection to the database closed.");

					}

				}
				globalMap.put("tDBInput_2_NB_LINE", nb_line_tDBInput_2);
				log.debug("tDBInput_2 - Retrieved records count: " + nb_line_tDBInput_2 + " .");

				if (log.isDebugEnabled())
					log.debug("tDBInput_2 - " + ("Done."));

				ok_Hash.put("tDBInput_2", true);
				end_Hash.put("tDBInput_2", System.currentTimeMillis());

				/**
				 * [tDBInput_2 end ] stop
				 */

				/**
				 * [tMap_2 end ] start
				 */

				currentComponent = "tMap_2";

// ###############################
// # Lookup hashes releasing
// ###############################      
				log.debug("tMap_2 - Written records count in the table 'SurgeonDetails': " + count_SurgeonDetails_tMap_2
						+ ".");
				log.debug("tMap_2 - Written records count in the table 'SortData': " + count_SortData_tMap_2 + ".");
				log.debug("tMap_2 - Written records count in the table 'HOD': " + count_HOD_tMap_2 + ".");

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "row2", 2, 0,
						"tDBInput_2", "Physician", "tMysqlInput", "tMap_2", "tMap_2", "tMap", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tMap_2 - " + ("Done."));

				ok_Hash.put("tMap_2", true);
				end_Hash.put("tMap_2", System.currentTimeMillis());

				/**
				 * [tMap_2 end ] stop
				 */

				/**
				 * [tFileOutputExcel_3 end ] start
				 */

				currentComponent = "tFileOutputExcel_3";

				cLabel = "SurgeonDetails";

				columnIndex_tFileOutputExcel_3 = 0;

				// modif start

				writableSheet_tFileOutputExcel_3.setColumnView(columnIndex_tFileOutputExcel_3,
						fitWidth_tFileOutputExcel_3[0]);

				// modif end

				columnIndex_tFileOutputExcel_3 = 1;

				// modif start

				writableSheet_tFileOutputExcel_3.setColumnView(columnIndex_tFileOutputExcel_3,
						fitWidth_tFileOutputExcel_3[1]);

				// modif end

				columnIndex_tFileOutputExcel_3 = 2;

				// modif start

				writableSheet_tFileOutputExcel_3.setColumnView(columnIndex_tFileOutputExcel_3,
						fitWidth_tFileOutputExcel_3[2]);

				// modif end

				columnIndex_tFileOutputExcel_3 = 3;

				// modif start

				writableSheet_tFileOutputExcel_3.setColumnView(columnIndex_tFileOutputExcel_3,
						fitWidth_tFileOutputExcel_3[3]);

				// modif end

				columnIndex_tFileOutputExcel_3 = 4;

				// modif start

				writableSheet_tFileOutputExcel_3.setColumnView(columnIndex_tFileOutputExcel_3,
						fitWidth_tFileOutputExcel_3[4]);

				// modif end

				columnIndex_tFileOutputExcel_3 = 5;

				// modif start

				writableSheet_tFileOutputExcel_3.setColumnView(columnIndex_tFileOutputExcel_3,
						fitWidth_tFileOutputExcel_3[5]);

				// modif end

				writeableWorkbook_tFileOutputExcel_3.write();
				writeableWorkbook_tFileOutputExcel_3.close();
				if (headerIsInserted_tFileOutputExcel_3 && nb_line_tFileOutputExcel_3 > 0) {
					nb_line_tFileOutputExcel_3 = nb_line_tFileOutputExcel_3 - 1;
				}
				globalMap.put("tFileOutputExcel_3_NB_LINE", nb_line_tFileOutputExcel_3);

				log.debug("tFileOutputExcel_3 - Written records count: " + nb_line_tFileOutputExcel_3 + " .");

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "SurgeonDetails", 2, 0,
						"tMap_2", "tMap_2", "tMap", "tFileOutputExcel_3", "SurgeonDetails", "tFileOutputExcel",
						"output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tFileOutputExcel_3 - " + ("Done."));

				ok_Hash.put("tFileOutputExcel_3", true);
				end_Hash.put("tFileOutputExcel_3", System.currentTimeMillis());

				/**
				 * [tFileOutputExcel_3 end ] stop
				 */

				/**
				 * [tSortRow_1_SortOut end ] start
				 */

				currentVirtualComponent = "tSortRow_1";

				currentComponent = "tSortRow_1_SortOut";

				SortDataStruct[] array_tSortRow_1_SortOut = list_tSortRow_1_SortOut
						.toArray(new ComparableSortDataStruct[0]);

				java.util.Arrays.sort(array_tSortRow_1_SortOut);

				globalMap.put("tSortRow_1", array_tSortRow_1_SortOut);

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "SortData", 2, 0,
						"tMap_2", "tMap_2", "tMap", "tSortRow_1_SortOut", "tSortRow_1_SortOut", "tSortOut", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tSortRow_1_SortOut - " + ("Done."));

				ok_Hash.put("tSortRow_1_SortOut", true);
				end_Hash.put("tSortRow_1_SortOut", System.currentTimeMillis());

				/**
				 * [tSortRow_1_SortOut end ] stop
				 */

				/**
				 * [tFileOutputExcel_4 begin ] start
				 */

				ok_Hash.put("tFileOutputExcel_4", false);
				start_Hash.put("tFileOutputExcel_4", System.currentTimeMillis());

				currentComponent = "tFileOutputExcel_4";

				cLabel = "SortedData";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "row3");

				int tos_count_tFileOutputExcel_4 = 0;

				if (log.isDebugEnabled())
					log.debug("tFileOutputExcel_4 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tFileOutputExcel_4 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tFileOutputExcel_4 = new StringBuilder();
							log4jParamters_tFileOutputExcel_4.append("Parameters:");
							log4jParamters_tFileOutputExcel_4.append("VERSION_2007" + " = " + "false");
							log4jParamters_tFileOutputExcel_4.append(" | ");
							log4jParamters_tFileOutputExcel_4.append("USESTREAM" + " = " + "false");
							log4jParamters_tFileOutputExcel_4.append(" | ");
							log4jParamters_tFileOutputExcel_4
									.append("FILENAME" + " = " + "\"C:/Users/2382187/Downloads/FR/SortedData.xls\"");
							log4jParamters_tFileOutputExcel_4.append(" | ");
							log4jParamters_tFileOutputExcel_4.append("SHEETNAME" + " = " + "\"SortedData\"");
							log4jParamters_tFileOutputExcel_4.append(" | ");
							log4jParamters_tFileOutputExcel_4.append("INCLUDEHEADER" + " = " + "true");
							log4jParamters_tFileOutputExcel_4.append(" | ");
							log4jParamters_tFileOutputExcel_4.append("APPEND_FILE" + " = " + "false");
							log4jParamters_tFileOutputExcel_4.append(" | ");
							log4jParamters_tFileOutputExcel_4.append("FIRST_CELL_Y_ABSOLUTE" + " = " + "false");
							log4jParamters_tFileOutputExcel_4.append(" | ");
							log4jParamters_tFileOutputExcel_4.append("FONT" + " = " + "");
							log4jParamters_tFileOutputExcel_4.append(" | ");
							log4jParamters_tFileOutputExcel_4.append("IS_ALL_AUTO_SZIE" + " = " + "true");
							log4jParamters_tFileOutputExcel_4.append(" | ");
							log4jParamters_tFileOutputExcel_4.append("CREATE" + " = " + "true");
							log4jParamters_tFileOutputExcel_4.append(" | ");
							log4jParamters_tFileOutputExcel_4.append("ADVANCED_SEPARATOR" + " = " + "false");
							log4jParamters_tFileOutputExcel_4.append(" | ");
							log4jParamters_tFileOutputExcel_4.append("ENCODING" + " = " + "\"ISO-8859-15\"");
							log4jParamters_tFileOutputExcel_4.append(" | ");
							log4jParamters_tFileOutputExcel_4.append("DELETE_EMPTYFILE" + " = " + "false");
							log4jParamters_tFileOutputExcel_4.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tFileOutputExcel_4 - " + (log4jParamters_tFileOutputExcel_4));
						}
					}
					new BytesLimit65535_tFileOutputExcel_4().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tFileOutputExcel_4", "SortedData", "tFileOutputExcel");
					talendJobLogProcess(globalMap);
				}

				int columnIndex_tFileOutputExcel_4 = 0;
				boolean headerIsInserted_tFileOutputExcel_4 = false;

				int nb_line_tFileOutputExcel_4 = 0;

				String fileName_tFileOutputExcel_4 = "C:/Users/2382187/Downloads/FR/SortedData.xls";
				java.io.File file_tFileOutputExcel_4 = new java.io.File(fileName_tFileOutputExcel_4);
				boolean isFileGenerated_tFileOutputExcel_4 = true;
//create directory only if not exists
				java.io.File parentFile_tFileOutputExcel_4 = file_tFileOutputExcel_4.getParentFile();
				if (parentFile_tFileOutputExcel_4 != null && !parentFile_tFileOutputExcel_4.exists()) {

					log.info("tFileOutputExcel_4 - Creating directory '"
							+ parentFile_tFileOutputExcel_4.getCanonicalPath() + "'.");

					parentFile_tFileOutputExcel_4.mkdirs();

					log.info("tFileOutputExcel_4 - Create directory '"
							+ parentFile_tFileOutputExcel_4.getCanonicalPath() + "' has succeeded.");

				}

				jxl.write.WritableWorkbook writeableWorkbook_tFileOutputExcel_4 = null;
				jxl.write.WritableSheet writableSheet_tFileOutputExcel_4 = null;

				jxl.WorkbookSettings workbookSettings_tFileOutputExcel_4 = new jxl.WorkbookSettings();
				workbookSettings_tFileOutputExcel_4.setEncoding("ISO-8859-15");
				writeableWorkbook_tFileOutputExcel_4 = new jxl.write.biff.WritableWorkbookImpl(
						new java.io.BufferedOutputStream(new java.io.FileOutputStream(fileName_tFileOutputExcel_4)),
						true, workbookSettings_tFileOutputExcel_4);

				writableSheet_tFileOutputExcel_4 = writeableWorkbook_tFileOutputExcel_4.getSheet("SortedData");
				if (writableSheet_tFileOutputExcel_4 == null) {
					writableSheet_tFileOutputExcel_4 = writeableWorkbook_tFileOutputExcel_4.createSheet("SortedData",
							writeableWorkbook_tFileOutputExcel_4.getNumberOfSheets());
				}

				// modif start
				int startRowNum_tFileOutputExcel_4 = writableSheet_tFileOutputExcel_4.getRows();
				// modif end

				int[] fitWidth_tFileOutputExcel_4 = new int[6];
				for (int i_tFileOutputExcel_4 = 0; i_tFileOutputExcel_4 < 6; i_tFileOutputExcel_4++) {
					int fitCellViewSize_tFileOutputExcel_4 = writableSheet_tFileOutputExcel_4
							.getColumnView(i_tFileOutputExcel_4).getSize();
					fitWidth_tFileOutputExcel_4[i_tFileOutputExcel_4] = fitCellViewSize_tFileOutputExcel_4 / 256;
					if (fitCellViewSize_tFileOutputExcel_4 % 256 != 0) {
						fitWidth_tFileOutputExcel_4[i_tFileOutputExcel_4] += 1;
					}
				}

				final jxl.write.WritableCellFormat cell_format_DateOfJoining_tFileOutputExcel_4 = new jxl.write.WritableCellFormat(
						new jxl.write.DateFormat("dd-MM-yyyy"));

				if (startRowNum_tFileOutputExcel_4 == 0) {
					// modif end
					// modif start
					writableSheet_tFileOutputExcel_4
							.addCell(new jxl.write.Label(0, nb_line_tFileOutputExcel_4, "PhysicianID"));
					// modif end
					fitWidth_tFileOutputExcel_4[0] = fitWidth_tFileOutputExcel_4[0] > 11
							? fitWidth_tFileOutputExcel_4[0]
							: 11;
					// modif start
					writableSheet_tFileOutputExcel_4
							.addCell(new jxl.write.Label(1, nb_line_tFileOutputExcel_4, "Name"));
					// modif end
					fitWidth_tFileOutputExcel_4[1] = fitWidth_tFileOutputExcel_4[1] > 4 ? fitWidth_tFileOutputExcel_4[1]
							: 4;
					// modif start
					writableSheet_tFileOutputExcel_4
							.addCell(new jxl.write.Label(2, nb_line_tFileOutputExcel_4, "DateOfJoining"));
					// modif end
					fitWidth_tFileOutputExcel_4[2] = fitWidth_tFileOutputExcel_4[2] > 13
							? fitWidth_tFileOutputExcel_4[2]
							: 13;
					// modif start
					writableSheet_tFileOutputExcel_4
							.addCell(new jxl.write.Label(3, nb_line_tFileOutputExcel_4, "Specialty"));
					// modif end
					fitWidth_tFileOutputExcel_4[3] = fitWidth_tFileOutputExcel_4[3] > 9 ? fitWidth_tFileOutputExcel_4[3]
							: 9;
					// modif start
					writableSheet_tFileOutputExcel_4
							.addCell(new jxl.write.Label(4, nb_line_tFileOutputExcel_4, "Designation"));
					// modif end
					fitWidth_tFileOutputExcel_4[4] = fitWidth_tFileOutputExcel_4[4] > 11
							? fitWidth_tFileOutputExcel_4[4]
							: 11;
					// modif start
					writableSheet_tFileOutputExcel_4
							.addCell(new jxl.write.Label(5, nb_line_tFileOutputExcel_4, "Experience"));
					// modif end
					fitWidth_tFileOutputExcel_4[5] = fitWidth_tFileOutputExcel_4[5] > 10
							? fitWidth_tFileOutputExcel_4[5]
							: 10;
					nb_line_tFileOutputExcel_4++;
					headerIsInserted_tFileOutputExcel_4 = true;
				}

				/**
				 * [tFileOutputExcel_4 begin ] stop
				 */

				/**
				 * [tSortRow_1_SortIn begin ] start
				 */

				ok_Hash.put("tSortRow_1_SortIn", false);
				start_Hash.put("tSortRow_1_SortIn", System.currentTimeMillis());

				currentVirtualComponent = "tSortRow_1";

				currentComponent = "tSortRow_1_SortIn";

				int tos_count_tSortRow_1_SortIn = 0;

				if (log.isDebugEnabled())
					log.debug("tSortRow_1_SortIn - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tSortRow_1_SortIn {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tSortRow_1_SortIn = new StringBuilder();
							log4jParamters_tSortRow_1_SortIn.append("Parameters:");
							log4jParamters_tSortRow_1_SortIn.append("ORIGIN" + " = " + "tSortRow_1");
							log4jParamters_tSortRow_1_SortIn.append(" | ");
							log4jParamters_tSortRow_1_SortIn.append("EXTERNAL" + " = " + "false");
							log4jParamters_tSortRow_1_SortIn.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tSortRow_1_SortIn - " + (log4jParamters_tSortRow_1_SortIn));
						}
					}
					new BytesLimit65535_tSortRow_1_SortIn().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tSortRow_1_SortIn", "tSortRow_1_SortIn", "tSortIn");
					talendJobLogProcess(globalMap);
				}

				SortDataStruct[] array_tSortRow_1_SortIn = (SortDataStruct[]) globalMap.remove("tSortRow_1");

				int nb_line_tSortRow_1_SortIn = 0;

				SortDataStruct current_tSortRow_1_SortIn = null;

				for (int i_tSortRow_1_SortIn = 0; i_tSortRow_1_SortIn < array_tSortRow_1_SortIn.length; i_tSortRow_1_SortIn++) {
					current_tSortRow_1_SortIn = array_tSortRow_1_SortIn[i_tSortRow_1_SortIn];
					row3.PhysicianID = current_tSortRow_1_SortIn.PhysicianID;
					row3.Name = current_tSortRow_1_SortIn.Name;
					row3.DateOfJoining = current_tSortRow_1_SortIn.DateOfJoining;
					row3.Specialty = current_tSortRow_1_SortIn.Specialty;
					row3.Designation = current_tSortRow_1_SortIn.Designation;
					row3.Experience = current_tSortRow_1_SortIn.Experience;
					// increase number of line sorted
					nb_line_tSortRow_1_SortIn++;

					/**
					 * [tSortRow_1_SortIn begin ] stop
					 */

					/**
					 * [tSortRow_1_SortIn main ] start
					 */

					currentVirtualComponent = "tSortRow_1";

					currentComponent = "tSortRow_1_SortIn";

					tos_count_tSortRow_1_SortIn++;

					/**
					 * [tSortRow_1_SortIn main ] stop
					 */

					/**
					 * [tSortRow_1_SortIn process_data_begin ] start
					 */

					currentVirtualComponent = "tSortRow_1";

					currentComponent = "tSortRow_1_SortIn";

					/**
					 * [tSortRow_1_SortIn process_data_begin ] stop
					 */

					/**
					 * [tFileOutputExcel_4 main ] start
					 */

					currentComponent = "tFileOutputExcel_4";

					cLabel = "SortedData";

					if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

							, "row3", "tSortRow_1_SortIn", "tSortRow_1_SortIn", "tSortIn", "tFileOutputExcel_4",
							"SortedData", "tFileOutputExcel"

					)) {
						talendJobLogProcess(globalMap);
					}

					if (log.isTraceEnabled()) {
						log.trace("row3 - " + (row3 == null ? "" : row3.toLogString()));
					}

//modif start

					columnIndex_tFileOutputExcel_4 = 0;

					jxl.write.WritableCell cell_0_tFileOutputExcel_4 = new jxl.write.Number(
							columnIndex_tFileOutputExcel_4, startRowNum_tFileOutputExcel_4 + nb_line_tFileOutputExcel_4,

//modif end
							row3.PhysicianID);
//modif start					
					// If we keep the cell format from the existing cell in sheet

//modif ends							
					writableSheet_tFileOutputExcel_4.addCell(cell_0_tFileOutputExcel_4);
					int currentWith_0_tFileOutputExcel_4 = String
							.valueOf(((jxl.write.Number) cell_0_tFileOutputExcel_4).getValue()).trim().length();
					currentWith_0_tFileOutputExcel_4 = currentWith_0_tFileOutputExcel_4 > 10 ? 10
							: currentWith_0_tFileOutputExcel_4;
					fitWidth_tFileOutputExcel_4[0] = fitWidth_tFileOutputExcel_4[0] > currentWith_0_tFileOutputExcel_4
							? fitWidth_tFileOutputExcel_4[0]
							: currentWith_0_tFileOutputExcel_4 + 2;

					if (row3.Name != null) {

//modif start

						columnIndex_tFileOutputExcel_4 = 1;

						jxl.write.WritableCell cell_1_tFileOutputExcel_4 = new jxl.write.Label(
								columnIndex_tFileOutputExcel_4,
								startRowNum_tFileOutputExcel_4 + nb_line_tFileOutputExcel_4,

//modif end
								row3.Name);
//modif start					
						// If we keep the cell format from the existing cell in sheet

//modif ends							
						writableSheet_tFileOutputExcel_4.addCell(cell_1_tFileOutputExcel_4);
						int currentWith_1_tFileOutputExcel_4 = cell_1_tFileOutputExcel_4.getContents().trim().length();
						fitWidth_tFileOutputExcel_4[1] = fitWidth_tFileOutputExcel_4[1] > currentWith_1_tFileOutputExcel_4
								? fitWidth_tFileOutputExcel_4[1]
								: currentWith_1_tFileOutputExcel_4 + 2;
					}

					if (row3.DateOfJoining != null) {

//modif start

						columnIndex_tFileOutputExcel_4 = 2;

						jxl.write.WritableCell cell_2_tFileOutputExcel_4 = new jxl.write.DateTime(
								columnIndex_tFileOutputExcel_4,
								startRowNum_tFileOutputExcel_4 + nb_line_tFileOutputExcel_4,

//modif end
								row3.DateOfJoining, cell_format_DateOfJoining_tFileOutputExcel_4);
//modif start					
						// If we keep the cell format from the existing cell in sheet

//modif ends							
						writableSheet_tFileOutputExcel_4.addCell(cell_2_tFileOutputExcel_4);
						int currentWith_2_tFileOutputExcel_4 = cell_2_tFileOutputExcel_4.getContents().trim().length();
						currentWith_2_tFileOutputExcel_4 = 12;
						fitWidth_tFileOutputExcel_4[2] = fitWidth_tFileOutputExcel_4[2] > currentWith_2_tFileOutputExcel_4
								? fitWidth_tFileOutputExcel_4[2]
								: currentWith_2_tFileOutputExcel_4 + 2;
					}

					if (row3.Specialty != null) {

//modif start

						columnIndex_tFileOutputExcel_4 = 3;

						jxl.write.WritableCell cell_3_tFileOutputExcel_4 = new jxl.write.Label(
								columnIndex_tFileOutputExcel_4,
								startRowNum_tFileOutputExcel_4 + nb_line_tFileOutputExcel_4,

//modif end
								row3.Specialty);
//modif start					
						// If we keep the cell format from the existing cell in sheet

//modif ends							
						writableSheet_tFileOutputExcel_4.addCell(cell_3_tFileOutputExcel_4);
						int currentWith_3_tFileOutputExcel_4 = cell_3_tFileOutputExcel_4.getContents().trim().length();
						fitWidth_tFileOutputExcel_4[3] = fitWidth_tFileOutputExcel_4[3] > currentWith_3_tFileOutputExcel_4
								? fitWidth_tFileOutputExcel_4[3]
								: currentWith_3_tFileOutputExcel_4 + 2;
					}

					if (row3.Designation != null) {

//modif start

						columnIndex_tFileOutputExcel_4 = 4;

						jxl.write.WritableCell cell_4_tFileOutputExcel_4 = new jxl.write.Label(
								columnIndex_tFileOutputExcel_4,
								startRowNum_tFileOutputExcel_4 + nb_line_tFileOutputExcel_4,

//modif end
								row3.Designation);
//modif start					
						// If we keep the cell format from the existing cell in sheet

//modif ends							
						writableSheet_tFileOutputExcel_4.addCell(cell_4_tFileOutputExcel_4);
						int currentWith_4_tFileOutputExcel_4 = cell_4_tFileOutputExcel_4.getContents().trim().length();
						fitWidth_tFileOutputExcel_4[4] = fitWidth_tFileOutputExcel_4[4] > currentWith_4_tFileOutputExcel_4
								? fitWidth_tFileOutputExcel_4[4]
								: currentWith_4_tFileOutputExcel_4 + 2;
					}

					if (row3.Experience != null) {

//modif start

						columnIndex_tFileOutputExcel_4 = 5;

						jxl.write.WritableCell cell_5_tFileOutputExcel_4 = new jxl.write.Number(
								columnIndex_tFileOutputExcel_4,
								startRowNum_tFileOutputExcel_4 + nb_line_tFileOutputExcel_4,

//modif end
								row3.Experience);
//modif start					
						// If we keep the cell format from the existing cell in sheet

//modif ends							
						writableSheet_tFileOutputExcel_4.addCell(cell_5_tFileOutputExcel_4);
						int currentWith_5_tFileOutputExcel_4 = String
								.valueOf(((jxl.write.Number) cell_5_tFileOutputExcel_4).getValue()).trim().length();
						currentWith_5_tFileOutputExcel_4 = currentWith_5_tFileOutputExcel_4 > 10 ? 10
								: currentWith_5_tFileOutputExcel_4;
						fitWidth_tFileOutputExcel_4[5] = fitWidth_tFileOutputExcel_4[5] > currentWith_5_tFileOutputExcel_4
								? fitWidth_tFileOutputExcel_4[5]
								: currentWith_5_tFileOutputExcel_4 + 2;
					}

					nb_line_tFileOutputExcel_4++;

					log.debug(
							"tFileOutputExcel_4 - Writing the record " + nb_line_tFileOutputExcel_4 + " to the file.");

					tos_count_tFileOutputExcel_4++;

					/**
					 * [tFileOutputExcel_4 main ] stop
					 */

					/**
					 * [tFileOutputExcel_4 process_data_begin ] start
					 */

					currentComponent = "tFileOutputExcel_4";

					cLabel = "SortedData";

					/**
					 * [tFileOutputExcel_4 process_data_begin ] stop
					 */

					/**
					 * [tFileOutputExcel_4 process_data_end ] start
					 */

					currentComponent = "tFileOutputExcel_4";

					cLabel = "SortedData";

					/**
					 * [tFileOutputExcel_4 process_data_end ] stop
					 */

					/**
					 * [tSortRow_1_SortIn process_data_end ] start
					 */

					currentVirtualComponent = "tSortRow_1";

					currentComponent = "tSortRow_1_SortIn";

					/**
					 * [tSortRow_1_SortIn process_data_end ] stop
					 */

					/**
					 * [tSortRow_1_SortIn end ] start
					 */

					currentVirtualComponent = "tSortRow_1";

					currentComponent = "tSortRow_1_SortIn";

				}

				globalMap.put("tSortRow_1_SortIn_NB_LINE", nb_line_tSortRow_1_SortIn);

				if (log.isDebugEnabled())
					log.debug("tSortRow_1_SortIn - " + ("Done."));

				ok_Hash.put("tSortRow_1_SortIn", true);
				end_Hash.put("tSortRow_1_SortIn", System.currentTimeMillis());

				/**
				 * [tSortRow_1_SortIn end ] stop
				 */

				/**
				 * [tFileOutputExcel_4 end ] start
				 */

				currentComponent = "tFileOutputExcel_4";

				cLabel = "SortedData";

				columnIndex_tFileOutputExcel_4 = 0;

				// modif start

				writableSheet_tFileOutputExcel_4.setColumnView(columnIndex_tFileOutputExcel_4,
						fitWidth_tFileOutputExcel_4[0]);

				// modif end

				columnIndex_tFileOutputExcel_4 = 1;

				// modif start

				writableSheet_tFileOutputExcel_4.setColumnView(columnIndex_tFileOutputExcel_4,
						fitWidth_tFileOutputExcel_4[1]);

				// modif end

				columnIndex_tFileOutputExcel_4 = 2;

				// modif start

				writableSheet_tFileOutputExcel_4.setColumnView(columnIndex_tFileOutputExcel_4,
						fitWidth_tFileOutputExcel_4[2]);

				// modif end

				columnIndex_tFileOutputExcel_4 = 3;

				// modif start

				writableSheet_tFileOutputExcel_4.setColumnView(columnIndex_tFileOutputExcel_4,
						fitWidth_tFileOutputExcel_4[3]);

				// modif end

				columnIndex_tFileOutputExcel_4 = 4;

				// modif start

				writableSheet_tFileOutputExcel_4.setColumnView(columnIndex_tFileOutputExcel_4,
						fitWidth_tFileOutputExcel_4[4]);

				// modif end

				columnIndex_tFileOutputExcel_4 = 5;

				// modif start

				writableSheet_tFileOutputExcel_4.setColumnView(columnIndex_tFileOutputExcel_4,
						fitWidth_tFileOutputExcel_4[5]);

				// modif end

				writeableWorkbook_tFileOutputExcel_4.write();
				writeableWorkbook_tFileOutputExcel_4.close();
				if (headerIsInserted_tFileOutputExcel_4 && nb_line_tFileOutputExcel_4 > 0) {
					nb_line_tFileOutputExcel_4 = nb_line_tFileOutputExcel_4 - 1;
				}
				globalMap.put("tFileOutputExcel_4_NB_LINE", nb_line_tFileOutputExcel_4);

				log.debug("tFileOutputExcel_4 - Written records count: " + nb_line_tFileOutputExcel_4 + " .");

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "row3", 2, 0,
						"tSortRow_1_SortIn", "tSortRow_1_SortIn", "tSortIn", "tFileOutputExcel_4", "SortedData",
						"tFileOutputExcel", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tFileOutputExcel_4 - " + ("Done."));

				ok_Hash.put("tFileOutputExcel_4", true);
				end_Hash.put("tFileOutputExcel_4", System.currentTimeMillis());

				/**
				 * [tFileOutputExcel_4 end ] stop
				 */

				/**
				 * [tFileOutputExcel_5 end ] start
				 */

				currentComponent = "tFileOutputExcel_5";

				cLabel = "HOD";

				columnIndex_tFileOutputExcel_5 = 0;

				// modif start

				writableSheet_tFileOutputExcel_5.setColumnView(columnIndex_tFileOutputExcel_5,
						fitWidth_tFileOutputExcel_5[0]);

				// modif end

				columnIndex_tFileOutputExcel_5 = 1;

				// modif start

				writableSheet_tFileOutputExcel_5.setColumnView(columnIndex_tFileOutputExcel_5,
						fitWidth_tFileOutputExcel_5[1]);

				// modif end

				columnIndex_tFileOutputExcel_5 = 2;

				// modif start

				writableSheet_tFileOutputExcel_5.setColumnView(columnIndex_tFileOutputExcel_5,
						fitWidth_tFileOutputExcel_5[2]);

				// modif end

				columnIndex_tFileOutputExcel_5 = 3;

				// modif start

				writableSheet_tFileOutputExcel_5.setColumnView(columnIndex_tFileOutputExcel_5,
						fitWidth_tFileOutputExcel_5[3]);

				// modif end

				columnIndex_tFileOutputExcel_5 = 4;

				// modif start

				writableSheet_tFileOutputExcel_5.setColumnView(columnIndex_tFileOutputExcel_5,
						fitWidth_tFileOutputExcel_5[4]);

				// modif end

				columnIndex_tFileOutputExcel_5 = 5;

				// modif start

				writableSheet_tFileOutputExcel_5.setColumnView(columnIndex_tFileOutputExcel_5,
						fitWidth_tFileOutputExcel_5[5]);

				// modif end

				writeableWorkbook_tFileOutputExcel_5.write();
				writeableWorkbook_tFileOutputExcel_5.close();
				if (headerIsInserted_tFileOutputExcel_5 && nb_line_tFileOutputExcel_5 > 0) {
					nb_line_tFileOutputExcel_5 = nb_line_tFileOutputExcel_5 - 1;
				}
				globalMap.put("tFileOutputExcel_5_NB_LINE", nb_line_tFileOutputExcel_5);

				log.debug("tFileOutputExcel_5 - Written records count: " + nb_line_tFileOutputExcel_5 + " .");

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "HOD", 2, 0, "tMap_2",
						"tMap_2", "tMap", "tFileOutputExcel_5", "HOD", "tFileOutputExcel", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tFileOutputExcel_5 - " + ("Done."));

				ok_Hash.put("tFileOutputExcel_5", true);
				end_Hash.put("tFileOutputExcel_5", System.currentTimeMillis());

				/**
				 * [tFileOutputExcel_5 end ] stop
				 */

			} // end the resume

			if (resumeEntryMethodName == null || globalResumeTicket) {
				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tDBInput_2:OnSubjobOk", "",
						Thread.currentThread().getId() + "", "", "", "", "", "");
			}

			if (execStat) {
				runStat.updateStatOnConnection("OnSubjobOk2", 0, "ok");
			}

			tDBInput_3Process(globalMap);

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage(), e);
			}

			TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);

			te.setVirtualComponentName(currentVirtualComponent);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			// free memory for "tSortRow_1_SortIn"
			globalMap.remove("tSortRow_1");

			try {

				/**
				 * [tDBInput_2 finally ] start
				 */

				currentComponent = "tDBInput_2";

				cLabel = "Physician";

				/**
				 * [tDBInput_2 finally ] stop
				 */

				/**
				 * [tMap_2 finally ] start
				 */

				currentComponent = "tMap_2";

				/**
				 * [tMap_2 finally ] stop
				 */

				/**
				 * [tFileOutputExcel_3 finally ] start
				 */

				currentComponent = "tFileOutputExcel_3";

				cLabel = "SurgeonDetails";

				/**
				 * [tFileOutputExcel_3 finally ] stop
				 */

				/**
				 * [tSortRow_1_SortOut finally ] start
				 */

				currentVirtualComponent = "tSortRow_1";

				currentComponent = "tSortRow_1_SortOut";

				/**
				 * [tSortRow_1_SortOut finally ] stop
				 */

				/**
				 * [tSortRow_1_SortIn finally ] start
				 */

				currentVirtualComponent = "tSortRow_1";

				currentComponent = "tSortRow_1_SortIn";

				/**
				 * [tSortRow_1_SortIn finally ] stop
				 */

				/**
				 * [tFileOutputExcel_4 finally ] start
				 */

				currentComponent = "tFileOutputExcel_4";

				cLabel = "SortedData";

				/**
				 * [tFileOutputExcel_4 finally ] stop
				 */

				/**
				 * [tFileOutputExcel_5 finally ] start
				 */

				currentComponent = "tFileOutputExcel_5";

				cLabel = "HOD";

				/**
				 * [tFileOutputExcel_5 finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tDBInput_2_SUBPROCESS_STATE", 1);
	}

	public static class row5Struct implements routines.system.IPersistableRow<row5Struct> {
		final static byte[] commonByteArrayLock_HMS_FunctionalRequirement = new byte[0];
		static byte[] commonByteArray_HMS_FunctionalRequirement = new byte[0];

		public Integer AppointmentID;

		public Integer getAppointmentID() {
			return this.AppointmentID;
		}

		public Boolean AppointmentIDIsNullable() {
			return true;
		}

		public Boolean AppointmentIDIsKey() {
			return false;
		}

		public Integer AppointmentIDLength() {
			return 10;
		}

		public Integer AppointmentIDPrecision() {
			return 0;
		}

		public String AppointmentIDDefault() {

			return null;

		}

		public String AppointmentIDComment() {

			return "";

		}

		public String AppointmentIDPattern() {

			return "";

		}

		public String AppointmentIDOriginalDbColumnName() {

			return "AppointmentID";

		}

		public Integer PatientID;

		public Integer getPatientID() {
			return this.PatientID;
		}

		public Boolean PatientIDIsNullable() {
			return true;
		}

		public Boolean PatientIDIsKey() {
			return false;
		}

		public Integer PatientIDLength() {
			return 10;
		}

		public Integer PatientIDPrecision() {
			return 0;
		}

		public String PatientIDDefault() {

			return null;

		}

		public String PatientIDComment() {

			return "";

		}

		public String PatientIDPattern() {

			return "";

		}

		public String PatientIDOriginalDbColumnName() {

			return "PatientID";

		}

		public Integer PhysicianID;

		public Integer getPhysicianID() {
			return this.PhysicianID;
		}

		public Boolean PhysicianIDIsNullable() {
			return true;
		}

		public Boolean PhysicianIDIsKey() {
			return false;
		}

		public Integer PhysicianIDLength() {
			return 10;
		}

		public Integer PhysicianIDPrecision() {
			return 0;
		}

		public String PhysicianIDDefault() {

			return null;

		}

		public String PhysicianIDComment() {

			return "";

		}

		public String PhysicianIDPattern() {

			return "";

		}

		public String PhysicianIDOriginalDbColumnName() {

			return "PhysicianID";

		}

		public java.util.Date StartDateTime;

		public java.util.Date getStartDateTime() {
			return this.StartDateTime;
		}

		public Boolean StartDateTimeIsNullable() {
			return true;
		}

		public Boolean StartDateTimeIsKey() {
			return false;
		}

		public Integer StartDateTimeLength() {
			return 19;
		}

		public Integer StartDateTimePrecision() {
			return 0;
		}

		public String StartDateTimeDefault() {

			return null;

		}

		public String StartDateTimeComment() {

			return "";

		}

		public String StartDateTimePattern() {

			return "dd-MM-yyyy";

		}

		public String StartDateTimeOriginalDbColumnName() {

			return "StartDateTime";

		}

		public String ExaminationRoom;

		public String getExaminationRoom() {
			return this.ExaminationRoom;
		}

		public Boolean ExaminationRoomIsNullable() {
			return true;
		}

		public Boolean ExaminationRoomIsKey() {
			return false;
		}

		public Integer ExaminationRoomLength() {
			return 30;
		}

		public Integer ExaminationRoomPrecision() {
			return 0;
		}

		public String ExaminationRoomDefault() {

			return null;

		}

		public String ExaminationRoomComment() {

			return "";

		}

		public String ExaminationRoomPattern() {

			return "";

		}

		public String ExaminationRoomOriginalDbColumnName() {

			return "ExaminationRoom";

		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_HMS_FunctionalRequirement.length) {
					if (length < 1024 && commonByteArray_HMS_FunctionalRequirement.length == 0) {
						commonByteArray_HMS_FunctionalRequirement = new byte[1024];
					} else {
						commonByteArray_HMS_FunctionalRequirement = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_HMS_FunctionalRequirement, 0, length);
				strReturn = new String(commonByteArray_HMS_FunctionalRequirement, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_HMS_FunctionalRequirement.length) {
					if (length < 1024 && commonByteArray_HMS_FunctionalRequirement.length == 0) {
						commonByteArray_HMS_FunctionalRequirement = new byte[1024];
					} else {
						commonByteArray_HMS_FunctionalRequirement = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_HMS_FunctionalRequirement, 0, length);
				strReturn = new String(commonByteArray_HMS_FunctionalRequirement, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_HMS_FunctionalRequirement) {

				try {

					int length = 0;

					this.AppointmentID = readInteger(dis);

					this.PatientID = readInteger(dis);

					this.PhysicianID = readInteger(dis);

					this.StartDateTime = readDate(dis);

					this.ExaminationRoom = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_HMS_FunctionalRequirement) {

				try {

					int length = 0;

					this.AppointmentID = readInteger(dis);

					this.PatientID = readInteger(dis);

					this.PhysicianID = readInteger(dis);

					this.StartDateTime = readDate(dis);

					this.ExaminationRoom = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.AppointmentID, dos);

				// Integer

				writeInteger(this.PatientID, dos);

				// Integer

				writeInteger(this.PhysicianID, dos);

				// java.util.Date

				writeDate(this.StartDateTime, dos);

				// String

				writeString(this.ExaminationRoom, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.AppointmentID, dos);

				// Integer

				writeInteger(this.PatientID, dos);

				// Integer

				writeInteger(this.PhysicianID, dos);

				// java.util.Date

				writeDate(this.StartDateTime, dos);

				// String

				writeString(this.ExaminationRoom, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("AppointmentID=" + String.valueOf(AppointmentID));
			sb.append(",PatientID=" + String.valueOf(PatientID));
			sb.append(",PhysicianID=" + String.valueOf(PhysicianID));
			sb.append(",StartDateTime=" + String.valueOf(StartDateTime));
			sb.append(",ExaminationRoom=" + ExaminationRoom);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (AppointmentID == null) {
				sb.append("<null>");
			} else {
				sb.append(AppointmentID);
			}

			sb.append("|");

			if (PatientID == null) {
				sb.append("<null>");
			} else {
				sb.append(PatientID);
			}

			sb.append("|");

			if (PhysicianID == null) {
				sb.append("<null>");
			} else {
				sb.append(PhysicianID);
			}

			sb.append("|");

			if (StartDateTime == null) {
				sb.append("<null>");
			} else {
				sb.append(StartDateTime);
			}

			sb.append("|");

			if (ExaminationRoom == null) {
				sb.append("<null>");
			} else {
				sb.append(ExaminationRoom);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row5Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class OnRowsEndStructtSortRow_2
			implements routines.system.IPersistableRow<OnRowsEndStructtSortRow_2> {
		final static byte[] commonByteArrayLock_HMS_FunctionalRequirement = new byte[0];
		static byte[] commonByteArray_HMS_FunctionalRequirement = new byte[0];

		public Integer AppointmentID;

		public Integer getAppointmentID() {
			return this.AppointmentID;
		}

		public Boolean AppointmentIDIsNullable() {
			return true;
		}

		public Boolean AppointmentIDIsKey() {
			return false;
		}

		public Integer AppointmentIDLength() {
			return 10;
		}

		public Integer AppointmentIDPrecision() {
			return 0;
		}

		public String AppointmentIDDefault() {

			return null;

		}

		public String AppointmentIDComment() {

			return "";

		}

		public String AppointmentIDPattern() {

			return "";

		}

		public String AppointmentIDOriginalDbColumnName() {

			return "AppointmentID";

		}

		public Integer PatientID;

		public Integer getPatientID() {
			return this.PatientID;
		}

		public Boolean PatientIDIsNullable() {
			return true;
		}

		public Boolean PatientIDIsKey() {
			return false;
		}

		public Integer PatientIDLength() {
			return 10;
		}

		public Integer PatientIDPrecision() {
			return 0;
		}

		public String PatientIDDefault() {

			return null;

		}

		public String PatientIDComment() {

			return "";

		}

		public String PatientIDPattern() {

			return "";

		}

		public String PatientIDOriginalDbColumnName() {

			return "PatientID";

		}

		public Integer PhysicianID;

		public Integer getPhysicianID() {
			return this.PhysicianID;
		}

		public Boolean PhysicianIDIsNullable() {
			return true;
		}

		public Boolean PhysicianIDIsKey() {
			return false;
		}

		public Integer PhysicianIDLength() {
			return 10;
		}

		public Integer PhysicianIDPrecision() {
			return 0;
		}

		public String PhysicianIDDefault() {

			return null;

		}

		public String PhysicianIDComment() {

			return "";

		}

		public String PhysicianIDPattern() {

			return "";

		}

		public String PhysicianIDOriginalDbColumnName() {

			return "PhysicianID";

		}

		public java.util.Date StartDateTime;

		public java.util.Date getStartDateTime() {
			return this.StartDateTime;
		}

		public Boolean StartDateTimeIsNullable() {
			return true;
		}

		public Boolean StartDateTimeIsKey() {
			return false;
		}

		public Integer StartDateTimeLength() {
			return 19;
		}

		public Integer StartDateTimePrecision() {
			return 0;
		}

		public String StartDateTimeDefault() {

			return null;

		}

		public String StartDateTimeComment() {

			return "";

		}

		public String StartDateTimePattern() {

			return "dd-MM-yyyy";

		}

		public String StartDateTimeOriginalDbColumnName() {

			return "StartDateTime";

		}

		public String ExaminationRoom;

		public String getExaminationRoom() {
			return this.ExaminationRoom;
		}

		public Boolean ExaminationRoomIsNullable() {
			return true;
		}

		public Boolean ExaminationRoomIsKey() {
			return false;
		}

		public Integer ExaminationRoomLength() {
			return 30;
		}

		public Integer ExaminationRoomPrecision() {
			return 0;
		}

		public String ExaminationRoomDefault() {

			return null;

		}

		public String ExaminationRoomComment() {

			return "";

		}

		public String ExaminationRoomPattern() {

			return "";

		}

		public String ExaminationRoomOriginalDbColumnName() {

			return "ExaminationRoom";

		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_HMS_FunctionalRequirement.length) {
					if (length < 1024 && commonByteArray_HMS_FunctionalRequirement.length == 0) {
						commonByteArray_HMS_FunctionalRequirement = new byte[1024];
					} else {
						commonByteArray_HMS_FunctionalRequirement = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_HMS_FunctionalRequirement, 0, length);
				strReturn = new String(commonByteArray_HMS_FunctionalRequirement, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_HMS_FunctionalRequirement.length) {
					if (length < 1024 && commonByteArray_HMS_FunctionalRequirement.length == 0) {
						commonByteArray_HMS_FunctionalRequirement = new byte[1024];
					} else {
						commonByteArray_HMS_FunctionalRequirement = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_HMS_FunctionalRequirement, 0, length);
				strReturn = new String(commonByteArray_HMS_FunctionalRequirement, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_HMS_FunctionalRequirement) {

				try {

					int length = 0;

					this.AppointmentID = readInteger(dis);

					this.PatientID = readInteger(dis);

					this.PhysicianID = readInteger(dis);

					this.StartDateTime = readDate(dis);

					this.ExaminationRoom = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_HMS_FunctionalRequirement) {

				try {

					int length = 0;

					this.AppointmentID = readInteger(dis);

					this.PatientID = readInteger(dis);

					this.PhysicianID = readInteger(dis);

					this.StartDateTime = readDate(dis);

					this.ExaminationRoom = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.AppointmentID, dos);

				// Integer

				writeInteger(this.PatientID, dos);

				// Integer

				writeInteger(this.PhysicianID, dos);

				// java.util.Date

				writeDate(this.StartDateTime, dos);

				// String

				writeString(this.ExaminationRoom, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.AppointmentID, dos);

				// Integer

				writeInteger(this.PatientID, dos);

				// Integer

				writeInteger(this.PhysicianID, dos);

				// java.util.Date

				writeDate(this.StartDateTime, dos);

				// String

				writeString(this.ExaminationRoom, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("AppointmentID=" + String.valueOf(AppointmentID));
			sb.append(",PatientID=" + String.valueOf(PatientID));
			sb.append(",PhysicianID=" + String.valueOf(PhysicianID));
			sb.append(",StartDateTime=" + String.valueOf(StartDateTime));
			sb.append(",ExaminationRoom=" + ExaminationRoom);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (AppointmentID == null) {
				sb.append("<null>");
			} else {
				sb.append(AppointmentID);
			}

			sb.append("|");

			if (PatientID == null) {
				sb.append("<null>");
			} else {
				sb.append(PatientID);
			}

			sb.append("|");

			if (PhysicianID == null) {
				sb.append("<null>");
			} else {
				sb.append(PhysicianID);
			}

			sb.append("|");

			if (StartDateTime == null) {
				sb.append("<null>");
			} else {
				sb.append(StartDateTime);
			}

			sb.append("|");

			if (ExaminationRoom == null) {
				sb.append("<null>");
			} else {
				sb.append(ExaminationRoom);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(OnRowsEndStructtSortRow_2 other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class TodaysAppointmentStruct implements routines.system.IPersistableRow<TodaysAppointmentStruct> {
		final static byte[] commonByteArrayLock_HMS_FunctionalRequirement = new byte[0];
		static byte[] commonByteArray_HMS_FunctionalRequirement = new byte[0];

		public Integer AppointmentID;

		public Integer getAppointmentID() {
			return this.AppointmentID;
		}

		public Boolean AppointmentIDIsNullable() {
			return true;
		}

		public Boolean AppointmentIDIsKey() {
			return false;
		}

		public Integer AppointmentIDLength() {
			return 10;
		}

		public Integer AppointmentIDPrecision() {
			return 0;
		}

		public String AppointmentIDDefault() {

			return null;

		}

		public String AppointmentIDComment() {

			return "";

		}

		public String AppointmentIDPattern() {

			return "";

		}

		public String AppointmentIDOriginalDbColumnName() {

			return "AppointmentID";

		}

		public Integer PatientID;

		public Integer getPatientID() {
			return this.PatientID;
		}

		public Boolean PatientIDIsNullable() {
			return true;
		}

		public Boolean PatientIDIsKey() {
			return false;
		}

		public Integer PatientIDLength() {
			return 10;
		}

		public Integer PatientIDPrecision() {
			return 0;
		}

		public String PatientIDDefault() {

			return null;

		}

		public String PatientIDComment() {

			return "";

		}

		public String PatientIDPattern() {

			return "";

		}

		public String PatientIDOriginalDbColumnName() {

			return "PatientID";

		}

		public Integer PhysicianID;

		public Integer getPhysicianID() {
			return this.PhysicianID;
		}

		public Boolean PhysicianIDIsNullable() {
			return true;
		}

		public Boolean PhysicianIDIsKey() {
			return false;
		}

		public Integer PhysicianIDLength() {
			return 10;
		}

		public Integer PhysicianIDPrecision() {
			return 0;
		}

		public String PhysicianIDDefault() {

			return null;

		}

		public String PhysicianIDComment() {

			return "";

		}

		public String PhysicianIDPattern() {

			return "";

		}

		public String PhysicianIDOriginalDbColumnName() {

			return "PhysicianID";

		}

		public java.util.Date StartDateTime;

		public java.util.Date getStartDateTime() {
			return this.StartDateTime;
		}

		public Boolean StartDateTimeIsNullable() {
			return true;
		}

		public Boolean StartDateTimeIsKey() {
			return false;
		}

		public Integer StartDateTimeLength() {
			return 19;
		}

		public Integer StartDateTimePrecision() {
			return 0;
		}

		public String StartDateTimeDefault() {

			return null;

		}

		public String StartDateTimeComment() {

			return "";

		}

		public String StartDateTimePattern() {

			return "dd-MM-yyyy";

		}

		public String StartDateTimeOriginalDbColumnName() {

			return "StartDateTime";

		}

		public String ExaminationRoom;

		public String getExaminationRoom() {
			return this.ExaminationRoom;
		}

		public Boolean ExaminationRoomIsNullable() {
			return true;
		}

		public Boolean ExaminationRoomIsKey() {
			return false;
		}

		public Integer ExaminationRoomLength() {
			return 30;
		}

		public Integer ExaminationRoomPrecision() {
			return 0;
		}

		public String ExaminationRoomDefault() {

			return null;

		}

		public String ExaminationRoomComment() {

			return "";

		}

		public String ExaminationRoomPattern() {

			return "";

		}

		public String ExaminationRoomOriginalDbColumnName() {

			return "ExaminationRoom";

		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_HMS_FunctionalRequirement.length) {
					if (length < 1024 && commonByteArray_HMS_FunctionalRequirement.length == 0) {
						commonByteArray_HMS_FunctionalRequirement = new byte[1024];
					} else {
						commonByteArray_HMS_FunctionalRequirement = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_HMS_FunctionalRequirement, 0, length);
				strReturn = new String(commonByteArray_HMS_FunctionalRequirement, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_HMS_FunctionalRequirement.length) {
					if (length < 1024 && commonByteArray_HMS_FunctionalRequirement.length == 0) {
						commonByteArray_HMS_FunctionalRequirement = new byte[1024];
					} else {
						commonByteArray_HMS_FunctionalRequirement = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_HMS_FunctionalRequirement, 0, length);
				strReturn = new String(commonByteArray_HMS_FunctionalRequirement, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_HMS_FunctionalRequirement) {

				try {

					int length = 0;

					this.AppointmentID = readInteger(dis);

					this.PatientID = readInteger(dis);

					this.PhysicianID = readInteger(dis);

					this.StartDateTime = readDate(dis);

					this.ExaminationRoom = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_HMS_FunctionalRequirement) {

				try {

					int length = 0;

					this.AppointmentID = readInteger(dis);

					this.PatientID = readInteger(dis);

					this.PhysicianID = readInteger(dis);

					this.StartDateTime = readDate(dis);

					this.ExaminationRoom = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.AppointmentID, dos);

				// Integer

				writeInteger(this.PatientID, dos);

				// Integer

				writeInteger(this.PhysicianID, dos);

				// java.util.Date

				writeDate(this.StartDateTime, dos);

				// String

				writeString(this.ExaminationRoom, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.AppointmentID, dos);

				// Integer

				writeInteger(this.PatientID, dos);

				// Integer

				writeInteger(this.PhysicianID, dos);

				// java.util.Date

				writeDate(this.StartDateTime, dos);

				// String

				writeString(this.ExaminationRoom, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("AppointmentID=" + String.valueOf(AppointmentID));
			sb.append(",PatientID=" + String.valueOf(PatientID));
			sb.append(",PhysicianID=" + String.valueOf(PhysicianID));
			sb.append(",StartDateTime=" + String.valueOf(StartDateTime));
			sb.append(",ExaminationRoom=" + ExaminationRoom);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (AppointmentID == null) {
				sb.append("<null>");
			} else {
				sb.append(AppointmentID);
			}

			sb.append("|");

			if (PatientID == null) {
				sb.append("<null>");
			} else {
				sb.append(PatientID);
			}

			sb.append("|");

			if (PhysicianID == null) {
				sb.append("<null>");
			} else {
				sb.append(PhysicianID);
			}

			sb.append("|");

			if (StartDateTime == null) {
				sb.append("<null>");
			} else {
				sb.append(StartDateTime);
			}

			sb.append("|");

			if (ExaminationRoom == null) {
				sb.append("<null>");
			} else {
				sb.append(ExaminationRoom);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(TodaysAppointmentStruct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class PhysicianAndExamroomStruct
			implements routines.system.IPersistableRow<PhysicianAndExamroomStruct> {
		final static byte[] commonByteArrayLock_HMS_FunctionalRequirement = new byte[0];
		static byte[] commonByteArray_HMS_FunctionalRequirement = new byte[0];

		public Integer AppointmentID;

		public Integer getAppointmentID() {
			return this.AppointmentID;
		}

		public Boolean AppointmentIDIsNullable() {
			return true;
		}

		public Boolean AppointmentIDIsKey() {
			return false;
		}

		public Integer AppointmentIDLength() {
			return 10;
		}

		public Integer AppointmentIDPrecision() {
			return 0;
		}

		public String AppointmentIDDefault() {

			return null;

		}

		public String AppointmentIDComment() {

			return "";

		}

		public String AppointmentIDPattern() {

			return "";

		}

		public String AppointmentIDOriginalDbColumnName() {

			return "AppointmentID";

		}

		public Integer PatientID;

		public Integer getPatientID() {
			return this.PatientID;
		}

		public Boolean PatientIDIsNullable() {
			return true;
		}

		public Boolean PatientIDIsKey() {
			return false;
		}

		public Integer PatientIDLength() {
			return 10;
		}

		public Integer PatientIDPrecision() {
			return 0;
		}

		public String PatientIDDefault() {

			return null;

		}

		public String PatientIDComment() {

			return "";

		}

		public String PatientIDPattern() {

			return "";

		}

		public String PatientIDOriginalDbColumnName() {

			return "PatientID";

		}

		public Integer PhysicianID;

		public Integer getPhysicianID() {
			return this.PhysicianID;
		}

		public Boolean PhysicianIDIsNullable() {
			return true;
		}

		public Boolean PhysicianIDIsKey() {
			return false;
		}

		public Integer PhysicianIDLength() {
			return 10;
		}

		public Integer PhysicianIDPrecision() {
			return 0;
		}

		public String PhysicianIDDefault() {

			return null;

		}

		public String PhysicianIDComment() {

			return "";

		}

		public String PhysicianIDPattern() {

			return "";

		}

		public String PhysicianIDOriginalDbColumnName() {

			return "PhysicianID";

		}

		public java.util.Date StartDateTime;

		public java.util.Date getStartDateTime() {
			return this.StartDateTime;
		}

		public Boolean StartDateTimeIsNullable() {
			return true;
		}

		public Boolean StartDateTimeIsKey() {
			return false;
		}

		public Integer StartDateTimeLength() {
			return 19;
		}

		public Integer StartDateTimePrecision() {
			return 0;
		}

		public String StartDateTimeDefault() {

			return null;

		}

		public String StartDateTimeComment() {

			return "";

		}

		public String StartDateTimePattern() {

			return "dd-MM-yyyy";

		}

		public String StartDateTimeOriginalDbColumnName() {

			return "StartDateTime";

		}

		public String ExaminationRoom;

		public String getExaminationRoom() {
			return this.ExaminationRoom;
		}

		public Boolean ExaminationRoomIsNullable() {
			return true;
		}

		public Boolean ExaminationRoomIsKey() {
			return false;
		}

		public Integer ExaminationRoomLength() {
			return 30;
		}

		public Integer ExaminationRoomPrecision() {
			return 0;
		}

		public String ExaminationRoomDefault() {

			return null;

		}

		public String ExaminationRoomComment() {

			return "";

		}

		public String ExaminationRoomPattern() {

			return "";

		}

		public String ExaminationRoomOriginalDbColumnName() {

			return "ExaminationRoom";

		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_HMS_FunctionalRequirement.length) {
					if (length < 1024 && commonByteArray_HMS_FunctionalRequirement.length == 0) {
						commonByteArray_HMS_FunctionalRequirement = new byte[1024];
					} else {
						commonByteArray_HMS_FunctionalRequirement = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_HMS_FunctionalRequirement, 0, length);
				strReturn = new String(commonByteArray_HMS_FunctionalRequirement, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_HMS_FunctionalRequirement.length) {
					if (length < 1024 && commonByteArray_HMS_FunctionalRequirement.length == 0) {
						commonByteArray_HMS_FunctionalRequirement = new byte[1024];
					} else {
						commonByteArray_HMS_FunctionalRequirement = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_HMS_FunctionalRequirement, 0, length);
				strReturn = new String(commonByteArray_HMS_FunctionalRequirement, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_HMS_FunctionalRequirement) {

				try {

					int length = 0;

					this.AppointmentID = readInteger(dis);

					this.PatientID = readInteger(dis);

					this.PhysicianID = readInteger(dis);

					this.StartDateTime = readDate(dis);

					this.ExaminationRoom = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_HMS_FunctionalRequirement) {

				try {

					int length = 0;

					this.AppointmentID = readInteger(dis);

					this.PatientID = readInteger(dis);

					this.PhysicianID = readInteger(dis);

					this.StartDateTime = readDate(dis);

					this.ExaminationRoom = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.AppointmentID, dos);

				// Integer

				writeInteger(this.PatientID, dos);

				// Integer

				writeInteger(this.PhysicianID, dos);

				// java.util.Date

				writeDate(this.StartDateTime, dos);

				// String

				writeString(this.ExaminationRoom, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.AppointmentID, dos);

				// Integer

				writeInteger(this.PatientID, dos);

				// Integer

				writeInteger(this.PhysicianID, dos);

				// java.util.Date

				writeDate(this.StartDateTime, dos);

				// String

				writeString(this.ExaminationRoom, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("AppointmentID=" + String.valueOf(AppointmentID));
			sb.append(",PatientID=" + String.valueOf(PatientID));
			sb.append(",PhysicianID=" + String.valueOf(PhysicianID));
			sb.append(",StartDateTime=" + String.valueOf(StartDateTime));
			sb.append(",ExaminationRoom=" + ExaminationRoom);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (AppointmentID == null) {
				sb.append("<null>");
			} else {
				sb.append(AppointmentID);
			}

			sb.append("|");

			if (PatientID == null) {
				sb.append("<null>");
			} else {
				sb.append(PatientID);
			}

			sb.append("|");

			if (PhysicianID == null) {
				sb.append("<null>");
			} else {
				sb.append(PhysicianID);
			}

			sb.append("|");

			if (StartDateTime == null) {
				sb.append("<null>");
			} else {
				sb.append(StartDateTime);
			}

			sb.append("|");

			if (ExaminationRoom == null) {
				sb.append("<null>");
			} else {
				sb.append(ExaminationRoom);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(PhysicianAndExamroomStruct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class FutureAppointmentsWithInsuranceStruct
			implements routines.system.IPersistableRow<FutureAppointmentsWithInsuranceStruct> {
		final static byte[] commonByteArrayLock_HMS_FunctionalRequirement = new byte[0];
		static byte[] commonByteArray_HMS_FunctionalRequirement = new byte[0];

		public Integer AppointmentID;

		public Integer getAppointmentID() {
			return this.AppointmentID;
		}

		public Boolean AppointmentIDIsNullable() {
			return true;
		}

		public Boolean AppointmentIDIsKey() {
			return false;
		}

		public Integer AppointmentIDLength() {
			return 10;
		}

		public Integer AppointmentIDPrecision() {
			return 0;
		}

		public String AppointmentIDDefault() {

			return null;

		}

		public String AppointmentIDComment() {

			return "";

		}

		public String AppointmentIDPattern() {

			return "";

		}

		public String AppointmentIDOriginalDbColumnName() {

			return "AppointmentID";

		}

		public Integer PatientID;

		public Integer getPatientID() {
			return this.PatientID;
		}

		public Boolean PatientIDIsNullable() {
			return true;
		}

		public Boolean PatientIDIsKey() {
			return false;
		}

		public Integer PatientIDLength() {
			return 10;
		}

		public Integer PatientIDPrecision() {
			return 0;
		}

		public String PatientIDDefault() {

			return null;

		}

		public String PatientIDComment() {

			return "";

		}

		public String PatientIDPattern() {

			return "";

		}

		public String PatientIDOriginalDbColumnName() {

			return "PatientID";

		}

		public Integer PhysicianID;

		public Integer getPhysicianID() {
			return this.PhysicianID;
		}

		public Boolean PhysicianIDIsNullable() {
			return true;
		}

		public Boolean PhysicianIDIsKey() {
			return false;
		}

		public Integer PhysicianIDLength() {
			return 10;
		}

		public Integer PhysicianIDPrecision() {
			return 0;
		}

		public String PhysicianIDDefault() {

			return null;

		}

		public String PhysicianIDComment() {

			return "";

		}

		public String PhysicianIDPattern() {

			return "";

		}

		public String PhysicianIDOriginalDbColumnName() {

			return "PhysicianID";

		}

		public java.util.Date StartDateTime;

		public java.util.Date getStartDateTime() {
			return this.StartDateTime;
		}

		public Boolean StartDateTimeIsNullable() {
			return true;
		}

		public Boolean StartDateTimeIsKey() {
			return false;
		}

		public Integer StartDateTimeLength() {
			return 19;
		}

		public Integer StartDateTimePrecision() {
			return 0;
		}

		public String StartDateTimeDefault() {

			return null;

		}

		public String StartDateTimeComment() {

			return "";

		}

		public String StartDateTimePattern() {

			return "dd-MM-yyyy";

		}

		public String StartDateTimeOriginalDbColumnName() {

			return "StartDateTime";

		}

		public String ExaminationRoom;

		public String getExaminationRoom() {
			return this.ExaminationRoom;
		}

		public Boolean ExaminationRoomIsNullable() {
			return true;
		}

		public Boolean ExaminationRoomIsKey() {
			return false;
		}

		public Integer ExaminationRoomLength() {
			return 30;
		}

		public Integer ExaminationRoomPrecision() {
			return 0;
		}

		public String ExaminationRoomDefault() {

			return null;

		}

		public String ExaminationRoomComment() {

			return "";

		}

		public String ExaminationRoomPattern() {

			return "";

		}

		public String ExaminationRoomOriginalDbColumnName() {

			return "ExaminationRoom";

		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_HMS_FunctionalRequirement.length) {
					if (length < 1024 && commonByteArray_HMS_FunctionalRequirement.length == 0) {
						commonByteArray_HMS_FunctionalRequirement = new byte[1024];
					} else {
						commonByteArray_HMS_FunctionalRequirement = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_HMS_FunctionalRequirement, 0, length);
				strReturn = new String(commonByteArray_HMS_FunctionalRequirement, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_HMS_FunctionalRequirement.length) {
					if (length < 1024 && commonByteArray_HMS_FunctionalRequirement.length == 0) {
						commonByteArray_HMS_FunctionalRequirement = new byte[1024];
					} else {
						commonByteArray_HMS_FunctionalRequirement = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_HMS_FunctionalRequirement, 0, length);
				strReturn = new String(commonByteArray_HMS_FunctionalRequirement, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_HMS_FunctionalRequirement) {

				try {

					int length = 0;

					this.AppointmentID = readInteger(dis);

					this.PatientID = readInteger(dis);

					this.PhysicianID = readInteger(dis);

					this.StartDateTime = readDate(dis);

					this.ExaminationRoom = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_HMS_FunctionalRequirement) {

				try {

					int length = 0;

					this.AppointmentID = readInteger(dis);

					this.PatientID = readInteger(dis);

					this.PhysicianID = readInteger(dis);

					this.StartDateTime = readDate(dis);

					this.ExaminationRoom = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.AppointmentID, dos);

				// Integer

				writeInteger(this.PatientID, dos);

				// Integer

				writeInteger(this.PhysicianID, dos);

				// java.util.Date

				writeDate(this.StartDateTime, dos);

				// String

				writeString(this.ExaminationRoom, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.AppointmentID, dos);

				// Integer

				writeInteger(this.PatientID, dos);

				// Integer

				writeInteger(this.PhysicianID, dos);

				// java.util.Date

				writeDate(this.StartDateTime, dos);

				// String

				writeString(this.ExaminationRoom, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("AppointmentID=" + String.valueOf(AppointmentID));
			sb.append(",PatientID=" + String.valueOf(PatientID));
			sb.append(",PhysicianID=" + String.valueOf(PhysicianID));
			sb.append(",StartDateTime=" + String.valueOf(StartDateTime));
			sb.append(",ExaminationRoom=" + ExaminationRoom);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (AppointmentID == null) {
				sb.append("<null>");
			} else {
				sb.append(AppointmentID);
			}

			sb.append("|");

			if (PatientID == null) {
				sb.append("<null>");
			} else {
				sb.append(PatientID);
			}

			sb.append("|");

			if (PhysicianID == null) {
				sb.append("<null>");
			} else {
				sb.append(PhysicianID);
			}

			sb.append("|");

			if (StartDateTime == null) {
				sb.append("<null>");
			} else {
				sb.append(StartDateTime);
			}

			sb.append("|");

			if (ExaminationRoom == null) {
				sb.append("<null>");
			} else {
				sb.append(ExaminationRoom);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(FutureAppointmentsWithInsuranceStruct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row4Struct implements routines.system.IPersistableRow<row4Struct> {
		final static byte[] commonByteArrayLock_HMS_FunctionalRequirement = new byte[0];
		static byte[] commonByteArray_HMS_FunctionalRequirement = new byte[0];

		public Integer AppointmentID;

		public Integer getAppointmentID() {
			return this.AppointmentID;
		}

		public Boolean AppointmentIDIsNullable() {
			return true;
		}

		public Boolean AppointmentIDIsKey() {
			return false;
		}

		public Integer AppointmentIDLength() {
			return 10;
		}

		public Integer AppointmentIDPrecision() {
			return 0;
		}

		public String AppointmentIDDefault() {

			return null;

		}

		public String AppointmentIDComment() {

			return "";

		}

		public String AppointmentIDPattern() {

			return "";

		}

		public String AppointmentIDOriginalDbColumnName() {

			return "AppointmentID";

		}

		public Integer PatientID;

		public Integer getPatientID() {
			return this.PatientID;
		}

		public Boolean PatientIDIsNullable() {
			return true;
		}

		public Boolean PatientIDIsKey() {
			return false;
		}

		public Integer PatientIDLength() {
			return 10;
		}

		public Integer PatientIDPrecision() {
			return 0;
		}

		public String PatientIDDefault() {

			return null;

		}

		public String PatientIDComment() {

			return "";

		}

		public String PatientIDPattern() {

			return "";

		}

		public String PatientIDOriginalDbColumnName() {

			return "PatientID";

		}

		public Integer PhysicianID;

		public Integer getPhysicianID() {
			return this.PhysicianID;
		}

		public Boolean PhysicianIDIsNullable() {
			return true;
		}

		public Boolean PhysicianIDIsKey() {
			return false;
		}

		public Integer PhysicianIDLength() {
			return 10;
		}

		public Integer PhysicianIDPrecision() {
			return 0;
		}

		public String PhysicianIDDefault() {

			return null;

		}

		public String PhysicianIDComment() {

			return "";

		}

		public String PhysicianIDPattern() {

			return "";

		}

		public String PhysicianIDOriginalDbColumnName() {

			return "PhysicianID";

		}

		public java.util.Date StartDateTime;

		public java.util.Date getStartDateTime() {
			return this.StartDateTime;
		}

		public Boolean StartDateTimeIsNullable() {
			return true;
		}

		public Boolean StartDateTimeIsKey() {
			return false;
		}

		public Integer StartDateTimeLength() {
			return 19;
		}

		public Integer StartDateTimePrecision() {
			return 0;
		}

		public String StartDateTimeDefault() {

			return null;

		}

		public String StartDateTimeComment() {

			return "";

		}

		public String StartDateTimePattern() {

			return "dd-MM-yyyy";

		}

		public String StartDateTimeOriginalDbColumnName() {

			return "StartDateTime";

		}

		public String ExaminationRoom;

		public String getExaminationRoom() {
			return this.ExaminationRoom;
		}

		public Boolean ExaminationRoomIsNullable() {
			return true;
		}

		public Boolean ExaminationRoomIsKey() {
			return false;
		}

		public Integer ExaminationRoomLength() {
			return 30;
		}

		public Integer ExaminationRoomPrecision() {
			return 0;
		}

		public String ExaminationRoomDefault() {

			return null;

		}

		public String ExaminationRoomComment() {

			return "";

		}

		public String ExaminationRoomPattern() {

			return "";

		}

		public String ExaminationRoomOriginalDbColumnName() {

			return "ExaminationRoom";

		}

		public java.util.Date StartDate;

		public java.util.Date getStartDate() {
			return this.StartDate;
		}

		public Boolean StartDateIsNullable() {
			return false;
		}

		public Boolean StartDateIsKey() {
			return false;
		}

		public Integer StartDateLength() {
			return 19;
		}

		public Integer StartDatePrecision() {
			return 0;
		}

		public String StartDateDefault() {

			return null;

		}

		public String StartDateComment() {

			return "";

		}

		public String StartDatePattern() {

			return "dd-MM-yyyy";

		}

		public String StartDateOriginalDbColumnName() {

			return "StartDate";

		}

		public java.util.Date EndDate;

		public java.util.Date getEndDate() {
			return this.EndDate;
		}

		public Boolean EndDateIsNullable() {
			return true;
		}

		public Boolean EndDateIsKey() {
			return false;
		}

		public Integer EndDateLength() {
			return 19;
		}

		public Integer EndDatePrecision() {
			return 0;
		}

		public String EndDateDefault() {

			return null;

		}

		public String EndDateComment() {

			return "";

		}

		public String EndDatePattern() {

			return "dd-MM-yyyy";

		}

		public String EndDateOriginalDbColumnName() {

			return "EndDate";

		}

		public int AppointmentSK;

		public int getAppointmentSK() {
			return this.AppointmentSK;
		}

		public Boolean AppointmentSKIsNullable() {
			return false;
		}

		public Boolean AppointmentSKIsKey() {
			return true;
		}

		public Integer AppointmentSKLength() {
			return 10;
		}

		public Integer AppointmentSKPrecision() {
			return 0;
		}

		public String AppointmentSKDefault() {

			return null;

		}

		public String AppointmentSKComment() {

			return "";

		}

		public String AppointmentSKPattern() {

			return "";

		}

		public String AppointmentSKOriginalDbColumnName() {

			return "AppointmentSK";

		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_HMS_FunctionalRequirement.length) {
					if (length < 1024 && commonByteArray_HMS_FunctionalRequirement.length == 0) {
						commonByteArray_HMS_FunctionalRequirement = new byte[1024];
					} else {
						commonByteArray_HMS_FunctionalRequirement = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_HMS_FunctionalRequirement, 0, length);
				strReturn = new String(commonByteArray_HMS_FunctionalRequirement, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_HMS_FunctionalRequirement.length) {
					if (length < 1024 && commonByteArray_HMS_FunctionalRequirement.length == 0) {
						commonByteArray_HMS_FunctionalRequirement = new byte[1024];
					} else {
						commonByteArray_HMS_FunctionalRequirement = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_HMS_FunctionalRequirement, 0, length);
				strReturn = new String(commonByteArray_HMS_FunctionalRequirement, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_HMS_FunctionalRequirement) {

				try {

					int length = 0;

					this.AppointmentID = readInteger(dis);

					this.PatientID = readInteger(dis);

					this.PhysicianID = readInteger(dis);

					this.StartDateTime = readDate(dis);

					this.ExaminationRoom = readString(dis);

					this.StartDate = readDate(dis);

					this.EndDate = readDate(dis);

					this.AppointmentSK = dis.readInt();

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_HMS_FunctionalRequirement) {

				try {

					int length = 0;

					this.AppointmentID = readInteger(dis);

					this.PatientID = readInteger(dis);

					this.PhysicianID = readInteger(dis);

					this.StartDateTime = readDate(dis);

					this.ExaminationRoom = readString(dis);

					this.StartDate = readDate(dis);

					this.EndDate = readDate(dis);

					this.AppointmentSK = dis.readInt();

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.AppointmentID, dos);

				// Integer

				writeInteger(this.PatientID, dos);

				// Integer

				writeInteger(this.PhysicianID, dos);

				// java.util.Date

				writeDate(this.StartDateTime, dos);

				// String

				writeString(this.ExaminationRoom, dos);

				// java.util.Date

				writeDate(this.StartDate, dos);

				// java.util.Date

				writeDate(this.EndDate, dos);

				// int

				dos.writeInt(this.AppointmentSK);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.AppointmentID, dos);

				// Integer

				writeInteger(this.PatientID, dos);

				// Integer

				writeInteger(this.PhysicianID, dos);

				// java.util.Date

				writeDate(this.StartDateTime, dos);

				// String

				writeString(this.ExaminationRoom, dos);

				// java.util.Date

				writeDate(this.StartDate, dos);

				// java.util.Date

				writeDate(this.EndDate, dos);

				// int

				dos.writeInt(this.AppointmentSK);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("AppointmentID=" + String.valueOf(AppointmentID));
			sb.append(",PatientID=" + String.valueOf(PatientID));
			sb.append(",PhysicianID=" + String.valueOf(PhysicianID));
			sb.append(",StartDateTime=" + String.valueOf(StartDateTime));
			sb.append(",ExaminationRoom=" + ExaminationRoom);
			sb.append(",StartDate=" + String.valueOf(StartDate));
			sb.append(",EndDate=" + String.valueOf(EndDate));
			sb.append(",AppointmentSK=" + String.valueOf(AppointmentSK));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (AppointmentID == null) {
				sb.append("<null>");
			} else {
				sb.append(AppointmentID);
			}

			sb.append("|");

			if (PatientID == null) {
				sb.append("<null>");
			} else {
				sb.append(PatientID);
			}

			sb.append("|");

			if (PhysicianID == null) {
				sb.append("<null>");
			} else {
				sb.append(PhysicianID);
			}

			sb.append("|");

			if (StartDateTime == null) {
				sb.append("<null>");
			} else {
				sb.append(StartDateTime);
			}

			sb.append("|");

			if (ExaminationRoom == null) {
				sb.append("<null>");
			} else {
				sb.append(ExaminationRoom);
			}

			sb.append("|");

			if (StartDate == null) {
				sb.append("<null>");
			} else {
				sb.append(StartDate);
			}

			sb.append("|");

			if (EndDate == null) {
				sb.append("<null>");
			} else {
				sb.append(EndDate);
			}

			sb.append("|");

			sb.append(AppointmentSK);

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row4Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tDBInput_3Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tDBInput_3_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tDBInput_3");
		org.slf4j.MDC.put("_subJobPid", "bxHDKn_" + subJobPidCounter.getAndIncrement());

		String currentVirtualComponent = null;

		String iterateId = "";

		String currentComponent = "";
		String cLabel = null;
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				row4Struct row4 = new row4Struct();
				TodaysAppointmentStruct TodaysAppointment = new TodaysAppointmentStruct();
				PhysicianAndExamroomStruct PhysicianAndExamroom = new PhysicianAndExamroomStruct();
				row5Struct row5 = new row5Struct();
				FutureAppointmentsWithInsuranceStruct FutureAppointmentsWithInsurance = new FutureAppointmentsWithInsuranceStruct();

				/**
				 * [tFileOutputExcel_6 begin ] start
				 */

				ok_Hash.put("tFileOutputExcel_6", false);
				start_Hash.put("tFileOutputExcel_6", System.currentTimeMillis());

				currentComponent = "tFileOutputExcel_6";

				cLabel = "TodaysAppointment";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "TodaysAppointment");

				int tos_count_tFileOutputExcel_6 = 0;

				if (log.isDebugEnabled())
					log.debug("tFileOutputExcel_6 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tFileOutputExcel_6 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tFileOutputExcel_6 = new StringBuilder();
							log4jParamters_tFileOutputExcel_6.append("Parameters:");
							log4jParamters_tFileOutputExcel_6.append("VERSION_2007" + " = " + "false");
							log4jParamters_tFileOutputExcel_6.append(" | ");
							log4jParamters_tFileOutputExcel_6.append("USESTREAM" + " = " + "false");
							log4jParamters_tFileOutputExcel_6.append(" | ");
							log4jParamters_tFileOutputExcel_6.append(
									"FILENAME" + " = " + "\"C:/Users/2382187/Downloads/FR/TodaysAppointment.xls\"");
							log4jParamters_tFileOutputExcel_6.append(" | ");
							log4jParamters_tFileOutputExcel_6.append("SHEETNAME" + " = " + "\"Sheet1\"");
							log4jParamters_tFileOutputExcel_6.append(" | ");
							log4jParamters_tFileOutputExcel_6.append("INCLUDEHEADER" + " = " + "false");
							log4jParamters_tFileOutputExcel_6.append(" | ");
							log4jParamters_tFileOutputExcel_6.append("APPEND_FILE" + " = " + "false");
							log4jParamters_tFileOutputExcel_6.append(" | ");
							log4jParamters_tFileOutputExcel_6.append("FIRST_CELL_Y_ABSOLUTE" + " = " + "false");
							log4jParamters_tFileOutputExcel_6.append(" | ");
							log4jParamters_tFileOutputExcel_6.append("FONT" + " = " + "");
							log4jParamters_tFileOutputExcel_6.append(" | ");
							log4jParamters_tFileOutputExcel_6.append("IS_ALL_AUTO_SZIE" + " = " + "false");
							log4jParamters_tFileOutputExcel_6.append(" | ");
							log4jParamters_tFileOutputExcel_6.append("AUTO_SZIE_SETTING" + " = " + "[{IS_AUTO_SIZE="
									+ ("false") + ", SCHEMA_COLUMN=" + ("AppointmentID") + "}, {IS_AUTO_SIZE="
									+ ("false") + ", SCHEMA_COLUMN=" + ("PatientID") + "}, {IS_AUTO_SIZE=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("PhysicianID") + "}, {IS_AUTO_SIZE=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("StartDateTime") + "}, {IS_AUTO_SIZE=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("ExaminationRoom") + "}]");
							log4jParamters_tFileOutputExcel_6.append(" | ");
							log4jParamters_tFileOutputExcel_6.append("CREATE" + " = " + "true");
							log4jParamters_tFileOutputExcel_6.append(" | ");
							log4jParamters_tFileOutputExcel_6.append("ADVANCED_SEPARATOR" + " = " + "false");
							log4jParamters_tFileOutputExcel_6.append(" | ");
							log4jParamters_tFileOutputExcel_6.append("ENCODING" + " = " + "\"ISO-8859-15\"");
							log4jParamters_tFileOutputExcel_6.append(" | ");
							log4jParamters_tFileOutputExcel_6.append("DELETE_EMPTYFILE" + " = " + "false");
							log4jParamters_tFileOutputExcel_6.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tFileOutputExcel_6 - " + (log4jParamters_tFileOutputExcel_6));
						}
					}
					new BytesLimit65535_tFileOutputExcel_6().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tFileOutputExcel_6", "TodaysAppointment", "tFileOutputExcel");
					talendJobLogProcess(globalMap);
				}

				int columnIndex_tFileOutputExcel_6 = 0;
				boolean headerIsInserted_tFileOutputExcel_6 = false;

				int nb_line_tFileOutputExcel_6 = 0;

				String fileName_tFileOutputExcel_6 = "C:/Users/2382187/Downloads/FR/TodaysAppointment.xls";
				java.io.File file_tFileOutputExcel_6 = new java.io.File(fileName_tFileOutputExcel_6);
				boolean isFileGenerated_tFileOutputExcel_6 = true;
//create directory only if not exists
				java.io.File parentFile_tFileOutputExcel_6 = file_tFileOutputExcel_6.getParentFile();
				if (parentFile_tFileOutputExcel_6 != null && !parentFile_tFileOutputExcel_6.exists()) {

					log.info("tFileOutputExcel_6 - Creating directory '"
							+ parentFile_tFileOutputExcel_6.getCanonicalPath() + "'.");

					parentFile_tFileOutputExcel_6.mkdirs();

					log.info("tFileOutputExcel_6 - Create directory '"
							+ parentFile_tFileOutputExcel_6.getCanonicalPath() + "' has succeeded.");

				}

				jxl.write.WritableWorkbook writeableWorkbook_tFileOutputExcel_6 = null;
				jxl.write.WritableSheet writableSheet_tFileOutputExcel_6 = null;

				jxl.WorkbookSettings workbookSettings_tFileOutputExcel_6 = new jxl.WorkbookSettings();
				workbookSettings_tFileOutputExcel_6.setEncoding("ISO-8859-15");
				writeableWorkbook_tFileOutputExcel_6 = new jxl.write.biff.WritableWorkbookImpl(
						new java.io.BufferedOutputStream(new java.io.FileOutputStream(fileName_tFileOutputExcel_6)),
						true, workbookSettings_tFileOutputExcel_6);

				writableSheet_tFileOutputExcel_6 = writeableWorkbook_tFileOutputExcel_6.getSheet("Sheet1");
				if (writableSheet_tFileOutputExcel_6 == null) {
					writableSheet_tFileOutputExcel_6 = writeableWorkbook_tFileOutputExcel_6.createSheet("Sheet1",
							writeableWorkbook_tFileOutputExcel_6.getNumberOfSheets());
				}

				// modif start
				int startRowNum_tFileOutputExcel_6 = writableSheet_tFileOutputExcel_6.getRows();
				// modif end

				int[] fitWidth_tFileOutputExcel_6 = new int[5];
				for (int i_tFileOutputExcel_6 = 0; i_tFileOutputExcel_6 < 5; i_tFileOutputExcel_6++) {
					int fitCellViewSize_tFileOutputExcel_6 = writableSheet_tFileOutputExcel_6
							.getColumnView(i_tFileOutputExcel_6).getSize();
					fitWidth_tFileOutputExcel_6[i_tFileOutputExcel_6] = fitCellViewSize_tFileOutputExcel_6 / 256;
					if (fitCellViewSize_tFileOutputExcel_6 % 256 != 0) {
						fitWidth_tFileOutputExcel_6[i_tFileOutputExcel_6] += 1;
					}
				}

				final jxl.write.WritableCellFormat cell_format_StartDateTime_tFileOutputExcel_6 = new jxl.write.WritableCellFormat(
						new jxl.write.DateFormat("dd-MM-yyyy"));

				/**
				 * [tFileOutputExcel_6 begin ] stop
				 */

				/**
				 * [tSortRow_2_SortOut begin ] start
				 */

				ok_Hash.put("tSortRow_2_SortOut", false);
				start_Hash.put("tSortRow_2_SortOut", System.currentTimeMillis());

				currentVirtualComponent = "tSortRow_2";

				currentComponent = "tSortRow_2_SortOut";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0,
						"PhysicianAndExamroom");

				int tos_count_tSortRow_2_SortOut = 0;

				if (log.isDebugEnabled())
					log.debug("tSortRow_2_SortOut - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tSortRow_2_SortOut {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tSortRow_2_SortOut = new StringBuilder();
							log4jParamters_tSortRow_2_SortOut.append("Parameters:");
							log4jParamters_tSortRow_2_SortOut.append("DESTINATION" + " = " + "tSortRow_2");
							log4jParamters_tSortRow_2_SortOut.append(" | ");
							log4jParamters_tSortRow_2_SortOut.append("EXTERNAL" + " = " + "false");
							log4jParamters_tSortRow_2_SortOut.append(" | ");
							log4jParamters_tSortRow_2_SortOut.append("CRITERIA" + " = " + "[{ORDER=" + ("asc")
									+ ", COLNAME=" + ("PhysicianID") + ", SORT=" + ("num") + "}, {ORDER=" + ("asc")
									+ ", COLNAME=" + ("ExaminationRoom") + ", SORT=" + ("alpha") + "}]");
							log4jParamters_tSortRow_2_SortOut.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tSortRow_2_SortOut - " + (log4jParamters_tSortRow_2_SortOut));
						}
					}
					new BytesLimit65535_tSortRow_2_SortOut().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tSortRow_2_SortOut", "tSortRow_2_SortOut", "tSortOut");
					talendJobLogProcess(globalMap);
				}

				class ComparablePhysicianAndExamroomStruct extends PhysicianAndExamroomStruct
						implements Comparable<ComparablePhysicianAndExamroomStruct> {

					public int compareTo(ComparablePhysicianAndExamroomStruct other) {

						if (this.PhysicianID == null && other.PhysicianID != null) {
							return -1;

						} else if (this.PhysicianID != null && other.PhysicianID == null) {
							return 1;

						} else if (this.PhysicianID != null && other.PhysicianID != null) {
							if (!this.PhysicianID.equals(other.PhysicianID)) {
								return this.PhysicianID.compareTo(other.PhysicianID);
							}
						}
						if (this.ExaminationRoom == null && other.ExaminationRoom != null) {
							return -1;

						} else if (this.ExaminationRoom != null && other.ExaminationRoom == null) {
							return 1;

						} else if (this.ExaminationRoom != null && other.ExaminationRoom != null) {
							if (!this.ExaminationRoom.equals(other.ExaminationRoom)) {
								return this.ExaminationRoom.compareTo(other.ExaminationRoom);
							}
						}
						return 0;
					}
				}

				java.util.List<ComparablePhysicianAndExamroomStruct> list_tSortRow_2_SortOut = new java.util.ArrayList<ComparablePhysicianAndExamroomStruct>();

				/**
				 * [tSortRow_2_SortOut begin ] stop
				 */

				/**
				 * [tFileOutputExcel_8 begin ] start
				 */

				ok_Hash.put("tFileOutputExcel_8", false);
				start_Hash.put("tFileOutputExcel_8", System.currentTimeMillis());

				currentComponent = "tFileOutputExcel_8";

				cLabel = "FutureAppointments";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0,
						"FutureAppointmentsWithInsurance");

				int tos_count_tFileOutputExcel_8 = 0;

				if (log.isDebugEnabled())
					log.debug("tFileOutputExcel_8 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tFileOutputExcel_8 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tFileOutputExcel_8 = new StringBuilder();
							log4jParamters_tFileOutputExcel_8.append("Parameters:");
							log4jParamters_tFileOutputExcel_8.append("VERSION_2007" + " = " + "false");
							log4jParamters_tFileOutputExcel_8.append(" | ");
							log4jParamters_tFileOutputExcel_8.append("USESTREAM" + " = " + "false");
							log4jParamters_tFileOutputExcel_8.append(" | ");
							log4jParamters_tFileOutputExcel_8.append(
									"FILENAME" + " = " + "\"C:/Users/2382187/Downloads/FR/FutureAppointments.xls\"");
							log4jParamters_tFileOutputExcel_8.append(" | ");
							log4jParamters_tFileOutputExcel_8.append("SHEETNAME" + " = " + "\"Sheet1\"");
							log4jParamters_tFileOutputExcel_8.append(" | ");
							log4jParamters_tFileOutputExcel_8.append("INCLUDEHEADER" + " = " + "true");
							log4jParamters_tFileOutputExcel_8.append(" | ");
							log4jParamters_tFileOutputExcel_8.append("APPEND_FILE" + " = " + "false");
							log4jParamters_tFileOutputExcel_8.append(" | ");
							log4jParamters_tFileOutputExcel_8.append("FIRST_CELL_Y_ABSOLUTE" + " = " + "false");
							log4jParamters_tFileOutputExcel_8.append(" | ");
							log4jParamters_tFileOutputExcel_8.append("FONT" + " = " + "");
							log4jParamters_tFileOutputExcel_8.append(" | ");
							log4jParamters_tFileOutputExcel_8.append("IS_ALL_AUTO_SZIE" + " = " + "true");
							log4jParamters_tFileOutputExcel_8.append(" | ");
							log4jParamters_tFileOutputExcel_8.append("CREATE" + " = " + "true");
							log4jParamters_tFileOutputExcel_8.append(" | ");
							log4jParamters_tFileOutputExcel_8.append("ADVANCED_SEPARATOR" + " = " + "false");
							log4jParamters_tFileOutputExcel_8.append(" | ");
							log4jParamters_tFileOutputExcel_8.append("ENCODING" + " = " + "\"ISO-8859-15\"");
							log4jParamters_tFileOutputExcel_8.append(" | ");
							log4jParamters_tFileOutputExcel_8.append("DELETE_EMPTYFILE" + " = " + "false");
							log4jParamters_tFileOutputExcel_8.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tFileOutputExcel_8 - " + (log4jParamters_tFileOutputExcel_8));
						}
					}
					new BytesLimit65535_tFileOutputExcel_8().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tFileOutputExcel_8", "FutureAppointments", "tFileOutputExcel");
					talendJobLogProcess(globalMap);
				}

				int columnIndex_tFileOutputExcel_8 = 0;
				boolean headerIsInserted_tFileOutputExcel_8 = false;

				int nb_line_tFileOutputExcel_8 = 0;

				String fileName_tFileOutputExcel_8 = "C:/Users/2382187/Downloads/FR/FutureAppointments.xls";
				java.io.File file_tFileOutputExcel_8 = new java.io.File(fileName_tFileOutputExcel_8);
				boolean isFileGenerated_tFileOutputExcel_8 = true;
//create directory only if not exists
				java.io.File parentFile_tFileOutputExcel_8 = file_tFileOutputExcel_8.getParentFile();
				if (parentFile_tFileOutputExcel_8 != null && !parentFile_tFileOutputExcel_8.exists()) {

					log.info("tFileOutputExcel_8 - Creating directory '"
							+ parentFile_tFileOutputExcel_8.getCanonicalPath() + "'.");

					parentFile_tFileOutputExcel_8.mkdirs();

					log.info("tFileOutputExcel_8 - Create directory '"
							+ parentFile_tFileOutputExcel_8.getCanonicalPath() + "' has succeeded.");

				}

				jxl.write.WritableWorkbook writeableWorkbook_tFileOutputExcel_8 = null;
				jxl.write.WritableSheet writableSheet_tFileOutputExcel_8 = null;

				jxl.WorkbookSettings workbookSettings_tFileOutputExcel_8 = new jxl.WorkbookSettings();
				workbookSettings_tFileOutputExcel_8.setEncoding("ISO-8859-15");
				writeableWorkbook_tFileOutputExcel_8 = new jxl.write.biff.WritableWorkbookImpl(
						new java.io.BufferedOutputStream(new java.io.FileOutputStream(fileName_tFileOutputExcel_8)),
						true, workbookSettings_tFileOutputExcel_8);

				writableSheet_tFileOutputExcel_8 = writeableWorkbook_tFileOutputExcel_8.getSheet("Sheet1");
				if (writableSheet_tFileOutputExcel_8 == null) {
					writableSheet_tFileOutputExcel_8 = writeableWorkbook_tFileOutputExcel_8.createSheet("Sheet1",
							writeableWorkbook_tFileOutputExcel_8.getNumberOfSheets());
				}

				// modif start
				int startRowNum_tFileOutputExcel_8 = writableSheet_tFileOutputExcel_8.getRows();
				// modif end

				int[] fitWidth_tFileOutputExcel_8 = new int[5];
				for (int i_tFileOutputExcel_8 = 0; i_tFileOutputExcel_8 < 5; i_tFileOutputExcel_8++) {
					int fitCellViewSize_tFileOutputExcel_8 = writableSheet_tFileOutputExcel_8
							.getColumnView(i_tFileOutputExcel_8).getSize();
					fitWidth_tFileOutputExcel_8[i_tFileOutputExcel_8] = fitCellViewSize_tFileOutputExcel_8 / 256;
					if (fitCellViewSize_tFileOutputExcel_8 % 256 != 0) {
						fitWidth_tFileOutputExcel_8[i_tFileOutputExcel_8] += 1;
					}
				}

				final jxl.write.WritableCellFormat cell_format_StartDateTime_tFileOutputExcel_8 = new jxl.write.WritableCellFormat(
						new jxl.write.DateFormat("dd-MM-yyyy"));

				if (startRowNum_tFileOutputExcel_8 == 0) {
					// modif end
					// modif start
					writableSheet_tFileOutputExcel_8
							.addCell(new jxl.write.Label(0, nb_line_tFileOutputExcel_8, "AppointmentID"));
					// modif end
					fitWidth_tFileOutputExcel_8[0] = fitWidth_tFileOutputExcel_8[0] > 13
							? fitWidth_tFileOutputExcel_8[0]
							: 13;
					// modif start
					writableSheet_tFileOutputExcel_8
							.addCell(new jxl.write.Label(1, nb_line_tFileOutputExcel_8, "PatientID"));
					// modif end
					fitWidth_tFileOutputExcel_8[1] = fitWidth_tFileOutputExcel_8[1] > 9 ? fitWidth_tFileOutputExcel_8[1]
							: 9;
					// modif start
					writableSheet_tFileOutputExcel_8
							.addCell(new jxl.write.Label(2, nb_line_tFileOutputExcel_8, "PhysicianID"));
					// modif end
					fitWidth_tFileOutputExcel_8[2] = fitWidth_tFileOutputExcel_8[2] > 11
							? fitWidth_tFileOutputExcel_8[2]
							: 11;
					// modif start
					writableSheet_tFileOutputExcel_8
							.addCell(new jxl.write.Label(3, nb_line_tFileOutputExcel_8, "StartDateTime"));
					// modif end
					fitWidth_tFileOutputExcel_8[3] = fitWidth_tFileOutputExcel_8[3] > 13
							? fitWidth_tFileOutputExcel_8[3]
							: 13;
					// modif start
					writableSheet_tFileOutputExcel_8
							.addCell(new jxl.write.Label(4, nb_line_tFileOutputExcel_8, "ExaminationRoom"));
					// modif end
					fitWidth_tFileOutputExcel_8[4] = fitWidth_tFileOutputExcel_8[4] > 15
							? fitWidth_tFileOutputExcel_8[4]
							: 15;
					nb_line_tFileOutputExcel_8++;
					headerIsInserted_tFileOutputExcel_8 = true;
				}

				/**
				 * [tFileOutputExcel_8 begin ] stop
				 */

				/**
				 * [tMap_3 begin ] start
				 */

				ok_Hash.put("tMap_3", false);
				start_Hash.put("tMap_3", System.currentTimeMillis());

				currentComponent = "tMap_3";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "row4");

				int tos_count_tMap_3 = 0;

				if (log.isDebugEnabled())
					log.debug("tMap_3 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tMap_3 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tMap_3 = new StringBuilder();
							log4jParamters_tMap_3.append("Parameters:");
							log4jParamters_tMap_3.append("LINK_STYLE" + " = " + "AUTO");
							log4jParamters_tMap_3.append(" | ");
							log4jParamters_tMap_3.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
							log4jParamters_tMap_3.append(" | ");
							log4jParamters_tMap_3.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
							log4jParamters_tMap_3.append(" | ");
							log4jParamters_tMap_3.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "true");
							log4jParamters_tMap_3.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tMap_3 - " + (log4jParamters_tMap_3));
						}
					}
					new BytesLimit65535_tMap_3().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tMap_3", "tMap_3", "tMap");
					talendJobLogProcess(globalMap);
				}

// ###############################
// # Lookup's keys initialization
				int count_row4_tMap_3 = 0;

// ###############################        

// ###############################
// # Vars initialization
				class Var__tMap_3__Struct {
				}
				Var__tMap_3__Struct Var__tMap_3 = new Var__tMap_3__Struct();
// ###############################

// ###############################
// # Outputs initialization
				int count_TodaysAppointment_tMap_3 = 0;

				TodaysAppointmentStruct TodaysAppointment_tmp = new TodaysAppointmentStruct();
				int count_PhysicianAndExamroom_tMap_3 = 0;

				PhysicianAndExamroomStruct PhysicianAndExamroom_tmp = new PhysicianAndExamroomStruct();
				int count_FutureAppointmentsWithInsurance_tMap_3 = 0;

				FutureAppointmentsWithInsuranceStruct FutureAppointmentsWithInsurance_tmp = new FutureAppointmentsWithInsuranceStruct();
// ###############################

				/**
				 * [tMap_3 begin ] stop
				 */

				/**
				 * [tDBInput_3 begin ] start
				 */

				ok_Hash.put("tDBInput_3", false);
				start_Hash.put("tDBInput_3", System.currentTimeMillis());

				currentComponent = "tDBInput_3";

				cLabel = "Appointment";

				int tos_count_tDBInput_3 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBInput_3 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tDBInput_3 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tDBInput_3 = new StringBuilder();
							log4jParamters_tDBInput_3.append("Parameters:");
							log4jParamters_tDBInput_3.append("DB_VERSION" + " = " + "MYSQL_8");
							log4jParamters_tDBInput_3.append(" | ");
							log4jParamters_tDBInput_3.append("USE_EXISTING_CONNECTION" + " = " + "false");
							log4jParamters_tDBInput_3.append(" | ");
							log4jParamters_tDBInput_3.append("HOST" + " = " + "\"localhost\"");
							log4jParamters_tDBInput_3.append(" | ");
							log4jParamters_tDBInput_3.append("PORT" + " = " + "\"3306\"");
							log4jParamters_tDBInput_3.append(" | ");
							log4jParamters_tDBInput_3.append("DBNAME" + " = " + "\"Warehouse\"");
							log4jParamters_tDBInput_3.append(" | ");
							log4jParamters_tDBInput_3.append("USER" + " = " + "\"root\"");
							log4jParamters_tDBInput_3.append(" | ");
							log4jParamters_tDBInput_3.append("PASS" + " = " + String.valueOf(
									"enc:routine.encryption.key.v1:5LeQSDS95fNGad1exzIQErJa+iNPLJpM8gU2wXfHPro=")
									.substring(0, 4) + "...");
							log4jParamters_tDBInput_3.append(" | ");
							log4jParamters_tDBInput_3.append("TABLE" + " = " + "\"appointmentdim\"");
							log4jParamters_tDBInput_3.append(" | ");
							log4jParamters_tDBInput_3.append("QUERYSTORE" + " = " + "\"\"");
							log4jParamters_tDBInput_3.append(" | ");
							log4jParamters_tDBInput_3.append("QUERY" + " = "
									+ "\"SELECT    `appointmentdim`.`AppointmentID`,    `appointmentdim`.`PatientID`,    `appointmentdim`.`PhysicianID`,    `appointmentdim`.`StartDateTime`,    `appointmentdim`.`ExaminationRoom`,    `appointmentdim`.`StartDate`,    `appointmentdim`.`EndDate`,    `appointmentdim`.`AppointmentSK` FROM `appointmentdim`\"");
							log4jParamters_tDBInput_3.append(" | ");
							log4jParamters_tDBInput_3.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
							log4jParamters_tDBInput_3.append(" | ");
							log4jParamters_tDBInput_3.append("PROPERTIES" + " = "
									+ "\"noDatetimeStringSync=true&enabledTLSProtocols=TLSv1.2,TLSv1.1,TLSv1\"");
							log4jParamters_tDBInput_3.append(" | ");
							log4jParamters_tDBInput_3.append("ENABLE_STREAM" + " = " + "false");
							log4jParamters_tDBInput_3.append(" | ");
							log4jParamters_tDBInput_3.append("TRIM_ALL_COLUMN" + " = " + "false");
							log4jParamters_tDBInput_3.append(" | ");
							log4jParamters_tDBInput_3.append("TRIM_COLUMN" + " = " + "[{TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("AppointmentID") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("PatientID") + "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN="
									+ ("PhysicianID") + "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN=" + ("StartDateTime")
									+ "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN=" + ("ExaminationRoom") + "}, {TRIM="
									+ ("false") + ", SCHEMA_COLUMN=" + ("StartDate") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("EndDate") + "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN="
									+ ("AppointmentSK") + "}]");
							log4jParamters_tDBInput_3.append(" | ");
							log4jParamters_tDBInput_3.append("UNIFIED_COMPONENTS" + " = " + "tMysqlInput");
							log4jParamters_tDBInput_3.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tDBInput_3 - " + (log4jParamters_tDBInput_3));
						}
					}
					new BytesLimit65535_tDBInput_3().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tDBInput_3", "Appointment", "tMysqlInput");
					talendJobLogProcess(globalMap);
				}

				java.util.Calendar calendar_tDBInput_3 = java.util.Calendar.getInstance();
				calendar_tDBInput_3.set(0, 0, 0, 0, 0, 0);
				java.util.Date year0_tDBInput_3 = calendar_tDBInput_3.getTime();
				int nb_line_tDBInput_3 = 0;
				java.sql.Connection conn_tDBInput_3 = null;
				String driverClass_tDBInput_3 = "com.mysql.cj.jdbc.Driver";
				java.lang.Class jdbcclazz_tDBInput_3 = java.lang.Class.forName(driverClass_tDBInput_3);
				String dbUser_tDBInput_3 = "root";

				final String decryptedPassword_tDBInput_3 = routines.system.PasswordEncryptUtil
						.decryptPassword("enc:routine.encryption.key.v1:L4bE+dW6TDGfbUsw6x18IRwLnUjyiNL/4zn9M3GsoS4=");

				String dbPwd_tDBInput_3 = decryptedPassword_tDBInput_3;

				String properties_tDBInput_3 = "noDatetimeStringSync=true&enabledTLSProtocols=TLSv1.2,TLSv1.1,TLSv1";
				if (properties_tDBInput_3 == null || properties_tDBInput_3.trim().length() == 0) {
					properties_tDBInput_3 = "";
				}
				String url_tDBInput_3 = "jdbc:mysql://" + "localhost" + ":" + "3306" + "/" + "Warehouse" + "?"
						+ properties_tDBInput_3;

				log.debug("tDBInput_3 - Driver ClassName: " + driverClass_tDBInput_3 + ".");

				log.debug("tDBInput_3 - Connection attempt to '" + url_tDBInput_3 + "' with the username '"
						+ dbUser_tDBInput_3 + "'.");

				conn_tDBInput_3 = java.sql.DriverManager.getConnection(url_tDBInput_3, dbUser_tDBInput_3,
						dbPwd_tDBInput_3);
				log.debug("tDBInput_3 - Connection to '" + url_tDBInput_3 + "' has succeeded.");

				java.sql.Statement stmt_tDBInput_3 = conn_tDBInput_3.createStatement();

				String dbquery_tDBInput_3 = "SELECT \n  `appointmentdim`.`AppointmentID`, \n  `appointmentdim`.`PatientID`, \n  `appointmentdim`.`PhysicianID`, \n  `app"
						+ "ointmentdim`.`StartDateTime`, \n  `appointmentdim`.`ExaminationRoom`, \n  `appointmentdim`.`StartDate`, \n  `appointmentdim"
						+ "`.`EndDate`, \n  `appointmentdim`.`AppointmentSK`\nFROM `appointmentdim`";

				log.debug("tDBInput_3 - Executing the query: '" + dbquery_tDBInput_3 + "'.");

				globalMap.put("tDBInput_3_QUERY", dbquery_tDBInput_3);

				java.sql.ResultSet rs_tDBInput_3 = null;

				try {
					rs_tDBInput_3 = stmt_tDBInput_3.executeQuery(dbquery_tDBInput_3);
					java.sql.ResultSetMetaData rsmd_tDBInput_3 = rs_tDBInput_3.getMetaData();
					int colQtyInRs_tDBInput_3 = rsmd_tDBInput_3.getColumnCount();

					String tmpContent_tDBInput_3 = null;

					log.debug("tDBInput_3 - Retrieving records from the database.");

					while (rs_tDBInput_3.next()) {
						nb_line_tDBInput_3++;

						if (colQtyInRs_tDBInput_3 < 1) {
							row4.AppointmentID = null;
						} else {

							row4.AppointmentID = rs_tDBInput_3.getInt(1);
							if (rs_tDBInput_3.wasNull()) {
								row4.AppointmentID = null;
							}
						}
						if (colQtyInRs_tDBInput_3 < 2) {
							row4.PatientID = null;
						} else {

							row4.PatientID = rs_tDBInput_3.getInt(2);
							if (rs_tDBInput_3.wasNull()) {
								row4.PatientID = null;
							}
						}
						if (colQtyInRs_tDBInput_3 < 3) {
							row4.PhysicianID = null;
						} else {

							row4.PhysicianID = rs_tDBInput_3.getInt(3);
							if (rs_tDBInput_3.wasNull()) {
								row4.PhysicianID = null;
							}
						}
						if (colQtyInRs_tDBInput_3 < 4) {
							row4.StartDateTime = null;
						} else {

							if (rs_tDBInput_3.getString(4) != null) {
								String dateString_tDBInput_3 = rs_tDBInput_3.getString(4);
								if (!("0000-00-00").equals(dateString_tDBInput_3)
										&& !("0000-00-00 00:00:00").equals(dateString_tDBInput_3)) {
									row4.StartDateTime = rs_tDBInput_3.getTimestamp(4);
								} else {
									row4.StartDateTime = (java.util.Date) year0_tDBInput_3.clone();
								}
							} else {
								row4.StartDateTime = null;
							}
						}
						if (colQtyInRs_tDBInput_3 < 5) {
							row4.ExaminationRoom = null;
						} else {

							row4.ExaminationRoom = routines.system.JDBCUtil.getString(rs_tDBInput_3, 5, false);
						}
						if (colQtyInRs_tDBInput_3 < 6) {
							row4.StartDate = null;
						} else {

							if (rs_tDBInput_3.getString(6) != null) {
								String dateString_tDBInput_3 = rs_tDBInput_3.getString(6);
								if (!("0000-00-00").equals(dateString_tDBInput_3)
										&& !("0000-00-00 00:00:00").equals(dateString_tDBInput_3)) {
									row4.StartDate = rs_tDBInput_3.getTimestamp(6);
								} else {
									row4.StartDate = (java.util.Date) year0_tDBInput_3.clone();
								}
							} else {
								row4.StartDate = null;
							}
						}
						if (colQtyInRs_tDBInput_3 < 7) {
							row4.EndDate = null;
						} else {

							if (rs_tDBInput_3.getString(7) != null) {
								String dateString_tDBInput_3 = rs_tDBInput_3.getString(7);
								if (!("0000-00-00").equals(dateString_tDBInput_3)
										&& !("0000-00-00 00:00:00").equals(dateString_tDBInput_3)) {
									row4.EndDate = rs_tDBInput_3.getTimestamp(7);
								} else {
									row4.EndDate = (java.util.Date) year0_tDBInput_3.clone();
								}
							} else {
								row4.EndDate = null;
							}
						}
						if (colQtyInRs_tDBInput_3 < 8) {
							row4.AppointmentSK = 0;
						} else {

							row4.AppointmentSK = rs_tDBInput_3.getInt(8);
							if (rs_tDBInput_3.wasNull()) {
								throw new RuntimeException("Null value in non-Nullable column");
							}
						}

						log.debug("tDBInput_3 - Retrieving the record " + nb_line_tDBInput_3 + ".");

						/**
						 * [tDBInput_3 begin ] stop
						 */

						/**
						 * [tDBInput_3 main ] start
						 */

						currentComponent = "tDBInput_3";

						cLabel = "Appointment";

						tos_count_tDBInput_3++;

						/**
						 * [tDBInput_3 main ] stop
						 */

						/**
						 * [tDBInput_3 process_data_begin ] start
						 */

						currentComponent = "tDBInput_3";

						cLabel = "Appointment";

						/**
						 * [tDBInput_3 process_data_begin ] stop
						 */

						/**
						 * [tMap_3 main ] start
						 */

						currentComponent = "tMap_3";

						if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

								, "row4", "tDBInput_3", "Appointment", "tMysqlInput", "tMap_3", "tMap_3", "tMap"

						)) {
							talendJobLogProcess(globalMap);
						}

						if (log.isTraceEnabled()) {
							log.trace("row4 - " + (row4 == null ? "" : row4.toLogString()));
						}

						boolean hasCasePrimitiveKeyWithNull_tMap_3 = false;

						// ###############################
						// # Input tables (lookups)

						boolean rejectedInnerJoin_tMap_3 = false;
						boolean mainRowRejected_tMap_3 = false;
						// ###############################
						{ // start of Var scope

							// ###############################
							// # Vars tables

							Var__tMap_3__Struct Var = Var__tMap_3;// ###############################
							// ###############################
							// # Output tables

							TodaysAppointment = null;
							PhysicianAndExamroom = null;
							FutureAppointmentsWithInsurance = null;

// # Output table : 'TodaysAppointment'
// # Filter conditions 
							if (

							TalendDate.formatDate("yyyy-MM-dd", row4.StartDateTime)
									.equals(TalendDate.formatDate("yyyy-MM-dd", TalendDate.getCurrentDate()))

							) {
								count_TodaysAppointment_tMap_3++;

								TodaysAppointment_tmp.AppointmentID = row4.AppointmentID;
								TodaysAppointment_tmp.PatientID = row4.PatientID;
								TodaysAppointment_tmp.PhysicianID = row4.PhysicianID;
								TodaysAppointment_tmp.StartDateTime = row4.StartDateTime;
								TodaysAppointment_tmp.ExaminationRoom = row4.ExaminationRoom;
								TodaysAppointment = TodaysAppointment_tmp;
								log.debug("tMap_3 - Outputting the record " + count_TodaysAppointment_tMap_3
										+ " of the output table 'TodaysAppointment'.");

							} // closing filter/reject

// # Output table : 'PhysicianAndExamroom'
							count_PhysicianAndExamroom_tMap_3++;

							PhysicianAndExamroom_tmp.AppointmentID = row4.AppointmentID;
							PhysicianAndExamroom_tmp.PatientID = row4.PatientID;
							PhysicianAndExamroom_tmp.PhysicianID = row4.PhysicianID;
							PhysicianAndExamroom_tmp.StartDateTime = row4.StartDateTime;
							PhysicianAndExamroom_tmp.ExaminationRoom = row4.ExaminationRoom;
							PhysicianAndExamroom = PhysicianAndExamroom_tmp;
							log.debug("tMap_3 - Outputting the record " + count_PhysicianAndExamroom_tMap_3
									+ " of the output table 'PhysicianAndExamroom'.");

// # Output table : 'FutureAppointmentsWithInsurance'
// # Filter conditions 
							if (

							TalendDate.compareDate(row4.StartDateTime, TalendDate.getCurrentDate(), "yyyy-MM-dd") == 1

							) {
								count_FutureAppointmentsWithInsurance_tMap_3++;

								FutureAppointmentsWithInsurance_tmp.AppointmentID = row4.AppointmentID;
								FutureAppointmentsWithInsurance_tmp.PatientID = row4.PatientID;
								FutureAppointmentsWithInsurance_tmp.PhysicianID = row4.PhysicianID;
								FutureAppointmentsWithInsurance_tmp.StartDateTime = row4.StartDateTime;
								FutureAppointmentsWithInsurance_tmp.ExaminationRoom = row4.ExaminationRoom;
								FutureAppointmentsWithInsurance = FutureAppointmentsWithInsurance_tmp;
								log.debug(
										"tMap_3 - Outputting the record " + count_FutureAppointmentsWithInsurance_tMap_3
												+ " of the output table 'FutureAppointmentsWithInsurance'.");

							} // closing filter/reject
// ###############################

						} // end of Var scope

						rejectedInnerJoin_tMap_3 = false;

						tos_count_tMap_3++;

						/**
						 * [tMap_3 main ] stop
						 */

						/**
						 * [tMap_3 process_data_begin ] start
						 */

						currentComponent = "tMap_3";

						/**
						 * [tMap_3 process_data_begin ] stop
						 */
// Start of branch "TodaysAppointment"
						if (TodaysAppointment != null) {

							/**
							 * [tFileOutputExcel_6 main ] start
							 */

							currentComponent = "tFileOutputExcel_6";

							cLabel = "TodaysAppointment";

							if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

									, "TodaysAppointment", "tMap_3", "tMap_3", "tMap", "tFileOutputExcel_6",
									"TodaysAppointment", "tFileOutputExcel"

							)) {
								talendJobLogProcess(globalMap);
							}

							if (log.isTraceEnabled()) {
								log.trace("TodaysAppointment - "
										+ (TodaysAppointment == null ? "" : TodaysAppointment.toLogString()));
							}

							if (TodaysAppointment.AppointmentID != null) {

//modif start

								columnIndex_tFileOutputExcel_6 = 0;

								jxl.write.WritableCell cell_0_tFileOutputExcel_6 = new jxl.write.Number(
										columnIndex_tFileOutputExcel_6,
										startRowNum_tFileOutputExcel_6 + nb_line_tFileOutputExcel_6,

//modif end
										TodaysAppointment.AppointmentID);
//modif start					
								// If we keep the cell format from the existing cell in sheet

//modif ends							
								writableSheet_tFileOutputExcel_6.addCell(cell_0_tFileOutputExcel_6);
								int currentWith_0_tFileOutputExcel_6 = String
										.valueOf(((jxl.write.Number) cell_0_tFileOutputExcel_6).getValue()).trim()
										.length();
								currentWith_0_tFileOutputExcel_6 = currentWith_0_tFileOutputExcel_6 > 10 ? 10
										: currentWith_0_tFileOutputExcel_6;
								fitWidth_tFileOutputExcel_6[0] = fitWidth_tFileOutputExcel_6[0] > currentWith_0_tFileOutputExcel_6
										? fitWidth_tFileOutputExcel_6[0]
										: currentWith_0_tFileOutputExcel_6 + 2;
							}

							if (TodaysAppointment.PatientID != null) {

//modif start

								columnIndex_tFileOutputExcel_6 = 1;

								jxl.write.WritableCell cell_1_tFileOutputExcel_6 = new jxl.write.Number(
										columnIndex_tFileOutputExcel_6,
										startRowNum_tFileOutputExcel_6 + nb_line_tFileOutputExcel_6,

//modif end
										TodaysAppointment.PatientID);
//modif start					
								// If we keep the cell format from the existing cell in sheet

//modif ends							
								writableSheet_tFileOutputExcel_6.addCell(cell_1_tFileOutputExcel_6);
								int currentWith_1_tFileOutputExcel_6 = String
										.valueOf(((jxl.write.Number) cell_1_tFileOutputExcel_6).getValue()).trim()
										.length();
								currentWith_1_tFileOutputExcel_6 = currentWith_1_tFileOutputExcel_6 > 10 ? 10
										: currentWith_1_tFileOutputExcel_6;
								fitWidth_tFileOutputExcel_6[1] = fitWidth_tFileOutputExcel_6[1] > currentWith_1_tFileOutputExcel_6
										? fitWidth_tFileOutputExcel_6[1]
										: currentWith_1_tFileOutputExcel_6 + 2;
							}

							if (TodaysAppointment.PhysicianID != null) {

//modif start

								columnIndex_tFileOutputExcel_6 = 2;

								jxl.write.WritableCell cell_2_tFileOutputExcel_6 = new jxl.write.Number(
										columnIndex_tFileOutputExcel_6,
										startRowNum_tFileOutputExcel_6 + nb_line_tFileOutputExcel_6,

//modif end
										TodaysAppointment.PhysicianID);
//modif start					
								// If we keep the cell format from the existing cell in sheet

//modif ends							
								writableSheet_tFileOutputExcel_6.addCell(cell_2_tFileOutputExcel_6);
								int currentWith_2_tFileOutputExcel_6 = String
										.valueOf(((jxl.write.Number) cell_2_tFileOutputExcel_6).getValue()).trim()
										.length();
								currentWith_2_tFileOutputExcel_6 = currentWith_2_tFileOutputExcel_6 > 10 ? 10
										: currentWith_2_tFileOutputExcel_6;
								fitWidth_tFileOutputExcel_6[2] = fitWidth_tFileOutputExcel_6[2] > currentWith_2_tFileOutputExcel_6
										? fitWidth_tFileOutputExcel_6[2]
										: currentWith_2_tFileOutputExcel_6 + 2;
							}

							if (TodaysAppointment.StartDateTime != null) {

//modif start

								columnIndex_tFileOutputExcel_6 = 3;

								jxl.write.WritableCell cell_3_tFileOutputExcel_6 = new jxl.write.DateTime(
										columnIndex_tFileOutputExcel_6,
										startRowNum_tFileOutputExcel_6 + nb_line_tFileOutputExcel_6,

//modif end
										TodaysAppointment.StartDateTime, cell_format_StartDateTime_tFileOutputExcel_6);
//modif start					
								// If we keep the cell format from the existing cell in sheet

//modif ends							
								writableSheet_tFileOutputExcel_6.addCell(cell_3_tFileOutputExcel_6);
								int currentWith_3_tFileOutputExcel_6 = cell_3_tFileOutputExcel_6.getContents().trim()
										.length();
								currentWith_3_tFileOutputExcel_6 = 12;
								fitWidth_tFileOutputExcel_6[3] = fitWidth_tFileOutputExcel_6[3] > currentWith_3_tFileOutputExcel_6
										? fitWidth_tFileOutputExcel_6[3]
										: currentWith_3_tFileOutputExcel_6 + 2;
							}

							if (TodaysAppointment.ExaminationRoom != null) {

//modif start

								columnIndex_tFileOutputExcel_6 = 4;

								jxl.write.WritableCell cell_4_tFileOutputExcel_6 = new jxl.write.Label(
										columnIndex_tFileOutputExcel_6,
										startRowNum_tFileOutputExcel_6 + nb_line_tFileOutputExcel_6,

//modif end
										TodaysAppointment.ExaminationRoom);
//modif start					
								// If we keep the cell format from the existing cell in sheet

//modif ends							
								writableSheet_tFileOutputExcel_6.addCell(cell_4_tFileOutputExcel_6);
								int currentWith_4_tFileOutputExcel_6 = cell_4_tFileOutputExcel_6.getContents().trim()
										.length();
								fitWidth_tFileOutputExcel_6[4] = fitWidth_tFileOutputExcel_6[4] > currentWith_4_tFileOutputExcel_6
										? fitWidth_tFileOutputExcel_6[4]
										: currentWith_4_tFileOutputExcel_6 + 2;
							}

							nb_line_tFileOutputExcel_6++;

							log.debug("tFileOutputExcel_6 - Writing the record " + nb_line_tFileOutputExcel_6
									+ " to the file.");

							tos_count_tFileOutputExcel_6++;

							/**
							 * [tFileOutputExcel_6 main ] stop
							 */

							/**
							 * [tFileOutputExcel_6 process_data_begin ] start
							 */

							currentComponent = "tFileOutputExcel_6";

							cLabel = "TodaysAppointment";

							/**
							 * [tFileOutputExcel_6 process_data_begin ] stop
							 */

							/**
							 * [tFileOutputExcel_6 process_data_end ] start
							 */

							currentComponent = "tFileOutputExcel_6";

							cLabel = "TodaysAppointment";

							/**
							 * [tFileOutputExcel_6 process_data_end ] stop
							 */

						} // End of branch "TodaysAppointment"

// Start of branch "PhysicianAndExamroom"
						if (PhysicianAndExamroom != null) {

							/**
							 * [tSortRow_2_SortOut main ] start
							 */

							currentVirtualComponent = "tSortRow_2";

							currentComponent = "tSortRow_2_SortOut";

							if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

									, "PhysicianAndExamroom", "tMap_3", "tMap_3", "tMap", "tSortRow_2_SortOut",
									"tSortRow_2_SortOut", "tSortOut"

							)) {
								talendJobLogProcess(globalMap);
							}

							if (log.isTraceEnabled()) {
								log.trace("PhysicianAndExamroom - "
										+ (PhysicianAndExamroom == null ? "" : PhysicianAndExamroom.toLogString()));
							}

							ComparablePhysicianAndExamroomStruct arrayRowtSortRow_2_SortOut = new ComparablePhysicianAndExamroomStruct();

							arrayRowtSortRow_2_SortOut.AppointmentID = PhysicianAndExamroom.AppointmentID;
							arrayRowtSortRow_2_SortOut.PatientID = PhysicianAndExamroom.PatientID;
							arrayRowtSortRow_2_SortOut.PhysicianID = PhysicianAndExamroom.PhysicianID;
							arrayRowtSortRow_2_SortOut.StartDateTime = PhysicianAndExamroom.StartDateTime;
							arrayRowtSortRow_2_SortOut.ExaminationRoom = PhysicianAndExamroom.ExaminationRoom;
							list_tSortRow_2_SortOut.add(arrayRowtSortRow_2_SortOut);

							tos_count_tSortRow_2_SortOut++;

							/**
							 * [tSortRow_2_SortOut main ] stop
							 */

							/**
							 * [tSortRow_2_SortOut process_data_begin ] start
							 */

							currentVirtualComponent = "tSortRow_2";

							currentComponent = "tSortRow_2_SortOut";

							/**
							 * [tSortRow_2_SortOut process_data_begin ] stop
							 */

							/**
							 * [tSortRow_2_SortOut process_data_end ] start
							 */

							currentVirtualComponent = "tSortRow_2";

							currentComponent = "tSortRow_2_SortOut";

							/**
							 * [tSortRow_2_SortOut process_data_end ] stop
							 */

						} // End of branch "PhysicianAndExamroom"

// Start of branch "FutureAppointmentsWithInsurance"
						if (FutureAppointmentsWithInsurance != null) {

							/**
							 * [tFileOutputExcel_8 main ] start
							 */

							currentComponent = "tFileOutputExcel_8";

							cLabel = "FutureAppointments";

							if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

									, "FutureAppointmentsWithInsurance", "tMap_3", "tMap_3", "tMap",
									"tFileOutputExcel_8", "FutureAppointments", "tFileOutputExcel"

							)) {
								talendJobLogProcess(globalMap);
							}

							if (log.isTraceEnabled()) {
								log.trace("FutureAppointmentsWithInsurance - "
										+ (FutureAppointmentsWithInsurance == null ? ""
												: FutureAppointmentsWithInsurance.toLogString()));
							}

							if (FutureAppointmentsWithInsurance.AppointmentID != null) {

//modif start

								columnIndex_tFileOutputExcel_8 = 0;

								jxl.write.WritableCell cell_0_tFileOutputExcel_8 = new jxl.write.Number(
										columnIndex_tFileOutputExcel_8,
										startRowNum_tFileOutputExcel_8 + nb_line_tFileOutputExcel_8,

//modif end
										FutureAppointmentsWithInsurance.AppointmentID);
//modif start					
								// If we keep the cell format from the existing cell in sheet

//modif ends							
								writableSheet_tFileOutputExcel_8.addCell(cell_0_tFileOutputExcel_8);
								int currentWith_0_tFileOutputExcel_8 = String
										.valueOf(((jxl.write.Number) cell_0_tFileOutputExcel_8).getValue()).trim()
										.length();
								currentWith_0_tFileOutputExcel_8 = currentWith_0_tFileOutputExcel_8 > 10 ? 10
										: currentWith_0_tFileOutputExcel_8;
								fitWidth_tFileOutputExcel_8[0] = fitWidth_tFileOutputExcel_8[0] > currentWith_0_tFileOutputExcel_8
										? fitWidth_tFileOutputExcel_8[0]
										: currentWith_0_tFileOutputExcel_8 + 2;
							}

							if (FutureAppointmentsWithInsurance.PatientID != null) {

//modif start

								columnIndex_tFileOutputExcel_8 = 1;

								jxl.write.WritableCell cell_1_tFileOutputExcel_8 = new jxl.write.Number(
										columnIndex_tFileOutputExcel_8,
										startRowNum_tFileOutputExcel_8 + nb_line_tFileOutputExcel_8,

//modif end
										FutureAppointmentsWithInsurance.PatientID);
//modif start					
								// If we keep the cell format from the existing cell in sheet

//modif ends							
								writableSheet_tFileOutputExcel_8.addCell(cell_1_tFileOutputExcel_8);
								int currentWith_1_tFileOutputExcel_8 = String
										.valueOf(((jxl.write.Number) cell_1_tFileOutputExcel_8).getValue()).trim()
										.length();
								currentWith_1_tFileOutputExcel_8 = currentWith_1_tFileOutputExcel_8 > 10 ? 10
										: currentWith_1_tFileOutputExcel_8;
								fitWidth_tFileOutputExcel_8[1] = fitWidth_tFileOutputExcel_8[1] > currentWith_1_tFileOutputExcel_8
										? fitWidth_tFileOutputExcel_8[1]
										: currentWith_1_tFileOutputExcel_8 + 2;
							}

							if (FutureAppointmentsWithInsurance.PhysicianID != null) {

//modif start

								columnIndex_tFileOutputExcel_8 = 2;

								jxl.write.WritableCell cell_2_tFileOutputExcel_8 = new jxl.write.Number(
										columnIndex_tFileOutputExcel_8,
										startRowNum_tFileOutputExcel_8 + nb_line_tFileOutputExcel_8,

//modif end
										FutureAppointmentsWithInsurance.PhysicianID);
//modif start					
								// If we keep the cell format from the existing cell in sheet

//modif ends							
								writableSheet_tFileOutputExcel_8.addCell(cell_2_tFileOutputExcel_8);
								int currentWith_2_tFileOutputExcel_8 = String
										.valueOf(((jxl.write.Number) cell_2_tFileOutputExcel_8).getValue()).trim()
										.length();
								currentWith_2_tFileOutputExcel_8 = currentWith_2_tFileOutputExcel_8 > 10 ? 10
										: currentWith_2_tFileOutputExcel_8;
								fitWidth_tFileOutputExcel_8[2] = fitWidth_tFileOutputExcel_8[2] > currentWith_2_tFileOutputExcel_8
										? fitWidth_tFileOutputExcel_8[2]
										: currentWith_2_tFileOutputExcel_8 + 2;
							}

							if (FutureAppointmentsWithInsurance.StartDateTime != null) {

//modif start

								columnIndex_tFileOutputExcel_8 = 3;

								jxl.write.WritableCell cell_3_tFileOutputExcel_8 = new jxl.write.DateTime(
										columnIndex_tFileOutputExcel_8,
										startRowNum_tFileOutputExcel_8 + nb_line_tFileOutputExcel_8,

//modif end
										FutureAppointmentsWithInsurance.StartDateTime,
										cell_format_StartDateTime_tFileOutputExcel_8);
//modif start					
								// If we keep the cell format from the existing cell in sheet

//modif ends							
								writableSheet_tFileOutputExcel_8.addCell(cell_3_tFileOutputExcel_8);
								int currentWith_3_tFileOutputExcel_8 = cell_3_tFileOutputExcel_8.getContents().trim()
										.length();
								currentWith_3_tFileOutputExcel_8 = 12;
								fitWidth_tFileOutputExcel_8[3] = fitWidth_tFileOutputExcel_8[3] > currentWith_3_tFileOutputExcel_8
										? fitWidth_tFileOutputExcel_8[3]
										: currentWith_3_tFileOutputExcel_8 + 2;
							}

							if (FutureAppointmentsWithInsurance.ExaminationRoom != null) {

//modif start

								columnIndex_tFileOutputExcel_8 = 4;

								jxl.write.WritableCell cell_4_tFileOutputExcel_8 = new jxl.write.Label(
										columnIndex_tFileOutputExcel_8,
										startRowNum_tFileOutputExcel_8 + nb_line_tFileOutputExcel_8,

//modif end
										FutureAppointmentsWithInsurance.ExaminationRoom);
//modif start					
								// If we keep the cell format from the existing cell in sheet

//modif ends							
								writableSheet_tFileOutputExcel_8.addCell(cell_4_tFileOutputExcel_8);
								int currentWith_4_tFileOutputExcel_8 = cell_4_tFileOutputExcel_8.getContents().trim()
										.length();
								fitWidth_tFileOutputExcel_8[4] = fitWidth_tFileOutputExcel_8[4] > currentWith_4_tFileOutputExcel_8
										? fitWidth_tFileOutputExcel_8[4]
										: currentWith_4_tFileOutputExcel_8 + 2;
							}

							nb_line_tFileOutputExcel_8++;

							log.debug("tFileOutputExcel_8 - Writing the record " + nb_line_tFileOutputExcel_8
									+ " to the file.");

							tos_count_tFileOutputExcel_8++;

							/**
							 * [tFileOutputExcel_8 main ] stop
							 */

							/**
							 * [tFileOutputExcel_8 process_data_begin ] start
							 */

							currentComponent = "tFileOutputExcel_8";

							cLabel = "FutureAppointments";

							/**
							 * [tFileOutputExcel_8 process_data_begin ] stop
							 */

							/**
							 * [tFileOutputExcel_8 process_data_end ] start
							 */

							currentComponent = "tFileOutputExcel_8";

							cLabel = "FutureAppointments";

							/**
							 * [tFileOutputExcel_8 process_data_end ] stop
							 */

						} // End of branch "FutureAppointmentsWithInsurance"

						/**
						 * [tMap_3 process_data_end ] start
						 */

						currentComponent = "tMap_3";

						/**
						 * [tMap_3 process_data_end ] stop
						 */

						/**
						 * [tDBInput_3 process_data_end ] start
						 */

						currentComponent = "tDBInput_3";

						cLabel = "Appointment";

						/**
						 * [tDBInput_3 process_data_end ] stop
						 */

						/**
						 * [tDBInput_3 end ] start
						 */

						currentComponent = "tDBInput_3";

						cLabel = "Appointment";

					}
				} finally {
					if (rs_tDBInput_3 != null) {
						rs_tDBInput_3.close();
					}
					if (stmt_tDBInput_3 != null) {
						stmt_tDBInput_3.close();
					}
					if (conn_tDBInput_3 != null && !conn_tDBInput_3.isClosed()) {

						log.debug("tDBInput_3 - Closing the connection to the database.");

						conn_tDBInput_3.close();

						if ("com.mysql.cj.jdbc.Driver".equals((String) globalMap.get("driverClass_"))
								&& routines.system.BundleUtils.inOSGi()) {
							Class.forName("com.mysql.cj.jdbc.AbandonedConnectionCleanupThread")
									.getMethod("checkedShutdown").invoke(null, (Object[]) null);
						}

						log.debug("tDBInput_3 - Connection to the database closed.");

					}

				}
				globalMap.put("tDBInput_3_NB_LINE", nb_line_tDBInput_3);
				log.debug("tDBInput_3 - Retrieved records count: " + nb_line_tDBInput_3 + " .");

				if (log.isDebugEnabled())
					log.debug("tDBInput_3 - " + ("Done."));

				ok_Hash.put("tDBInput_3", true);
				end_Hash.put("tDBInput_3", System.currentTimeMillis());

				/**
				 * [tDBInput_3 end ] stop
				 */

				/**
				 * [tMap_3 end ] start
				 */

				currentComponent = "tMap_3";

// ###############################
// # Lookup hashes releasing
// ###############################      
				log.debug("tMap_3 - Written records count in the table 'TodaysAppointment': "
						+ count_TodaysAppointment_tMap_3 + ".");
				log.debug("tMap_3 - Written records count in the table 'PhysicianAndExamroom': "
						+ count_PhysicianAndExamroom_tMap_3 + ".");
				log.debug("tMap_3 - Written records count in the table 'FutureAppointmentsWithInsurance': "
						+ count_FutureAppointmentsWithInsurance_tMap_3 + ".");

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "row4", 2, 0,
						"tDBInput_3", "Appointment", "tMysqlInput", "tMap_3", "tMap_3", "tMap", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tMap_3 - " + ("Done."));

				ok_Hash.put("tMap_3", true);
				end_Hash.put("tMap_3", System.currentTimeMillis());

				/**
				 * [tMap_3 end ] stop
				 */

				/**
				 * [tFileOutputExcel_6 end ] start
				 */

				currentComponent = "tFileOutputExcel_6";

				cLabel = "TodaysAppointment";

				writeableWorkbook_tFileOutputExcel_6.write();
				writeableWorkbook_tFileOutputExcel_6.close();
				if (headerIsInserted_tFileOutputExcel_6 && nb_line_tFileOutputExcel_6 > 0) {
					nb_line_tFileOutputExcel_6 = nb_line_tFileOutputExcel_6 - 1;
				}
				globalMap.put("tFileOutputExcel_6_NB_LINE", nb_line_tFileOutputExcel_6);

				log.debug("tFileOutputExcel_6 - Written records count: " + nb_line_tFileOutputExcel_6 + " .");

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "TodaysAppointment", 2,
						0, "tMap_3", "tMap_3", "tMap", "tFileOutputExcel_6", "TodaysAppointment", "tFileOutputExcel",
						"output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tFileOutputExcel_6 - " + ("Done."));

				ok_Hash.put("tFileOutputExcel_6", true);
				end_Hash.put("tFileOutputExcel_6", System.currentTimeMillis());

				/**
				 * [tFileOutputExcel_6 end ] stop
				 */

				/**
				 * [tSortRow_2_SortOut end ] start
				 */

				currentVirtualComponent = "tSortRow_2";

				currentComponent = "tSortRow_2_SortOut";

				PhysicianAndExamroomStruct[] array_tSortRow_2_SortOut = list_tSortRow_2_SortOut
						.toArray(new ComparablePhysicianAndExamroomStruct[0]);

				java.util.Arrays.sort(array_tSortRow_2_SortOut);

				globalMap.put("tSortRow_2", array_tSortRow_2_SortOut);

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "PhysicianAndExamroom",
						2, 0, "tMap_3", "tMap_3", "tMap", "tSortRow_2_SortOut", "tSortRow_2_SortOut", "tSortOut",
						"output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tSortRow_2_SortOut - " + ("Done."));

				ok_Hash.put("tSortRow_2_SortOut", true);
				end_Hash.put("tSortRow_2_SortOut", System.currentTimeMillis());

				/**
				 * [tSortRow_2_SortOut end ] stop
				 */

				/**
				 * [tFileOutputExcel_7 begin ] start
				 */

				ok_Hash.put("tFileOutputExcel_7", false);
				start_Hash.put("tFileOutputExcel_7", System.currentTimeMillis());

				currentComponent = "tFileOutputExcel_7";

				cLabel = "PhysicianExmRoom";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "row5");

				int tos_count_tFileOutputExcel_7 = 0;

				if (log.isDebugEnabled())
					log.debug("tFileOutputExcel_7 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tFileOutputExcel_7 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tFileOutputExcel_7 = new StringBuilder();
							log4jParamters_tFileOutputExcel_7.append("Parameters:");
							log4jParamters_tFileOutputExcel_7.append("VERSION_2007" + " = " + "false");
							log4jParamters_tFileOutputExcel_7.append(" | ");
							log4jParamters_tFileOutputExcel_7.append("USESTREAM" + " = " + "false");
							log4jParamters_tFileOutputExcel_7.append(" | ");
							log4jParamters_tFileOutputExcel_7.append(
									"FILENAME" + " = " + "\"C:/Users/2382187/Downloads/FR/PhysicianExmRoom.xls\"");
							log4jParamters_tFileOutputExcel_7.append(" | ");
							log4jParamters_tFileOutputExcel_7.append("SHEETNAME" + " = " + "\"AppointmentExmRoom\"");
							log4jParamters_tFileOutputExcel_7.append(" | ");
							log4jParamters_tFileOutputExcel_7.append("INCLUDEHEADER" + " = " + "true");
							log4jParamters_tFileOutputExcel_7.append(" | ");
							log4jParamters_tFileOutputExcel_7.append("APPEND_FILE" + " = " + "false");
							log4jParamters_tFileOutputExcel_7.append(" | ");
							log4jParamters_tFileOutputExcel_7.append("FIRST_CELL_Y_ABSOLUTE" + " = " + "false");
							log4jParamters_tFileOutputExcel_7.append(" | ");
							log4jParamters_tFileOutputExcel_7.append("FONT" + " = " + "");
							log4jParamters_tFileOutputExcel_7.append(" | ");
							log4jParamters_tFileOutputExcel_7.append("IS_ALL_AUTO_SZIE" + " = " + "true");
							log4jParamters_tFileOutputExcel_7.append(" | ");
							log4jParamters_tFileOutputExcel_7.append("CREATE" + " = " + "true");
							log4jParamters_tFileOutputExcel_7.append(" | ");
							log4jParamters_tFileOutputExcel_7.append("ADVANCED_SEPARATOR" + " = " + "false");
							log4jParamters_tFileOutputExcel_7.append(" | ");
							log4jParamters_tFileOutputExcel_7.append("ENCODING" + " = " + "\"ISO-8859-15\"");
							log4jParamters_tFileOutputExcel_7.append(" | ");
							log4jParamters_tFileOutputExcel_7.append("DELETE_EMPTYFILE" + " = " + "false");
							log4jParamters_tFileOutputExcel_7.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tFileOutputExcel_7 - " + (log4jParamters_tFileOutputExcel_7));
						}
					}
					new BytesLimit65535_tFileOutputExcel_7().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tFileOutputExcel_7", "PhysicianExmRoom", "tFileOutputExcel");
					talendJobLogProcess(globalMap);
				}

				int columnIndex_tFileOutputExcel_7 = 0;
				boolean headerIsInserted_tFileOutputExcel_7 = false;

				int nb_line_tFileOutputExcel_7 = 0;

				String fileName_tFileOutputExcel_7 = "C:/Users/2382187/Downloads/FR/PhysicianExmRoom.xls";
				java.io.File file_tFileOutputExcel_7 = new java.io.File(fileName_tFileOutputExcel_7);
				boolean isFileGenerated_tFileOutputExcel_7 = true;
//create directory only if not exists
				java.io.File parentFile_tFileOutputExcel_7 = file_tFileOutputExcel_7.getParentFile();
				if (parentFile_tFileOutputExcel_7 != null && !parentFile_tFileOutputExcel_7.exists()) {

					log.info("tFileOutputExcel_7 - Creating directory '"
							+ parentFile_tFileOutputExcel_7.getCanonicalPath() + "'.");

					parentFile_tFileOutputExcel_7.mkdirs();

					log.info("tFileOutputExcel_7 - Create directory '"
							+ parentFile_tFileOutputExcel_7.getCanonicalPath() + "' has succeeded.");

				}

				jxl.write.WritableWorkbook writeableWorkbook_tFileOutputExcel_7 = null;
				jxl.write.WritableSheet writableSheet_tFileOutputExcel_7 = null;

				jxl.WorkbookSettings workbookSettings_tFileOutputExcel_7 = new jxl.WorkbookSettings();
				workbookSettings_tFileOutputExcel_7.setEncoding("ISO-8859-15");
				writeableWorkbook_tFileOutputExcel_7 = new jxl.write.biff.WritableWorkbookImpl(
						new java.io.BufferedOutputStream(new java.io.FileOutputStream(fileName_tFileOutputExcel_7)),
						true, workbookSettings_tFileOutputExcel_7);

				writableSheet_tFileOutputExcel_7 = writeableWorkbook_tFileOutputExcel_7.getSheet("AppointmentExmRoom");
				if (writableSheet_tFileOutputExcel_7 == null) {
					writableSheet_tFileOutputExcel_7 = writeableWorkbook_tFileOutputExcel_7.createSheet(
							"AppointmentExmRoom", writeableWorkbook_tFileOutputExcel_7.getNumberOfSheets());
				}

				// modif start
				int startRowNum_tFileOutputExcel_7 = writableSheet_tFileOutputExcel_7.getRows();
				// modif end

				int[] fitWidth_tFileOutputExcel_7 = new int[5];
				for (int i_tFileOutputExcel_7 = 0; i_tFileOutputExcel_7 < 5; i_tFileOutputExcel_7++) {
					int fitCellViewSize_tFileOutputExcel_7 = writableSheet_tFileOutputExcel_7
							.getColumnView(i_tFileOutputExcel_7).getSize();
					fitWidth_tFileOutputExcel_7[i_tFileOutputExcel_7] = fitCellViewSize_tFileOutputExcel_7 / 256;
					if (fitCellViewSize_tFileOutputExcel_7 % 256 != 0) {
						fitWidth_tFileOutputExcel_7[i_tFileOutputExcel_7] += 1;
					}
				}

				final jxl.write.WritableCellFormat cell_format_StartDateTime_tFileOutputExcel_7 = new jxl.write.WritableCellFormat(
						new jxl.write.DateFormat("dd-MM-yyyy"));

				if (startRowNum_tFileOutputExcel_7 == 0) {
					// modif end
					// modif start
					writableSheet_tFileOutputExcel_7
							.addCell(new jxl.write.Label(0, nb_line_tFileOutputExcel_7, "AppointmentID"));
					// modif end
					fitWidth_tFileOutputExcel_7[0] = fitWidth_tFileOutputExcel_7[0] > 13
							? fitWidth_tFileOutputExcel_7[0]
							: 13;
					// modif start
					writableSheet_tFileOutputExcel_7
							.addCell(new jxl.write.Label(1, nb_line_tFileOutputExcel_7, "PatientID"));
					// modif end
					fitWidth_tFileOutputExcel_7[1] = fitWidth_tFileOutputExcel_7[1] > 9 ? fitWidth_tFileOutputExcel_7[1]
							: 9;
					// modif start
					writableSheet_tFileOutputExcel_7
							.addCell(new jxl.write.Label(2, nb_line_tFileOutputExcel_7, "PhysicianID"));
					// modif end
					fitWidth_tFileOutputExcel_7[2] = fitWidth_tFileOutputExcel_7[2] > 11
							? fitWidth_tFileOutputExcel_7[2]
							: 11;
					// modif start
					writableSheet_tFileOutputExcel_7
							.addCell(new jxl.write.Label(3, nb_line_tFileOutputExcel_7, "StartDateTime"));
					// modif end
					fitWidth_tFileOutputExcel_7[3] = fitWidth_tFileOutputExcel_7[3] > 13
							? fitWidth_tFileOutputExcel_7[3]
							: 13;
					// modif start
					writableSheet_tFileOutputExcel_7
							.addCell(new jxl.write.Label(4, nb_line_tFileOutputExcel_7, "ExaminationRoom"));
					// modif end
					fitWidth_tFileOutputExcel_7[4] = fitWidth_tFileOutputExcel_7[4] > 15
							? fitWidth_tFileOutputExcel_7[4]
							: 15;
					nb_line_tFileOutputExcel_7++;
					headerIsInserted_tFileOutputExcel_7 = true;
				}

				/**
				 * [tFileOutputExcel_7 begin ] stop
				 */

				/**
				 * [tSortRow_2_SortIn begin ] start
				 */

				ok_Hash.put("tSortRow_2_SortIn", false);
				start_Hash.put("tSortRow_2_SortIn", System.currentTimeMillis());

				currentVirtualComponent = "tSortRow_2";

				currentComponent = "tSortRow_2_SortIn";

				int tos_count_tSortRow_2_SortIn = 0;

				if (log.isDebugEnabled())
					log.debug("tSortRow_2_SortIn - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tSortRow_2_SortIn {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tSortRow_2_SortIn = new StringBuilder();
							log4jParamters_tSortRow_2_SortIn.append("Parameters:");
							log4jParamters_tSortRow_2_SortIn.append("ORIGIN" + " = " + "tSortRow_2");
							log4jParamters_tSortRow_2_SortIn.append(" | ");
							log4jParamters_tSortRow_2_SortIn.append("EXTERNAL" + " = " + "false");
							log4jParamters_tSortRow_2_SortIn.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tSortRow_2_SortIn - " + (log4jParamters_tSortRow_2_SortIn));
						}
					}
					new BytesLimit65535_tSortRow_2_SortIn().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tSortRow_2_SortIn", "tSortRow_2_SortIn", "tSortIn");
					talendJobLogProcess(globalMap);
				}

				PhysicianAndExamroomStruct[] array_tSortRow_2_SortIn = (PhysicianAndExamroomStruct[]) globalMap
						.remove("tSortRow_2");

				int nb_line_tSortRow_2_SortIn = 0;

				PhysicianAndExamroomStruct current_tSortRow_2_SortIn = null;

				for (int i_tSortRow_2_SortIn = 0; i_tSortRow_2_SortIn < array_tSortRow_2_SortIn.length; i_tSortRow_2_SortIn++) {
					current_tSortRow_2_SortIn = array_tSortRow_2_SortIn[i_tSortRow_2_SortIn];
					row5.AppointmentID = current_tSortRow_2_SortIn.AppointmentID;
					row5.PatientID = current_tSortRow_2_SortIn.PatientID;
					row5.PhysicianID = current_tSortRow_2_SortIn.PhysicianID;
					row5.StartDateTime = current_tSortRow_2_SortIn.StartDateTime;
					row5.ExaminationRoom = current_tSortRow_2_SortIn.ExaminationRoom;
					// increase number of line sorted
					nb_line_tSortRow_2_SortIn++;

					/**
					 * [tSortRow_2_SortIn begin ] stop
					 */

					/**
					 * [tSortRow_2_SortIn main ] start
					 */

					currentVirtualComponent = "tSortRow_2";

					currentComponent = "tSortRow_2_SortIn";

					tos_count_tSortRow_2_SortIn++;

					/**
					 * [tSortRow_2_SortIn main ] stop
					 */

					/**
					 * [tSortRow_2_SortIn process_data_begin ] start
					 */

					currentVirtualComponent = "tSortRow_2";

					currentComponent = "tSortRow_2_SortIn";

					/**
					 * [tSortRow_2_SortIn process_data_begin ] stop
					 */

					/**
					 * [tFileOutputExcel_7 main ] start
					 */

					currentComponent = "tFileOutputExcel_7";

					cLabel = "PhysicianExmRoom";

					if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

							, "row5", "tSortRow_2_SortIn", "tSortRow_2_SortIn", "tSortIn", "tFileOutputExcel_7",
							"PhysicianExmRoom", "tFileOutputExcel"

					)) {
						talendJobLogProcess(globalMap);
					}

					if (log.isTraceEnabled()) {
						log.trace("row5 - " + (row5 == null ? "" : row5.toLogString()));
					}

					if (row5.AppointmentID != null) {

//modif start

						columnIndex_tFileOutputExcel_7 = 0;

						jxl.write.WritableCell cell_0_tFileOutputExcel_7 = new jxl.write.Number(
								columnIndex_tFileOutputExcel_7,
								startRowNum_tFileOutputExcel_7 + nb_line_tFileOutputExcel_7,

//modif end
								row5.AppointmentID);
//modif start					
						// If we keep the cell format from the existing cell in sheet

//modif ends							
						writableSheet_tFileOutputExcel_7.addCell(cell_0_tFileOutputExcel_7);
						int currentWith_0_tFileOutputExcel_7 = String
								.valueOf(((jxl.write.Number) cell_0_tFileOutputExcel_7).getValue()).trim().length();
						currentWith_0_tFileOutputExcel_7 = currentWith_0_tFileOutputExcel_7 > 10 ? 10
								: currentWith_0_tFileOutputExcel_7;
						fitWidth_tFileOutputExcel_7[0] = fitWidth_tFileOutputExcel_7[0] > currentWith_0_tFileOutputExcel_7
								? fitWidth_tFileOutputExcel_7[0]
								: currentWith_0_tFileOutputExcel_7 + 2;
					}

					if (row5.PatientID != null) {

//modif start

						columnIndex_tFileOutputExcel_7 = 1;

						jxl.write.WritableCell cell_1_tFileOutputExcel_7 = new jxl.write.Number(
								columnIndex_tFileOutputExcel_7,
								startRowNum_tFileOutputExcel_7 + nb_line_tFileOutputExcel_7,

//modif end
								row5.PatientID);
//modif start					
						// If we keep the cell format from the existing cell in sheet

//modif ends							
						writableSheet_tFileOutputExcel_7.addCell(cell_1_tFileOutputExcel_7);
						int currentWith_1_tFileOutputExcel_7 = String
								.valueOf(((jxl.write.Number) cell_1_tFileOutputExcel_7).getValue()).trim().length();
						currentWith_1_tFileOutputExcel_7 = currentWith_1_tFileOutputExcel_7 > 10 ? 10
								: currentWith_1_tFileOutputExcel_7;
						fitWidth_tFileOutputExcel_7[1] = fitWidth_tFileOutputExcel_7[1] > currentWith_1_tFileOutputExcel_7
								? fitWidth_tFileOutputExcel_7[1]
								: currentWith_1_tFileOutputExcel_7 + 2;
					}

					if (row5.PhysicianID != null) {

//modif start

						columnIndex_tFileOutputExcel_7 = 2;

						jxl.write.WritableCell cell_2_tFileOutputExcel_7 = new jxl.write.Number(
								columnIndex_tFileOutputExcel_7,
								startRowNum_tFileOutputExcel_7 + nb_line_tFileOutputExcel_7,

//modif end
								row5.PhysicianID);
//modif start					
						// If we keep the cell format from the existing cell in sheet

//modif ends							
						writableSheet_tFileOutputExcel_7.addCell(cell_2_tFileOutputExcel_7);
						int currentWith_2_tFileOutputExcel_7 = String
								.valueOf(((jxl.write.Number) cell_2_tFileOutputExcel_7).getValue()).trim().length();
						currentWith_2_tFileOutputExcel_7 = currentWith_2_tFileOutputExcel_7 > 10 ? 10
								: currentWith_2_tFileOutputExcel_7;
						fitWidth_tFileOutputExcel_7[2] = fitWidth_tFileOutputExcel_7[2] > currentWith_2_tFileOutputExcel_7
								? fitWidth_tFileOutputExcel_7[2]
								: currentWith_2_tFileOutputExcel_7 + 2;
					}

					if (row5.StartDateTime != null) {

//modif start

						columnIndex_tFileOutputExcel_7 = 3;

						jxl.write.WritableCell cell_3_tFileOutputExcel_7 = new jxl.write.DateTime(
								columnIndex_tFileOutputExcel_7,
								startRowNum_tFileOutputExcel_7 + nb_line_tFileOutputExcel_7,

//modif end
								row5.StartDateTime, cell_format_StartDateTime_tFileOutputExcel_7);
//modif start					
						// If we keep the cell format from the existing cell in sheet

//modif ends							
						writableSheet_tFileOutputExcel_7.addCell(cell_3_tFileOutputExcel_7);
						int currentWith_3_tFileOutputExcel_7 = cell_3_tFileOutputExcel_7.getContents().trim().length();
						currentWith_3_tFileOutputExcel_7 = 12;
						fitWidth_tFileOutputExcel_7[3] = fitWidth_tFileOutputExcel_7[3] > currentWith_3_tFileOutputExcel_7
								? fitWidth_tFileOutputExcel_7[3]
								: currentWith_3_tFileOutputExcel_7 + 2;
					}

					if (row5.ExaminationRoom != null) {

//modif start

						columnIndex_tFileOutputExcel_7 = 4;

						jxl.write.WritableCell cell_4_tFileOutputExcel_7 = new jxl.write.Label(
								columnIndex_tFileOutputExcel_7,
								startRowNum_tFileOutputExcel_7 + nb_line_tFileOutputExcel_7,

//modif end
								row5.ExaminationRoom);
//modif start					
						// If we keep the cell format from the existing cell in sheet

//modif ends							
						writableSheet_tFileOutputExcel_7.addCell(cell_4_tFileOutputExcel_7);
						int currentWith_4_tFileOutputExcel_7 = cell_4_tFileOutputExcel_7.getContents().trim().length();
						fitWidth_tFileOutputExcel_7[4] = fitWidth_tFileOutputExcel_7[4] > currentWith_4_tFileOutputExcel_7
								? fitWidth_tFileOutputExcel_7[4]
								: currentWith_4_tFileOutputExcel_7 + 2;
					}

					nb_line_tFileOutputExcel_7++;

					log.debug(
							"tFileOutputExcel_7 - Writing the record " + nb_line_tFileOutputExcel_7 + " to the file.");

					tos_count_tFileOutputExcel_7++;

					/**
					 * [tFileOutputExcel_7 main ] stop
					 */

					/**
					 * [tFileOutputExcel_7 process_data_begin ] start
					 */

					currentComponent = "tFileOutputExcel_7";

					cLabel = "PhysicianExmRoom";

					/**
					 * [tFileOutputExcel_7 process_data_begin ] stop
					 */

					/**
					 * [tFileOutputExcel_7 process_data_end ] start
					 */

					currentComponent = "tFileOutputExcel_7";

					cLabel = "PhysicianExmRoom";

					/**
					 * [tFileOutputExcel_7 process_data_end ] stop
					 */

					/**
					 * [tSortRow_2_SortIn process_data_end ] start
					 */

					currentVirtualComponent = "tSortRow_2";

					currentComponent = "tSortRow_2_SortIn";

					/**
					 * [tSortRow_2_SortIn process_data_end ] stop
					 */

					/**
					 * [tSortRow_2_SortIn end ] start
					 */

					currentVirtualComponent = "tSortRow_2";

					currentComponent = "tSortRow_2_SortIn";

				}

				globalMap.put("tSortRow_2_SortIn_NB_LINE", nb_line_tSortRow_2_SortIn);

				if (log.isDebugEnabled())
					log.debug("tSortRow_2_SortIn - " + ("Done."));

				ok_Hash.put("tSortRow_2_SortIn", true);
				end_Hash.put("tSortRow_2_SortIn", System.currentTimeMillis());

				/**
				 * [tSortRow_2_SortIn end ] stop
				 */

				/**
				 * [tFileOutputExcel_7 end ] start
				 */

				currentComponent = "tFileOutputExcel_7";

				cLabel = "PhysicianExmRoom";

				columnIndex_tFileOutputExcel_7 = 0;

				// modif start

				writableSheet_tFileOutputExcel_7.setColumnView(columnIndex_tFileOutputExcel_7,
						fitWidth_tFileOutputExcel_7[0]);

				// modif end

				columnIndex_tFileOutputExcel_7 = 1;

				// modif start

				writableSheet_tFileOutputExcel_7.setColumnView(columnIndex_tFileOutputExcel_7,
						fitWidth_tFileOutputExcel_7[1]);

				// modif end

				columnIndex_tFileOutputExcel_7 = 2;

				// modif start

				writableSheet_tFileOutputExcel_7.setColumnView(columnIndex_tFileOutputExcel_7,
						fitWidth_tFileOutputExcel_7[2]);

				// modif end

				columnIndex_tFileOutputExcel_7 = 3;

				// modif start

				writableSheet_tFileOutputExcel_7.setColumnView(columnIndex_tFileOutputExcel_7,
						fitWidth_tFileOutputExcel_7[3]);

				// modif end

				columnIndex_tFileOutputExcel_7 = 4;

				// modif start

				writableSheet_tFileOutputExcel_7.setColumnView(columnIndex_tFileOutputExcel_7,
						fitWidth_tFileOutputExcel_7[4]);

				// modif end

				writeableWorkbook_tFileOutputExcel_7.write();
				writeableWorkbook_tFileOutputExcel_7.close();
				if (headerIsInserted_tFileOutputExcel_7 && nb_line_tFileOutputExcel_7 > 0) {
					nb_line_tFileOutputExcel_7 = nb_line_tFileOutputExcel_7 - 1;
				}
				globalMap.put("tFileOutputExcel_7_NB_LINE", nb_line_tFileOutputExcel_7);

				log.debug("tFileOutputExcel_7 - Written records count: " + nb_line_tFileOutputExcel_7 + " .");

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "row5", 2, 0,
						"tSortRow_2_SortIn", "tSortRow_2_SortIn", "tSortIn", "tFileOutputExcel_7", "PhysicianExmRoom",
						"tFileOutputExcel", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tFileOutputExcel_7 - " + ("Done."));

				ok_Hash.put("tFileOutputExcel_7", true);
				end_Hash.put("tFileOutputExcel_7", System.currentTimeMillis());

				/**
				 * [tFileOutputExcel_7 end ] stop
				 */

				/**
				 * [tFileOutputExcel_8 end ] start
				 */

				currentComponent = "tFileOutputExcel_8";

				cLabel = "FutureAppointments";

				columnIndex_tFileOutputExcel_8 = 0;

				// modif start

				writableSheet_tFileOutputExcel_8.setColumnView(columnIndex_tFileOutputExcel_8,
						fitWidth_tFileOutputExcel_8[0]);

				// modif end

				columnIndex_tFileOutputExcel_8 = 1;

				// modif start

				writableSheet_tFileOutputExcel_8.setColumnView(columnIndex_tFileOutputExcel_8,
						fitWidth_tFileOutputExcel_8[1]);

				// modif end

				columnIndex_tFileOutputExcel_8 = 2;

				// modif start

				writableSheet_tFileOutputExcel_8.setColumnView(columnIndex_tFileOutputExcel_8,
						fitWidth_tFileOutputExcel_8[2]);

				// modif end

				columnIndex_tFileOutputExcel_8 = 3;

				// modif start

				writableSheet_tFileOutputExcel_8.setColumnView(columnIndex_tFileOutputExcel_8,
						fitWidth_tFileOutputExcel_8[3]);

				// modif end

				columnIndex_tFileOutputExcel_8 = 4;

				// modif start

				writableSheet_tFileOutputExcel_8.setColumnView(columnIndex_tFileOutputExcel_8,
						fitWidth_tFileOutputExcel_8[4]);

				// modif end

				writeableWorkbook_tFileOutputExcel_8.write();
				writeableWorkbook_tFileOutputExcel_8.close();
				if (headerIsInserted_tFileOutputExcel_8 && nb_line_tFileOutputExcel_8 > 0) {
					nb_line_tFileOutputExcel_8 = nb_line_tFileOutputExcel_8 - 1;
				}
				globalMap.put("tFileOutputExcel_8_NB_LINE", nb_line_tFileOutputExcel_8);

				log.debug("tFileOutputExcel_8 - Written records count: " + nb_line_tFileOutputExcel_8 + " .");

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId,
						"FutureAppointmentsWithInsurance", 2, 0, "tMap_3", "tMap_3", "tMap", "tFileOutputExcel_8",
						"FutureAppointments", "tFileOutputExcel", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tFileOutputExcel_8 - " + ("Done."));

				ok_Hash.put("tFileOutputExcel_8", true);
				end_Hash.put("tFileOutputExcel_8", System.currentTimeMillis());

				/**
				 * [tFileOutputExcel_8 end ] stop
				 */

			} // end the resume

			if (resumeEntryMethodName == null || globalResumeTicket) {
				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tDBInput_3:OnSubjobOk", "",
						Thread.currentThread().getId() + "", "", "", "", "", "");
			}

			if (execStat) {
				runStat.updateStatOnConnection("OnSubjobOk3", 0, "ok");
			}

			tDBInput_4Process(globalMap);

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage(), e);
			}

			TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);

			te.setVirtualComponentName(currentVirtualComponent);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			// free memory for "tSortRow_2_SortIn"
			globalMap.remove("tSortRow_2");

			try {

				/**
				 * [tDBInput_3 finally ] start
				 */

				currentComponent = "tDBInput_3";

				cLabel = "Appointment";

				/**
				 * [tDBInput_3 finally ] stop
				 */

				/**
				 * [tMap_3 finally ] start
				 */

				currentComponent = "tMap_3";

				/**
				 * [tMap_3 finally ] stop
				 */

				/**
				 * [tFileOutputExcel_6 finally ] start
				 */

				currentComponent = "tFileOutputExcel_6";

				cLabel = "TodaysAppointment";

				/**
				 * [tFileOutputExcel_6 finally ] stop
				 */

				/**
				 * [tSortRow_2_SortOut finally ] start
				 */

				currentVirtualComponent = "tSortRow_2";

				currentComponent = "tSortRow_2_SortOut";

				/**
				 * [tSortRow_2_SortOut finally ] stop
				 */

				/**
				 * [tSortRow_2_SortIn finally ] start
				 */

				currentVirtualComponent = "tSortRow_2";

				currentComponent = "tSortRow_2_SortIn";

				/**
				 * [tSortRow_2_SortIn finally ] stop
				 */

				/**
				 * [tFileOutputExcel_7 finally ] start
				 */

				currentComponent = "tFileOutputExcel_7";

				cLabel = "PhysicianExmRoom";

				/**
				 * [tFileOutputExcel_7 finally ] stop
				 */

				/**
				 * [tFileOutputExcel_8 finally ] start
				 */

				currentComponent = "tFileOutputExcel_8";

				cLabel = "FutureAppointments";

				/**
				 * [tFileOutputExcel_8 finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tDBInput_3_SUBPROCESS_STATE", 1);
	}

	public static class row7Struct implements routines.system.IPersistableRow<row7Struct> {
		final static byte[] commonByteArrayLock_HMS_FunctionalRequirement = new byte[0];
		static byte[] commonByteArray_HMS_FunctionalRequirement = new byte[0];

		public String InsuranceID;

		public String getInsuranceID() {
			return this.InsuranceID;
		}

		public Boolean InsuranceIDIsNullable() {
			return true;
		}

		public Boolean InsuranceIDIsKey() {
			return false;
		}

		public Integer InsuranceIDLength() {
			return 20;
		}

		public Integer InsuranceIDPrecision() {
			return 0;
		}

		public String InsuranceIDDefault() {

			return null;

		}

		public String InsuranceIDComment() {

			return "";

		}

		public String InsuranceIDPattern() {

			return "";

		}

		public String InsuranceIDOriginalDbColumnName() {

			return "InsuranceID";

		}

		public String InsuranceName;

		public String getInsuranceName() {
			return this.InsuranceName;
		}

		public Boolean InsuranceNameIsNullable() {
			return true;
		}

		public Boolean InsuranceNameIsKey() {
			return false;
		}

		public Integer InsuranceNameLength() {
			return 50;
		}

		public Integer InsuranceNamePrecision() {
			return 0;
		}

		public String InsuranceNameDefault() {

			return null;

		}

		public String InsuranceNameComment() {

			return "";

		}

		public String InsuranceNamePattern() {

			return "";

		}

		public String InsuranceNameOriginalDbColumnName() {

			return "InsuranceName";

		}

		public Integer PatientCount;

		public Integer getPatientCount() {
			return this.PatientCount;
		}

		public Boolean PatientCountIsNullable() {
			return true;
		}

		public Boolean PatientCountIsKey() {
			return false;
		}

		public Integer PatientCountLength() {
			return null;
		}

		public Integer PatientCountPrecision() {
			return null;
		}

		public String PatientCountDefault() {

			return null;

		}

		public String PatientCountComment() {

			return "";

		}

		public String PatientCountPattern() {

			return "";

		}

		public String PatientCountOriginalDbColumnName() {

			return "PatientCount";

		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_HMS_FunctionalRequirement.length) {
					if (length < 1024 && commonByteArray_HMS_FunctionalRequirement.length == 0) {
						commonByteArray_HMS_FunctionalRequirement = new byte[1024];
					} else {
						commonByteArray_HMS_FunctionalRequirement = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_HMS_FunctionalRequirement, 0, length);
				strReturn = new String(commonByteArray_HMS_FunctionalRequirement, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_HMS_FunctionalRequirement.length) {
					if (length < 1024 && commonByteArray_HMS_FunctionalRequirement.length == 0) {
						commonByteArray_HMS_FunctionalRequirement = new byte[1024];
					} else {
						commonByteArray_HMS_FunctionalRequirement = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_HMS_FunctionalRequirement, 0, length);
				strReturn = new String(commonByteArray_HMS_FunctionalRequirement, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_HMS_FunctionalRequirement) {

				try {

					int length = 0;

					this.InsuranceID = readString(dis);

					this.InsuranceName = readString(dis);

					this.PatientCount = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_HMS_FunctionalRequirement) {

				try {

					int length = 0;

					this.InsuranceID = readString(dis);

					this.InsuranceName = readString(dis);

					this.PatientCount = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.InsuranceID, dos);

				// String

				writeString(this.InsuranceName, dos);

				// Integer

				writeInteger(this.PatientCount, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.InsuranceID, dos);

				// String

				writeString(this.InsuranceName, dos);

				// Integer

				writeInteger(this.PatientCount, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("InsuranceID=" + InsuranceID);
			sb.append(",InsuranceName=" + InsuranceName);
			sb.append(",PatientCount=" + String.valueOf(PatientCount));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (InsuranceID == null) {
				sb.append("<null>");
			} else {
				sb.append(InsuranceID);
			}

			sb.append("|");

			if (InsuranceName == null) {
				sb.append("<null>");
			} else {
				sb.append(InsuranceName);
			}

			sb.append("|");

			if (PatientCount == null) {
				sb.append("<null>");
			} else {
				sb.append(PatientCount);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row7Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class OnRowsEndStructtAggregateRow_1
			implements routines.system.IPersistableRow<OnRowsEndStructtAggregateRow_1> {
		final static byte[] commonByteArrayLock_HMS_FunctionalRequirement = new byte[0];
		static byte[] commonByteArray_HMS_FunctionalRequirement = new byte[0];

		public String InsuranceID;

		public String getInsuranceID() {
			return this.InsuranceID;
		}

		public Boolean InsuranceIDIsNullable() {
			return true;
		}

		public Boolean InsuranceIDIsKey() {
			return false;
		}

		public Integer InsuranceIDLength() {
			return 20;
		}

		public Integer InsuranceIDPrecision() {
			return 0;
		}

		public String InsuranceIDDefault() {

			return null;

		}

		public String InsuranceIDComment() {

			return "";

		}

		public String InsuranceIDPattern() {

			return "";

		}

		public String InsuranceIDOriginalDbColumnName() {

			return "InsuranceID";

		}

		public String InsuranceName;

		public String getInsuranceName() {
			return this.InsuranceName;
		}

		public Boolean InsuranceNameIsNullable() {
			return true;
		}

		public Boolean InsuranceNameIsKey() {
			return false;
		}

		public Integer InsuranceNameLength() {
			return 50;
		}

		public Integer InsuranceNamePrecision() {
			return 0;
		}

		public String InsuranceNameDefault() {

			return null;

		}

		public String InsuranceNameComment() {

			return "";

		}

		public String InsuranceNamePattern() {

			return "";

		}

		public String InsuranceNameOriginalDbColumnName() {

			return "InsuranceName";

		}

		public Integer PatientCount;

		public Integer getPatientCount() {
			return this.PatientCount;
		}

		public Boolean PatientCountIsNullable() {
			return true;
		}

		public Boolean PatientCountIsKey() {
			return false;
		}

		public Integer PatientCountLength() {
			return null;
		}

		public Integer PatientCountPrecision() {
			return null;
		}

		public String PatientCountDefault() {

			return null;

		}

		public String PatientCountComment() {

			return "";

		}

		public String PatientCountPattern() {

			return "";

		}

		public String PatientCountOriginalDbColumnName() {

			return "PatientCount";

		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_HMS_FunctionalRequirement.length) {
					if (length < 1024 && commonByteArray_HMS_FunctionalRequirement.length == 0) {
						commonByteArray_HMS_FunctionalRequirement = new byte[1024];
					} else {
						commonByteArray_HMS_FunctionalRequirement = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_HMS_FunctionalRequirement, 0, length);
				strReturn = new String(commonByteArray_HMS_FunctionalRequirement, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_HMS_FunctionalRequirement.length) {
					if (length < 1024 && commonByteArray_HMS_FunctionalRequirement.length == 0) {
						commonByteArray_HMS_FunctionalRequirement = new byte[1024];
					} else {
						commonByteArray_HMS_FunctionalRequirement = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_HMS_FunctionalRequirement, 0, length);
				strReturn = new String(commonByteArray_HMS_FunctionalRequirement, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_HMS_FunctionalRequirement) {

				try {

					int length = 0;

					this.InsuranceID = readString(dis);

					this.InsuranceName = readString(dis);

					this.PatientCount = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_HMS_FunctionalRequirement) {

				try {

					int length = 0;

					this.InsuranceID = readString(dis);

					this.InsuranceName = readString(dis);

					this.PatientCount = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.InsuranceID, dos);

				// String

				writeString(this.InsuranceName, dos);

				// Integer

				writeInteger(this.PatientCount, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.InsuranceID, dos);

				// String

				writeString(this.InsuranceName, dos);

				// Integer

				writeInteger(this.PatientCount, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("InsuranceID=" + InsuranceID);
			sb.append(",InsuranceName=" + InsuranceName);
			sb.append(",PatientCount=" + String.valueOf(PatientCount));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (InsuranceID == null) {
				sb.append("<null>");
			} else {
				sb.append(InsuranceID);
			}

			sb.append("|");

			if (InsuranceName == null) {
				sb.append("<null>");
			} else {
				sb.append(InsuranceName);
			}

			sb.append("|");

			if (PatientCount == null) {
				sb.append("<null>");
			} else {
				sb.append(PatientCount);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(OnRowsEndStructtAggregateRow_1 other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class GreaterThan2LStruct implements routines.system.IPersistableRow<GreaterThan2LStruct> {
		final static byte[] commonByteArrayLock_HMS_FunctionalRequirement = new byte[0];
		static byte[] commonByteArray_HMS_FunctionalRequirement = new byte[0];

		public Integer PatientID;

		public Integer getPatientID() {
			return this.PatientID;
		}

		public Boolean PatientIDIsNullable() {
			return true;
		}

		public Boolean PatientIDIsKey() {
			return false;
		}

		public Integer PatientIDLength() {
			return 10;
		}

		public Integer PatientIDPrecision() {
			return 0;
		}

		public String PatientIDDefault() {

			return null;

		}

		public String PatientIDComment() {

			return "";

		}

		public String PatientIDPattern() {

			return "";

		}

		public String PatientIDOriginalDbColumnName() {

			return "PatientID";

		}

		public String Name;

		public String getName() {
			return this.Name;
		}

		public Boolean NameIsNullable() {
			return true;
		}

		public Boolean NameIsKey() {
			return false;
		}

		public Integer NameLength() {
			return 30;
		}

		public Integer NamePrecision() {
			return 0;
		}

		public String NameDefault() {

			return null;

		}

		public String NameComment() {

			return "";

		}

		public String NamePattern() {

			return "";

		}

		public String NameOriginalDbColumnName() {

			return "Name";

		}

		public java.util.Date DOB;

		public java.util.Date getDOB() {
			return this.DOB;
		}

		public Boolean DOBIsNullable() {
			return true;
		}

		public Boolean DOBIsKey() {
			return false;
		}

		public Integer DOBLength() {
			return 19;
		}

		public Integer DOBPrecision() {
			return 0;
		}

		public String DOBDefault() {

			return null;

		}

		public String DOBComment() {

			return "";

		}

		public String DOBPattern() {

			return "dd-MM-yyyy";

		}

		public String DOBOriginalDbColumnName() {

			return "DOB";

		}

		public String Gender;

		public String getGender() {
			return this.Gender;
		}

		public Boolean GenderIsNullable() {
			return true;
		}

		public Boolean GenderIsKey() {
			return false;
		}

		public Integer GenderLength() {
			return 6;
		}

		public Integer GenderPrecision() {
			return 0;
		}

		public String GenderDefault() {

			return null;

		}

		public String GenderComment() {

			return "";

		}

		public String GenderPattern() {

			return "";

		}

		public String GenderOriginalDbColumnName() {

			return "Gender";

		}

		public String Address;

		public String getAddress() {
			return this.Address;
		}

		public Boolean AddressIsNullable() {
			return true;
		}

		public Boolean AddressIsKey() {
			return false;
		}

		public Integer AddressLength() {
			return 50;
		}

		public Integer AddressPrecision() {
			return 0;
		}

		public String AddressDefault() {

			return null;

		}

		public String AddressComment() {

			return "";

		}

		public String AddressPattern() {

			return "";

		}

		public String AddressOriginalDbColumnName() {

			return "Address";

		}

		public String City;

		public String getCity() {
			return this.City;
		}

		public Boolean CityIsNullable() {
			return true;
		}

		public Boolean CityIsKey() {
			return false;
		}

		public Integer CityLength() {
			return 30;
		}

		public Integer CityPrecision() {
			return 0;
		}

		public String CityDefault() {

			return null;

		}

		public String CityComment() {

			return "";

		}

		public String CityPattern() {

			return "";

		}

		public String CityOriginalDbColumnName() {

			return "City";

		}

		public String Country;

		public String getCountry() {
			return this.Country;
		}

		public Boolean CountryIsNullable() {
			return true;
		}

		public Boolean CountryIsKey() {
			return false;
		}

		public Integer CountryLength() {
			return 30;
		}

		public Integer CountryPrecision() {
			return 0;
		}

		public String CountryDefault() {

			return null;

		}

		public String CountryComment() {

			return "";

		}

		public String CountryPattern() {

			return "";

		}

		public String CountryOriginalDbColumnName() {

			return "Country";

		}

		public String Phone;

		public String getPhone() {
			return this.Phone;
		}

		public Boolean PhoneIsNullable() {
			return true;
		}

		public Boolean PhoneIsKey() {
			return false;
		}

		public Integer PhoneLength() {
			return 15;
		}

		public Integer PhonePrecision() {
			return 0;
		}

		public String PhoneDefault() {

			return null;

		}

		public String PhoneComment() {

			return "";

		}

		public String PhonePattern() {

			return "";

		}

		public String PhoneOriginalDbColumnName() {

			return "Phone";

		}

		public String InsuranceID;

		public String getInsuranceID() {
			return this.InsuranceID;
		}

		public Boolean InsuranceIDIsNullable() {
			return true;
		}

		public Boolean InsuranceIDIsKey() {
			return false;
		}

		public Integer InsuranceIDLength() {
			return 20;
		}

		public Integer InsuranceIDPrecision() {
			return 0;
		}

		public String InsuranceIDDefault() {

			return null;

		}

		public String InsuranceIDComment() {

			return "";

		}

		public String InsuranceIDPattern() {

			return "";

		}

		public String InsuranceIDOriginalDbColumnName() {

			return "InsuranceID";

		}

		public String InsuranceName;

		public String getInsuranceName() {
			return this.InsuranceName;
		}

		public Boolean InsuranceNameIsNullable() {
			return true;
		}

		public Boolean InsuranceNameIsKey() {
			return false;
		}

		public Integer InsuranceNameLength() {
			return 50;
		}

		public Integer InsuranceNamePrecision() {
			return 0;
		}

		public String InsuranceNameDefault() {

			return null;

		}

		public String InsuranceNameComment() {

			return "";

		}

		public String InsuranceNamePattern() {

			return "";

		}

		public String InsuranceNameOriginalDbColumnName() {

			return "InsuranceName";

		}

		public Integer MaxCoverageAmount;

		public Integer getMaxCoverageAmount() {
			return this.MaxCoverageAmount;
		}

		public Boolean MaxCoverageAmountIsNullable() {
			return true;
		}

		public Boolean MaxCoverageAmountIsKey() {
			return false;
		}

		public Integer MaxCoverageAmountLength() {
			return 10;
		}

		public Integer MaxCoverageAmountPrecision() {
			return 0;
		}

		public String MaxCoverageAmountDefault() {

			return null;

		}

		public String MaxCoverageAmountComment() {

			return "";

		}

		public String MaxCoverageAmountPattern() {

			return "";

		}

		public String MaxCoverageAmountOriginalDbColumnName() {

			return "MaxCoverageAmount";

		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_HMS_FunctionalRequirement.length) {
					if (length < 1024 && commonByteArray_HMS_FunctionalRequirement.length == 0) {
						commonByteArray_HMS_FunctionalRequirement = new byte[1024];
					} else {
						commonByteArray_HMS_FunctionalRequirement = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_HMS_FunctionalRequirement, 0, length);
				strReturn = new String(commonByteArray_HMS_FunctionalRequirement, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_HMS_FunctionalRequirement.length) {
					if (length < 1024 && commonByteArray_HMS_FunctionalRequirement.length == 0) {
						commonByteArray_HMS_FunctionalRequirement = new byte[1024];
					} else {
						commonByteArray_HMS_FunctionalRequirement = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_HMS_FunctionalRequirement, 0, length);
				strReturn = new String(commonByteArray_HMS_FunctionalRequirement, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_HMS_FunctionalRequirement) {

				try {

					int length = 0;

					this.PatientID = readInteger(dis);

					this.Name = readString(dis);

					this.DOB = readDate(dis);

					this.Gender = readString(dis);

					this.Address = readString(dis);

					this.City = readString(dis);

					this.Country = readString(dis);

					this.Phone = readString(dis);

					this.InsuranceID = readString(dis);

					this.InsuranceName = readString(dis);

					this.MaxCoverageAmount = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_HMS_FunctionalRequirement) {

				try {

					int length = 0;

					this.PatientID = readInteger(dis);

					this.Name = readString(dis);

					this.DOB = readDate(dis);

					this.Gender = readString(dis);

					this.Address = readString(dis);

					this.City = readString(dis);

					this.Country = readString(dis);

					this.Phone = readString(dis);

					this.InsuranceID = readString(dis);

					this.InsuranceName = readString(dis);

					this.MaxCoverageAmount = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.PatientID, dos);

				// String

				writeString(this.Name, dos);

				// java.util.Date

				writeDate(this.DOB, dos);

				// String

				writeString(this.Gender, dos);

				// String

				writeString(this.Address, dos);

				// String

				writeString(this.City, dos);

				// String

				writeString(this.Country, dos);

				// String

				writeString(this.Phone, dos);

				// String

				writeString(this.InsuranceID, dos);

				// String

				writeString(this.InsuranceName, dos);

				// Integer

				writeInteger(this.MaxCoverageAmount, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.PatientID, dos);

				// String

				writeString(this.Name, dos);

				// java.util.Date

				writeDate(this.DOB, dos);

				// String

				writeString(this.Gender, dos);

				// String

				writeString(this.Address, dos);

				// String

				writeString(this.City, dos);

				// String

				writeString(this.Country, dos);

				// String

				writeString(this.Phone, dos);

				// String

				writeString(this.InsuranceID, dos);

				// String

				writeString(this.InsuranceName, dos);

				// Integer

				writeInteger(this.MaxCoverageAmount, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("PatientID=" + String.valueOf(PatientID));
			sb.append(",Name=" + Name);
			sb.append(",DOB=" + String.valueOf(DOB));
			sb.append(",Gender=" + Gender);
			sb.append(",Address=" + Address);
			sb.append(",City=" + City);
			sb.append(",Country=" + Country);
			sb.append(",Phone=" + Phone);
			sb.append(",InsuranceID=" + InsuranceID);
			sb.append(",InsuranceName=" + InsuranceName);
			sb.append(",MaxCoverageAmount=" + String.valueOf(MaxCoverageAmount));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (PatientID == null) {
				sb.append("<null>");
			} else {
				sb.append(PatientID);
			}

			sb.append("|");

			if (Name == null) {
				sb.append("<null>");
			} else {
				sb.append(Name);
			}

			sb.append("|");

			if (DOB == null) {
				sb.append("<null>");
			} else {
				sb.append(DOB);
			}

			sb.append("|");

			if (Gender == null) {
				sb.append("<null>");
			} else {
				sb.append(Gender);
			}

			sb.append("|");

			if (Address == null) {
				sb.append("<null>");
			} else {
				sb.append(Address);
			}

			sb.append("|");

			if (City == null) {
				sb.append("<null>");
			} else {
				sb.append(City);
			}

			sb.append("|");

			if (Country == null) {
				sb.append("<null>");
			} else {
				sb.append(Country);
			}

			sb.append("|");

			if (Phone == null) {
				sb.append("<null>");
			} else {
				sb.append(Phone);
			}

			sb.append("|");

			if (InsuranceID == null) {
				sb.append("<null>");
			} else {
				sb.append(InsuranceID);
			}

			sb.append("|");

			if (InsuranceName == null) {
				sb.append("<null>");
			} else {
				sb.append(InsuranceName);
			}

			sb.append("|");

			if (MaxCoverageAmount == null) {
				sb.append("<null>");
			} else {
				sb.append(MaxCoverageAmount);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(GreaterThan2LStruct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class PatientsCoveredByEachInsuranceStruct
			implements routines.system.IPersistableRow<PatientsCoveredByEachInsuranceStruct> {
		final static byte[] commonByteArrayLock_HMS_FunctionalRequirement = new byte[0];
		static byte[] commonByteArray_HMS_FunctionalRequirement = new byte[0];

		public Integer PatientID;

		public Integer getPatientID() {
			return this.PatientID;
		}

		public Boolean PatientIDIsNullable() {
			return true;
		}

		public Boolean PatientIDIsKey() {
			return false;
		}

		public Integer PatientIDLength() {
			return 10;
		}

		public Integer PatientIDPrecision() {
			return 0;
		}

		public String PatientIDDefault() {

			return null;

		}

		public String PatientIDComment() {

			return "";

		}

		public String PatientIDPattern() {

			return "";

		}

		public String PatientIDOriginalDbColumnName() {

			return "PatientID";

		}

		public String Name;

		public String getName() {
			return this.Name;
		}

		public Boolean NameIsNullable() {
			return true;
		}

		public Boolean NameIsKey() {
			return false;
		}

		public Integer NameLength() {
			return 30;
		}

		public Integer NamePrecision() {
			return 0;
		}

		public String NameDefault() {

			return null;

		}

		public String NameComment() {

			return "";

		}

		public String NamePattern() {

			return "";

		}

		public String NameOriginalDbColumnName() {

			return "Name";

		}

		public java.util.Date DOB;

		public java.util.Date getDOB() {
			return this.DOB;
		}

		public Boolean DOBIsNullable() {
			return true;
		}

		public Boolean DOBIsKey() {
			return false;
		}

		public Integer DOBLength() {
			return 19;
		}

		public Integer DOBPrecision() {
			return 0;
		}

		public String DOBDefault() {

			return null;

		}

		public String DOBComment() {

			return "";

		}

		public String DOBPattern() {

			return "dd-MM-yyyy";

		}

		public String DOBOriginalDbColumnName() {

			return "DOB";

		}

		public String Gender;

		public String getGender() {
			return this.Gender;
		}

		public Boolean GenderIsNullable() {
			return true;
		}

		public Boolean GenderIsKey() {
			return false;
		}

		public Integer GenderLength() {
			return 6;
		}

		public Integer GenderPrecision() {
			return 0;
		}

		public String GenderDefault() {

			return null;

		}

		public String GenderComment() {

			return "";

		}

		public String GenderPattern() {

			return "";

		}

		public String GenderOriginalDbColumnName() {

			return "Gender";

		}

		public String Address;

		public String getAddress() {
			return this.Address;
		}

		public Boolean AddressIsNullable() {
			return true;
		}

		public Boolean AddressIsKey() {
			return false;
		}

		public Integer AddressLength() {
			return 50;
		}

		public Integer AddressPrecision() {
			return 0;
		}

		public String AddressDefault() {

			return null;

		}

		public String AddressComment() {

			return "";

		}

		public String AddressPattern() {

			return "";

		}

		public String AddressOriginalDbColumnName() {

			return "Address";

		}

		public String City;

		public String getCity() {
			return this.City;
		}

		public Boolean CityIsNullable() {
			return true;
		}

		public Boolean CityIsKey() {
			return false;
		}

		public Integer CityLength() {
			return 30;
		}

		public Integer CityPrecision() {
			return 0;
		}

		public String CityDefault() {

			return null;

		}

		public String CityComment() {

			return "";

		}

		public String CityPattern() {

			return "";

		}

		public String CityOriginalDbColumnName() {

			return "City";

		}

		public String Country;

		public String getCountry() {
			return this.Country;
		}

		public Boolean CountryIsNullable() {
			return true;
		}

		public Boolean CountryIsKey() {
			return false;
		}

		public Integer CountryLength() {
			return 30;
		}

		public Integer CountryPrecision() {
			return 0;
		}

		public String CountryDefault() {

			return null;

		}

		public String CountryComment() {

			return "";

		}

		public String CountryPattern() {

			return "";

		}

		public String CountryOriginalDbColumnName() {

			return "Country";

		}

		public String Phone;

		public String getPhone() {
			return this.Phone;
		}

		public Boolean PhoneIsNullable() {
			return true;
		}

		public Boolean PhoneIsKey() {
			return false;
		}

		public Integer PhoneLength() {
			return 15;
		}

		public Integer PhonePrecision() {
			return 0;
		}

		public String PhoneDefault() {

			return null;

		}

		public String PhoneComment() {

			return "";

		}

		public String PhonePattern() {

			return "";

		}

		public String PhoneOriginalDbColumnName() {

			return "Phone";

		}

		public String InsuranceID;

		public String getInsuranceID() {
			return this.InsuranceID;
		}

		public Boolean InsuranceIDIsNullable() {
			return true;
		}

		public Boolean InsuranceIDIsKey() {
			return false;
		}

		public Integer InsuranceIDLength() {
			return 20;
		}

		public Integer InsuranceIDPrecision() {
			return 0;
		}

		public String InsuranceIDDefault() {

			return null;

		}

		public String InsuranceIDComment() {

			return "";

		}

		public String InsuranceIDPattern() {

			return "";

		}

		public String InsuranceIDOriginalDbColumnName() {

			return "InsuranceID";

		}

		public String InsuranceName;

		public String getInsuranceName() {
			return this.InsuranceName;
		}

		public Boolean InsuranceNameIsNullable() {
			return true;
		}

		public Boolean InsuranceNameIsKey() {
			return false;
		}

		public Integer InsuranceNameLength() {
			return 50;
		}

		public Integer InsuranceNamePrecision() {
			return 0;
		}

		public String InsuranceNameDefault() {

			return null;

		}

		public String InsuranceNameComment() {

			return "";

		}

		public String InsuranceNamePattern() {

			return "";

		}

		public String InsuranceNameOriginalDbColumnName() {

			return "InsuranceName";

		}

		public Integer MaxCoverageAmount;

		public Integer getMaxCoverageAmount() {
			return this.MaxCoverageAmount;
		}

		public Boolean MaxCoverageAmountIsNullable() {
			return true;
		}

		public Boolean MaxCoverageAmountIsKey() {
			return false;
		}

		public Integer MaxCoverageAmountLength() {
			return 10;
		}

		public Integer MaxCoverageAmountPrecision() {
			return 0;
		}

		public String MaxCoverageAmountDefault() {

			return null;

		}

		public String MaxCoverageAmountComment() {

			return "";

		}

		public String MaxCoverageAmountPattern() {

			return "";

		}

		public String MaxCoverageAmountOriginalDbColumnName() {

			return "MaxCoverageAmount";

		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_HMS_FunctionalRequirement.length) {
					if (length < 1024 && commonByteArray_HMS_FunctionalRequirement.length == 0) {
						commonByteArray_HMS_FunctionalRequirement = new byte[1024];
					} else {
						commonByteArray_HMS_FunctionalRequirement = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_HMS_FunctionalRequirement, 0, length);
				strReturn = new String(commonByteArray_HMS_FunctionalRequirement, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_HMS_FunctionalRequirement.length) {
					if (length < 1024 && commonByteArray_HMS_FunctionalRequirement.length == 0) {
						commonByteArray_HMS_FunctionalRequirement = new byte[1024];
					} else {
						commonByteArray_HMS_FunctionalRequirement = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_HMS_FunctionalRequirement, 0, length);
				strReturn = new String(commonByteArray_HMS_FunctionalRequirement, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_HMS_FunctionalRequirement) {

				try {

					int length = 0;

					this.PatientID = readInteger(dis);

					this.Name = readString(dis);

					this.DOB = readDate(dis);

					this.Gender = readString(dis);

					this.Address = readString(dis);

					this.City = readString(dis);

					this.Country = readString(dis);

					this.Phone = readString(dis);

					this.InsuranceID = readString(dis);

					this.InsuranceName = readString(dis);

					this.MaxCoverageAmount = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_HMS_FunctionalRequirement) {

				try {

					int length = 0;

					this.PatientID = readInteger(dis);

					this.Name = readString(dis);

					this.DOB = readDate(dis);

					this.Gender = readString(dis);

					this.Address = readString(dis);

					this.City = readString(dis);

					this.Country = readString(dis);

					this.Phone = readString(dis);

					this.InsuranceID = readString(dis);

					this.InsuranceName = readString(dis);

					this.MaxCoverageAmount = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.PatientID, dos);

				// String

				writeString(this.Name, dos);

				// java.util.Date

				writeDate(this.DOB, dos);

				// String

				writeString(this.Gender, dos);

				// String

				writeString(this.Address, dos);

				// String

				writeString(this.City, dos);

				// String

				writeString(this.Country, dos);

				// String

				writeString(this.Phone, dos);

				// String

				writeString(this.InsuranceID, dos);

				// String

				writeString(this.InsuranceName, dos);

				// Integer

				writeInteger(this.MaxCoverageAmount, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.PatientID, dos);

				// String

				writeString(this.Name, dos);

				// java.util.Date

				writeDate(this.DOB, dos);

				// String

				writeString(this.Gender, dos);

				// String

				writeString(this.Address, dos);

				// String

				writeString(this.City, dos);

				// String

				writeString(this.Country, dos);

				// String

				writeString(this.Phone, dos);

				// String

				writeString(this.InsuranceID, dos);

				// String

				writeString(this.InsuranceName, dos);

				// Integer

				writeInteger(this.MaxCoverageAmount, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("PatientID=" + String.valueOf(PatientID));
			sb.append(",Name=" + Name);
			sb.append(",DOB=" + String.valueOf(DOB));
			sb.append(",Gender=" + Gender);
			sb.append(",Address=" + Address);
			sb.append(",City=" + City);
			sb.append(",Country=" + Country);
			sb.append(",Phone=" + Phone);
			sb.append(",InsuranceID=" + InsuranceID);
			sb.append(",InsuranceName=" + InsuranceName);
			sb.append(",MaxCoverageAmount=" + String.valueOf(MaxCoverageAmount));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (PatientID == null) {
				sb.append("<null>");
			} else {
				sb.append(PatientID);
			}

			sb.append("|");

			if (Name == null) {
				sb.append("<null>");
			} else {
				sb.append(Name);
			}

			sb.append("|");

			if (DOB == null) {
				sb.append("<null>");
			} else {
				sb.append(DOB);
			}

			sb.append("|");

			if (Gender == null) {
				sb.append("<null>");
			} else {
				sb.append(Gender);
			}

			sb.append("|");

			if (Address == null) {
				sb.append("<null>");
			} else {
				sb.append(Address);
			}

			sb.append("|");

			if (City == null) {
				sb.append("<null>");
			} else {
				sb.append(City);
			}

			sb.append("|");

			if (Country == null) {
				sb.append("<null>");
			} else {
				sb.append(Country);
			}

			sb.append("|");

			if (Phone == null) {
				sb.append("<null>");
			} else {
				sb.append(Phone);
			}

			sb.append("|");

			if (InsuranceID == null) {
				sb.append("<null>");
			} else {
				sb.append(InsuranceID);
			}

			sb.append("|");

			if (InsuranceName == null) {
				sb.append("<null>");
			} else {
				sb.append(InsuranceName);
			}

			sb.append("|");

			if (MaxCoverageAmount == null) {
				sb.append("<null>");
			} else {
				sb.append(MaxCoverageAmount);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(PatientsCoveredByEachInsuranceStruct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row6Struct implements routines.system.IPersistableRow<row6Struct> {
		final static byte[] commonByteArrayLock_HMS_FunctionalRequirement = new byte[0];
		static byte[] commonByteArray_HMS_FunctionalRequirement = new byte[0];

		public Integer PatientID;

		public Integer getPatientID() {
			return this.PatientID;
		}

		public Boolean PatientIDIsNullable() {
			return true;
		}

		public Boolean PatientIDIsKey() {
			return false;
		}

		public Integer PatientIDLength() {
			return 10;
		}

		public Integer PatientIDPrecision() {
			return 0;
		}

		public String PatientIDDefault() {

			return null;

		}

		public String PatientIDComment() {

			return "";

		}

		public String PatientIDPattern() {

			return "";

		}

		public String PatientIDOriginalDbColumnName() {

			return "PatientID";

		}

		public String Name;

		public String getName() {
			return this.Name;
		}

		public Boolean NameIsNullable() {
			return true;
		}

		public Boolean NameIsKey() {
			return false;
		}

		public Integer NameLength() {
			return 30;
		}

		public Integer NamePrecision() {
			return 0;
		}

		public String NameDefault() {

			return null;

		}

		public String NameComment() {

			return "";

		}

		public String NamePattern() {

			return "";

		}

		public String NameOriginalDbColumnName() {

			return "Name";

		}

		public java.util.Date DOB;

		public java.util.Date getDOB() {
			return this.DOB;
		}

		public Boolean DOBIsNullable() {
			return true;
		}

		public Boolean DOBIsKey() {
			return false;
		}

		public Integer DOBLength() {
			return 19;
		}

		public Integer DOBPrecision() {
			return 0;
		}

		public String DOBDefault() {

			return null;

		}

		public String DOBComment() {

			return "";

		}

		public String DOBPattern() {

			return "dd-MM-yyyy";

		}

		public String DOBOriginalDbColumnName() {

			return "DOB";

		}

		public String Gender;

		public String getGender() {
			return this.Gender;
		}

		public Boolean GenderIsNullable() {
			return true;
		}

		public Boolean GenderIsKey() {
			return false;
		}

		public Integer GenderLength() {
			return 6;
		}

		public Integer GenderPrecision() {
			return 0;
		}

		public String GenderDefault() {

			return null;

		}

		public String GenderComment() {

			return "";

		}

		public String GenderPattern() {

			return "";

		}

		public String GenderOriginalDbColumnName() {

			return "Gender";

		}

		public String Address;

		public String getAddress() {
			return this.Address;
		}

		public Boolean AddressIsNullable() {
			return true;
		}

		public Boolean AddressIsKey() {
			return false;
		}

		public Integer AddressLength() {
			return 50;
		}

		public Integer AddressPrecision() {
			return 0;
		}

		public String AddressDefault() {

			return null;

		}

		public String AddressComment() {

			return "";

		}

		public String AddressPattern() {

			return "";

		}

		public String AddressOriginalDbColumnName() {

			return "Address";

		}

		public String City;

		public String getCity() {
			return this.City;
		}

		public Boolean CityIsNullable() {
			return true;
		}

		public Boolean CityIsKey() {
			return false;
		}

		public Integer CityLength() {
			return 30;
		}

		public Integer CityPrecision() {
			return 0;
		}

		public String CityDefault() {

			return null;

		}

		public String CityComment() {

			return "";

		}

		public String CityPattern() {

			return "";

		}

		public String CityOriginalDbColumnName() {

			return "City";

		}

		public String Country;

		public String getCountry() {
			return this.Country;
		}

		public Boolean CountryIsNullable() {
			return true;
		}

		public Boolean CountryIsKey() {
			return false;
		}

		public Integer CountryLength() {
			return 30;
		}

		public Integer CountryPrecision() {
			return 0;
		}

		public String CountryDefault() {

			return null;

		}

		public String CountryComment() {

			return "";

		}

		public String CountryPattern() {

			return "";

		}

		public String CountryOriginalDbColumnName() {

			return "Country";

		}

		public String Phone;

		public String getPhone() {
			return this.Phone;
		}

		public Boolean PhoneIsNullable() {
			return true;
		}

		public Boolean PhoneIsKey() {
			return false;
		}

		public Integer PhoneLength() {
			return 15;
		}

		public Integer PhonePrecision() {
			return 0;
		}

		public String PhoneDefault() {

			return null;

		}

		public String PhoneComment() {

			return "";

		}

		public String PhonePattern() {

			return "";

		}

		public String PhoneOriginalDbColumnName() {

			return "Phone";

		}

		public String InsuranceID;

		public String getInsuranceID() {
			return this.InsuranceID;
		}

		public Boolean InsuranceIDIsNullable() {
			return true;
		}

		public Boolean InsuranceIDIsKey() {
			return false;
		}

		public Integer InsuranceIDLength() {
			return 20;
		}

		public Integer InsuranceIDPrecision() {
			return 0;
		}

		public String InsuranceIDDefault() {

			return null;

		}

		public String InsuranceIDComment() {

			return "";

		}

		public String InsuranceIDPattern() {

			return "";

		}

		public String InsuranceIDOriginalDbColumnName() {

			return "InsuranceID";

		}

		public String InsuranceName;

		public String getInsuranceName() {
			return this.InsuranceName;
		}

		public Boolean InsuranceNameIsNullable() {
			return true;
		}

		public Boolean InsuranceNameIsKey() {
			return false;
		}

		public Integer InsuranceNameLength() {
			return 50;
		}

		public Integer InsuranceNamePrecision() {
			return 0;
		}

		public String InsuranceNameDefault() {

			return null;

		}

		public String InsuranceNameComment() {

			return "";

		}

		public String InsuranceNamePattern() {

			return "";

		}

		public String InsuranceNameOriginalDbColumnName() {

			return "InsuranceName";

		}

		public Integer MaxCoverageAmount;

		public Integer getMaxCoverageAmount() {
			return this.MaxCoverageAmount;
		}

		public Boolean MaxCoverageAmountIsNullable() {
			return true;
		}

		public Boolean MaxCoverageAmountIsKey() {
			return false;
		}

		public Integer MaxCoverageAmountLength() {
			return 10;
		}

		public Integer MaxCoverageAmountPrecision() {
			return 0;
		}

		public String MaxCoverageAmountDefault() {

			return null;

		}

		public String MaxCoverageAmountComment() {

			return "";

		}

		public String MaxCoverageAmountPattern() {

			return "";

		}

		public String MaxCoverageAmountOriginalDbColumnName() {

			return "MaxCoverageAmount";

		}

		public java.util.Date Start_date;

		public java.util.Date getStart_date() {
			return this.Start_date;
		}

		public Boolean Start_dateIsNullable() {
			return false;
		}

		public Boolean Start_dateIsKey() {
			return false;
		}

		public Integer Start_dateLength() {
			return 19;
		}

		public Integer Start_datePrecision() {
			return 0;
		}

		public String Start_dateDefault() {

			return null;

		}

		public String Start_dateComment() {

			return "";

		}

		public String Start_datePattern() {

			return "dd-MM-yyyy";

		}

		public String Start_dateOriginalDbColumnName() {

			return "Start_date";

		}

		public java.util.Date End_date;

		public java.util.Date getEnd_date() {
			return this.End_date;
		}

		public Boolean End_dateIsNullable() {
			return true;
		}

		public Boolean End_dateIsKey() {
			return false;
		}

		public Integer End_dateLength() {
			return 19;
		}

		public Integer End_datePrecision() {
			return 0;
		}

		public String End_dateDefault() {

			return null;

		}

		public String End_dateComment() {

			return "";

		}

		public String End_datePattern() {

			return "dd-MM-yyyy";

		}

		public String End_dateOriginalDbColumnName() {

			return "End_date";

		}

		public int InsuranceSK;

		public int getInsuranceSK() {
			return this.InsuranceSK;
		}

		public Boolean InsuranceSKIsNullable() {
			return false;
		}

		public Boolean InsuranceSKIsKey() {
			return true;
		}

		public Integer InsuranceSKLength() {
			return 10;
		}

		public Integer InsuranceSKPrecision() {
			return 0;
		}

		public String InsuranceSKDefault() {

			return null;

		}

		public String InsuranceSKComment() {

			return "";

		}

		public String InsuranceSKPattern() {

			return "";

		}

		public String InsuranceSKOriginalDbColumnName() {

			return "InsuranceSK";

		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_HMS_FunctionalRequirement.length) {
					if (length < 1024 && commonByteArray_HMS_FunctionalRequirement.length == 0) {
						commonByteArray_HMS_FunctionalRequirement = new byte[1024];
					} else {
						commonByteArray_HMS_FunctionalRequirement = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_HMS_FunctionalRequirement, 0, length);
				strReturn = new String(commonByteArray_HMS_FunctionalRequirement, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_HMS_FunctionalRequirement.length) {
					if (length < 1024 && commonByteArray_HMS_FunctionalRequirement.length == 0) {
						commonByteArray_HMS_FunctionalRequirement = new byte[1024];
					} else {
						commonByteArray_HMS_FunctionalRequirement = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_HMS_FunctionalRequirement, 0, length);
				strReturn = new String(commonByteArray_HMS_FunctionalRequirement, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_HMS_FunctionalRequirement) {

				try {

					int length = 0;

					this.PatientID = readInteger(dis);

					this.Name = readString(dis);

					this.DOB = readDate(dis);

					this.Gender = readString(dis);

					this.Address = readString(dis);

					this.City = readString(dis);

					this.Country = readString(dis);

					this.Phone = readString(dis);

					this.InsuranceID = readString(dis);

					this.InsuranceName = readString(dis);

					this.MaxCoverageAmount = readInteger(dis);

					this.Start_date = readDate(dis);

					this.End_date = readDate(dis);

					this.InsuranceSK = dis.readInt();

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_HMS_FunctionalRequirement) {

				try {

					int length = 0;

					this.PatientID = readInteger(dis);

					this.Name = readString(dis);

					this.DOB = readDate(dis);

					this.Gender = readString(dis);

					this.Address = readString(dis);

					this.City = readString(dis);

					this.Country = readString(dis);

					this.Phone = readString(dis);

					this.InsuranceID = readString(dis);

					this.InsuranceName = readString(dis);

					this.MaxCoverageAmount = readInteger(dis);

					this.Start_date = readDate(dis);

					this.End_date = readDate(dis);

					this.InsuranceSK = dis.readInt();

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.PatientID, dos);

				// String

				writeString(this.Name, dos);

				// java.util.Date

				writeDate(this.DOB, dos);

				// String

				writeString(this.Gender, dos);

				// String

				writeString(this.Address, dos);

				// String

				writeString(this.City, dos);

				// String

				writeString(this.Country, dos);

				// String

				writeString(this.Phone, dos);

				// String

				writeString(this.InsuranceID, dos);

				// String

				writeString(this.InsuranceName, dos);

				// Integer

				writeInteger(this.MaxCoverageAmount, dos);

				// java.util.Date

				writeDate(this.Start_date, dos);

				// java.util.Date

				writeDate(this.End_date, dos);

				// int

				dos.writeInt(this.InsuranceSK);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.PatientID, dos);

				// String

				writeString(this.Name, dos);

				// java.util.Date

				writeDate(this.DOB, dos);

				// String

				writeString(this.Gender, dos);

				// String

				writeString(this.Address, dos);

				// String

				writeString(this.City, dos);

				// String

				writeString(this.Country, dos);

				// String

				writeString(this.Phone, dos);

				// String

				writeString(this.InsuranceID, dos);

				// String

				writeString(this.InsuranceName, dos);

				// Integer

				writeInteger(this.MaxCoverageAmount, dos);

				// java.util.Date

				writeDate(this.Start_date, dos);

				// java.util.Date

				writeDate(this.End_date, dos);

				// int

				dos.writeInt(this.InsuranceSK);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("PatientID=" + String.valueOf(PatientID));
			sb.append(",Name=" + Name);
			sb.append(",DOB=" + String.valueOf(DOB));
			sb.append(",Gender=" + Gender);
			sb.append(",Address=" + Address);
			sb.append(",City=" + City);
			sb.append(",Country=" + Country);
			sb.append(",Phone=" + Phone);
			sb.append(",InsuranceID=" + InsuranceID);
			sb.append(",InsuranceName=" + InsuranceName);
			sb.append(",MaxCoverageAmount=" + String.valueOf(MaxCoverageAmount));
			sb.append(",Start_date=" + String.valueOf(Start_date));
			sb.append(",End_date=" + String.valueOf(End_date));
			sb.append(",InsuranceSK=" + String.valueOf(InsuranceSK));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (PatientID == null) {
				sb.append("<null>");
			} else {
				sb.append(PatientID);
			}

			sb.append("|");

			if (Name == null) {
				sb.append("<null>");
			} else {
				sb.append(Name);
			}

			sb.append("|");

			if (DOB == null) {
				sb.append("<null>");
			} else {
				sb.append(DOB);
			}

			sb.append("|");

			if (Gender == null) {
				sb.append("<null>");
			} else {
				sb.append(Gender);
			}

			sb.append("|");

			if (Address == null) {
				sb.append("<null>");
			} else {
				sb.append(Address);
			}

			sb.append("|");

			if (City == null) {
				sb.append("<null>");
			} else {
				sb.append(City);
			}

			sb.append("|");

			if (Country == null) {
				sb.append("<null>");
			} else {
				sb.append(Country);
			}

			sb.append("|");

			if (Phone == null) {
				sb.append("<null>");
			} else {
				sb.append(Phone);
			}

			sb.append("|");

			if (InsuranceID == null) {
				sb.append("<null>");
			} else {
				sb.append(InsuranceID);
			}

			sb.append("|");

			if (InsuranceName == null) {
				sb.append("<null>");
			} else {
				sb.append(InsuranceName);
			}

			sb.append("|");

			if (MaxCoverageAmount == null) {
				sb.append("<null>");
			} else {
				sb.append(MaxCoverageAmount);
			}

			sb.append("|");

			if (Start_date == null) {
				sb.append("<null>");
			} else {
				sb.append(Start_date);
			}

			sb.append("|");

			if (End_date == null) {
				sb.append("<null>");
			} else {
				sb.append(End_date);
			}

			sb.append("|");

			sb.append(InsuranceSK);

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row6Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tDBInput_4Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tDBInput_4_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tDBInput_4");
		org.slf4j.MDC.put("_subJobPid", "nCyce9_" + subJobPidCounter.getAndIncrement());

		String currentVirtualComponent = null;

		String iterateId = "";

		String currentComponent = "";
		String cLabel = null;
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				row6Struct row6 = new row6Struct();
				GreaterThan2LStruct GreaterThan2L = new GreaterThan2LStruct();
				PatientsCoveredByEachInsuranceStruct PatientsCoveredByEachInsurance = new PatientsCoveredByEachInsuranceStruct();
				row7Struct row7 = new row7Struct();

				/**
				 * [tFileOutputExcel_9 begin ] start
				 */

				ok_Hash.put("tFileOutputExcel_9", false);
				start_Hash.put("tFileOutputExcel_9", System.currentTimeMillis());

				currentComponent = "tFileOutputExcel_9";

				cLabel = "GreaterThan2L";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "GreaterThan2L");

				int tos_count_tFileOutputExcel_9 = 0;

				if (log.isDebugEnabled())
					log.debug("tFileOutputExcel_9 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tFileOutputExcel_9 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tFileOutputExcel_9 = new StringBuilder();
							log4jParamters_tFileOutputExcel_9.append("Parameters:");
							log4jParamters_tFileOutputExcel_9.append("VERSION_2007" + " = " + "false");
							log4jParamters_tFileOutputExcel_9.append(" | ");
							log4jParamters_tFileOutputExcel_9.append("USESTREAM" + " = " + "false");
							log4jParamters_tFileOutputExcel_9.append(" | ");
							log4jParamters_tFileOutputExcel_9
									.append("FILENAME" + " = " + "\"C:/Users/2382187/Downloads/FR/GreaterThan2L.xls\"");
							log4jParamters_tFileOutputExcel_9.append(" | ");
							log4jParamters_tFileOutputExcel_9.append("SHEETNAME" + " = " + "\"Sheet1\"");
							log4jParamters_tFileOutputExcel_9.append(" | ");
							log4jParamters_tFileOutputExcel_9.append("INCLUDEHEADER" + " = " + "true");
							log4jParamters_tFileOutputExcel_9.append(" | ");
							log4jParamters_tFileOutputExcel_9.append("APPEND_FILE" + " = " + "false");
							log4jParamters_tFileOutputExcel_9.append(" | ");
							log4jParamters_tFileOutputExcel_9.append("FIRST_CELL_Y_ABSOLUTE" + " = " + "false");
							log4jParamters_tFileOutputExcel_9.append(" | ");
							log4jParamters_tFileOutputExcel_9.append("FONT" + " = " + "");
							log4jParamters_tFileOutputExcel_9.append(" | ");
							log4jParamters_tFileOutputExcel_9.append("IS_ALL_AUTO_SZIE" + " = " + "true");
							log4jParamters_tFileOutputExcel_9.append(" | ");
							log4jParamters_tFileOutputExcel_9.append("CREATE" + " = " + "true");
							log4jParamters_tFileOutputExcel_9.append(" | ");
							log4jParamters_tFileOutputExcel_9.append("ADVANCED_SEPARATOR" + " = " + "false");
							log4jParamters_tFileOutputExcel_9.append(" | ");
							log4jParamters_tFileOutputExcel_9.append("ENCODING" + " = " + "\"ISO-8859-15\"");
							log4jParamters_tFileOutputExcel_9.append(" | ");
							log4jParamters_tFileOutputExcel_9.append("DELETE_EMPTYFILE" + " = " + "false");
							log4jParamters_tFileOutputExcel_9.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tFileOutputExcel_9 - " + (log4jParamters_tFileOutputExcel_9));
						}
					}
					new BytesLimit65535_tFileOutputExcel_9().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tFileOutputExcel_9", "GreaterThan2L", "tFileOutputExcel");
					talendJobLogProcess(globalMap);
				}

				int columnIndex_tFileOutputExcel_9 = 0;
				boolean headerIsInserted_tFileOutputExcel_9 = false;

				int nb_line_tFileOutputExcel_9 = 0;

				String fileName_tFileOutputExcel_9 = "C:/Users/2382187/Downloads/FR/GreaterThan2L.xls";
				java.io.File file_tFileOutputExcel_9 = new java.io.File(fileName_tFileOutputExcel_9);
				boolean isFileGenerated_tFileOutputExcel_9 = true;
//create directory only if not exists
				java.io.File parentFile_tFileOutputExcel_9 = file_tFileOutputExcel_9.getParentFile();
				if (parentFile_tFileOutputExcel_9 != null && !parentFile_tFileOutputExcel_9.exists()) {

					log.info("tFileOutputExcel_9 - Creating directory '"
							+ parentFile_tFileOutputExcel_9.getCanonicalPath() + "'.");

					parentFile_tFileOutputExcel_9.mkdirs();

					log.info("tFileOutputExcel_9 - Create directory '"
							+ parentFile_tFileOutputExcel_9.getCanonicalPath() + "' has succeeded.");

				}

				jxl.write.WritableWorkbook writeableWorkbook_tFileOutputExcel_9 = null;
				jxl.write.WritableSheet writableSheet_tFileOutputExcel_9 = null;

				jxl.WorkbookSettings workbookSettings_tFileOutputExcel_9 = new jxl.WorkbookSettings();
				workbookSettings_tFileOutputExcel_9.setEncoding("ISO-8859-15");
				writeableWorkbook_tFileOutputExcel_9 = new jxl.write.biff.WritableWorkbookImpl(
						new java.io.BufferedOutputStream(new java.io.FileOutputStream(fileName_tFileOutputExcel_9)),
						true, workbookSettings_tFileOutputExcel_9);

				writableSheet_tFileOutputExcel_9 = writeableWorkbook_tFileOutputExcel_9.getSheet("Sheet1");
				if (writableSheet_tFileOutputExcel_9 == null) {
					writableSheet_tFileOutputExcel_9 = writeableWorkbook_tFileOutputExcel_9.createSheet("Sheet1",
							writeableWorkbook_tFileOutputExcel_9.getNumberOfSheets());
				}

				// modif start
				int startRowNum_tFileOutputExcel_9 = writableSheet_tFileOutputExcel_9.getRows();
				// modif end

				int[] fitWidth_tFileOutputExcel_9 = new int[11];
				for (int i_tFileOutputExcel_9 = 0; i_tFileOutputExcel_9 < 11; i_tFileOutputExcel_9++) {
					int fitCellViewSize_tFileOutputExcel_9 = writableSheet_tFileOutputExcel_9
							.getColumnView(i_tFileOutputExcel_9).getSize();
					fitWidth_tFileOutputExcel_9[i_tFileOutputExcel_9] = fitCellViewSize_tFileOutputExcel_9 / 256;
					if (fitCellViewSize_tFileOutputExcel_9 % 256 != 0) {
						fitWidth_tFileOutputExcel_9[i_tFileOutputExcel_9] += 1;
					}
				}

				final jxl.write.WritableCellFormat cell_format_DOB_tFileOutputExcel_9 = new jxl.write.WritableCellFormat(
						new jxl.write.DateFormat("dd-MM-yyyy"));

				if (startRowNum_tFileOutputExcel_9 == 0) {
					// modif end
					// modif start
					writableSheet_tFileOutputExcel_9
							.addCell(new jxl.write.Label(0, nb_line_tFileOutputExcel_9, "PatientID"));
					// modif end
					fitWidth_tFileOutputExcel_9[0] = fitWidth_tFileOutputExcel_9[0] > 9 ? fitWidth_tFileOutputExcel_9[0]
							: 9;
					// modif start
					writableSheet_tFileOutputExcel_9
							.addCell(new jxl.write.Label(1, nb_line_tFileOutputExcel_9, "Name"));
					// modif end
					fitWidth_tFileOutputExcel_9[1] = fitWidth_tFileOutputExcel_9[1] > 4 ? fitWidth_tFileOutputExcel_9[1]
							: 4;
					// modif start
					writableSheet_tFileOutputExcel_9.addCell(new jxl.write.Label(2, nb_line_tFileOutputExcel_9, "DOB"));
					// modif end
					fitWidth_tFileOutputExcel_9[2] = fitWidth_tFileOutputExcel_9[2] > 3 ? fitWidth_tFileOutputExcel_9[2]
							: 3;
					// modif start
					writableSheet_tFileOutputExcel_9
							.addCell(new jxl.write.Label(3, nb_line_tFileOutputExcel_9, "Gender"));
					// modif end
					fitWidth_tFileOutputExcel_9[3] = fitWidth_tFileOutputExcel_9[3] > 6 ? fitWidth_tFileOutputExcel_9[3]
							: 6;
					// modif start
					writableSheet_tFileOutputExcel_9
							.addCell(new jxl.write.Label(4, nb_line_tFileOutputExcel_9, "Address"));
					// modif end
					fitWidth_tFileOutputExcel_9[4] = fitWidth_tFileOutputExcel_9[4] > 7 ? fitWidth_tFileOutputExcel_9[4]
							: 7;
					// modif start
					writableSheet_tFileOutputExcel_9
							.addCell(new jxl.write.Label(5, nb_line_tFileOutputExcel_9, "City"));
					// modif end
					fitWidth_tFileOutputExcel_9[5] = fitWidth_tFileOutputExcel_9[5] > 4 ? fitWidth_tFileOutputExcel_9[5]
							: 4;
					// modif start
					writableSheet_tFileOutputExcel_9
							.addCell(new jxl.write.Label(6, nb_line_tFileOutputExcel_9, "Country"));
					// modif end
					fitWidth_tFileOutputExcel_9[6] = fitWidth_tFileOutputExcel_9[6] > 7 ? fitWidth_tFileOutputExcel_9[6]
							: 7;
					// modif start
					writableSheet_tFileOutputExcel_9
							.addCell(new jxl.write.Label(7, nb_line_tFileOutputExcel_9, "Phone"));
					// modif end
					fitWidth_tFileOutputExcel_9[7] = fitWidth_tFileOutputExcel_9[7] > 5 ? fitWidth_tFileOutputExcel_9[7]
							: 5;
					// modif start
					writableSheet_tFileOutputExcel_9
							.addCell(new jxl.write.Label(8, nb_line_tFileOutputExcel_9, "InsuranceID"));
					// modif end
					fitWidth_tFileOutputExcel_9[8] = fitWidth_tFileOutputExcel_9[8] > 11
							? fitWidth_tFileOutputExcel_9[8]
							: 11;
					// modif start
					writableSheet_tFileOutputExcel_9
							.addCell(new jxl.write.Label(9, nb_line_tFileOutputExcel_9, "InsuranceName"));
					// modif end
					fitWidth_tFileOutputExcel_9[9] = fitWidth_tFileOutputExcel_9[9] > 13
							? fitWidth_tFileOutputExcel_9[9]
							: 13;
					// modif start
					writableSheet_tFileOutputExcel_9
							.addCell(new jxl.write.Label(10, nb_line_tFileOutputExcel_9, "MaxCoverageAmount"));
					// modif end
					fitWidth_tFileOutputExcel_9[10] = fitWidth_tFileOutputExcel_9[10] > 17
							? fitWidth_tFileOutputExcel_9[10]
							: 17;
					nb_line_tFileOutputExcel_9++;
					headerIsInserted_tFileOutputExcel_9 = true;
				}

				/**
				 * [tFileOutputExcel_9 begin ] stop
				 */

				/**
				 * [tAggregateRow_1_AGGOUT begin ] start
				 */

				ok_Hash.put("tAggregateRow_1_AGGOUT", false);
				start_Hash.put("tAggregateRow_1_AGGOUT", System.currentTimeMillis());

				currentVirtualComponent = "tAggregateRow_1";

				currentComponent = "tAggregateRow_1_AGGOUT";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0,
						"PatientsCoveredByEachInsurance");

				int tos_count_tAggregateRow_1_AGGOUT = 0;

				if (log.isDebugEnabled())
					log.debug("tAggregateRow_1_AGGOUT - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tAggregateRow_1_AGGOUT {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tAggregateRow_1_AGGOUT = new StringBuilder();
							log4jParamters_tAggregateRow_1_AGGOUT.append("Parameters:");
							log4jParamters_tAggregateRow_1_AGGOUT.append("DESTINATION" + " = " + "tAggregateRow_1");
							log4jParamters_tAggregateRow_1_AGGOUT.append(" | ");
							log4jParamters_tAggregateRow_1_AGGOUT.append("GROUPBYS" + " = " + "[{OUTPUT_COLUMN="
									+ ("InsuranceID") + ", INPUT_COLUMN=" + ("InsuranceID") + "}, {OUTPUT_COLUMN="
									+ ("InsuranceName") + ", INPUT_COLUMN=" + ("InsuranceName") + "}]");
							log4jParamters_tAggregateRow_1_AGGOUT.append(" | ");
							log4jParamters_tAggregateRow_1_AGGOUT.append("OPERATIONS" + " = " + "[{OUTPUT_COLUMN="
									+ ("PatientCount") + ", INPUT_COLUMN=" + ("PatientID") + ", IGNORE_NULL="
									+ ("false") + ", FUNCTION=" + ("count") + "}]");
							log4jParamters_tAggregateRow_1_AGGOUT.append(" | ");
							log4jParamters_tAggregateRow_1_AGGOUT.append("LIST_DELIMITER" + " = " + "\",\"");
							log4jParamters_tAggregateRow_1_AGGOUT.append(" | ");
							log4jParamters_tAggregateRow_1_AGGOUT.append("USE_FINANCIAL_PRECISION" + " = " + "true");
							log4jParamters_tAggregateRow_1_AGGOUT.append(" | ");
							log4jParamters_tAggregateRow_1_AGGOUT.append("CHECK_TYPE_OVERFLOW" + " = " + "false");
							log4jParamters_tAggregateRow_1_AGGOUT.append(" | ");
							log4jParamters_tAggregateRow_1_AGGOUT.append("CHECK_ULP" + " = " + "false");
							log4jParamters_tAggregateRow_1_AGGOUT.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tAggregateRow_1_AGGOUT - " + (log4jParamters_tAggregateRow_1_AGGOUT));
						}
					}
					new BytesLimit65535_tAggregateRow_1_AGGOUT().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tAggregateRow_1_AGGOUT", "count_AGGOUT", "tAggregateOut");
					talendJobLogProcess(globalMap);
				}

// ------------ Seems it is not used

				java.util.Map hashAggreg_tAggregateRow_1 = new java.util.HashMap();

// ------------

				class UtilClass_tAggregateRow_1 { // G_OutBegin_AggR_144

					public double sd(Double[] data) {
						final int n = data.length;
						if (n < 2) {
							return Double.NaN;
						}
						double d1 = 0d;
						double d2 = 0d;

						for (int i = 0; i < data.length; i++) {
							d1 += (data[i] * data[i]);
							d2 += data[i];
						}

						return Math.sqrt((n * d1 - d2 * d2) / n / (n - 1));
					}

					public void checkedIADD(byte a, byte b, boolean checkTypeOverFlow, boolean checkUlp) {
						byte r = (byte) (a + b);
						if (checkTypeOverFlow && ((a ^ r) & (b ^ r)) < 0) {
							throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b),
									"'short/Short'", "'byte/Byte'"));
						}
					}

					public void checkedIADD(short a, short b, boolean checkTypeOverFlow, boolean checkUlp) {
						short r = (short) (a + b);
						if (checkTypeOverFlow && ((a ^ r) & (b ^ r)) < 0) {
							throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b),
									"'int/Integer'", "'short/Short'"));
						}
					}

					public void checkedIADD(int a, int b, boolean checkTypeOverFlow, boolean checkUlp) {
						int r = a + b;
						if (checkTypeOverFlow && ((a ^ r) & (b ^ r)) < 0) {
							throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b),
									"'long/Long'", "'int/Integer'"));
						}
					}

					public void checkedIADD(long a, long b, boolean checkTypeOverFlow, boolean checkUlp) {
						long r = a + b;
						if (checkTypeOverFlow && ((a ^ r) & (b ^ r)) < 0) {
							throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b),
									"'BigDecimal'", "'long/Long'"));
						}
					}

					public void checkedIADD(float a, float b, boolean checkTypeOverFlow, boolean checkUlp) {

						if (checkUlp) {
							float minAddedValue = Math.ulp(a);
							if (minAddedValue > Math.abs(b)) {
								throw new RuntimeException(buildPrecisionMessage(String.valueOf(a), String.valueOf(b),
										"'double' or 'BigDecimal'", "'float/Float'"));
							}
						}

						if (checkTypeOverFlow && ((double) a + (double) b > (double) Float.MAX_VALUE)
								|| ((double) a + (double) b < (double) -Float.MAX_VALUE)) {
							throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b),
									"'double' or 'BigDecimal'", "'float/Float'"));
						}
					}

					public void checkedIADD(double a, double b, boolean checkTypeOverFlow, boolean checkUlp) {

						if (checkUlp) {
							double minAddedValue = Math.ulp(a);
							if (minAddedValue > Math.abs(b)) {
								throw new RuntimeException(buildPrecisionMessage(String.valueOf(a), String.valueOf(a),
										"'BigDecimal'", "'double/Double'"));
							}
						}

						if (checkTypeOverFlow && (a + b > (double) Double.MAX_VALUE) || (a + b < -Double.MAX_VALUE)) {
							throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b),
									"'BigDecimal'", "'double/Double'"));
						}
					}

					public void checkedIADD(double a, byte b, boolean checkTypeOverFlow, boolean checkUlp) {

						if (checkTypeOverFlow && (a + b > (double) Double.MAX_VALUE) || (a + b < -Double.MAX_VALUE)) {
							throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b),
									"'BigDecimal'", "'double/Double'"));
						}
					}

					public void checkedIADD(double a, short b, boolean checkTypeOverFlow, boolean checkUlp) {

						if (checkTypeOverFlow && (a + b > (double) Double.MAX_VALUE) || (a + b < -Double.MAX_VALUE)) {
							throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b),
									"'BigDecimal'", "'double/Double'"));
						}
					}

					public void checkedIADD(double a, int b, boolean checkTypeOverFlow, boolean checkUlp) {

						if (checkTypeOverFlow && (a + b > (double) Double.MAX_VALUE) || (a + b < -Double.MAX_VALUE)) {
							throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b),
									"'BigDecimal'", "'double/Double'"));
						}
					}

					public void checkedIADD(double a, float b, boolean checkTypeOverFlow, boolean checkUlp) {

						if (checkUlp) {
							double minAddedValue = Math.ulp(a);
							if (minAddedValue > Math.abs(b)) {
								throw new RuntimeException(buildPrecisionMessage(String.valueOf(a), String.valueOf(a),
										"'BigDecimal'", "'double/Double'"));
							}
						}

						if (checkTypeOverFlow && (a + b > (double) Double.MAX_VALUE) || (a + b < -Double.MAX_VALUE)) {
							throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b),
									"'BigDecimal'", "'double/Double'"));
						}
					}

					private String buildOverflowMessage(String a, String b, String advicedTypes, String originalType) {
						return "Type overflow when adding " + b + " to " + a
								+ ", to resolve this problem, increase the precision by using " + advicedTypes
								+ " type in place of " + originalType + ".";
					}

					private String buildPrecisionMessage(String a, String b, String advicedTypes, String originalType) {
						return "The double precision is unsufficient to add the value " + b + " to " + a
								+ ", to resolve this problem, increase the precision by using " + advicedTypes
								+ " type in place of " + originalType + ".";
					}

				} // G_OutBegin_AggR_144

				UtilClass_tAggregateRow_1 utilClass_tAggregateRow_1 = new UtilClass_tAggregateRow_1();

				class AggOperationStruct_tAggregateRow_1 { // G_OutBegin_AggR_100

					private static final int DEFAULT_HASHCODE = 1;
					private static final int PRIME = 31;
					private int hashCode = DEFAULT_HASHCODE;
					public boolean hashCodeDirty = true;

					String InsuranceID;
					String InsuranceName;
					int count = 0;
					int PatientCount_clmCount = 0;

					@Override
					public int hashCode() {
						if (this.hashCodeDirty) {
							final int prime = PRIME;
							int result = DEFAULT_HASHCODE;

							result = prime * result + ((this.InsuranceID == null) ? 0 : this.InsuranceID.hashCode());

							result = prime * result
									+ ((this.InsuranceName == null) ? 0 : this.InsuranceName.hashCode());

							this.hashCode = result;
							this.hashCodeDirty = false;
						}
						return this.hashCode;
					}

					@Override
					public boolean equals(Object obj) {
						if (this == obj)
							return true;
						if (obj == null)
							return false;
						if (getClass() != obj.getClass())
							return false;
						final AggOperationStruct_tAggregateRow_1 other = (AggOperationStruct_tAggregateRow_1) obj;

						if (this.InsuranceID == null) {
							if (other.InsuranceID != null)
								return false;
						} else if (!this.InsuranceID.equals(other.InsuranceID))
							return false;

						if (this.InsuranceName == null) {
							if (other.InsuranceName != null)
								return false;
						} else if (!this.InsuranceName.equals(other.InsuranceName))
							return false;

						return true;
					}

				} // G_OutBegin_AggR_100

				AggOperationStruct_tAggregateRow_1 operation_result_tAggregateRow_1 = null;
				AggOperationStruct_tAggregateRow_1 operation_finder_tAggregateRow_1 = new AggOperationStruct_tAggregateRow_1();
				java.util.Map<AggOperationStruct_tAggregateRow_1, AggOperationStruct_tAggregateRow_1> hash_tAggregateRow_1 = new java.util.HashMap<AggOperationStruct_tAggregateRow_1, AggOperationStruct_tAggregateRow_1>();

				/**
				 * [tAggregateRow_1_AGGOUT begin ] stop
				 */

				/**
				 * [tMap_4 begin ] start
				 */

				ok_Hash.put("tMap_4", false);
				start_Hash.put("tMap_4", System.currentTimeMillis());

				currentComponent = "tMap_4";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "row6");

				int tos_count_tMap_4 = 0;

				if (log.isDebugEnabled())
					log.debug("tMap_4 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tMap_4 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tMap_4 = new StringBuilder();
							log4jParamters_tMap_4.append("Parameters:");
							log4jParamters_tMap_4.append("LINK_STYLE" + " = " + "AUTO");
							log4jParamters_tMap_4.append(" | ");
							log4jParamters_tMap_4.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
							log4jParamters_tMap_4.append(" | ");
							log4jParamters_tMap_4.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
							log4jParamters_tMap_4.append(" | ");
							log4jParamters_tMap_4.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "true");
							log4jParamters_tMap_4.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tMap_4 - " + (log4jParamters_tMap_4));
						}
					}
					new BytesLimit65535_tMap_4().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tMap_4", "tMap_4", "tMap");
					talendJobLogProcess(globalMap);
				}

// ###############################
// # Lookup's keys initialization
				int count_row6_tMap_4 = 0;

// ###############################        

// ###############################
// # Vars initialization
				class Var__tMap_4__Struct {
				}
				Var__tMap_4__Struct Var__tMap_4 = new Var__tMap_4__Struct();
// ###############################

// ###############################
// # Outputs initialization
				int count_GreaterThan2L_tMap_4 = 0;

				GreaterThan2LStruct GreaterThan2L_tmp = new GreaterThan2LStruct();
				int count_PatientsCoveredByEachInsurance_tMap_4 = 0;

				PatientsCoveredByEachInsuranceStruct PatientsCoveredByEachInsurance_tmp = new PatientsCoveredByEachInsuranceStruct();
// ###############################

				/**
				 * [tMap_4 begin ] stop
				 */

				/**
				 * [tDBInput_4 begin ] start
				 */

				ok_Hash.put("tDBInput_4", false);
				start_Hash.put("tDBInput_4", System.currentTimeMillis());

				currentComponent = "tDBInput_4";

				cLabel = "Insurance";

				int tos_count_tDBInput_4 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBInput_4 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tDBInput_4 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tDBInput_4 = new StringBuilder();
							log4jParamters_tDBInput_4.append("Parameters:");
							log4jParamters_tDBInput_4.append("DB_VERSION" + " = " + "MYSQL_8");
							log4jParamters_tDBInput_4.append(" | ");
							log4jParamters_tDBInput_4.append("USE_EXISTING_CONNECTION" + " = " + "false");
							log4jParamters_tDBInput_4.append(" | ");
							log4jParamters_tDBInput_4.append("HOST" + " = " + "\"localhost\"");
							log4jParamters_tDBInput_4.append(" | ");
							log4jParamters_tDBInput_4.append("PORT" + " = " + "\"3306\"");
							log4jParamters_tDBInput_4.append(" | ");
							log4jParamters_tDBInput_4.append("DBNAME" + " = " + "\"Warehouse\"");
							log4jParamters_tDBInput_4.append(" | ");
							log4jParamters_tDBInput_4.append("USER" + " = " + "\"root\"");
							log4jParamters_tDBInput_4.append(" | ");
							log4jParamters_tDBInput_4.append("PASS" + " = " + String.valueOf(
									"enc:routine.encryption.key.v1:w7yOIGmUXVz9GXU7Wk7aGmmTrbQhDa0faySQMnobV1c=")
									.substring(0, 4) + "...");
							log4jParamters_tDBInput_4.append(" | ");
							log4jParamters_tDBInput_4.append("TABLE" + " = " + "\"insurancedim\"");
							log4jParamters_tDBInput_4.append(" | ");
							log4jParamters_tDBInput_4.append("QUERYSTORE" + " = " + "\"\"");
							log4jParamters_tDBInput_4.append(" | ");
							log4jParamters_tDBInput_4.append("QUERY" + " = "
									+ "\"SELECT    `insurancedim`.`PatientID`,    `insurancedim`.`Name`,    `insurancedim`.`DOB`,    `insurancedim`.`Gender`,    `insurancedim`.`Address`,    `insurancedim`.`City`,    `insurancedim`.`Country`,    `insurancedim`.`Phone`,    `insurancedim`.`InsuranceID`,    `insurancedim`.`InsuranceName`,    `insurancedim`.`MaxCoverageAmount`,    `insurancedim`.`Start_date`,    `insurancedim`.`End_date`,    `insurancedim`.`InsuranceSK` FROM `insurancedim`\"");
							log4jParamters_tDBInput_4.append(" | ");
							log4jParamters_tDBInput_4.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
							log4jParamters_tDBInput_4.append(" | ");
							log4jParamters_tDBInput_4.append("PROPERTIES" + " = "
									+ "\"noDatetimeStringSync=true&enabledTLSProtocols=TLSv1.2,TLSv1.1,TLSv1\"");
							log4jParamters_tDBInput_4.append(" | ");
							log4jParamters_tDBInput_4.append("ENABLE_STREAM" + " = " + "false");
							log4jParamters_tDBInput_4.append(" | ");
							log4jParamters_tDBInput_4.append("TRIM_ALL_COLUMN" + " = " + "false");
							log4jParamters_tDBInput_4.append(" | ");
							log4jParamters_tDBInput_4.append("TRIM_COLUMN" + " = " + "[{TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("PatientID") + "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN="
									+ ("Name") + "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN=" + ("DOB") + "}, {TRIM="
									+ ("false") + ", SCHEMA_COLUMN=" + ("Gender") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("Address") + "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN="
									+ ("City") + "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN=" + ("Country")
									+ "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN=" + ("Phone") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("InsuranceID") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("InsuranceName") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("MaxCoverageAmount") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("Start_date") + "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN="
									+ ("End_date") + "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN=" + ("InsuranceSK")
									+ "}]");
							log4jParamters_tDBInput_4.append(" | ");
							log4jParamters_tDBInput_4.append("UNIFIED_COMPONENTS" + " = " + "tMysqlInput");
							log4jParamters_tDBInput_4.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tDBInput_4 - " + (log4jParamters_tDBInput_4));
						}
					}
					new BytesLimit65535_tDBInput_4().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tDBInput_4", "Insurance", "tMysqlInput");
					talendJobLogProcess(globalMap);
				}

				java.util.Calendar calendar_tDBInput_4 = java.util.Calendar.getInstance();
				calendar_tDBInput_4.set(0, 0, 0, 0, 0, 0);
				java.util.Date year0_tDBInput_4 = calendar_tDBInput_4.getTime();
				int nb_line_tDBInput_4 = 0;
				java.sql.Connection conn_tDBInput_4 = null;
				String driverClass_tDBInput_4 = "com.mysql.cj.jdbc.Driver";
				java.lang.Class jdbcclazz_tDBInput_4 = java.lang.Class.forName(driverClass_tDBInput_4);
				String dbUser_tDBInput_4 = "root";

				final String decryptedPassword_tDBInput_4 = routines.system.PasswordEncryptUtil
						.decryptPassword("enc:routine.encryption.key.v1:rHeWHKTF5yQ7WADugPV6XlxuflsGI4OjsyTNmybIBoU=");

				String dbPwd_tDBInput_4 = decryptedPassword_tDBInput_4;

				String properties_tDBInput_4 = "noDatetimeStringSync=true&enabledTLSProtocols=TLSv1.2,TLSv1.1,TLSv1";
				if (properties_tDBInput_4 == null || properties_tDBInput_4.trim().length() == 0) {
					properties_tDBInput_4 = "";
				}
				String url_tDBInput_4 = "jdbc:mysql://" + "localhost" + ":" + "3306" + "/" + "Warehouse" + "?"
						+ properties_tDBInput_4;

				log.debug("tDBInput_4 - Driver ClassName: " + driverClass_tDBInput_4 + ".");

				log.debug("tDBInput_4 - Connection attempt to '" + url_tDBInput_4 + "' with the username '"
						+ dbUser_tDBInput_4 + "'.");

				conn_tDBInput_4 = java.sql.DriverManager.getConnection(url_tDBInput_4, dbUser_tDBInput_4,
						dbPwd_tDBInput_4);
				log.debug("tDBInput_4 - Connection to '" + url_tDBInput_4 + "' has succeeded.");

				java.sql.Statement stmt_tDBInput_4 = conn_tDBInput_4.createStatement();

				String dbquery_tDBInput_4 = "SELECT \n  `insurancedim`.`PatientID`, \n  `insurancedim`.`Name`, \n  `insurancedim`.`DOB`, \n  `insurancedim`.`Gender`, \n "
						+ " `insurancedim`.`Address`, \n  `insurancedim`.`City`, \n  `insurancedim`.`Country`, \n  `insurancedim`.`Phone`, \n  `insuran"
						+ "cedim`.`InsuranceID`, \n  `insurancedim`.`InsuranceName`, \n  `insurancedim`.`MaxCoverageAmount`, \n  `insurancedim`.`Start"
						+ "_date`, \n  `insurancedim`.`End_date`, \n  `insurancedim`.`InsuranceSK`\nFROM `insurancedim`";

				log.debug("tDBInput_4 - Executing the query: '" + dbquery_tDBInput_4 + "'.");

				globalMap.put("tDBInput_4_QUERY", dbquery_tDBInput_4);

				java.sql.ResultSet rs_tDBInput_4 = null;

				try {
					rs_tDBInput_4 = stmt_tDBInput_4.executeQuery(dbquery_tDBInput_4);
					java.sql.ResultSetMetaData rsmd_tDBInput_4 = rs_tDBInput_4.getMetaData();
					int colQtyInRs_tDBInput_4 = rsmd_tDBInput_4.getColumnCount();

					String tmpContent_tDBInput_4 = null;

					log.debug("tDBInput_4 - Retrieving records from the database.");

					while (rs_tDBInput_4.next()) {
						nb_line_tDBInput_4++;

						if (colQtyInRs_tDBInput_4 < 1) {
							row6.PatientID = null;
						} else {

							row6.PatientID = rs_tDBInput_4.getInt(1);
							if (rs_tDBInput_4.wasNull()) {
								row6.PatientID = null;
							}
						}
						if (colQtyInRs_tDBInput_4 < 2) {
							row6.Name = null;
						} else {

							row6.Name = routines.system.JDBCUtil.getString(rs_tDBInput_4, 2, false);
						}
						if (colQtyInRs_tDBInput_4 < 3) {
							row6.DOB = null;
						} else {

							if (rs_tDBInput_4.getString(3) != null) {
								String dateString_tDBInput_4 = rs_tDBInput_4.getString(3);
								if (!("0000-00-00").equals(dateString_tDBInput_4)
										&& !("0000-00-00 00:00:00").equals(dateString_tDBInput_4)) {
									row6.DOB = rs_tDBInput_4.getTimestamp(3);
								} else {
									row6.DOB = (java.util.Date) year0_tDBInput_4.clone();
								}
							} else {
								row6.DOB = null;
							}
						}
						if (colQtyInRs_tDBInput_4 < 4) {
							row6.Gender = null;
						} else {

							row6.Gender = routines.system.JDBCUtil.getString(rs_tDBInput_4, 4, false);
						}
						if (colQtyInRs_tDBInput_4 < 5) {
							row6.Address = null;
						} else {

							row6.Address = routines.system.JDBCUtil.getString(rs_tDBInput_4, 5, false);
						}
						if (colQtyInRs_tDBInput_4 < 6) {
							row6.City = null;
						} else {

							row6.City = routines.system.JDBCUtil.getString(rs_tDBInput_4, 6, false);
						}
						if (colQtyInRs_tDBInput_4 < 7) {
							row6.Country = null;
						} else {

							row6.Country = routines.system.JDBCUtil.getString(rs_tDBInput_4, 7, false);
						}
						if (colQtyInRs_tDBInput_4 < 8) {
							row6.Phone = null;
						} else {

							row6.Phone = routines.system.JDBCUtil.getString(rs_tDBInput_4, 8, false);
						}
						if (colQtyInRs_tDBInput_4 < 9) {
							row6.InsuranceID = null;
						} else {

							row6.InsuranceID = routines.system.JDBCUtil.getString(rs_tDBInput_4, 9, false);
						}
						if (colQtyInRs_tDBInput_4 < 10) {
							row6.InsuranceName = null;
						} else {

							row6.InsuranceName = routines.system.JDBCUtil.getString(rs_tDBInput_4, 10, false);
						}
						if (colQtyInRs_tDBInput_4 < 11) {
							row6.MaxCoverageAmount = null;
						} else {

							row6.MaxCoverageAmount = rs_tDBInput_4.getInt(11);
							if (rs_tDBInput_4.wasNull()) {
								row6.MaxCoverageAmount = null;
							}
						}
						if (colQtyInRs_tDBInput_4 < 12) {
							row6.Start_date = null;
						} else {

							if (rs_tDBInput_4.getString(12) != null) {
								String dateString_tDBInput_4 = rs_tDBInput_4.getString(12);
								if (!("0000-00-00").equals(dateString_tDBInput_4)
										&& !("0000-00-00 00:00:00").equals(dateString_tDBInput_4)) {
									row6.Start_date = rs_tDBInput_4.getTimestamp(12);
								} else {
									row6.Start_date = (java.util.Date) year0_tDBInput_4.clone();
								}
							} else {
								row6.Start_date = null;
							}
						}
						if (colQtyInRs_tDBInput_4 < 13) {
							row6.End_date = null;
						} else {

							if (rs_tDBInput_4.getString(13) != null) {
								String dateString_tDBInput_4 = rs_tDBInput_4.getString(13);
								if (!("0000-00-00").equals(dateString_tDBInput_4)
										&& !("0000-00-00 00:00:00").equals(dateString_tDBInput_4)) {
									row6.End_date = rs_tDBInput_4.getTimestamp(13);
								} else {
									row6.End_date = (java.util.Date) year0_tDBInput_4.clone();
								}
							} else {
								row6.End_date = null;
							}
						}
						if (colQtyInRs_tDBInput_4 < 14) {
							row6.InsuranceSK = 0;
						} else {

							row6.InsuranceSK = rs_tDBInput_4.getInt(14);
							if (rs_tDBInput_4.wasNull()) {
								throw new RuntimeException("Null value in non-Nullable column");
							}
						}

						log.debug("tDBInput_4 - Retrieving the record " + nb_line_tDBInput_4 + ".");

						/**
						 * [tDBInput_4 begin ] stop
						 */

						/**
						 * [tDBInput_4 main ] start
						 */

						currentComponent = "tDBInput_4";

						cLabel = "Insurance";

						tos_count_tDBInput_4++;

						/**
						 * [tDBInput_4 main ] stop
						 */

						/**
						 * [tDBInput_4 process_data_begin ] start
						 */

						currentComponent = "tDBInput_4";

						cLabel = "Insurance";

						/**
						 * [tDBInput_4 process_data_begin ] stop
						 */

						/**
						 * [tMap_4 main ] start
						 */

						currentComponent = "tMap_4";

						if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

								, "row6", "tDBInput_4", "Insurance", "tMysqlInput", "tMap_4", "tMap_4", "tMap"

						)) {
							talendJobLogProcess(globalMap);
						}

						if (log.isTraceEnabled()) {
							log.trace("row6 - " + (row6 == null ? "" : row6.toLogString()));
						}

						boolean hasCasePrimitiveKeyWithNull_tMap_4 = false;

						// ###############################
						// # Input tables (lookups)

						boolean rejectedInnerJoin_tMap_4 = false;
						boolean mainRowRejected_tMap_4 = false;
						// ###############################
						{ // start of Var scope

							// ###############################
							// # Vars tables

							Var__tMap_4__Struct Var = Var__tMap_4;// ###############################
							// ###############################
							// # Output tables

							GreaterThan2L = null;
							PatientsCoveredByEachInsurance = null;

// # Output table : 'GreaterThan2L'
// # Filter conditions 
							if (

							row6.MaxCoverageAmount != null && row6.MaxCoverageAmount > 200000

							) {
								count_GreaterThan2L_tMap_4++;

								GreaterThan2L_tmp.PatientID = row6.PatientID;
								GreaterThan2L_tmp.Name = row6.Name;
								GreaterThan2L_tmp.DOB = row6.DOB;
								GreaterThan2L_tmp.Gender = row6.Gender;
								GreaterThan2L_tmp.Address = row6.Address;
								GreaterThan2L_tmp.City = row6.City;
								GreaterThan2L_tmp.Country = row6.Country;
								GreaterThan2L_tmp.Phone = row6.Phone;
								GreaterThan2L_tmp.InsuranceID = row6.InsuranceID;
								GreaterThan2L_tmp.InsuranceName = row6.InsuranceName;
								GreaterThan2L_tmp.MaxCoverageAmount = row6.MaxCoverageAmount;
								GreaterThan2L = GreaterThan2L_tmp;
								log.debug("tMap_4 - Outputting the record " + count_GreaterThan2L_tMap_4
										+ " of the output table 'GreaterThan2L'.");

							} // closing filter/reject

// # Output table : 'PatientsCoveredByEachInsurance'
							count_PatientsCoveredByEachInsurance_tMap_4++;

							PatientsCoveredByEachInsurance_tmp.PatientID = row6.PatientID;
							PatientsCoveredByEachInsurance_tmp.Name = row6.Name;
							PatientsCoveredByEachInsurance_tmp.DOB = row6.DOB;
							PatientsCoveredByEachInsurance_tmp.Gender = row6.Gender;
							PatientsCoveredByEachInsurance_tmp.Address = row6.Address;
							PatientsCoveredByEachInsurance_tmp.City = row6.City;
							PatientsCoveredByEachInsurance_tmp.Country = row6.Country;
							PatientsCoveredByEachInsurance_tmp.Phone = row6.Phone;
							PatientsCoveredByEachInsurance_tmp.InsuranceID = row6.InsuranceID;
							PatientsCoveredByEachInsurance_tmp.InsuranceName = row6.InsuranceName;
							PatientsCoveredByEachInsurance_tmp.MaxCoverageAmount = row6.MaxCoverageAmount;
							PatientsCoveredByEachInsurance = PatientsCoveredByEachInsurance_tmp;
							log.debug("tMap_4 - Outputting the record " + count_PatientsCoveredByEachInsurance_tMap_4
									+ " of the output table 'PatientsCoveredByEachInsurance'.");

// ###############################

						} // end of Var scope

						rejectedInnerJoin_tMap_4 = false;

						tos_count_tMap_4++;

						/**
						 * [tMap_4 main ] stop
						 */

						/**
						 * [tMap_4 process_data_begin ] start
						 */

						currentComponent = "tMap_4";

						/**
						 * [tMap_4 process_data_begin ] stop
						 */
// Start of branch "GreaterThan2L"
						if (GreaterThan2L != null) {

							/**
							 * [tFileOutputExcel_9 main ] start
							 */

							currentComponent = "tFileOutputExcel_9";

							cLabel = "GreaterThan2L";

							if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

									, "GreaterThan2L", "tMap_4", "tMap_4", "tMap", "tFileOutputExcel_9",
									"GreaterThan2L", "tFileOutputExcel"

							)) {
								talendJobLogProcess(globalMap);
							}

							if (log.isTraceEnabled()) {
								log.trace("GreaterThan2L - "
										+ (GreaterThan2L == null ? "" : GreaterThan2L.toLogString()));
							}

							if (GreaterThan2L.PatientID != null) {

//modif start

								columnIndex_tFileOutputExcel_9 = 0;

								jxl.write.WritableCell cell_0_tFileOutputExcel_9 = new jxl.write.Number(
										columnIndex_tFileOutputExcel_9,
										startRowNum_tFileOutputExcel_9 + nb_line_tFileOutputExcel_9,

//modif end
										GreaterThan2L.PatientID);
//modif start					
								// If we keep the cell format from the existing cell in sheet

//modif ends							
								writableSheet_tFileOutputExcel_9.addCell(cell_0_tFileOutputExcel_9);
								int currentWith_0_tFileOutputExcel_9 = String
										.valueOf(((jxl.write.Number) cell_0_tFileOutputExcel_9).getValue()).trim()
										.length();
								currentWith_0_tFileOutputExcel_9 = currentWith_0_tFileOutputExcel_9 > 10 ? 10
										: currentWith_0_tFileOutputExcel_9;
								fitWidth_tFileOutputExcel_9[0] = fitWidth_tFileOutputExcel_9[0] > currentWith_0_tFileOutputExcel_9
										? fitWidth_tFileOutputExcel_9[0]
										: currentWith_0_tFileOutputExcel_9 + 2;
							}

							if (GreaterThan2L.Name != null) {

//modif start

								columnIndex_tFileOutputExcel_9 = 1;

								jxl.write.WritableCell cell_1_tFileOutputExcel_9 = new jxl.write.Label(
										columnIndex_tFileOutputExcel_9,
										startRowNum_tFileOutputExcel_9 + nb_line_tFileOutputExcel_9,

//modif end
										GreaterThan2L.Name);
//modif start					
								// If we keep the cell format from the existing cell in sheet

//modif ends							
								writableSheet_tFileOutputExcel_9.addCell(cell_1_tFileOutputExcel_9);
								int currentWith_1_tFileOutputExcel_9 = cell_1_tFileOutputExcel_9.getContents().trim()
										.length();
								fitWidth_tFileOutputExcel_9[1] = fitWidth_tFileOutputExcel_9[1] > currentWith_1_tFileOutputExcel_9
										? fitWidth_tFileOutputExcel_9[1]
										: currentWith_1_tFileOutputExcel_9 + 2;
							}

							if (GreaterThan2L.DOB != null) {

//modif start

								columnIndex_tFileOutputExcel_9 = 2;

								jxl.write.WritableCell cell_2_tFileOutputExcel_9 = new jxl.write.DateTime(
										columnIndex_tFileOutputExcel_9,
										startRowNum_tFileOutputExcel_9 + nb_line_tFileOutputExcel_9,

//modif end
										GreaterThan2L.DOB, cell_format_DOB_tFileOutputExcel_9);
//modif start					
								// If we keep the cell format from the existing cell in sheet

//modif ends							
								writableSheet_tFileOutputExcel_9.addCell(cell_2_tFileOutputExcel_9);
								int currentWith_2_tFileOutputExcel_9 = cell_2_tFileOutputExcel_9.getContents().trim()
										.length();
								currentWith_2_tFileOutputExcel_9 = 12;
								fitWidth_tFileOutputExcel_9[2] = fitWidth_tFileOutputExcel_9[2] > currentWith_2_tFileOutputExcel_9
										? fitWidth_tFileOutputExcel_9[2]
										: currentWith_2_tFileOutputExcel_9 + 2;
							}

							if (GreaterThan2L.Gender != null) {

//modif start

								columnIndex_tFileOutputExcel_9 = 3;

								jxl.write.WritableCell cell_3_tFileOutputExcel_9 = new jxl.write.Label(
										columnIndex_tFileOutputExcel_9,
										startRowNum_tFileOutputExcel_9 + nb_line_tFileOutputExcel_9,

//modif end
										GreaterThan2L.Gender);
//modif start					
								// If we keep the cell format from the existing cell in sheet

//modif ends							
								writableSheet_tFileOutputExcel_9.addCell(cell_3_tFileOutputExcel_9);
								int currentWith_3_tFileOutputExcel_9 = cell_3_tFileOutputExcel_9.getContents().trim()
										.length();
								fitWidth_tFileOutputExcel_9[3] = fitWidth_tFileOutputExcel_9[3] > currentWith_3_tFileOutputExcel_9
										? fitWidth_tFileOutputExcel_9[3]
										: currentWith_3_tFileOutputExcel_9 + 2;
							}

							if (GreaterThan2L.Address != null) {

//modif start

								columnIndex_tFileOutputExcel_9 = 4;

								jxl.write.WritableCell cell_4_tFileOutputExcel_9 = new jxl.write.Label(
										columnIndex_tFileOutputExcel_9,
										startRowNum_tFileOutputExcel_9 + nb_line_tFileOutputExcel_9,

//modif end
										GreaterThan2L.Address);
//modif start					
								// If we keep the cell format from the existing cell in sheet

//modif ends							
								writableSheet_tFileOutputExcel_9.addCell(cell_4_tFileOutputExcel_9);
								int currentWith_4_tFileOutputExcel_9 = cell_4_tFileOutputExcel_9.getContents().trim()
										.length();
								fitWidth_tFileOutputExcel_9[4] = fitWidth_tFileOutputExcel_9[4] > currentWith_4_tFileOutputExcel_9
										? fitWidth_tFileOutputExcel_9[4]
										: currentWith_4_tFileOutputExcel_9 + 2;
							}

							if (GreaterThan2L.City != null) {

//modif start

								columnIndex_tFileOutputExcel_9 = 5;

								jxl.write.WritableCell cell_5_tFileOutputExcel_9 = new jxl.write.Label(
										columnIndex_tFileOutputExcel_9,
										startRowNum_tFileOutputExcel_9 + nb_line_tFileOutputExcel_9,

//modif end
										GreaterThan2L.City);
//modif start					
								// If we keep the cell format from the existing cell in sheet

//modif ends							
								writableSheet_tFileOutputExcel_9.addCell(cell_5_tFileOutputExcel_9);
								int currentWith_5_tFileOutputExcel_9 = cell_5_tFileOutputExcel_9.getContents().trim()
										.length();
								fitWidth_tFileOutputExcel_9[5] = fitWidth_tFileOutputExcel_9[5] > currentWith_5_tFileOutputExcel_9
										? fitWidth_tFileOutputExcel_9[5]
										: currentWith_5_tFileOutputExcel_9 + 2;
							}

							if (GreaterThan2L.Country != null) {

//modif start

								columnIndex_tFileOutputExcel_9 = 6;

								jxl.write.WritableCell cell_6_tFileOutputExcel_9 = new jxl.write.Label(
										columnIndex_tFileOutputExcel_9,
										startRowNum_tFileOutputExcel_9 + nb_line_tFileOutputExcel_9,

//modif end
										GreaterThan2L.Country);
//modif start					
								// If we keep the cell format from the existing cell in sheet

//modif ends							
								writableSheet_tFileOutputExcel_9.addCell(cell_6_tFileOutputExcel_9);
								int currentWith_6_tFileOutputExcel_9 = cell_6_tFileOutputExcel_9.getContents().trim()
										.length();
								fitWidth_tFileOutputExcel_9[6] = fitWidth_tFileOutputExcel_9[6] > currentWith_6_tFileOutputExcel_9
										? fitWidth_tFileOutputExcel_9[6]
										: currentWith_6_tFileOutputExcel_9 + 2;
							}

							if (GreaterThan2L.Phone != null) {

//modif start

								columnIndex_tFileOutputExcel_9 = 7;

								jxl.write.WritableCell cell_7_tFileOutputExcel_9 = new jxl.write.Label(
										columnIndex_tFileOutputExcel_9,
										startRowNum_tFileOutputExcel_9 + nb_line_tFileOutputExcel_9,

//modif end
										GreaterThan2L.Phone);
//modif start					
								// If we keep the cell format from the existing cell in sheet

//modif ends							
								writableSheet_tFileOutputExcel_9.addCell(cell_7_tFileOutputExcel_9);
								int currentWith_7_tFileOutputExcel_9 = cell_7_tFileOutputExcel_9.getContents().trim()
										.length();
								fitWidth_tFileOutputExcel_9[7] = fitWidth_tFileOutputExcel_9[7] > currentWith_7_tFileOutputExcel_9
										? fitWidth_tFileOutputExcel_9[7]
										: currentWith_7_tFileOutputExcel_9 + 2;
							}

							if (GreaterThan2L.InsuranceID != null) {

//modif start

								columnIndex_tFileOutputExcel_9 = 8;

								jxl.write.WritableCell cell_8_tFileOutputExcel_9 = new jxl.write.Label(
										columnIndex_tFileOutputExcel_9,
										startRowNum_tFileOutputExcel_9 + nb_line_tFileOutputExcel_9,

//modif end
										GreaterThan2L.InsuranceID);
//modif start					
								// If we keep the cell format from the existing cell in sheet

//modif ends							
								writableSheet_tFileOutputExcel_9.addCell(cell_8_tFileOutputExcel_9);
								int currentWith_8_tFileOutputExcel_9 = cell_8_tFileOutputExcel_9.getContents().trim()
										.length();
								fitWidth_tFileOutputExcel_9[8] = fitWidth_tFileOutputExcel_9[8] > currentWith_8_tFileOutputExcel_9
										? fitWidth_tFileOutputExcel_9[8]
										: currentWith_8_tFileOutputExcel_9 + 2;
							}

							if (GreaterThan2L.InsuranceName != null) {

//modif start

								columnIndex_tFileOutputExcel_9 = 9;

								jxl.write.WritableCell cell_9_tFileOutputExcel_9 = new jxl.write.Label(
										columnIndex_tFileOutputExcel_9,
										startRowNum_tFileOutputExcel_9 + nb_line_tFileOutputExcel_9,

//modif end
										GreaterThan2L.InsuranceName);
//modif start					
								// If we keep the cell format from the existing cell in sheet

//modif ends							
								writableSheet_tFileOutputExcel_9.addCell(cell_9_tFileOutputExcel_9);
								int currentWith_9_tFileOutputExcel_9 = cell_9_tFileOutputExcel_9.getContents().trim()
										.length();
								fitWidth_tFileOutputExcel_9[9] = fitWidth_tFileOutputExcel_9[9] > currentWith_9_tFileOutputExcel_9
										? fitWidth_tFileOutputExcel_9[9]
										: currentWith_9_tFileOutputExcel_9 + 2;
							}

							if (GreaterThan2L.MaxCoverageAmount != null) {

//modif start

								columnIndex_tFileOutputExcel_9 = 10;

								jxl.write.WritableCell cell_10_tFileOutputExcel_9 = new jxl.write.Number(
										columnIndex_tFileOutputExcel_9,
										startRowNum_tFileOutputExcel_9 + nb_line_tFileOutputExcel_9,

//modif end
										GreaterThan2L.MaxCoverageAmount);
//modif start					
								// If we keep the cell format from the existing cell in sheet

//modif ends							
								writableSheet_tFileOutputExcel_9.addCell(cell_10_tFileOutputExcel_9);
								int currentWith_10_tFileOutputExcel_9 = String
										.valueOf(((jxl.write.Number) cell_10_tFileOutputExcel_9).getValue()).trim()
										.length();
								currentWith_10_tFileOutputExcel_9 = currentWith_10_tFileOutputExcel_9 > 10 ? 10
										: currentWith_10_tFileOutputExcel_9;
								fitWidth_tFileOutputExcel_9[10] = fitWidth_tFileOutputExcel_9[10] > currentWith_10_tFileOutputExcel_9
										? fitWidth_tFileOutputExcel_9[10]
										: currentWith_10_tFileOutputExcel_9 + 2;
							}

							nb_line_tFileOutputExcel_9++;

							log.debug("tFileOutputExcel_9 - Writing the record " + nb_line_tFileOutputExcel_9
									+ " to the file.");

							tos_count_tFileOutputExcel_9++;

							/**
							 * [tFileOutputExcel_9 main ] stop
							 */

							/**
							 * [tFileOutputExcel_9 process_data_begin ] start
							 */

							currentComponent = "tFileOutputExcel_9";

							cLabel = "GreaterThan2L";

							/**
							 * [tFileOutputExcel_9 process_data_begin ] stop
							 */

							/**
							 * [tFileOutputExcel_9 process_data_end ] start
							 */

							currentComponent = "tFileOutputExcel_9";

							cLabel = "GreaterThan2L";

							/**
							 * [tFileOutputExcel_9 process_data_end ] stop
							 */

						} // End of branch "GreaterThan2L"

// Start of branch "PatientsCoveredByEachInsurance"
						if (PatientsCoveredByEachInsurance != null) {

							/**
							 * [tAggregateRow_1_AGGOUT main ] start
							 */

							currentVirtualComponent = "tAggregateRow_1";

							currentComponent = "tAggregateRow_1_AGGOUT";

							if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

									, "PatientsCoveredByEachInsurance", "tMap_4", "tMap_4", "tMap",
									"tAggregateRow_1_AGGOUT", "count_AGGOUT", "tAggregateOut"

							)) {
								talendJobLogProcess(globalMap);
							}

							if (log.isTraceEnabled()) {
								log.trace("PatientsCoveredByEachInsurance - "
										+ (PatientsCoveredByEachInsurance == null ? ""
												: PatientsCoveredByEachInsurance.toLogString()));
							}

							operation_finder_tAggregateRow_1.InsuranceID = PatientsCoveredByEachInsurance.InsuranceID;
							operation_finder_tAggregateRow_1.InsuranceName = PatientsCoveredByEachInsurance.InsuranceName;

							operation_finder_tAggregateRow_1.hashCodeDirty = true;

							operation_result_tAggregateRow_1 = hash_tAggregateRow_1
									.get(operation_finder_tAggregateRow_1);

							if (operation_result_tAggregateRow_1 == null) { // G_OutMain_AggR_001

								operation_result_tAggregateRow_1 = new AggOperationStruct_tAggregateRow_1();

								operation_result_tAggregateRow_1.InsuranceID = operation_finder_tAggregateRow_1.InsuranceID;
								operation_result_tAggregateRow_1.InsuranceName = operation_finder_tAggregateRow_1.InsuranceName;

								hash_tAggregateRow_1.put(operation_result_tAggregateRow_1,
										operation_result_tAggregateRow_1);

							} // G_OutMain_AggR_001

							operation_result_tAggregateRow_1.PatientCount_clmCount++;
							operation_result_tAggregateRow_1.count++;

							tos_count_tAggregateRow_1_AGGOUT++;

							/**
							 * [tAggregateRow_1_AGGOUT main ] stop
							 */

							/**
							 * [tAggregateRow_1_AGGOUT process_data_begin ] start
							 */

							currentVirtualComponent = "tAggregateRow_1";

							currentComponent = "tAggregateRow_1_AGGOUT";

							/**
							 * [tAggregateRow_1_AGGOUT process_data_begin ] stop
							 */

							/**
							 * [tAggregateRow_1_AGGOUT process_data_end ] start
							 */

							currentVirtualComponent = "tAggregateRow_1";

							currentComponent = "tAggregateRow_1_AGGOUT";

							/**
							 * [tAggregateRow_1_AGGOUT process_data_end ] stop
							 */

						} // End of branch "PatientsCoveredByEachInsurance"

						/**
						 * [tMap_4 process_data_end ] start
						 */

						currentComponent = "tMap_4";

						/**
						 * [tMap_4 process_data_end ] stop
						 */

						/**
						 * [tDBInput_4 process_data_end ] start
						 */

						currentComponent = "tDBInput_4";

						cLabel = "Insurance";

						/**
						 * [tDBInput_4 process_data_end ] stop
						 */

						/**
						 * [tDBInput_4 end ] start
						 */

						currentComponent = "tDBInput_4";

						cLabel = "Insurance";

					}
				} finally {
					if (rs_tDBInput_4 != null) {
						rs_tDBInput_4.close();
					}
					if (stmt_tDBInput_4 != null) {
						stmt_tDBInput_4.close();
					}
					if (conn_tDBInput_4 != null && !conn_tDBInput_4.isClosed()) {

						log.debug("tDBInput_4 - Closing the connection to the database.");

						conn_tDBInput_4.close();

						if ("com.mysql.cj.jdbc.Driver".equals((String) globalMap.get("driverClass_"))
								&& routines.system.BundleUtils.inOSGi()) {
							Class.forName("com.mysql.cj.jdbc.AbandonedConnectionCleanupThread")
									.getMethod("checkedShutdown").invoke(null, (Object[]) null);
						}

						log.debug("tDBInput_4 - Connection to the database closed.");

					}

				}
				globalMap.put("tDBInput_4_NB_LINE", nb_line_tDBInput_4);
				log.debug("tDBInput_4 - Retrieved records count: " + nb_line_tDBInput_4 + " .");

				if (log.isDebugEnabled())
					log.debug("tDBInput_4 - " + ("Done."));

				ok_Hash.put("tDBInput_4", true);
				end_Hash.put("tDBInput_4", System.currentTimeMillis());

				/**
				 * [tDBInput_4 end ] stop
				 */

				/**
				 * [tMap_4 end ] start
				 */

				currentComponent = "tMap_4";

// ###############################
// # Lookup hashes releasing
// ###############################      
				log.debug("tMap_4 - Written records count in the table 'GreaterThan2L': " + count_GreaterThan2L_tMap_4
						+ ".");
				log.debug("tMap_4 - Written records count in the table 'PatientsCoveredByEachInsurance': "
						+ count_PatientsCoveredByEachInsurance_tMap_4 + ".");

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "row6", 2, 0,
						"tDBInput_4", "Insurance", "tMysqlInput", "tMap_4", "tMap_4", "tMap", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tMap_4 - " + ("Done."));

				ok_Hash.put("tMap_4", true);
				end_Hash.put("tMap_4", System.currentTimeMillis());

				/**
				 * [tMap_4 end ] stop
				 */

				/**
				 * [tFileOutputExcel_9 end ] start
				 */

				currentComponent = "tFileOutputExcel_9";

				cLabel = "GreaterThan2L";

				columnIndex_tFileOutputExcel_9 = 0;

				// modif start

				writableSheet_tFileOutputExcel_9.setColumnView(columnIndex_tFileOutputExcel_9,
						fitWidth_tFileOutputExcel_9[0]);

				// modif end

				columnIndex_tFileOutputExcel_9 = 1;

				// modif start

				writableSheet_tFileOutputExcel_9.setColumnView(columnIndex_tFileOutputExcel_9,
						fitWidth_tFileOutputExcel_9[1]);

				// modif end

				columnIndex_tFileOutputExcel_9 = 2;

				// modif start

				writableSheet_tFileOutputExcel_9.setColumnView(columnIndex_tFileOutputExcel_9,
						fitWidth_tFileOutputExcel_9[2]);

				// modif end

				columnIndex_tFileOutputExcel_9 = 3;

				// modif start

				writableSheet_tFileOutputExcel_9.setColumnView(columnIndex_tFileOutputExcel_9,
						fitWidth_tFileOutputExcel_9[3]);

				// modif end

				columnIndex_tFileOutputExcel_9 = 4;

				// modif start

				writableSheet_tFileOutputExcel_9.setColumnView(columnIndex_tFileOutputExcel_9,
						fitWidth_tFileOutputExcel_9[4]);

				// modif end

				columnIndex_tFileOutputExcel_9 = 5;

				// modif start

				writableSheet_tFileOutputExcel_9.setColumnView(columnIndex_tFileOutputExcel_9,
						fitWidth_tFileOutputExcel_9[5]);

				// modif end

				columnIndex_tFileOutputExcel_9 = 6;

				// modif start

				writableSheet_tFileOutputExcel_9.setColumnView(columnIndex_tFileOutputExcel_9,
						fitWidth_tFileOutputExcel_9[6]);

				// modif end

				columnIndex_tFileOutputExcel_9 = 7;

				// modif start

				writableSheet_tFileOutputExcel_9.setColumnView(columnIndex_tFileOutputExcel_9,
						fitWidth_tFileOutputExcel_9[7]);

				// modif end

				columnIndex_tFileOutputExcel_9 = 8;

				// modif start

				writableSheet_tFileOutputExcel_9.setColumnView(columnIndex_tFileOutputExcel_9,
						fitWidth_tFileOutputExcel_9[8]);

				// modif end

				columnIndex_tFileOutputExcel_9 = 9;

				// modif start

				writableSheet_tFileOutputExcel_9.setColumnView(columnIndex_tFileOutputExcel_9,
						fitWidth_tFileOutputExcel_9[9]);

				// modif end

				columnIndex_tFileOutputExcel_9 = 10;

				// modif start

				writableSheet_tFileOutputExcel_9.setColumnView(columnIndex_tFileOutputExcel_9,
						fitWidth_tFileOutputExcel_9[10]);

				// modif end

				writeableWorkbook_tFileOutputExcel_9.write();
				writeableWorkbook_tFileOutputExcel_9.close();
				if (headerIsInserted_tFileOutputExcel_9 && nb_line_tFileOutputExcel_9 > 0) {
					nb_line_tFileOutputExcel_9 = nb_line_tFileOutputExcel_9 - 1;
				}
				globalMap.put("tFileOutputExcel_9_NB_LINE", nb_line_tFileOutputExcel_9);

				log.debug("tFileOutputExcel_9 - Written records count: " + nb_line_tFileOutputExcel_9 + " .");

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "GreaterThan2L", 2, 0,
						"tMap_4", "tMap_4", "tMap", "tFileOutputExcel_9", "GreaterThan2L", "tFileOutputExcel",
						"output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tFileOutputExcel_9 - " + ("Done."));

				ok_Hash.put("tFileOutputExcel_9", true);
				end_Hash.put("tFileOutputExcel_9", System.currentTimeMillis());

				/**
				 * [tFileOutputExcel_9 end ] stop
				 */

				/**
				 * [tAggregateRow_1_AGGOUT end ] start
				 */

				currentVirtualComponent = "tAggregateRow_1";

				currentComponent = "tAggregateRow_1_AGGOUT";

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId,
						"PatientsCoveredByEachInsurance", 2, 0, "tMap_4", "tMap_4", "tMap", "tAggregateRow_1_AGGOUT",
						"count_AGGOUT", "tAggregateOut", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tAggregateRow_1_AGGOUT - " + ("Done."));

				ok_Hash.put("tAggregateRow_1_AGGOUT", true);
				end_Hash.put("tAggregateRow_1_AGGOUT", System.currentTimeMillis());

				/**
				 * [tAggregateRow_1_AGGOUT end ] stop
				 */

				/**
				 * [tFileOutputExcel_10 begin ] start
				 */

				ok_Hash.put("tFileOutputExcel_10", false);
				start_Hash.put("tFileOutputExcel_10", System.currentTimeMillis());

				currentComponent = "tFileOutputExcel_10";

				cLabel = "PatientCount";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "row7");

				int tos_count_tFileOutputExcel_10 = 0;

				if (log.isDebugEnabled())
					log.debug("tFileOutputExcel_10 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tFileOutputExcel_10 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tFileOutputExcel_10 = new StringBuilder();
							log4jParamters_tFileOutputExcel_10.append("Parameters:");
							log4jParamters_tFileOutputExcel_10.append("VERSION_2007" + " = " + "false");
							log4jParamters_tFileOutputExcel_10.append(" | ");
							log4jParamters_tFileOutputExcel_10.append("USESTREAM" + " = " + "false");
							log4jParamters_tFileOutputExcel_10.append(" | ");
							log4jParamters_tFileOutputExcel_10
									.append("FILENAME" + " = " + "\"C:/Users/2382187/Downloads/FR/PatientCount.xls\"");
							log4jParamters_tFileOutputExcel_10.append(" | ");
							log4jParamters_tFileOutputExcel_10.append("SHEETNAME" + " = " + "\"Sheet1\"");
							log4jParamters_tFileOutputExcel_10.append(" | ");
							log4jParamters_tFileOutputExcel_10.append("INCLUDEHEADER" + " = " + "true");
							log4jParamters_tFileOutputExcel_10.append(" | ");
							log4jParamters_tFileOutputExcel_10.append("APPEND_FILE" + " = " + "false");
							log4jParamters_tFileOutputExcel_10.append(" | ");
							log4jParamters_tFileOutputExcel_10.append("FIRST_CELL_Y_ABSOLUTE" + " = " + "false");
							log4jParamters_tFileOutputExcel_10.append(" | ");
							log4jParamters_tFileOutputExcel_10.append("FONT" + " = " + "");
							log4jParamters_tFileOutputExcel_10.append(" | ");
							log4jParamters_tFileOutputExcel_10.append("IS_ALL_AUTO_SZIE" + " = " + "true");
							log4jParamters_tFileOutputExcel_10.append(" | ");
							log4jParamters_tFileOutputExcel_10.append("CREATE" + " = " + "true");
							log4jParamters_tFileOutputExcel_10.append(" | ");
							log4jParamters_tFileOutputExcel_10.append("ADVANCED_SEPARATOR" + " = " + "false");
							log4jParamters_tFileOutputExcel_10.append(" | ");
							log4jParamters_tFileOutputExcel_10.append("ENCODING" + " = " + "\"ISO-8859-15\"");
							log4jParamters_tFileOutputExcel_10.append(" | ");
							log4jParamters_tFileOutputExcel_10.append("DELETE_EMPTYFILE" + " = " + "false");
							log4jParamters_tFileOutputExcel_10.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tFileOutputExcel_10 - " + (log4jParamters_tFileOutputExcel_10));
						}
					}
					new BytesLimit65535_tFileOutputExcel_10().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tFileOutputExcel_10", "PatientCount", "tFileOutputExcel");
					talendJobLogProcess(globalMap);
				}

				int columnIndex_tFileOutputExcel_10 = 0;
				boolean headerIsInserted_tFileOutputExcel_10 = false;

				int nb_line_tFileOutputExcel_10 = 0;

				String fileName_tFileOutputExcel_10 = "C:/Users/2382187/Downloads/FR/PatientCount.xls";
				java.io.File file_tFileOutputExcel_10 = new java.io.File(fileName_tFileOutputExcel_10);
				boolean isFileGenerated_tFileOutputExcel_10 = true;
//create directory only if not exists
				java.io.File parentFile_tFileOutputExcel_10 = file_tFileOutputExcel_10.getParentFile();
				if (parentFile_tFileOutputExcel_10 != null && !parentFile_tFileOutputExcel_10.exists()) {

					log.info("tFileOutputExcel_10 - Creating directory '"
							+ parentFile_tFileOutputExcel_10.getCanonicalPath() + "'.");

					parentFile_tFileOutputExcel_10.mkdirs();

					log.info("tFileOutputExcel_10 - Create directory '"
							+ parentFile_tFileOutputExcel_10.getCanonicalPath() + "' has succeeded.");

				}

				jxl.write.WritableWorkbook writeableWorkbook_tFileOutputExcel_10 = null;
				jxl.write.WritableSheet writableSheet_tFileOutputExcel_10 = null;

				jxl.WorkbookSettings workbookSettings_tFileOutputExcel_10 = new jxl.WorkbookSettings();
				workbookSettings_tFileOutputExcel_10.setEncoding("ISO-8859-15");
				writeableWorkbook_tFileOutputExcel_10 = new jxl.write.biff.WritableWorkbookImpl(
						new java.io.BufferedOutputStream(new java.io.FileOutputStream(fileName_tFileOutputExcel_10)),
						true, workbookSettings_tFileOutputExcel_10);

				writableSheet_tFileOutputExcel_10 = writeableWorkbook_tFileOutputExcel_10.getSheet("Sheet1");
				if (writableSheet_tFileOutputExcel_10 == null) {
					writableSheet_tFileOutputExcel_10 = writeableWorkbook_tFileOutputExcel_10.createSheet("Sheet1",
							writeableWorkbook_tFileOutputExcel_10.getNumberOfSheets());
				}

				// modif start
				int startRowNum_tFileOutputExcel_10 = writableSheet_tFileOutputExcel_10.getRows();
				// modif end

				int[] fitWidth_tFileOutputExcel_10 = new int[3];
				for (int i_tFileOutputExcel_10 = 0; i_tFileOutputExcel_10 < 3; i_tFileOutputExcel_10++) {
					int fitCellViewSize_tFileOutputExcel_10 = writableSheet_tFileOutputExcel_10
							.getColumnView(i_tFileOutputExcel_10).getSize();
					fitWidth_tFileOutputExcel_10[i_tFileOutputExcel_10] = fitCellViewSize_tFileOutputExcel_10 / 256;
					if (fitCellViewSize_tFileOutputExcel_10 % 256 != 0) {
						fitWidth_tFileOutputExcel_10[i_tFileOutputExcel_10] += 1;
					}
				}

				if (startRowNum_tFileOutputExcel_10 == 0) {
					// modif end
					// modif start
					writableSheet_tFileOutputExcel_10
							.addCell(new jxl.write.Label(0, nb_line_tFileOutputExcel_10, "InsuranceID"));
					// modif end
					fitWidth_tFileOutputExcel_10[0] = fitWidth_tFileOutputExcel_10[0] > 11
							? fitWidth_tFileOutputExcel_10[0]
							: 11;
					// modif start
					writableSheet_tFileOutputExcel_10
							.addCell(new jxl.write.Label(1, nb_line_tFileOutputExcel_10, "InsuranceName"));
					// modif end
					fitWidth_tFileOutputExcel_10[1] = fitWidth_tFileOutputExcel_10[1] > 13
							? fitWidth_tFileOutputExcel_10[1]
							: 13;
					// modif start
					writableSheet_tFileOutputExcel_10
							.addCell(new jxl.write.Label(2, nb_line_tFileOutputExcel_10, "PatientCount"));
					// modif end
					fitWidth_tFileOutputExcel_10[2] = fitWidth_tFileOutputExcel_10[2] > 12
							? fitWidth_tFileOutputExcel_10[2]
							: 12;
					nb_line_tFileOutputExcel_10++;
					headerIsInserted_tFileOutputExcel_10 = true;
				}

				/**
				 * [tFileOutputExcel_10 begin ] stop
				 */

				/**
				 * [tAggregateRow_1_AGGIN begin ] start
				 */

				ok_Hash.put("tAggregateRow_1_AGGIN", false);
				start_Hash.put("tAggregateRow_1_AGGIN", System.currentTimeMillis());

				currentVirtualComponent = "tAggregateRow_1";

				currentComponent = "tAggregateRow_1_AGGIN";

				int tos_count_tAggregateRow_1_AGGIN = 0;

				if (log.isDebugEnabled())
					log.debug("tAggregateRow_1_AGGIN - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tAggregateRow_1_AGGIN {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tAggregateRow_1_AGGIN = new StringBuilder();
							log4jParamters_tAggregateRow_1_AGGIN.append("Parameters:");
							log4jParamters_tAggregateRow_1_AGGIN.append("ORIGIN" + " = " + "tAggregateRow_1");
							log4jParamters_tAggregateRow_1_AGGIN.append(" | ");
							log4jParamters_tAggregateRow_1_AGGIN.append("GROUPBYS" + " = " + "[{OUTPUT_COLUMN="
									+ ("InsuranceID") + ", INPUT_COLUMN=" + ("InsuranceID") + "}, {OUTPUT_COLUMN="
									+ ("InsuranceName") + ", INPUT_COLUMN=" + ("InsuranceName") + "}]");
							log4jParamters_tAggregateRow_1_AGGIN.append(" | ");
							log4jParamters_tAggregateRow_1_AGGIN.append("OPERATIONS" + " = " + "[{OUTPUT_COLUMN="
									+ ("PatientCount") + ", INPUT_COLUMN=" + ("PatientID") + ", IGNORE_NULL="
									+ ("false") + ", FUNCTION=" + ("count") + "}]");
							log4jParamters_tAggregateRow_1_AGGIN.append(" | ");
							log4jParamters_tAggregateRow_1_AGGIN.append("LIST_DELIMITER" + " = " + "\",\"");
							log4jParamters_tAggregateRow_1_AGGIN.append(" | ");
							log4jParamters_tAggregateRow_1_AGGIN.append("USE_FINANCIAL_PRECISION" + " = " + "true");
							log4jParamters_tAggregateRow_1_AGGIN.append(" | ");
							log4jParamters_tAggregateRow_1_AGGIN.append("CHECK_TYPE_OVERFLOW" + " = " + "false");
							log4jParamters_tAggregateRow_1_AGGIN.append(" | ");
							log4jParamters_tAggregateRow_1_AGGIN.append("CHECK_ULP" + " = " + "false");
							log4jParamters_tAggregateRow_1_AGGIN.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tAggregateRow_1_AGGIN - " + (log4jParamters_tAggregateRow_1_AGGIN));
						}
					}
					new BytesLimit65535_tAggregateRow_1_AGGIN().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tAggregateRow_1_AGGIN", "count_AGGIN", "tAggregateIn");
					talendJobLogProcess(globalMap);
				}

				java.util.Collection<AggOperationStruct_tAggregateRow_1> values_tAggregateRow_1 = hash_tAggregateRow_1
						.values();

				globalMap.put("tAggregateRow_1_NB_LINE", values_tAggregateRow_1.size());

				if (log.isInfoEnabled())
					log.info("tAggregateRow_1_AGGIN - " + ("Retrieving the aggregation results."));
				for (AggOperationStruct_tAggregateRow_1 aggregated_row_tAggregateRow_1 : values_tAggregateRow_1) { // G_AggR_600

					/**
					 * [tAggregateRow_1_AGGIN begin ] stop
					 */

					/**
					 * [tAggregateRow_1_AGGIN main ] start
					 */

					currentVirtualComponent = "tAggregateRow_1";

					currentComponent = "tAggregateRow_1_AGGIN";

					row7.InsuranceID = aggregated_row_tAggregateRow_1.InsuranceID;

					row7.InsuranceName = aggregated_row_tAggregateRow_1.InsuranceName;
					row7.PatientCount = (int) aggregated_row_tAggregateRow_1.count;
					row7.PatientCount = (int) aggregated_row_tAggregateRow_1.PatientCount_clmCount;

					if (log.isDebugEnabled())
						log.debug("tAggregateRow_1_AGGIN - "
								+ ("Operation function: 'count' on the column 'PatientID'."));

					tos_count_tAggregateRow_1_AGGIN++;

					/**
					 * [tAggregateRow_1_AGGIN main ] stop
					 */

					/**
					 * [tAggregateRow_1_AGGIN process_data_begin ] start
					 */

					currentVirtualComponent = "tAggregateRow_1";

					currentComponent = "tAggregateRow_1_AGGIN";

					/**
					 * [tAggregateRow_1_AGGIN process_data_begin ] stop
					 */

					/**
					 * [tFileOutputExcel_10 main ] start
					 */

					currentComponent = "tFileOutputExcel_10";

					cLabel = "PatientCount";

					if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

							, "row7", "tAggregateRow_1_AGGIN", "count_AGGIN", "tAggregateIn", "tFileOutputExcel_10",
							"PatientCount", "tFileOutputExcel"

					)) {
						talendJobLogProcess(globalMap);
					}

					if (log.isTraceEnabled()) {
						log.trace("row7 - " + (row7 == null ? "" : row7.toLogString()));
					}

					if (row7.InsuranceID != null) {

//modif start

						columnIndex_tFileOutputExcel_10 = 0;

						jxl.write.WritableCell cell_0_tFileOutputExcel_10 = new jxl.write.Label(
								columnIndex_tFileOutputExcel_10,
								startRowNum_tFileOutputExcel_10 + nb_line_tFileOutputExcel_10,

//modif end
								row7.InsuranceID);
//modif start					
						// If we keep the cell format from the existing cell in sheet

//modif ends							
						writableSheet_tFileOutputExcel_10.addCell(cell_0_tFileOutputExcel_10);
						int currentWith_0_tFileOutputExcel_10 = cell_0_tFileOutputExcel_10.getContents().trim()
								.length();
						fitWidth_tFileOutputExcel_10[0] = fitWidth_tFileOutputExcel_10[0] > currentWith_0_tFileOutputExcel_10
								? fitWidth_tFileOutputExcel_10[0]
								: currentWith_0_tFileOutputExcel_10 + 2;
					}

					if (row7.InsuranceName != null) {

//modif start

						columnIndex_tFileOutputExcel_10 = 1;

						jxl.write.WritableCell cell_1_tFileOutputExcel_10 = new jxl.write.Label(
								columnIndex_tFileOutputExcel_10,
								startRowNum_tFileOutputExcel_10 + nb_line_tFileOutputExcel_10,

//modif end
								row7.InsuranceName);
//modif start					
						// If we keep the cell format from the existing cell in sheet

//modif ends							
						writableSheet_tFileOutputExcel_10.addCell(cell_1_tFileOutputExcel_10);
						int currentWith_1_tFileOutputExcel_10 = cell_1_tFileOutputExcel_10.getContents().trim()
								.length();
						fitWidth_tFileOutputExcel_10[1] = fitWidth_tFileOutputExcel_10[1] > currentWith_1_tFileOutputExcel_10
								? fitWidth_tFileOutputExcel_10[1]
								: currentWith_1_tFileOutputExcel_10 + 2;
					}

					if (row7.PatientCount != null) {

//modif start

						columnIndex_tFileOutputExcel_10 = 2;

						jxl.write.WritableCell cell_2_tFileOutputExcel_10 = new jxl.write.Number(
								columnIndex_tFileOutputExcel_10,
								startRowNum_tFileOutputExcel_10 + nb_line_tFileOutputExcel_10,

//modif end
								row7.PatientCount);
//modif start					
						// If we keep the cell format from the existing cell in sheet

//modif ends							
						writableSheet_tFileOutputExcel_10.addCell(cell_2_tFileOutputExcel_10);
						int currentWith_2_tFileOutputExcel_10 = String
								.valueOf(((jxl.write.Number) cell_2_tFileOutputExcel_10).getValue()).trim().length();
						currentWith_2_tFileOutputExcel_10 = currentWith_2_tFileOutputExcel_10 > 10 ? 10
								: currentWith_2_tFileOutputExcel_10;
						fitWidth_tFileOutputExcel_10[2] = fitWidth_tFileOutputExcel_10[2] > currentWith_2_tFileOutputExcel_10
								? fitWidth_tFileOutputExcel_10[2]
								: currentWith_2_tFileOutputExcel_10 + 2;
					}

					nb_line_tFileOutputExcel_10++;

					log.debug("tFileOutputExcel_10 - Writing the record " + nb_line_tFileOutputExcel_10
							+ " to the file.");

					tos_count_tFileOutputExcel_10++;

					/**
					 * [tFileOutputExcel_10 main ] stop
					 */

					/**
					 * [tFileOutputExcel_10 process_data_begin ] start
					 */

					currentComponent = "tFileOutputExcel_10";

					cLabel = "PatientCount";

					/**
					 * [tFileOutputExcel_10 process_data_begin ] stop
					 */

					/**
					 * [tFileOutputExcel_10 process_data_end ] start
					 */

					currentComponent = "tFileOutputExcel_10";

					cLabel = "PatientCount";

					/**
					 * [tFileOutputExcel_10 process_data_end ] stop
					 */

					/**
					 * [tAggregateRow_1_AGGIN process_data_end ] start
					 */

					currentVirtualComponent = "tAggregateRow_1";

					currentComponent = "tAggregateRow_1_AGGIN";

					/**
					 * [tAggregateRow_1_AGGIN process_data_end ] stop
					 */

					/**
					 * [tAggregateRow_1_AGGIN end ] start
					 */

					currentVirtualComponent = "tAggregateRow_1";

					currentComponent = "tAggregateRow_1_AGGIN";

				} // G_AggR_600

				if (log.isDebugEnabled())
					log.debug("tAggregateRow_1_AGGIN - " + ("Done."));

				ok_Hash.put("tAggregateRow_1_AGGIN", true);
				end_Hash.put("tAggregateRow_1_AGGIN", System.currentTimeMillis());

				/**
				 * [tAggregateRow_1_AGGIN end ] stop
				 */

				/**
				 * [tFileOutputExcel_10 end ] start
				 */

				currentComponent = "tFileOutputExcel_10";

				cLabel = "PatientCount";

				columnIndex_tFileOutputExcel_10 = 0;

				// modif start

				writableSheet_tFileOutputExcel_10.setColumnView(columnIndex_tFileOutputExcel_10,
						fitWidth_tFileOutputExcel_10[0]);

				// modif end

				columnIndex_tFileOutputExcel_10 = 1;

				// modif start

				writableSheet_tFileOutputExcel_10.setColumnView(columnIndex_tFileOutputExcel_10,
						fitWidth_tFileOutputExcel_10[1]);

				// modif end

				columnIndex_tFileOutputExcel_10 = 2;

				// modif start

				writableSheet_tFileOutputExcel_10.setColumnView(columnIndex_tFileOutputExcel_10,
						fitWidth_tFileOutputExcel_10[2]);

				// modif end

				writeableWorkbook_tFileOutputExcel_10.write();
				writeableWorkbook_tFileOutputExcel_10.close();
				if (headerIsInserted_tFileOutputExcel_10 && nb_line_tFileOutputExcel_10 > 0) {
					nb_line_tFileOutputExcel_10 = nb_line_tFileOutputExcel_10 - 1;
				}
				globalMap.put("tFileOutputExcel_10_NB_LINE", nb_line_tFileOutputExcel_10);

				log.debug("tFileOutputExcel_10 - Written records count: " + nb_line_tFileOutputExcel_10 + " .");

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "row7", 2, 0,
						"tAggregateRow_1_AGGIN", "count_AGGIN", "tAggregateIn", "tFileOutputExcel_10", "PatientCount",
						"tFileOutputExcel", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tFileOutputExcel_10 - " + ("Done."));

				ok_Hash.put("tFileOutputExcel_10", true);
				end_Hash.put("tFileOutputExcel_10", System.currentTimeMillis());

				/**
				 * [tFileOutputExcel_10 end ] stop
				 */

			} // end the resume

			if (resumeEntryMethodName == null || globalResumeTicket) {
				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tDBInput_4:OnSubjobOk", "",
						Thread.currentThread().getId() + "", "", "", "", "", "");
			}

			if (execStat) {
				runStat.updateStatOnConnection("OnSubjobOk4", 0, "ok");
			}

			tDBInput_5Process(globalMap);

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage(), e);
			}

			TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);

			te.setVirtualComponentName(currentVirtualComponent);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			// free memory for "tAggregateRow_1_AGGIN"
			globalMap.remove("tAggregateRow_1");

			try {

				/**
				 * [tDBInput_4 finally ] start
				 */

				currentComponent = "tDBInput_4";

				cLabel = "Insurance";

				/**
				 * [tDBInput_4 finally ] stop
				 */

				/**
				 * [tMap_4 finally ] start
				 */

				currentComponent = "tMap_4";

				/**
				 * [tMap_4 finally ] stop
				 */

				/**
				 * [tFileOutputExcel_9 finally ] start
				 */

				currentComponent = "tFileOutputExcel_9";

				cLabel = "GreaterThan2L";

				/**
				 * [tFileOutputExcel_9 finally ] stop
				 */

				/**
				 * [tAggregateRow_1_AGGOUT finally ] start
				 */

				currentVirtualComponent = "tAggregateRow_1";

				currentComponent = "tAggregateRow_1_AGGOUT";

				/**
				 * [tAggregateRow_1_AGGOUT finally ] stop
				 */

				/**
				 * [tAggregateRow_1_AGGIN finally ] start
				 */

				currentVirtualComponent = "tAggregateRow_1";

				currentComponent = "tAggregateRow_1_AGGIN";

				/**
				 * [tAggregateRow_1_AGGIN finally ] stop
				 */

				/**
				 * [tFileOutputExcel_10 finally ] start
				 */

				currentComponent = "tFileOutputExcel_10";

				cLabel = "PatientCount";

				/**
				 * [tFileOutputExcel_10 finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tDBInput_4_SUBPROCESS_STATE", 1);
	}

	public static class row13Struct implements routines.system.IPersistableRow<row13Struct> {
		final static byte[] commonByteArrayLock_HMS_FunctionalRequirement = new byte[0];
		static byte[] commonByteArray_HMS_FunctionalRequirement = new byte[0];

		public Integer PhysicianID;

		public Integer getPhysicianID() {
			return this.PhysicianID;
		}

		public Boolean PhysicianIDIsNullable() {
			return true;
		}

		public Boolean PhysicianIDIsKey() {
			return false;
		}

		public Integer PhysicianIDLength() {
			return 10;
		}

		public Integer PhysicianIDPrecision() {
			return 0;
		}

		public String PhysicianIDDefault() {

			return null;

		}

		public String PhysicianIDComment() {

			return "";

		}

		public String PhysicianIDPattern() {

			return "";

		}

		public String PhysicianIDOriginalDbColumnName() {

			return "PhysicianID";

		}

		public Integer TotalAmountPerPhysician;

		public Integer getTotalAmountPerPhysician() {
			return this.TotalAmountPerPhysician;
		}

		public Boolean TotalAmountPerPhysicianIsNullable() {
			return true;
		}

		public Boolean TotalAmountPerPhysicianIsKey() {
			return false;
		}

		public Integer TotalAmountPerPhysicianLength() {
			return 10;
		}

		public Integer TotalAmountPerPhysicianPrecision() {
			return 0;
		}

		public String TotalAmountPerPhysicianDefault() {

			return null;

		}

		public String TotalAmountPerPhysicianComment() {

			return "";

		}

		public String TotalAmountPerPhysicianPattern() {

			return "";

		}

		public String TotalAmountPerPhysicianOriginalDbColumnName() {

			return "TotalAmountPerPhysician";

		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_HMS_FunctionalRequirement) {

				try {

					int length = 0;

					this.PhysicianID = readInteger(dis);

					this.TotalAmountPerPhysician = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_HMS_FunctionalRequirement) {

				try {

					int length = 0;

					this.PhysicianID = readInteger(dis);

					this.TotalAmountPerPhysician = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.PhysicianID, dos);

				// Integer

				writeInteger(this.TotalAmountPerPhysician, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.PhysicianID, dos);

				// Integer

				writeInteger(this.TotalAmountPerPhysician, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("PhysicianID=" + String.valueOf(PhysicianID));
			sb.append(",TotalAmountPerPhysician=" + String.valueOf(TotalAmountPerPhysician));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (PhysicianID == null) {
				sb.append("<null>");
			} else {
				sb.append(PhysicianID);
			}

			sb.append("|");

			if (TotalAmountPerPhysician == null) {
				sb.append("<null>");
			} else {
				sb.append(TotalAmountPerPhysician);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row13Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row11Struct implements routines.system.IPersistableRow<row11Struct> {
		final static byte[] commonByteArrayLock_HMS_FunctionalRequirement = new byte[0];
		static byte[] commonByteArray_HMS_FunctionalRequirement = new byte[0];

		public Integer PhysicianID;

		public Integer getPhysicianID() {
			return this.PhysicianID;
		}

		public Boolean PhysicianIDIsNullable() {
			return true;
		}

		public Boolean PhysicianIDIsKey() {
			return false;
		}

		public Integer PhysicianIDLength() {
			return 10;
		}

		public Integer PhysicianIDPrecision() {
			return 0;
		}

		public String PhysicianIDDefault() {

			return null;

		}

		public String PhysicianIDComment() {

			return "";

		}

		public String PhysicianIDPattern() {

			return "";

		}

		public String PhysicianIDOriginalDbColumnName() {

			return "PhysicianID";

		}

		public Integer TotalAmountPerPhysician;

		public Integer getTotalAmountPerPhysician() {
			return this.TotalAmountPerPhysician;
		}

		public Boolean TotalAmountPerPhysicianIsNullable() {
			return true;
		}

		public Boolean TotalAmountPerPhysicianIsKey() {
			return false;
		}

		public Integer TotalAmountPerPhysicianLength() {
			return 10;
		}

		public Integer TotalAmountPerPhysicianPrecision() {
			return 0;
		}

		public String TotalAmountPerPhysicianDefault() {

			return null;

		}

		public String TotalAmountPerPhysicianComment() {

			return "";

		}

		public String TotalAmountPerPhysicianPattern() {

			return "";

		}

		public String TotalAmountPerPhysicianOriginalDbColumnName() {

			return "TotalAmountPerPhysician";

		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_HMS_FunctionalRequirement) {

				try {

					int length = 0;

					this.PhysicianID = readInteger(dis);

					this.TotalAmountPerPhysician = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_HMS_FunctionalRequirement) {

				try {

					int length = 0;

					this.PhysicianID = readInteger(dis);

					this.TotalAmountPerPhysician = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.PhysicianID, dos);

				// Integer

				writeInteger(this.TotalAmountPerPhysician, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.PhysicianID, dos);

				// Integer

				writeInteger(this.TotalAmountPerPhysician, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("PhysicianID=" + String.valueOf(PhysicianID));
			sb.append(",TotalAmountPerPhysician=" + String.valueOf(TotalAmountPerPhysician));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (PhysicianID == null) {
				sb.append("<null>");
			} else {
				sb.append(PhysicianID);
			}

			sb.append("|");

			if (TotalAmountPerPhysician == null) {
				sb.append("<null>");
			} else {
				sb.append(TotalAmountPerPhysician);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row11Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row10Struct implements routines.system.IPersistableRow<row10Struct> {
		final static byte[] commonByteArrayLock_HMS_FunctionalRequirement = new byte[0];
		static byte[] commonByteArray_HMS_FunctionalRequirement = new byte[0];

		public Integer PhysicianID;

		public Integer getPhysicianID() {
			return this.PhysicianID;
		}

		public Boolean PhysicianIDIsNullable() {
			return true;
		}

		public Boolean PhysicianIDIsKey() {
			return false;
		}

		public Integer PhysicianIDLength() {
			return 10;
		}

		public Integer PhysicianIDPrecision() {
			return 0;
		}

		public String PhysicianIDDefault() {

			return null;

		}

		public String PhysicianIDComment() {

			return "";

		}

		public String PhysicianIDPattern() {

			return "";

		}

		public String PhysicianIDOriginalDbColumnName() {

			return "PhysicianID";

		}

		public Integer TotalAmountPerPhysician;

		public Integer getTotalAmountPerPhysician() {
			return this.TotalAmountPerPhysician;
		}

		public Boolean TotalAmountPerPhysicianIsNullable() {
			return true;
		}

		public Boolean TotalAmountPerPhysicianIsKey() {
			return false;
		}

		public Integer TotalAmountPerPhysicianLength() {
			return 10;
		}

		public Integer TotalAmountPerPhysicianPrecision() {
			return 0;
		}

		public String TotalAmountPerPhysicianDefault() {

			return null;

		}

		public String TotalAmountPerPhysicianComment() {

			return "";

		}

		public String TotalAmountPerPhysicianPattern() {

			return "";

		}

		public String TotalAmountPerPhysicianOriginalDbColumnName() {

			return "TotalAmountPerPhysician";

		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_HMS_FunctionalRequirement) {

				try {

					int length = 0;

					this.PhysicianID = readInteger(dis);

					this.TotalAmountPerPhysician = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_HMS_FunctionalRequirement) {

				try {

					int length = 0;

					this.PhysicianID = readInteger(dis);

					this.TotalAmountPerPhysician = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.PhysicianID, dos);

				// Integer

				writeInteger(this.TotalAmountPerPhysician, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.PhysicianID, dos);

				// Integer

				writeInteger(this.TotalAmountPerPhysician, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("PhysicianID=" + String.valueOf(PhysicianID));
			sb.append(",TotalAmountPerPhysician=" + String.valueOf(TotalAmountPerPhysician));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (PhysicianID == null) {
				sb.append("<null>");
			} else {
				sb.append(PhysicianID);
			}

			sb.append("|");

			if (TotalAmountPerPhysician == null) {
				sb.append("<null>");
			} else {
				sb.append(TotalAmountPerPhysician);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row10Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class OnRowsEndStructtSortRow_3
			implements routines.system.IPersistableRow<OnRowsEndStructtSortRow_3> {
		final static byte[] commonByteArrayLock_HMS_FunctionalRequirement = new byte[0];
		static byte[] commonByteArray_HMS_FunctionalRequirement = new byte[0];

		public Integer PhysicianID;

		public Integer getPhysicianID() {
			return this.PhysicianID;
		}

		public Boolean PhysicianIDIsNullable() {
			return true;
		}

		public Boolean PhysicianIDIsKey() {
			return false;
		}

		public Integer PhysicianIDLength() {
			return 10;
		}

		public Integer PhysicianIDPrecision() {
			return 0;
		}

		public String PhysicianIDDefault() {

			return null;

		}

		public String PhysicianIDComment() {

			return "";

		}

		public String PhysicianIDPattern() {

			return "";

		}

		public String PhysicianIDOriginalDbColumnName() {

			return "PhysicianID";

		}

		public Integer TotalAmountPerPhysician;

		public Integer getTotalAmountPerPhysician() {
			return this.TotalAmountPerPhysician;
		}

		public Boolean TotalAmountPerPhysicianIsNullable() {
			return true;
		}

		public Boolean TotalAmountPerPhysicianIsKey() {
			return false;
		}

		public Integer TotalAmountPerPhysicianLength() {
			return 10;
		}

		public Integer TotalAmountPerPhysicianPrecision() {
			return 0;
		}

		public String TotalAmountPerPhysicianDefault() {

			return null;

		}

		public String TotalAmountPerPhysicianComment() {

			return "";

		}

		public String TotalAmountPerPhysicianPattern() {

			return "";

		}

		public String TotalAmountPerPhysicianOriginalDbColumnName() {

			return "TotalAmountPerPhysician";

		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_HMS_FunctionalRequirement) {

				try {

					int length = 0;

					this.PhysicianID = readInteger(dis);

					this.TotalAmountPerPhysician = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_HMS_FunctionalRequirement) {

				try {

					int length = 0;

					this.PhysicianID = readInteger(dis);

					this.TotalAmountPerPhysician = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.PhysicianID, dos);

				// Integer

				writeInteger(this.TotalAmountPerPhysician, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.PhysicianID, dos);

				// Integer

				writeInteger(this.TotalAmountPerPhysician, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("PhysicianID=" + String.valueOf(PhysicianID));
			sb.append(",TotalAmountPerPhysician=" + String.valueOf(TotalAmountPerPhysician));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (PhysicianID == null) {
				sb.append("<null>");
			} else {
				sb.append(PhysicianID);
			}

			sb.append("|");

			if (TotalAmountPerPhysician == null) {
				sb.append("<null>");
			} else {
				sb.append(TotalAmountPerPhysician);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(OnRowsEndStructtSortRow_3 other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row9Struct implements routines.system.IPersistableRow<row9Struct> {
		final static byte[] commonByteArrayLock_HMS_FunctionalRequirement = new byte[0];
		static byte[] commonByteArray_HMS_FunctionalRequirement = new byte[0];

		public Integer PhysicianID;

		public Integer getPhysicianID() {
			return this.PhysicianID;
		}

		public Boolean PhysicianIDIsNullable() {
			return true;
		}

		public Boolean PhysicianIDIsKey() {
			return false;
		}

		public Integer PhysicianIDLength() {
			return 10;
		}

		public Integer PhysicianIDPrecision() {
			return 0;
		}

		public String PhysicianIDDefault() {

			return null;

		}

		public String PhysicianIDComment() {

			return "";

		}

		public String PhysicianIDPattern() {

			return "";

		}

		public String PhysicianIDOriginalDbColumnName() {

			return "PhysicianID";

		}

		public Integer TotalAmountPerPhysician;

		public Integer getTotalAmountPerPhysician() {
			return this.TotalAmountPerPhysician;
		}

		public Boolean TotalAmountPerPhysicianIsNullable() {
			return true;
		}

		public Boolean TotalAmountPerPhysicianIsKey() {
			return false;
		}

		public Integer TotalAmountPerPhysicianLength() {
			return 10;
		}

		public Integer TotalAmountPerPhysicianPrecision() {
			return 0;
		}

		public String TotalAmountPerPhysicianDefault() {

			return null;

		}

		public String TotalAmountPerPhysicianComment() {

			return "";

		}

		public String TotalAmountPerPhysicianPattern() {

			return "";

		}

		public String TotalAmountPerPhysicianOriginalDbColumnName() {

			return "TotalAmountPerPhysician";

		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_HMS_FunctionalRequirement) {

				try {

					int length = 0;

					this.PhysicianID = readInteger(dis);

					this.TotalAmountPerPhysician = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_HMS_FunctionalRequirement) {

				try {

					int length = 0;

					this.PhysicianID = readInteger(dis);

					this.TotalAmountPerPhysician = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.PhysicianID, dos);

				// Integer

				writeInteger(this.TotalAmountPerPhysician, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.PhysicianID, dos);

				// Integer

				writeInteger(this.TotalAmountPerPhysician, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("PhysicianID=" + String.valueOf(PhysicianID));
			sb.append(",TotalAmountPerPhysician=" + String.valueOf(TotalAmountPerPhysician));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (PhysicianID == null) {
				sb.append("<null>");
			} else {
				sb.append(PhysicianID);
			}

			sb.append("|");

			if (TotalAmountPerPhysician == null) {
				sb.append("<null>");
			} else {
				sb.append(TotalAmountPerPhysician);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row9Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class OnRowsEndStructtAggregateRow_2
			implements routines.system.IPersistableRow<OnRowsEndStructtAggregateRow_2> {
		final static byte[] commonByteArrayLock_HMS_FunctionalRequirement = new byte[0];
		static byte[] commonByteArray_HMS_FunctionalRequirement = new byte[0];

		public Integer PhysicianID;

		public Integer getPhysicianID() {
			return this.PhysicianID;
		}

		public Boolean PhysicianIDIsNullable() {
			return true;
		}

		public Boolean PhysicianIDIsKey() {
			return false;
		}

		public Integer PhysicianIDLength() {
			return 10;
		}

		public Integer PhysicianIDPrecision() {
			return 0;
		}

		public String PhysicianIDDefault() {

			return null;

		}

		public String PhysicianIDComment() {

			return "";

		}

		public String PhysicianIDPattern() {

			return "";

		}

		public String PhysicianIDOriginalDbColumnName() {

			return "PhysicianID";

		}

		public Integer TotalAmountPerPhysician;

		public Integer getTotalAmountPerPhysician() {
			return this.TotalAmountPerPhysician;
		}

		public Boolean TotalAmountPerPhysicianIsNullable() {
			return true;
		}

		public Boolean TotalAmountPerPhysicianIsKey() {
			return false;
		}

		public Integer TotalAmountPerPhysicianLength() {
			return 10;
		}

		public Integer TotalAmountPerPhysicianPrecision() {
			return 0;
		}

		public String TotalAmountPerPhysicianDefault() {

			return null;

		}

		public String TotalAmountPerPhysicianComment() {

			return "";

		}

		public String TotalAmountPerPhysicianPattern() {

			return "";

		}

		public String TotalAmountPerPhysicianOriginalDbColumnName() {

			return "TotalAmountPerPhysician";

		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_HMS_FunctionalRequirement) {

				try {

					int length = 0;

					this.PhysicianID = readInteger(dis);

					this.TotalAmountPerPhysician = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_HMS_FunctionalRequirement) {

				try {

					int length = 0;

					this.PhysicianID = readInteger(dis);

					this.TotalAmountPerPhysician = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.PhysicianID, dos);

				// Integer

				writeInteger(this.TotalAmountPerPhysician, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.PhysicianID, dos);

				// Integer

				writeInteger(this.TotalAmountPerPhysician, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("PhysicianID=" + String.valueOf(PhysicianID));
			sb.append(",TotalAmountPerPhysician=" + String.valueOf(TotalAmountPerPhysician));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (PhysicianID == null) {
				sb.append("<null>");
			} else {
				sb.append(PhysicianID);
			}

			sb.append("|");

			if (TotalAmountPerPhysician == null) {
				sb.append("<null>");
			} else {
				sb.append(TotalAmountPerPhysician);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(OnRowsEndStructtAggregateRow_2 other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class NotCoveredByInsuranceStruct
			implements routines.system.IPersistableRow<NotCoveredByInsuranceStruct> {
		final static byte[] commonByteArrayLock_HMS_FunctionalRequirement = new byte[0];
		static byte[] commonByteArray_HMS_FunctionalRequirement = new byte[0];

		public String PaymentID;

		public String getPaymentID() {
			return this.PaymentID;
		}

		public Boolean PaymentIDIsNullable() {
			return true;
		}

		public Boolean PaymentIDIsKey() {
			return false;
		}

		public Integer PaymentIDLength() {
			return 25;
		}

		public Integer PaymentIDPrecision() {
			return 0;
		}

		public String PaymentIDDefault() {

			return null;

		}

		public String PaymentIDComment() {

			return "";

		}

		public String PaymentIDPattern() {

			return "";

		}

		public String PaymentIDOriginalDbColumnName() {

			return "PaymentID";

		}

		public Integer PatientID;

		public Integer getPatientID() {
			return this.PatientID;
		}

		public Boolean PatientIDIsNullable() {
			return true;
		}

		public Boolean PatientIDIsKey() {
			return false;
		}

		public Integer PatientIDLength() {
			return 10;
		}

		public Integer PatientIDPrecision() {
			return 0;
		}

		public String PatientIDDefault() {

			return null;

		}

		public String PatientIDComment() {

			return "";

		}

		public String PatientIDPattern() {

			return "";

		}

		public String PatientIDOriginalDbColumnName() {

			return "PatientID";

		}

		public Integer PhysicianID;

		public Integer getPhysicianID() {
			return this.PhysicianID;
		}

		public Boolean PhysicianIDIsNullable() {
			return true;
		}

		public Boolean PhysicianIDIsKey() {
			return false;
		}

		public Integer PhysicianIDLength() {
			return 10;
		}

		public Integer PhysicianIDPrecision() {
			return 0;
		}

		public String PhysicianIDDefault() {

			return null;

		}

		public String PhysicianIDComment() {

			return "";

		}

		public String PhysicianIDPattern() {

			return "";

		}

		public String PhysicianIDOriginalDbColumnName() {

			return "PhysicianID";

		}

		public Integer AmountToBePaid;

		public Integer getAmountToBePaid() {
			return this.AmountToBePaid;
		}

		public Boolean AmountToBePaidIsNullable() {
			return true;
		}

		public Boolean AmountToBePaidIsKey() {
			return false;
		}

		public Integer AmountToBePaidLength() {
			return 10;
		}

		public Integer AmountToBePaidPrecision() {
			return 0;
		}

		public String AmountToBePaidDefault() {

			return null;

		}

		public String AmountToBePaidComment() {

			return "";

		}

		public String AmountToBePaidPattern() {

			return "";

		}

		public String AmountToBePaidOriginalDbColumnName() {

			return "AmountToBePaid";

		}

		public java.util.Date PaymentDate;

		public java.util.Date getPaymentDate() {
			return this.PaymentDate;
		}

		public Boolean PaymentDateIsNullable() {
			return true;
		}

		public Boolean PaymentDateIsKey() {
			return false;
		}

		public Integer PaymentDateLength() {
			return 19;
		}

		public Integer PaymentDatePrecision() {
			return 0;
		}

		public String PaymentDateDefault() {

			return null;

		}

		public String PaymentDateComment() {

			return "";

		}

		public String PaymentDatePattern() {

			return "dd-MM-yyyy";

		}

		public String PaymentDateOriginalDbColumnName() {

			return "PaymentDate";

		}

		public String InsuranceID;

		public String getInsuranceID() {
			return this.InsuranceID;
		}

		public Boolean InsuranceIDIsNullable() {
			return true;
		}

		public Boolean InsuranceIDIsKey() {
			return false;
		}

		public Integer InsuranceIDLength() {
			return 25;
		}

		public Integer InsuranceIDPrecision() {
			return 0;
		}

		public String InsuranceIDDefault() {

			return null;

		}

		public String InsuranceIDComment() {

			return "";

		}

		public String InsuranceIDPattern() {

			return "";

		}

		public String InsuranceIDOriginalDbColumnName() {

			return "InsuranceID";

		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_HMS_FunctionalRequirement.length) {
					if (length < 1024 && commonByteArray_HMS_FunctionalRequirement.length == 0) {
						commonByteArray_HMS_FunctionalRequirement = new byte[1024];
					} else {
						commonByteArray_HMS_FunctionalRequirement = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_HMS_FunctionalRequirement, 0, length);
				strReturn = new String(commonByteArray_HMS_FunctionalRequirement, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_HMS_FunctionalRequirement.length) {
					if (length < 1024 && commonByteArray_HMS_FunctionalRequirement.length == 0) {
						commonByteArray_HMS_FunctionalRequirement = new byte[1024];
					} else {
						commonByteArray_HMS_FunctionalRequirement = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_HMS_FunctionalRequirement, 0, length);
				strReturn = new String(commonByteArray_HMS_FunctionalRequirement, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_HMS_FunctionalRequirement) {

				try {

					int length = 0;

					this.PaymentID = readString(dis);

					this.PatientID = readInteger(dis);

					this.PhysicianID = readInteger(dis);

					this.AmountToBePaid = readInteger(dis);

					this.PaymentDate = readDate(dis);

					this.InsuranceID = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_HMS_FunctionalRequirement) {

				try {

					int length = 0;

					this.PaymentID = readString(dis);

					this.PatientID = readInteger(dis);

					this.PhysicianID = readInteger(dis);

					this.AmountToBePaid = readInteger(dis);

					this.PaymentDate = readDate(dis);

					this.InsuranceID = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.PaymentID, dos);

				// Integer

				writeInteger(this.PatientID, dos);

				// Integer

				writeInteger(this.PhysicianID, dos);

				// Integer

				writeInteger(this.AmountToBePaid, dos);

				// java.util.Date

				writeDate(this.PaymentDate, dos);

				// String

				writeString(this.InsuranceID, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.PaymentID, dos);

				// Integer

				writeInteger(this.PatientID, dos);

				// Integer

				writeInteger(this.PhysicianID, dos);

				// Integer

				writeInteger(this.AmountToBePaid, dos);

				// java.util.Date

				writeDate(this.PaymentDate, dos);

				// String

				writeString(this.InsuranceID, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("PaymentID=" + PaymentID);
			sb.append(",PatientID=" + String.valueOf(PatientID));
			sb.append(",PhysicianID=" + String.valueOf(PhysicianID));
			sb.append(",AmountToBePaid=" + String.valueOf(AmountToBePaid));
			sb.append(",PaymentDate=" + String.valueOf(PaymentDate));
			sb.append(",InsuranceID=" + InsuranceID);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (PaymentID == null) {
				sb.append("<null>");
			} else {
				sb.append(PaymentID);
			}

			sb.append("|");

			if (PatientID == null) {
				sb.append("<null>");
			} else {
				sb.append(PatientID);
			}

			sb.append("|");

			if (PhysicianID == null) {
				sb.append("<null>");
			} else {
				sb.append(PhysicianID);
			}

			sb.append("|");

			if (AmountToBePaid == null) {
				sb.append("<null>");
			} else {
				sb.append(AmountToBePaid);
			}

			sb.append("|");

			if (PaymentDate == null) {
				sb.append("<null>");
			} else {
				sb.append(PaymentDate);
			}

			sb.append("|");

			if (InsuranceID == null) {
				sb.append("<null>");
			} else {
				sb.append(InsuranceID);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(NotCoveredByInsuranceStruct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class MaxToBePaidPhysicianStruct
			implements routines.system.IPersistableRow<MaxToBePaidPhysicianStruct> {
		final static byte[] commonByteArrayLock_HMS_FunctionalRequirement = new byte[0];
		static byte[] commonByteArray_HMS_FunctionalRequirement = new byte[0];

		public String PaymentID;

		public String getPaymentID() {
			return this.PaymentID;
		}

		public Boolean PaymentIDIsNullable() {
			return true;
		}

		public Boolean PaymentIDIsKey() {
			return false;
		}

		public Integer PaymentIDLength() {
			return 25;
		}

		public Integer PaymentIDPrecision() {
			return 0;
		}

		public String PaymentIDDefault() {

			return null;

		}

		public String PaymentIDComment() {

			return "";

		}

		public String PaymentIDPattern() {

			return "";

		}

		public String PaymentIDOriginalDbColumnName() {

			return "PaymentID";

		}

		public Integer PatientID;

		public Integer getPatientID() {
			return this.PatientID;
		}

		public Boolean PatientIDIsNullable() {
			return true;
		}

		public Boolean PatientIDIsKey() {
			return false;
		}

		public Integer PatientIDLength() {
			return 10;
		}

		public Integer PatientIDPrecision() {
			return 0;
		}

		public String PatientIDDefault() {

			return null;

		}

		public String PatientIDComment() {

			return "";

		}

		public String PatientIDPattern() {

			return "";

		}

		public String PatientIDOriginalDbColumnName() {

			return "PatientID";

		}

		public Integer PhysicianID;

		public Integer getPhysicianID() {
			return this.PhysicianID;
		}

		public Boolean PhysicianIDIsNullable() {
			return true;
		}

		public Boolean PhysicianIDIsKey() {
			return false;
		}

		public Integer PhysicianIDLength() {
			return 10;
		}

		public Integer PhysicianIDPrecision() {
			return 0;
		}

		public String PhysicianIDDefault() {

			return null;

		}

		public String PhysicianIDComment() {

			return "";

		}

		public String PhysicianIDPattern() {

			return "";

		}

		public String PhysicianIDOriginalDbColumnName() {

			return "PhysicianID";

		}

		public Integer AmountToBePaid;

		public Integer getAmountToBePaid() {
			return this.AmountToBePaid;
		}

		public Boolean AmountToBePaidIsNullable() {
			return true;
		}

		public Boolean AmountToBePaidIsKey() {
			return false;
		}

		public Integer AmountToBePaidLength() {
			return 10;
		}

		public Integer AmountToBePaidPrecision() {
			return 0;
		}

		public String AmountToBePaidDefault() {

			return null;

		}

		public String AmountToBePaidComment() {

			return "";

		}

		public String AmountToBePaidPattern() {

			return "";

		}

		public String AmountToBePaidOriginalDbColumnName() {

			return "AmountToBePaid";

		}

		public java.util.Date PaymentDate;

		public java.util.Date getPaymentDate() {
			return this.PaymentDate;
		}

		public Boolean PaymentDateIsNullable() {
			return true;
		}

		public Boolean PaymentDateIsKey() {
			return false;
		}

		public Integer PaymentDateLength() {
			return 19;
		}

		public Integer PaymentDatePrecision() {
			return 0;
		}

		public String PaymentDateDefault() {

			return null;

		}

		public String PaymentDateComment() {

			return "";

		}

		public String PaymentDatePattern() {

			return "dd-MM-yyyy";

		}

		public String PaymentDateOriginalDbColumnName() {

			return "PaymentDate";

		}

		public String InsuranceID;

		public String getInsuranceID() {
			return this.InsuranceID;
		}

		public Boolean InsuranceIDIsNullable() {
			return true;
		}

		public Boolean InsuranceIDIsKey() {
			return false;
		}

		public Integer InsuranceIDLength() {
			return 25;
		}

		public Integer InsuranceIDPrecision() {
			return 0;
		}

		public String InsuranceIDDefault() {

			return null;

		}

		public String InsuranceIDComment() {

			return "";

		}

		public String InsuranceIDPattern() {

			return "";

		}

		public String InsuranceIDOriginalDbColumnName() {

			return "InsuranceID";

		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_HMS_FunctionalRequirement.length) {
					if (length < 1024 && commonByteArray_HMS_FunctionalRequirement.length == 0) {
						commonByteArray_HMS_FunctionalRequirement = new byte[1024];
					} else {
						commonByteArray_HMS_FunctionalRequirement = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_HMS_FunctionalRequirement, 0, length);
				strReturn = new String(commonByteArray_HMS_FunctionalRequirement, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_HMS_FunctionalRequirement.length) {
					if (length < 1024 && commonByteArray_HMS_FunctionalRequirement.length == 0) {
						commonByteArray_HMS_FunctionalRequirement = new byte[1024];
					} else {
						commonByteArray_HMS_FunctionalRequirement = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_HMS_FunctionalRequirement, 0, length);
				strReturn = new String(commonByteArray_HMS_FunctionalRequirement, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_HMS_FunctionalRequirement) {

				try {

					int length = 0;

					this.PaymentID = readString(dis);

					this.PatientID = readInteger(dis);

					this.PhysicianID = readInteger(dis);

					this.AmountToBePaid = readInteger(dis);

					this.PaymentDate = readDate(dis);

					this.InsuranceID = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_HMS_FunctionalRequirement) {

				try {

					int length = 0;

					this.PaymentID = readString(dis);

					this.PatientID = readInteger(dis);

					this.PhysicianID = readInteger(dis);

					this.AmountToBePaid = readInteger(dis);

					this.PaymentDate = readDate(dis);

					this.InsuranceID = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.PaymentID, dos);

				// Integer

				writeInteger(this.PatientID, dos);

				// Integer

				writeInteger(this.PhysicianID, dos);

				// Integer

				writeInteger(this.AmountToBePaid, dos);

				// java.util.Date

				writeDate(this.PaymentDate, dos);

				// String

				writeString(this.InsuranceID, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.PaymentID, dos);

				// Integer

				writeInteger(this.PatientID, dos);

				// Integer

				writeInteger(this.PhysicianID, dos);

				// Integer

				writeInteger(this.AmountToBePaid, dos);

				// java.util.Date

				writeDate(this.PaymentDate, dos);

				// String

				writeString(this.InsuranceID, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("PaymentID=" + PaymentID);
			sb.append(",PatientID=" + String.valueOf(PatientID));
			sb.append(",PhysicianID=" + String.valueOf(PhysicianID));
			sb.append(",AmountToBePaid=" + String.valueOf(AmountToBePaid));
			sb.append(",PaymentDate=" + String.valueOf(PaymentDate));
			sb.append(",InsuranceID=" + InsuranceID);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (PaymentID == null) {
				sb.append("<null>");
			} else {
				sb.append(PaymentID);
			}

			sb.append("|");

			if (PatientID == null) {
				sb.append("<null>");
			} else {
				sb.append(PatientID);
			}

			sb.append("|");

			if (PhysicianID == null) {
				sb.append("<null>");
			} else {
				sb.append(PhysicianID);
			}

			sb.append("|");

			if (AmountToBePaid == null) {
				sb.append("<null>");
			} else {
				sb.append(AmountToBePaid);
			}

			sb.append("|");

			if (PaymentDate == null) {
				sb.append("<null>");
			} else {
				sb.append(PaymentDate);
			}

			sb.append("|");

			if (InsuranceID == null) {
				sb.append("<null>");
			} else {
				sb.append(InsuranceID);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(MaxToBePaidPhysicianStruct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class ThisMonthPaymentStruct implements routines.system.IPersistableRow<ThisMonthPaymentStruct> {
		final static byte[] commonByteArrayLock_HMS_FunctionalRequirement = new byte[0];
		static byte[] commonByteArray_HMS_FunctionalRequirement = new byte[0];

		public String PaymentID;

		public String getPaymentID() {
			return this.PaymentID;
		}

		public Boolean PaymentIDIsNullable() {
			return true;
		}

		public Boolean PaymentIDIsKey() {
			return false;
		}

		public Integer PaymentIDLength() {
			return 25;
		}

		public Integer PaymentIDPrecision() {
			return 0;
		}

		public String PaymentIDDefault() {

			return null;

		}

		public String PaymentIDComment() {

			return "";

		}

		public String PaymentIDPattern() {

			return "";

		}

		public String PaymentIDOriginalDbColumnName() {

			return "PaymentID";

		}

		public Integer PatientID;

		public Integer getPatientID() {
			return this.PatientID;
		}

		public Boolean PatientIDIsNullable() {
			return true;
		}

		public Boolean PatientIDIsKey() {
			return false;
		}

		public Integer PatientIDLength() {
			return 10;
		}

		public Integer PatientIDPrecision() {
			return 0;
		}

		public String PatientIDDefault() {

			return null;

		}

		public String PatientIDComment() {

			return "";

		}

		public String PatientIDPattern() {

			return "";

		}

		public String PatientIDOriginalDbColumnName() {

			return "PatientID";

		}

		public Integer PhysicianID;

		public Integer getPhysicianID() {
			return this.PhysicianID;
		}

		public Boolean PhysicianIDIsNullable() {
			return true;
		}

		public Boolean PhysicianIDIsKey() {
			return false;
		}

		public Integer PhysicianIDLength() {
			return 10;
		}

		public Integer PhysicianIDPrecision() {
			return 0;
		}

		public String PhysicianIDDefault() {

			return null;

		}

		public String PhysicianIDComment() {

			return "";

		}

		public String PhysicianIDPattern() {

			return "";

		}

		public String PhysicianIDOriginalDbColumnName() {

			return "PhysicianID";

		}

		public Integer AmountToBePaid;

		public Integer getAmountToBePaid() {
			return this.AmountToBePaid;
		}

		public Boolean AmountToBePaidIsNullable() {
			return true;
		}

		public Boolean AmountToBePaidIsKey() {
			return false;
		}

		public Integer AmountToBePaidLength() {
			return 10;
		}

		public Integer AmountToBePaidPrecision() {
			return 0;
		}

		public String AmountToBePaidDefault() {

			return null;

		}

		public String AmountToBePaidComment() {

			return "";

		}

		public String AmountToBePaidPattern() {

			return "";

		}

		public String AmountToBePaidOriginalDbColumnName() {

			return "AmountToBePaid";

		}

		public java.util.Date PaymentDate;

		public java.util.Date getPaymentDate() {
			return this.PaymentDate;
		}

		public Boolean PaymentDateIsNullable() {
			return true;
		}

		public Boolean PaymentDateIsKey() {
			return false;
		}

		public Integer PaymentDateLength() {
			return 19;
		}

		public Integer PaymentDatePrecision() {
			return 0;
		}

		public String PaymentDateDefault() {

			return null;

		}

		public String PaymentDateComment() {

			return "";

		}

		public String PaymentDatePattern() {

			return "dd-MM-yyyy";

		}

		public String PaymentDateOriginalDbColumnName() {

			return "PaymentDate";

		}

		public String InsuranceID;

		public String getInsuranceID() {
			return this.InsuranceID;
		}

		public Boolean InsuranceIDIsNullable() {
			return true;
		}

		public Boolean InsuranceIDIsKey() {
			return false;
		}

		public Integer InsuranceIDLength() {
			return 25;
		}

		public Integer InsuranceIDPrecision() {
			return 0;
		}

		public String InsuranceIDDefault() {

			return null;

		}

		public String InsuranceIDComment() {

			return "";

		}

		public String InsuranceIDPattern() {

			return "";

		}

		public String InsuranceIDOriginalDbColumnName() {

			return "InsuranceID";

		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_HMS_FunctionalRequirement.length) {
					if (length < 1024 && commonByteArray_HMS_FunctionalRequirement.length == 0) {
						commonByteArray_HMS_FunctionalRequirement = new byte[1024];
					} else {
						commonByteArray_HMS_FunctionalRequirement = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_HMS_FunctionalRequirement, 0, length);
				strReturn = new String(commonByteArray_HMS_FunctionalRequirement, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_HMS_FunctionalRequirement.length) {
					if (length < 1024 && commonByteArray_HMS_FunctionalRequirement.length == 0) {
						commonByteArray_HMS_FunctionalRequirement = new byte[1024];
					} else {
						commonByteArray_HMS_FunctionalRequirement = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_HMS_FunctionalRequirement, 0, length);
				strReturn = new String(commonByteArray_HMS_FunctionalRequirement, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_HMS_FunctionalRequirement) {

				try {

					int length = 0;

					this.PaymentID = readString(dis);

					this.PatientID = readInteger(dis);

					this.PhysicianID = readInteger(dis);

					this.AmountToBePaid = readInteger(dis);

					this.PaymentDate = readDate(dis);

					this.InsuranceID = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_HMS_FunctionalRequirement) {

				try {

					int length = 0;

					this.PaymentID = readString(dis);

					this.PatientID = readInteger(dis);

					this.PhysicianID = readInteger(dis);

					this.AmountToBePaid = readInteger(dis);

					this.PaymentDate = readDate(dis);

					this.InsuranceID = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.PaymentID, dos);

				// Integer

				writeInteger(this.PatientID, dos);

				// Integer

				writeInteger(this.PhysicianID, dos);

				// Integer

				writeInteger(this.AmountToBePaid, dos);

				// java.util.Date

				writeDate(this.PaymentDate, dos);

				// String

				writeString(this.InsuranceID, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.PaymentID, dos);

				// Integer

				writeInteger(this.PatientID, dos);

				// Integer

				writeInteger(this.PhysicianID, dos);

				// Integer

				writeInteger(this.AmountToBePaid, dos);

				// java.util.Date

				writeDate(this.PaymentDate, dos);

				// String

				writeString(this.InsuranceID, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("PaymentID=" + PaymentID);
			sb.append(",PatientID=" + String.valueOf(PatientID));
			sb.append(",PhysicianID=" + String.valueOf(PhysicianID));
			sb.append(",AmountToBePaid=" + String.valueOf(AmountToBePaid));
			sb.append(",PaymentDate=" + String.valueOf(PaymentDate));
			sb.append(",InsuranceID=" + InsuranceID);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (PaymentID == null) {
				sb.append("<null>");
			} else {
				sb.append(PaymentID);
			}

			sb.append("|");

			if (PatientID == null) {
				sb.append("<null>");
			} else {
				sb.append(PatientID);
			}

			sb.append("|");

			if (PhysicianID == null) {
				sb.append("<null>");
			} else {
				sb.append(PhysicianID);
			}

			sb.append("|");

			if (AmountToBePaid == null) {
				sb.append("<null>");
			} else {
				sb.append(AmountToBePaid);
			}

			sb.append("|");

			if (PaymentDate == null) {
				sb.append("<null>");
			} else {
				sb.append(PaymentDate);
			}

			sb.append("|");

			if (InsuranceID == null) {
				sb.append("<null>");
			} else {
				sb.append(InsuranceID);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(ThisMonthPaymentStruct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class ActualAmountToBePaidStruct
			implements routines.system.IPersistableRow<ActualAmountToBePaidStruct> {
		final static byte[] commonByteArrayLock_HMS_FunctionalRequirement = new byte[0];
		static byte[] commonByteArray_HMS_FunctionalRequirement = new byte[0];

		public Integer PatientID;

		public Integer getPatientID() {
			return this.PatientID;
		}

		public Boolean PatientIDIsNullable() {
			return true;
		}

		public Boolean PatientIDIsKey() {
			return false;
		}

		public Integer PatientIDLength() {
			return 10;
		}

		public Integer PatientIDPrecision() {
			return 0;
		}

		public String PatientIDDefault() {

			return null;

		}

		public String PatientIDComment() {

			return "";

		}

		public String PatientIDPattern() {

			return "";

		}

		public String PatientIDOriginalDbColumnName() {

			return "PatientID";

		}

		public Integer ActualAmountToBePaid;

		public Integer getActualAmountToBePaid() {
			return this.ActualAmountToBePaid;
		}

		public Boolean ActualAmountToBePaidIsNullable() {
			return true;
		}

		public Boolean ActualAmountToBePaidIsKey() {
			return false;
		}

		public Integer ActualAmountToBePaidLength() {
			return null;
		}

		public Integer ActualAmountToBePaidPrecision() {
			return null;
		}

		public String ActualAmountToBePaidDefault() {

			return null;

		}

		public String ActualAmountToBePaidComment() {

			return "";

		}

		public String ActualAmountToBePaidPattern() {

			return "";

		}

		public String ActualAmountToBePaidOriginalDbColumnName() {

			return "ActualAmountToBePaid";

		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_HMS_FunctionalRequirement) {

				try {

					int length = 0;

					this.PatientID = readInteger(dis);

					this.ActualAmountToBePaid = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_HMS_FunctionalRequirement) {

				try {

					int length = 0;

					this.PatientID = readInteger(dis);

					this.ActualAmountToBePaid = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.PatientID, dos);

				// Integer

				writeInteger(this.ActualAmountToBePaid, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.PatientID, dos);

				// Integer

				writeInteger(this.ActualAmountToBePaid, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("PatientID=" + String.valueOf(PatientID));
			sb.append(",ActualAmountToBePaid=" + String.valueOf(ActualAmountToBePaid));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (PatientID == null) {
				sb.append("<null>");
			} else {
				sb.append(PatientID);
			}

			sb.append("|");

			if (ActualAmountToBePaid == null) {
				sb.append("<null>");
			} else {
				sb.append(ActualAmountToBePaid);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(ActualAmountToBePaidStruct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row8Struct implements routines.system.IPersistableRow<row8Struct> {
		final static byte[] commonByteArrayLock_HMS_FunctionalRequirement = new byte[0];
		static byte[] commonByteArray_HMS_FunctionalRequirement = new byte[0];

		public String PaymentID;

		public String getPaymentID() {
			return this.PaymentID;
		}

		public Boolean PaymentIDIsNullable() {
			return true;
		}

		public Boolean PaymentIDIsKey() {
			return false;
		}

		public Integer PaymentIDLength() {
			return 25;
		}

		public Integer PaymentIDPrecision() {
			return 0;
		}

		public String PaymentIDDefault() {

			return null;

		}

		public String PaymentIDComment() {

			return "";

		}

		public String PaymentIDPattern() {

			return "";

		}

		public String PaymentIDOriginalDbColumnName() {

			return "PaymentID";

		}

		public Integer PatientID;

		public Integer getPatientID() {
			return this.PatientID;
		}

		public Boolean PatientIDIsNullable() {
			return true;
		}

		public Boolean PatientIDIsKey() {
			return false;
		}

		public Integer PatientIDLength() {
			return 10;
		}

		public Integer PatientIDPrecision() {
			return 0;
		}

		public String PatientIDDefault() {

			return null;

		}

		public String PatientIDComment() {

			return "";

		}

		public String PatientIDPattern() {

			return "";

		}

		public String PatientIDOriginalDbColumnName() {

			return "PatientID";

		}

		public Integer PhysicianID;

		public Integer getPhysicianID() {
			return this.PhysicianID;
		}

		public Boolean PhysicianIDIsNullable() {
			return true;
		}

		public Boolean PhysicianIDIsKey() {
			return false;
		}

		public Integer PhysicianIDLength() {
			return 10;
		}

		public Integer PhysicianIDPrecision() {
			return 0;
		}

		public String PhysicianIDDefault() {

			return null;

		}

		public String PhysicianIDComment() {

			return "";

		}

		public String PhysicianIDPattern() {

			return "";

		}

		public String PhysicianIDOriginalDbColumnName() {

			return "PhysicianID";

		}

		public Integer AmountToBePaid;

		public Integer getAmountToBePaid() {
			return this.AmountToBePaid;
		}

		public Boolean AmountToBePaidIsNullable() {
			return true;
		}

		public Boolean AmountToBePaidIsKey() {
			return false;
		}

		public Integer AmountToBePaidLength() {
			return 10;
		}

		public Integer AmountToBePaidPrecision() {
			return 0;
		}

		public String AmountToBePaidDefault() {

			return null;

		}

		public String AmountToBePaidComment() {

			return "";

		}

		public String AmountToBePaidPattern() {

			return "";

		}

		public String AmountToBePaidOriginalDbColumnName() {

			return "AmountToBePaid";

		}

		public java.util.Date PaymentDate;

		public java.util.Date getPaymentDate() {
			return this.PaymentDate;
		}

		public Boolean PaymentDateIsNullable() {
			return true;
		}

		public Boolean PaymentDateIsKey() {
			return false;
		}

		public Integer PaymentDateLength() {
			return 19;
		}

		public Integer PaymentDatePrecision() {
			return 0;
		}

		public String PaymentDateDefault() {

			return null;

		}

		public String PaymentDateComment() {

			return "";

		}

		public String PaymentDatePattern() {

			return "dd-MM-yyyy";

		}

		public String PaymentDateOriginalDbColumnName() {

			return "PaymentDate";

		}

		public String InsuranceID;

		public String getInsuranceID() {
			return this.InsuranceID;
		}

		public Boolean InsuranceIDIsNullable() {
			return true;
		}

		public Boolean InsuranceIDIsKey() {
			return false;
		}

		public Integer InsuranceIDLength() {
			return 25;
		}

		public Integer InsuranceIDPrecision() {
			return 0;
		}

		public String InsuranceIDDefault() {

			return null;

		}

		public String InsuranceIDComment() {

			return "";

		}

		public String InsuranceIDPattern() {

			return "";

		}

		public String InsuranceIDOriginalDbColumnName() {

			return "InsuranceID";

		}

		public Integer MaxCoverageAmount;

		public Integer getMaxCoverageAmount() {
			return this.MaxCoverageAmount;
		}

		public Boolean MaxCoverageAmountIsNullable() {
			return true;
		}

		public Boolean MaxCoverageAmountIsKey() {
			return false;
		}

		public Integer MaxCoverageAmountLength() {
			return 10;
		}

		public Integer MaxCoverageAmountPrecision() {
			return 0;
		}

		public String MaxCoverageAmountDefault() {

			return null;

		}

		public String MaxCoverageAmountComment() {

			return "";

		}

		public String MaxCoverageAmountPattern() {

			return "";

		}

		public String MaxCoverageAmountOriginalDbColumnName() {

			return "MaxCoverageAmount";

		}

		public int Billing_SK;

		public int getBilling_SK() {
			return this.Billing_SK;
		}

		public Boolean Billing_SKIsNullable() {
			return false;
		}

		public Boolean Billing_SKIsKey() {
			return true;
		}

		public Integer Billing_SKLength() {
			return 10;
		}

		public Integer Billing_SKPrecision() {
			return 0;
		}

		public String Billing_SKDefault() {

			return null;

		}

		public String Billing_SKComment() {

			return "";

		}

		public String Billing_SKPattern() {

			return "";

		}

		public String Billing_SKOriginalDbColumnName() {

			return "Billing_SK";

		}

		public java.util.Date Start_date;

		public java.util.Date getStart_date() {
			return this.Start_date;
		}

		public Boolean Start_dateIsNullable() {
			return false;
		}

		public Boolean Start_dateIsKey() {
			return false;
		}

		public Integer Start_dateLength() {
			return 19;
		}

		public Integer Start_datePrecision() {
			return 0;
		}

		public String Start_dateDefault() {

			return null;

		}

		public String Start_dateComment() {

			return "";

		}

		public String Start_datePattern() {

			return "dd-MM-yyyy";

		}

		public String Start_dateOriginalDbColumnName() {

			return "Start_date";

		}

		public java.util.Date End_date;

		public java.util.Date getEnd_date() {
			return this.End_date;
		}

		public Boolean End_dateIsNullable() {
			return true;
		}

		public Boolean End_dateIsKey() {
			return false;
		}

		public Integer End_dateLength() {
			return 19;
		}

		public Integer End_datePrecision() {
			return 0;
		}

		public String End_dateDefault() {

			return null;

		}

		public String End_dateComment() {

			return "";

		}

		public String End_datePattern() {

			return "dd-MM-yyyy";

		}

		public String End_dateOriginalDbColumnName() {

			return "End_date";

		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_HMS_FunctionalRequirement.length) {
					if (length < 1024 && commonByteArray_HMS_FunctionalRequirement.length == 0) {
						commonByteArray_HMS_FunctionalRequirement = new byte[1024];
					} else {
						commonByteArray_HMS_FunctionalRequirement = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_HMS_FunctionalRequirement, 0, length);
				strReturn = new String(commonByteArray_HMS_FunctionalRequirement, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_HMS_FunctionalRequirement.length) {
					if (length < 1024 && commonByteArray_HMS_FunctionalRequirement.length == 0) {
						commonByteArray_HMS_FunctionalRequirement = new byte[1024];
					} else {
						commonByteArray_HMS_FunctionalRequirement = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_HMS_FunctionalRequirement, 0, length);
				strReturn = new String(commonByteArray_HMS_FunctionalRequirement, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_HMS_FunctionalRequirement) {

				try {

					int length = 0;

					this.PaymentID = readString(dis);

					this.PatientID = readInteger(dis);

					this.PhysicianID = readInteger(dis);

					this.AmountToBePaid = readInteger(dis);

					this.PaymentDate = readDate(dis);

					this.InsuranceID = readString(dis);

					this.MaxCoverageAmount = readInteger(dis);

					this.Billing_SK = dis.readInt();

					this.Start_date = readDate(dis);

					this.End_date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_HMS_FunctionalRequirement) {

				try {

					int length = 0;

					this.PaymentID = readString(dis);

					this.PatientID = readInteger(dis);

					this.PhysicianID = readInteger(dis);

					this.AmountToBePaid = readInteger(dis);

					this.PaymentDate = readDate(dis);

					this.InsuranceID = readString(dis);

					this.MaxCoverageAmount = readInteger(dis);

					this.Billing_SK = dis.readInt();

					this.Start_date = readDate(dis);

					this.End_date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.PaymentID, dos);

				// Integer

				writeInteger(this.PatientID, dos);

				// Integer

				writeInteger(this.PhysicianID, dos);

				// Integer

				writeInteger(this.AmountToBePaid, dos);

				// java.util.Date

				writeDate(this.PaymentDate, dos);

				// String

				writeString(this.InsuranceID, dos);

				// Integer

				writeInteger(this.MaxCoverageAmount, dos);

				// int

				dos.writeInt(this.Billing_SK);

				// java.util.Date

				writeDate(this.Start_date, dos);

				// java.util.Date

				writeDate(this.End_date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.PaymentID, dos);

				// Integer

				writeInteger(this.PatientID, dos);

				// Integer

				writeInteger(this.PhysicianID, dos);

				// Integer

				writeInteger(this.AmountToBePaid, dos);

				// java.util.Date

				writeDate(this.PaymentDate, dos);

				// String

				writeString(this.InsuranceID, dos);

				// Integer

				writeInteger(this.MaxCoverageAmount, dos);

				// int

				dos.writeInt(this.Billing_SK);

				// java.util.Date

				writeDate(this.Start_date, dos);

				// java.util.Date

				writeDate(this.End_date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("PaymentID=" + PaymentID);
			sb.append(",PatientID=" + String.valueOf(PatientID));
			sb.append(",PhysicianID=" + String.valueOf(PhysicianID));
			sb.append(",AmountToBePaid=" + String.valueOf(AmountToBePaid));
			sb.append(",PaymentDate=" + String.valueOf(PaymentDate));
			sb.append(",InsuranceID=" + InsuranceID);
			sb.append(",MaxCoverageAmount=" + String.valueOf(MaxCoverageAmount));
			sb.append(",Billing_SK=" + String.valueOf(Billing_SK));
			sb.append(",Start_date=" + String.valueOf(Start_date));
			sb.append(",End_date=" + String.valueOf(End_date));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (PaymentID == null) {
				sb.append("<null>");
			} else {
				sb.append(PaymentID);
			}

			sb.append("|");

			if (PatientID == null) {
				sb.append("<null>");
			} else {
				sb.append(PatientID);
			}

			sb.append("|");

			if (PhysicianID == null) {
				sb.append("<null>");
			} else {
				sb.append(PhysicianID);
			}

			sb.append("|");

			if (AmountToBePaid == null) {
				sb.append("<null>");
			} else {
				sb.append(AmountToBePaid);
			}

			sb.append("|");

			if (PaymentDate == null) {
				sb.append("<null>");
			} else {
				sb.append(PaymentDate);
			}

			sb.append("|");

			if (InsuranceID == null) {
				sb.append("<null>");
			} else {
				sb.append(InsuranceID);
			}

			sb.append("|");

			if (MaxCoverageAmount == null) {
				sb.append("<null>");
			} else {
				sb.append(MaxCoverageAmount);
			}

			sb.append("|");

			sb.append(Billing_SK);

			sb.append("|");

			if (Start_date == null) {
				sb.append("<null>");
			} else {
				sb.append(Start_date);
			}

			sb.append("|");

			if (End_date == null) {
				sb.append("<null>");
			} else {
				sb.append(End_date);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row8Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class after_tDBInput_5Struct implements routines.system.IPersistableRow<after_tDBInput_5Struct> {
		final static byte[] commonByteArrayLock_HMS_FunctionalRequirement = new byte[0];
		static byte[] commonByteArray_HMS_FunctionalRequirement = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public String PaymentID;

		public String getPaymentID() {
			return this.PaymentID;
		}

		public Boolean PaymentIDIsNullable() {
			return true;
		}

		public Boolean PaymentIDIsKey() {
			return false;
		}

		public Integer PaymentIDLength() {
			return 25;
		}

		public Integer PaymentIDPrecision() {
			return 0;
		}

		public String PaymentIDDefault() {

			return null;

		}

		public String PaymentIDComment() {

			return "";

		}

		public String PaymentIDPattern() {

			return "";

		}

		public String PaymentIDOriginalDbColumnName() {

			return "PaymentID";

		}

		public Integer PatientID;

		public Integer getPatientID() {
			return this.PatientID;
		}

		public Boolean PatientIDIsNullable() {
			return true;
		}

		public Boolean PatientIDIsKey() {
			return false;
		}

		public Integer PatientIDLength() {
			return 10;
		}

		public Integer PatientIDPrecision() {
			return 0;
		}

		public String PatientIDDefault() {

			return null;

		}

		public String PatientIDComment() {

			return "";

		}

		public String PatientIDPattern() {

			return "";

		}

		public String PatientIDOriginalDbColumnName() {

			return "PatientID";

		}

		public Integer PhysicianID;

		public Integer getPhysicianID() {
			return this.PhysicianID;
		}

		public Boolean PhysicianIDIsNullable() {
			return true;
		}

		public Boolean PhysicianIDIsKey() {
			return false;
		}

		public Integer PhysicianIDLength() {
			return 10;
		}

		public Integer PhysicianIDPrecision() {
			return 0;
		}

		public String PhysicianIDDefault() {

			return null;

		}

		public String PhysicianIDComment() {

			return "";

		}

		public String PhysicianIDPattern() {

			return "";

		}

		public String PhysicianIDOriginalDbColumnName() {

			return "PhysicianID";

		}

		public Integer AmountToBePaid;

		public Integer getAmountToBePaid() {
			return this.AmountToBePaid;
		}

		public Boolean AmountToBePaidIsNullable() {
			return true;
		}

		public Boolean AmountToBePaidIsKey() {
			return false;
		}

		public Integer AmountToBePaidLength() {
			return 10;
		}

		public Integer AmountToBePaidPrecision() {
			return 0;
		}

		public String AmountToBePaidDefault() {

			return null;

		}

		public String AmountToBePaidComment() {

			return "";

		}

		public String AmountToBePaidPattern() {

			return "";

		}

		public String AmountToBePaidOriginalDbColumnName() {

			return "AmountToBePaid";

		}

		public java.util.Date PaymentDate;

		public java.util.Date getPaymentDate() {
			return this.PaymentDate;
		}

		public Boolean PaymentDateIsNullable() {
			return true;
		}

		public Boolean PaymentDateIsKey() {
			return false;
		}

		public Integer PaymentDateLength() {
			return 19;
		}

		public Integer PaymentDatePrecision() {
			return 0;
		}

		public String PaymentDateDefault() {

			return null;

		}

		public String PaymentDateComment() {

			return "";

		}

		public String PaymentDatePattern() {

			return "dd-MM-yyyy";

		}

		public String PaymentDateOriginalDbColumnName() {

			return "PaymentDate";

		}

		public String InsuranceID;

		public String getInsuranceID() {
			return this.InsuranceID;
		}

		public Boolean InsuranceIDIsNullable() {
			return true;
		}

		public Boolean InsuranceIDIsKey() {
			return false;
		}

		public Integer InsuranceIDLength() {
			return 25;
		}

		public Integer InsuranceIDPrecision() {
			return 0;
		}

		public String InsuranceIDDefault() {

			return null;

		}

		public String InsuranceIDComment() {

			return "";

		}

		public String InsuranceIDPattern() {

			return "";

		}

		public String InsuranceIDOriginalDbColumnName() {

			return "InsuranceID";

		}

		public Integer MaxCoverageAmount;

		public Integer getMaxCoverageAmount() {
			return this.MaxCoverageAmount;
		}

		public Boolean MaxCoverageAmountIsNullable() {
			return true;
		}

		public Boolean MaxCoverageAmountIsKey() {
			return false;
		}

		public Integer MaxCoverageAmountLength() {
			return 10;
		}

		public Integer MaxCoverageAmountPrecision() {
			return 0;
		}

		public String MaxCoverageAmountDefault() {

			return null;

		}

		public String MaxCoverageAmountComment() {

			return "";

		}

		public String MaxCoverageAmountPattern() {

			return "";

		}

		public String MaxCoverageAmountOriginalDbColumnName() {

			return "MaxCoverageAmount";

		}

		public int Billing_SK;

		public int getBilling_SK() {
			return this.Billing_SK;
		}

		public Boolean Billing_SKIsNullable() {
			return false;
		}

		public Boolean Billing_SKIsKey() {
			return true;
		}

		public Integer Billing_SKLength() {
			return 10;
		}

		public Integer Billing_SKPrecision() {
			return 0;
		}

		public String Billing_SKDefault() {

			return null;

		}

		public String Billing_SKComment() {

			return "";

		}

		public String Billing_SKPattern() {

			return "";

		}

		public String Billing_SKOriginalDbColumnName() {

			return "Billing_SK";

		}

		public java.util.Date Start_date;

		public java.util.Date getStart_date() {
			return this.Start_date;
		}

		public Boolean Start_dateIsNullable() {
			return false;
		}

		public Boolean Start_dateIsKey() {
			return false;
		}

		public Integer Start_dateLength() {
			return 19;
		}

		public Integer Start_datePrecision() {
			return 0;
		}

		public String Start_dateDefault() {

			return null;

		}

		public String Start_dateComment() {

			return "";

		}

		public String Start_datePattern() {

			return "dd-MM-yyyy";

		}

		public String Start_dateOriginalDbColumnName() {

			return "Start_date";

		}

		public java.util.Date End_date;

		public java.util.Date getEnd_date() {
			return this.End_date;
		}

		public Boolean End_dateIsNullable() {
			return true;
		}

		public Boolean End_dateIsKey() {
			return false;
		}

		public Integer End_dateLength() {
			return 19;
		}

		public Integer End_datePrecision() {
			return 0;
		}

		public String End_dateDefault() {

			return null;

		}

		public String End_dateComment() {

			return "";

		}

		public String End_datePattern() {

			return "dd-MM-yyyy";

		}

		public String End_dateOriginalDbColumnName() {

			return "End_date";

		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + (int) this.Billing_SK;

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final after_tDBInput_5Struct other = (after_tDBInput_5Struct) obj;

			if (this.Billing_SK != other.Billing_SK)
				return false;

			return true;
		}

		public void copyDataTo(after_tDBInput_5Struct other) {

			other.PaymentID = this.PaymentID;
			other.PatientID = this.PatientID;
			other.PhysicianID = this.PhysicianID;
			other.AmountToBePaid = this.AmountToBePaid;
			other.PaymentDate = this.PaymentDate;
			other.InsuranceID = this.InsuranceID;
			other.MaxCoverageAmount = this.MaxCoverageAmount;
			other.Billing_SK = this.Billing_SK;
			other.Start_date = this.Start_date;
			other.End_date = this.End_date;

		}

		public void copyKeysDataTo(after_tDBInput_5Struct other) {

			other.Billing_SK = this.Billing_SK;

		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_HMS_FunctionalRequirement.length) {
					if (length < 1024 && commonByteArray_HMS_FunctionalRequirement.length == 0) {
						commonByteArray_HMS_FunctionalRequirement = new byte[1024];
					} else {
						commonByteArray_HMS_FunctionalRequirement = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_HMS_FunctionalRequirement, 0, length);
				strReturn = new String(commonByteArray_HMS_FunctionalRequirement, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_HMS_FunctionalRequirement.length) {
					if (length < 1024 && commonByteArray_HMS_FunctionalRequirement.length == 0) {
						commonByteArray_HMS_FunctionalRequirement = new byte[1024];
					} else {
						commonByteArray_HMS_FunctionalRequirement = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_HMS_FunctionalRequirement, 0, length);
				strReturn = new String(commonByteArray_HMS_FunctionalRequirement, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_HMS_FunctionalRequirement) {

				try {

					int length = 0;

					this.PaymentID = readString(dis);

					this.PatientID = readInteger(dis);

					this.PhysicianID = readInteger(dis);

					this.AmountToBePaid = readInteger(dis);

					this.PaymentDate = readDate(dis);

					this.InsuranceID = readString(dis);

					this.MaxCoverageAmount = readInteger(dis);

					this.Billing_SK = dis.readInt();

					this.Start_date = readDate(dis);

					this.End_date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_HMS_FunctionalRequirement) {

				try {

					int length = 0;

					this.PaymentID = readString(dis);

					this.PatientID = readInteger(dis);

					this.PhysicianID = readInteger(dis);

					this.AmountToBePaid = readInteger(dis);

					this.PaymentDate = readDate(dis);

					this.InsuranceID = readString(dis);

					this.MaxCoverageAmount = readInteger(dis);

					this.Billing_SK = dis.readInt();

					this.Start_date = readDate(dis);

					this.End_date = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.PaymentID, dos);

				// Integer

				writeInteger(this.PatientID, dos);

				// Integer

				writeInteger(this.PhysicianID, dos);

				// Integer

				writeInteger(this.AmountToBePaid, dos);

				// java.util.Date

				writeDate(this.PaymentDate, dos);

				// String

				writeString(this.InsuranceID, dos);

				// Integer

				writeInteger(this.MaxCoverageAmount, dos);

				// int

				dos.writeInt(this.Billing_SK);

				// java.util.Date

				writeDate(this.Start_date, dos);

				// java.util.Date

				writeDate(this.End_date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.PaymentID, dos);

				// Integer

				writeInteger(this.PatientID, dos);

				// Integer

				writeInteger(this.PhysicianID, dos);

				// Integer

				writeInteger(this.AmountToBePaid, dos);

				// java.util.Date

				writeDate(this.PaymentDate, dos);

				// String

				writeString(this.InsuranceID, dos);

				// Integer

				writeInteger(this.MaxCoverageAmount, dos);

				// int

				dos.writeInt(this.Billing_SK);

				// java.util.Date

				writeDate(this.Start_date, dos);

				// java.util.Date

				writeDate(this.End_date, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("PaymentID=" + PaymentID);
			sb.append(",PatientID=" + String.valueOf(PatientID));
			sb.append(",PhysicianID=" + String.valueOf(PhysicianID));
			sb.append(",AmountToBePaid=" + String.valueOf(AmountToBePaid));
			sb.append(",PaymentDate=" + String.valueOf(PaymentDate));
			sb.append(",InsuranceID=" + InsuranceID);
			sb.append(",MaxCoverageAmount=" + String.valueOf(MaxCoverageAmount));
			sb.append(",Billing_SK=" + String.valueOf(Billing_SK));
			sb.append(",Start_date=" + String.valueOf(Start_date));
			sb.append(",End_date=" + String.valueOf(End_date));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (PaymentID == null) {
				sb.append("<null>");
			} else {
				sb.append(PaymentID);
			}

			sb.append("|");

			if (PatientID == null) {
				sb.append("<null>");
			} else {
				sb.append(PatientID);
			}

			sb.append("|");

			if (PhysicianID == null) {
				sb.append("<null>");
			} else {
				sb.append(PhysicianID);
			}

			sb.append("|");

			if (AmountToBePaid == null) {
				sb.append("<null>");
			} else {
				sb.append(AmountToBePaid);
			}

			sb.append("|");

			if (PaymentDate == null) {
				sb.append("<null>");
			} else {
				sb.append(PaymentDate);
			}

			sb.append("|");

			if (InsuranceID == null) {
				sb.append("<null>");
			} else {
				sb.append(InsuranceID);
			}

			sb.append("|");

			if (MaxCoverageAmount == null) {
				sb.append("<null>");
			} else {
				sb.append(MaxCoverageAmount);
			}

			sb.append("|");

			sb.append(Billing_SK);

			sb.append("|");

			if (Start_date == null) {
				sb.append("<null>");
			} else {
				sb.append(Start_date);
			}

			sb.append("|");

			if (End_date == null) {
				sb.append("<null>");
			} else {
				sb.append(End_date);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(after_tDBInput_5Struct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.Billing_SK, other.Billing_SK);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tDBInput_5Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tDBInput_5_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tDBInput_5");
		org.slf4j.MDC.put("_subJobPid", "KRngCx_" + subJobPidCounter.getAndIncrement());

		String currentVirtualComponent = null;

		String iterateId = "";

		String currentComponent = "";
		String cLabel = null;
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				tDBInput_6Process(globalMap);

				row8Struct row8 = new row8Struct();
				NotCoveredByInsuranceStruct NotCoveredByInsurance = new NotCoveredByInsuranceStruct();
				MaxToBePaidPhysicianStruct MaxToBePaidPhysician = new MaxToBePaidPhysicianStruct();
				row9Struct row9 = new row9Struct();
				row10Struct row10 = new row10Struct();
				row11Struct row11 = new row11Struct();
				row13Struct row13 = new row13Struct();
				ThisMonthPaymentStruct ThisMonthPayment = new ThisMonthPaymentStruct();
				ActualAmountToBePaidStruct ActualAmountToBePaid = new ActualAmountToBePaidStruct();

				/**
				 * [tFileOutputExcel_11 begin ] start
				 */

				ok_Hash.put("tFileOutputExcel_11", false);
				start_Hash.put("tFileOutputExcel_11", System.currentTimeMillis());

				currentComponent = "tFileOutputExcel_11";

				cLabel = "NotCoveredByInsurance";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0,
						"NotCoveredByInsurance");

				int tos_count_tFileOutputExcel_11 = 0;

				if (log.isDebugEnabled())
					log.debug("tFileOutputExcel_11 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tFileOutputExcel_11 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tFileOutputExcel_11 = new StringBuilder();
							log4jParamters_tFileOutputExcel_11.append("Parameters:");
							log4jParamters_tFileOutputExcel_11.append("VERSION_2007" + " = " + "false");
							log4jParamters_tFileOutputExcel_11.append(" | ");
							log4jParamters_tFileOutputExcel_11.append("USESTREAM" + " = " + "false");
							log4jParamters_tFileOutputExcel_11.append(" | ");
							log4jParamters_tFileOutputExcel_11.append(
									"FILENAME" + " = " + "\"C:/Users/2382187/Downloads/FR/NotCoveredByInsurance.xls\"");
							log4jParamters_tFileOutputExcel_11.append(" | ");
							log4jParamters_tFileOutputExcel_11.append("SHEETNAME" + " = " + "\"Sheet1\"");
							log4jParamters_tFileOutputExcel_11.append(" | ");
							log4jParamters_tFileOutputExcel_11.append("INCLUDEHEADER" + " = " + "true");
							log4jParamters_tFileOutputExcel_11.append(" | ");
							log4jParamters_tFileOutputExcel_11.append("APPEND_FILE" + " = " + "false");
							log4jParamters_tFileOutputExcel_11.append(" | ");
							log4jParamters_tFileOutputExcel_11.append("FIRST_CELL_Y_ABSOLUTE" + " = " + "false");
							log4jParamters_tFileOutputExcel_11.append(" | ");
							log4jParamters_tFileOutputExcel_11.append("FONT" + " = " + "");
							log4jParamters_tFileOutputExcel_11.append(" | ");
							log4jParamters_tFileOutputExcel_11.append("IS_ALL_AUTO_SZIE" + " = " + "true");
							log4jParamters_tFileOutputExcel_11.append(" | ");
							log4jParamters_tFileOutputExcel_11.append("CREATE" + " = " + "true");
							log4jParamters_tFileOutputExcel_11.append(" | ");
							log4jParamters_tFileOutputExcel_11.append("ADVANCED_SEPARATOR" + " = " + "false");
							log4jParamters_tFileOutputExcel_11.append(" | ");
							log4jParamters_tFileOutputExcel_11.append("ENCODING" + " = " + "\"ISO-8859-15\"");
							log4jParamters_tFileOutputExcel_11.append(" | ");
							log4jParamters_tFileOutputExcel_11.append("DELETE_EMPTYFILE" + " = " + "false");
							log4jParamters_tFileOutputExcel_11.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tFileOutputExcel_11 - " + (log4jParamters_tFileOutputExcel_11));
						}
					}
					new BytesLimit65535_tFileOutputExcel_11().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tFileOutputExcel_11", "NotCoveredByInsurance", "tFileOutputExcel");
					talendJobLogProcess(globalMap);
				}

				int columnIndex_tFileOutputExcel_11 = 0;
				boolean headerIsInserted_tFileOutputExcel_11 = false;

				int nb_line_tFileOutputExcel_11 = 0;

				String fileName_tFileOutputExcel_11 = "C:/Users/2382187/Downloads/FR/NotCoveredByInsurance.xls";
				java.io.File file_tFileOutputExcel_11 = new java.io.File(fileName_tFileOutputExcel_11);
				boolean isFileGenerated_tFileOutputExcel_11 = true;
//create directory only if not exists
				java.io.File parentFile_tFileOutputExcel_11 = file_tFileOutputExcel_11.getParentFile();
				if (parentFile_tFileOutputExcel_11 != null && !parentFile_tFileOutputExcel_11.exists()) {

					log.info("tFileOutputExcel_11 - Creating directory '"
							+ parentFile_tFileOutputExcel_11.getCanonicalPath() + "'.");

					parentFile_tFileOutputExcel_11.mkdirs();

					log.info("tFileOutputExcel_11 - Create directory '"
							+ parentFile_tFileOutputExcel_11.getCanonicalPath() + "' has succeeded.");

				}

				jxl.write.WritableWorkbook writeableWorkbook_tFileOutputExcel_11 = null;
				jxl.write.WritableSheet writableSheet_tFileOutputExcel_11 = null;

				jxl.WorkbookSettings workbookSettings_tFileOutputExcel_11 = new jxl.WorkbookSettings();
				workbookSettings_tFileOutputExcel_11.setEncoding("ISO-8859-15");
				writeableWorkbook_tFileOutputExcel_11 = new jxl.write.biff.WritableWorkbookImpl(
						new java.io.BufferedOutputStream(new java.io.FileOutputStream(fileName_tFileOutputExcel_11)),
						true, workbookSettings_tFileOutputExcel_11);

				writableSheet_tFileOutputExcel_11 = writeableWorkbook_tFileOutputExcel_11.getSheet("Sheet1");
				if (writableSheet_tFileOutputExcel_11 == null) {
					writableSheet_tFileOutputExcel_11 = writeableWorkbook_tFileOutputExcel_11.createSheet("Sheet1",
							writeableWorkbook_tFileOutputExcel_11.getNumberOfSheets());
				}

				// modif start
				int startRowNum_tFileOutputExcel_11 = writableSheet_tFileOutputExcel_11.getRows();
				// modif end

				int[] fitWidth_tFileOutputExcel_11 = new int[6];
				for (int i_tFileOutputExcel_11 = 0; i_tFileOutputExcel_11 < 6; i_tFileOutputExcel_11++) {
					int fitCellViewSize_tFileOutputExcel_11 = writableSheet_tFileOutputExcel_11
							.getColumnView(i_tFileOutputExcel_11).getSize();
					fitWidth_tFileOutputExcel_11[i_tFileOutputExcel_11] = fitCellViewSize_tFileOutputExcel_11 / 256;
					if (fitCellViewSize_tFileOutputExcel_11 % 256 != 0) {
						fitWidth_tFileOutputExcel_11[i_tFileOutputExcel_11] += 1;
					}
				}

				final jxl.write.WritableCellFormat cell_format_PaymentDate_tFileOutputExcel_11 = new jxl.write.WritableCellFormat(
						new jxl.write.DateFormat("dd-MM-yyyy"));

				if (startRowNum_tFileOutputExcel_11 == 0) {
					// modif end
					// modif start
					writableSheet_tFileOutputExcel_11
							.addCell(new jxl.write.Label(0, nb_line_tFileOutputExcel_11, "PaymentID"));
					// modif end
					fitWidth_tFileOutputExcel_11[0] = fitWidth_tFileOutputExcel_11[0] > 9
							? fitWidth_tFileOutputExcel_11[0]
							: 9;
					// modif start
					writableSheet_tFileOutputExcel_11
							.addCell(new jxl.write.Label(1, nb_line_tFileOutputExcel_11, "PatientID"));
					// modif end
					fitWidth_tFileOutputExcel_11[1] = fitWidth_tFileOutputExcel_11[1] > 9
							? fitWidth_tFileOutputExcel_11[1]
							: 9;
					// modif start
					writableSheet_tFileOutputExcel_11
							.addCell(new jxl.write.Label(2, nb_line_tFileOutputExcel_11, "PhysicianID"));
					// modif end
					fitWidth_tFileOutputExcel_11[2] = fitWidth_tFileOutputExcel_11[2] > 11
							? fitWidth_tFileOutputExcel_11[2]
							: 11;
					// modif start
					writableSheet_tFileOutputExcel_11
							.addCell(new jxl.write.Label(3, nb_line_tFileOutputExcel_11, "AmountToBePaid"));
					// modif end
					fitWidth_tFileOutputExcel_11[3] = fitWidth_tFileOutputExcel_11[3] > 14
							? fitWidth_tFileOutputExcel_11[3]
							: 14;
					// modif start
					writableSheet_tFileOutputExcel_11
							.addCell(new jxl.write.Label(4, nb_line_tFileOutputExcel_11, "PaymentDate"));
					// modif end
					fitWidth_tFileOutputExcel_11[4] = fitWidth_tFileOutputExcel_11[4] > 11
							? fitWidth_tFileOutputExcel_11[4]
							: 11;
					// modif start
					writableSheet_tFileOutputExcel_11
							.addCell(new jxl.write.Label(5, nb_line_tFileOutputExcel_11, "InsuranceID"));
					// modif end
					fitWidth_tFileOutputExcel_11[5] = fitWidth_tFileOutputExcel_11[5] > 11
							? fitWidth_tFileOutputExcel_11[5]
							: 11;
					nb_line_tFileOutputExcel_11++;
					headerIsInserted_tFileOutputExcel_11 = true;
				}

				/**
				 * [tFileOutputExcel_11 begin ] stop
				 */

				/**
				 * [tAggregateRow_2_AGGOUT begin ] start
				 */

				ok_Hash.put("tAggregateRow_2_AGGOUT", false);
				start_Hash.put("tAggregateRow_2_AGGOUT", System.currentTimeMillis());

				currentVirtualComponent = "tAggregateRow_2";

				currentComponent = "tAggregateRow_2_AGGOUT";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0,
						"MaxToBePaidPhysician");

				int tos_count_tAggregateRow_2_AGGOUT = 0;

				if (log.isDebugEnabled())
					log.debug("tAggregateRow_2_AGGOUT - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tAggregateRow_2_AGGOUT {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tAggregateRow_2_AGGOUT = new StringBuilder();
							log4jParamters_tAggregateRow_2_AGGOUT.append("Parameters:");
							log4jParamters_tAggregateRow_2_AGGOUT.append("DESTINATION" + " = " + "tAggregateRow_2");
							log4jParamters_tAggregateRow_2_AGGOUT.append(" | ");
							log4jParamters_tAggregateRow_2_AGGOUT.append("GROUPBYS" + " = " + "[{OUTPUT_COLUMN="
									+ ("PhysicianID") + ", INPUT_COLUMN=" + ("PhysicianID") + "}]");
							log4jParamters_tAggregateRow_2_AGGOUT.append(" | ");
							log4jParamters_tAggregateRow_2_AGGOUT.append("OPERATIONS" + " = " + "[{OUTPUT_COLUMN="
									+ ("TotalAmountPerPhysician") + ", INPUT_COLUMN=" + ("AmountToBePaid")
									+ ", IGNORE_NULL=" + ("false") + ", FUNCTION=" + ("sum") + "}]");
							log4jParamters_tAggregateRow_2_AGGOUT.append(" | ");
							log4jParamters_tAggregateRow_2_AGGOUT.append("LIST_DELIMITER" + " = " + "\",\"");
							log4jParamters_tAggregateRow_2_AGGOUT.append(" | ");
							log4jParamters_tAggregateRow_2_AGGOUT.append("USE_FINANCIAL_PRECISION" + " = " + "true");
							log4jParamters_tAggregateRow_2_AGGOUT.append(" | ");
							log4jParamters_tAggregateRow_2_AGGOUT.append("CHECK_TYPE_OVERFLOW" + " = " + "false");
							log4jParamters_tAggregateRow_2_AGGOUT.append(" | ");
							log4jParamters_tAggregateRow_2_AGGOUT.append("CHECK_ULP" + " = " + "false");
							log4jParamters_tAggregateRow_2_AGGOUT.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tAggregateRow_2_AGGOUT - " + (log4jParamters_tAggregateRow_2_AGGOUT));
						}
					}
					new BytesLimit65535_tAggregateRow_2_AGGOUT().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tAggregateRow_2_AGGOUT", "tAggregateRow_2_AGGOUT", "tAggregateOut");
					talendJobLogProcess(globalMap);
				}

// ------------ Seems it is not used

				java.util.Map hashAggreg_tAggregateRow_2 = new java.util.HashMap();

// ------------

				class UtilClass_tAggregateRow_2 { // G_OutBegin_AggR_144

					public double sd(Double[] data) {
						final int n = data.length;
						if (n < 2) {
							return Double.NaN;
						}
						double d1 = 0d;
						double d2 = 0d;

						for (int i = 0; i < data.length; i++) {
							d1 += (data[i] * data[i]);
							d2 += data[i];
						}

						return Math.sqrt((n * d1 - d2 * d2) / n / (n - 1));
					}

					public void checkedIADD(byte a, byte b, boolean checkTypeOverFlow, boolean checkUlp) {
						byte r = (byte) (a + b);
						if (checkTypeOverFlow && ((a ^ r) & (b ^ r)) < 0) {
							throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b),
									"'short/Short'", "'byte/Byte'"));
						}
					}

					public void checkedIADD(short a, short b, boolean checkTypeOverFlow, boolean checkUlp) {
						short r = (short) (a + b);
						if (checkTypeOverFlow && ((a ^ r) & (b ^ r)) < 0) {
							throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b),
									"'int/Integer'", "'short/Short'"));
						}
					}

					public void checkedIADD(int a, int b, boolean checkTypeOverFlow, boolean checkUlp) {
						int r = a + b;
						if (checkTypeOverFlow && ((a ^ r) & (b ^ r)) < 0) {
							throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b),
									"'long/Long'", "'int/Integer'"));
						}
					}

					public void checkedIADD(long a, long b, boolean checkTypeOverFlow, boolean checkUlp) {
						long r = a + b;
						if (checkTypeOverFlow && ((a ^ r) & (b ^ r)) < 0) {
							throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b),
									"'BigDecimal'", "'long/Long'"));
						}
					}

					public void checkedIADD(float a, float b, boolean checkTypeOverFlow, boolean checkUlp) {

						if (checkUlp) {
							float minAddedValue = Math.ulp(a);
							if (minAddedValue > Math.abs(b)) {
								throw new RuntimeException(buildPrecisionMessage(String.valueOf(a), String.valueOf(b),
										"'double' or 'BigDecimal'", "'float/Float'"));
							}
						}

						if (checkTypeOverFlow && ((double) a + (double) b > (double) Float.MAX_VALUE)
								|| ((double) a + (double) b < (double) -Float.MAX_VALUE)) {
							throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b),
									"'double' or 'BigDecimal'", "'float/Float'"));
						}
					}

					public void checkedIADD(double a, double b, boolean checkTypeOverFlow, boolean checkUlp) {

						if (checkUlp) {
							double minAddedValue = Math.ulp(a);
							if (minAddedValue > Math.abs(b)) {
								throw new RuntimeException(buildPrecisionMessage(String.valueOf(a), String.valueOf(a),
										"'BigDecimal'", "'double/Double'"));
							}
						}

						if (checkTypeOverFlow && (a + b > (double) Double.MAX_VALUE) || (a + b < -Double.MAX_VALUE)) {
							throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b),
									"'BigDecimal'", "'double/Double'"));
						}
					}

					public void checkedIADD(double a, byte b, boolean checkTypeOverFlow, boolean checkUlp) {

						if (checkTypeOverFlow && (a + b > (double) Double.MAX_VALUE) || (a + b < -Double.MAX_VALUE)) {
							throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b),
									"'BigDecimal'", "'double/Double'"));
						}
					}

					public void checkedIADD(double a, short b, boolean checkTypeOverFlow, boolean checkUlp) {

						if (checkTypeOverFlow && (a + b > (double) Double.MAX_VALUE) || (a + b < -Double.MAX_VALUE)) {
							throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b),
									"'BigDecimal'", "'double/Double'"));
						}
					}

					public void checkedIADD(double a, int b, boolean checkTypeOverFlow, boolean checkUlp) {

						if (checkTypeOverFlow && (a + b > (double) Double.MAX_VALUE) || (a + b < -Double.MAX_VALUE)) {
							throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b),
									"'BigDecimal'", "'double/Double'"));
						}
					}

					public void checkedIADD(double a, float b, boolean checkTypeOverFlow, boolean checkUlp) {

						if (checkUlp) {
							double minAddedValue = Math.ulp(a);
							if (minAddedValue > Math.abs(b)) {
								throw new RuntimeException(buildPrecisionMessage(String.valueOf(a), String.valueOf(a),
										"'BigDecimal'", "'double/Double'"));
							}
						}

						if (checkTypeOverFlow && (a + b > (double) Double.MAX_VALUE) || (a + b < -Double.MAX_VALUE)) {
							throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b),
									"'BigDecimal'", "'double/Double'"));
						}
					}

					private String buildOverflowMessage(String a, String b, String advicedTypes, String originalType) {
						return "Type overflow when adding " + b + " to " + a
								+ ", to resolve this problem, increase the precision by using " + advicedTypes
								+ " type in place of " + originalType + ".";
					}

					private String buildPrecisionMessage(String a, String b, String advicedTypes, String originalType) {
						return "The double precision is unsufficient to add the value " + b + " to " + a
								+ ", to resolve this problem, increase the precision by using " + advicedTypes
								+ " type in place of " + originalType + ".";
					}

				} // G_OutBegin_AggR_144

				UtilClass_tAggregateRow_2 utilClass_tAggregateRow_2 = new UtilClass_tAggregateRow_2();

				class AggOperationStruct_tAggregateRow_2 { // G_OutBegin_AggR_100

					private static final int DEFAULT_HASHCODE = 1;
					private static final int PRIME = 31;
					private int hashCode = DEFAULT_HASHCODE;
					public boolean hashCodeDirty = true;

					Integer PhysicianID;
					Integer TotalAmountPerPhysician_sum;

					@Override
					public int hashCode() {
						if (this.hashCodeDirty) {
							final int prime = PRIME;
							int result = DEFAULT_HASHCODE;

							result = prime * result + ((this.PhysicianID == null) ? 0 : this.PhysicianID.hashCode());

							this.hashCode = result;
							this.hashCodeDirty = false;
						}
						return this.hashCode;
					}

					@Override
					public boolean equals(Object obj) {
						if (this == obj)
							return true;
						if (obj == null)
							return false;
						if (getClass() != obj.getClass())
							return false;
						final AggOperationStruct_tAggregateRow_2 other = (AggOperationStruct_tAggregateRow_2) obj;

						if (this.PhysicianID == null) {
							if (other.PhysicianID != null)
								return false;
						} else if (!this.PhysicianID.equals(other.PhysicianID))
							return false;

						return true;
					}

				} // G_OutBegin_AggR_100

				AggOperationStruct_tAggregateRow_2 operation_result_tAggregateRow_2 = null;
				AggOperationStruct_tAggregateRow_2 operation_finder_tAggregateRow_2 = new AggOperationStruct_tAggregateRow_2();
				java.util.Map<AggOperationStruct_tAggregateRow_2, AggOperationStruct_tAggregateRow_2> hash_tAggregateRow_2 = new java.util.HashMap<AggOperationStruct_tAggregateRow_2, AggOperationStruct_tAggregateRow_2>();

				/**
				 * [tAggregateRow_2_AGGOUT begin ] stop
				 */

				/**
				 * [tLogRow_3 begin ] start
				 */

				ok_Hash.put("tLogRow_3", false);
				start_Hash.put("tLogRow_3", System.currentTimeMillis());

				currentComponent = "tLogRow_3";

				cLabel = "CurrentMonthPayment";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "ThisMonthPayment");

				int tos_count_tLogRow_3 = 0;

				if (log.isDebugEnabled())
					log.debug("tLogRow_3 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tLogRow_3 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tLogRow_3 = new StringBuilder();
							log4jParamters_tLogRow_3.append("Parameters:");
							log4jParamters_tLogRow_3.append("BASIC_MODE" + " = " + "false");
							log4jParamters_tLogRow_3.append(" | ");
							log4jParamters_tLogRow_3.append("TABLE_PRINT" + " = " + "true");
							log4jParamters_tLogRow_3.append(" | ");
							log4jParamters_tLogRow_3.append("VERTICAL" + " = " + "false");
							log4jParamters_tLogRow_3.append(" | ");
							log4jParamters_tLogRow_3.append("PRINT_CONTENT_WITH_LOG4J" + " = " + "true");
							log4jParamters_tLogRow_3.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tLogRow_3 - " + (log4jParamters_tLogRow_3));
						}
					}
					new BytesLimit65535_tLogRow_3().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tLogRow_3", "CurrentMonthPayment", "tLogRow");
					talendJobLogProcess(globalMap);
				}

				///////////////////////

				class Util_tLogRow_3 {

					String[] des_top = { ".", ".", "-", "+" };

					String[] des_head = { "|=", "=|", "-", "+" };

					String[] des_bottom = { "'", "'", "-", "+" };

					String name = "";

					java.util.List<String[]> list = new java.util.ArrayList<String[]>();

					int[] colLengths = new int[6];

					public void addRow(String[] row) {

						for (int i = 0; i < 6; i++) {
							if (row[i] != null) {
								colLengths[i] = Math.max(colLengths[i], row[i].length());
							}
						}
						list.add(row);
					}

					public void setTableName(String name) {

						this.name = name;
					}

					public StringBuilder format() {

						StringBuilder sb = new StringBuilder();

						sb.append(print(des_top));

						int totals = 0;
						for (int i = 0; i < colLengths.length; i++) {
							totals = totals + colLengths[i];
						}

						// name
						sb.append("|");
						int k = 0;
						for (k = 0; k < (totals + 5 - name.length()) / 2; k++) {
							sb.append(' ');
						}
						sb.append(name);
						for (int i = 0; i < totals + 5 - name.length() - k; i++) {
							sb.append(' ');
						}
						sb.append("|\n");

						// head and rows
						sb.append(print(des_head));
						for (int i = 0; i < list.size(); i++) {

							String[] row = list.get(i);

							java.util.Formatter formatter = new java.util.Formatter(new StringBuilder());

							StringBuilder sbformat = new StringBuilder();
							sbformat.append("|%1$-");
							sbformat.append(colLengths[0]);
							sbformat.append("s");

							sbformat.append("|%2$-");
							sbformat.append(colLengths[1]);
							sbformat.append("s");

							sbformat.append("|%3$-");
							sbformat.append(colLengths[2]);
							sbformat.append("s");

							sbformat.append("|%4$-");
							sbformat.append(colLengths[3]);
							sbformat.append("s");

							sbformat.append("|%5$-");
							sbformat.append(colLengths[4]);
							sbformat.append("s");

							sbformat.append("|%6$-");
							sbformat.append(colLengths[5]);
							sbformat.append("s");

							sbformat.append("|\n");

							formatter.format(sbformat.toString(), (Object[]) row);

							sb.append(formatter.toString());
							if (i == 0)
								sb.append(print(des_head)); // print the head
						}

						// end
						sb.append(print(des_bottom));
						return sb;
					}

					private StringBuilder print(String[] fillChars) {
						StringBuilder sb = new StringBuilder();
						// first column
						sb.append(fillChars[0]);
						for (int i = 0; i < colLengths[0] - fillChars[0].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);

						for (int i = 0; i < colLengths[1] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[2] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[3] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[4] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);

						// last column
						for (int i = 0; i < colLengths[5] - fillChars[1].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[1]);
						sb.append("\n");
						return sb;
					}

					public boolean isTableEmpty() {
						if (list.size() > 1)
							return false;
						return true;
					}
				}
				Util_tLogRow_3 util_tLogRow_3 = new Util_tLogRow_3();
				util_tLogRow_3.setTableName("CurrentMonthPayment");
				util_tLogRow_3.addRow(new String[] { "PaymentID", "PatientID", "PhysicianID", "AmountToBePaid",
						"PaymentDate", "InsuranceID", });
				StringBuilder strBuffer_tLogRow_3 = null;
				int nb_line_tLogRow_3 = 0;
///////////////////////    			

				/**
				 * [tLogRow_3 begin ] stop
				 */

				/**
				 * [tLogRow_4 begin ] start
				 */

				ok_Hash.put("tLogRow_4", false);
				start_Hash.put("tLogRow_4", System.currentTimeMillis());

				currentComponent = "tLogRow_4";

				cLabel = "ActualAmount";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0,
						"ActualAmountToBePaid");

				int tos_count_tLogRow_4 = 0;

				if (log.isDebugEnabled())
					log.debug("tLogRow_4 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tLogRow_4 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tLogRow_4 = new StringBuilder();
							log4jParamters_tLogRow_4.append("Parameters:");
							log4jParamters_tLogRow_4.append("BASIC_MODE" + " = " + "false");
							log4jParamters_tLogRow_4.append(" | ");
							log4jParamters_tLogRow_4.append("TABLE_PRINT" + " = " + "true");
							log4jParamters_tLogRow_4.append(" | ");
							log4jParamters_tLogRow_4.append("VERTICAL" + " = " + "false");
							log4jParamters_tLogRow_4.append(" | ");
							log4jParamters_tLogRow_4.append("PRINT_CONTENT_WITH_LOG4J" + " = " + "true");
							log4jParamters_tLogRow_4.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tLogRow_4 - " + (log4jParamters_tLogRow_4));
						}
					}
					new BytesLimit65535_tLogRow_4().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tLogRow_4", "ActualAmount", "tLogRow");
					talendJobLogProcess(globalMap);
				}

				///////////////////////

				class Util_tLogRow_4 {

					String[] des_top = { ".", ".", "-", "+" };

					String[] des_head = { "|=", "=|", "-", "+" };

					String[] des_bottom = { "'", "'", "-", "+" };

					String name = "";

					java.util.List<String[]> list = new java.util.ArrayList<String[]>();

					int[] colLengths = new int[2];

					public void addRow(String[] row) {

						for (int i = 0; i < 2; i++) {
							if (row[i] != null) {
								colLengths[i] = Math.max(colLengths[i], row[i].length());
							}
						}
						list.add(row);
					}

					public void setTableName(String name) {

						this.name = name;
					}

					public StringBuilder format() {

						StringBuilder sb = new StringBuilder();

						sb.append(print(des_top));

						int totals = 0;
						for (int i = 0; i < colLengths.length; i++) {
							totals = totals + colLengths[i];
						}

						// name
						sb.append("|");
						int k = 0;
						for (k = 0; k < (totals + 1 - name.length()) / 2; k++) {
							sb.append(' ');
						}
						sb.append(name);
						for (int i = 0; i < totals + 1 - name.length() - k; i++) {
							sb.append(' ');
						}
						sb.append("|\n");

						// head and rows
						sb.append(print(des_head));
						for (int i = 0; i < list.size(); i++) {

							String[] row = list.get(i);

							java.util.Formatter formatter = new java.util.Formatter(new StringBuilder());

							StringBuilder sbformat = new StringBuilder();
							sbformat.append("|%1$-");
							sbformat.append(colLengths[0]);
							sbformat.append("s");

							sbformat.append("|%2$-");
							sbformat.append(colLengths[1]);
							sbformat.append("s");

							sbformat.append("|\n");

							formatter.format(sbformat.toString(), (Object[]) row);

							sb.append(formatter.toString());
							if (i == 0)
								sb.append(print(des_head)); // print the head
						}

						// end
						sb.append(print(des_bottom));
						return sb;
					}

					private StringBuilder print(String[] fillChars) {
						StringBuilder sb = new StringBuilder();
						// first column
						sb.append(fillChars[0]);
						for (int i = 0; i < colLengths[0] - fillChars[0].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);

						// last column
						for (int i = 0; i < colLengths[1] - fillChars[1].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[1]);
						sb.append("\n");
						return sb;
					}

					public boolean isTableEmpty() {
						if (list.size() > 1)
							return false;
						return true;
					}
				}
				Util_tLogRow_4 util_tLogRow_4 = new Util_tLogRow_4();
				util_tLogRow_4.setTableName("ActualAmount");
				util_tLogRow_4.addRow(new String[] { "PatientID", "ActualAmountToBePaid", });
				StringBuilder strBuffer_tLogRow_4 = null;
				int nb_line_tLogRow_4 = 0;
///////////////////////    			

				/**
				 * [tLogRow_4 begin ] stop
				 */

				/**
				 * [tMap_5 begin ] start
				 */

				ok_Hash.put("tMap_5", false);
				start_Hash.put("tMap_5", System.currentTimeMillis());

				currentComponent = "tMap_5";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "row8");

				int tos_count_tMap_5 = 0;

				if (log.isDebugEnabled())
					log.debug("tMap_5 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tMap_5 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tMap_5 = new StringBuilder();
							log4jParamters_tMap_5.append("Parameters:");
							log4jParamters_tMap_5.append("LINK_STYLE" + " = " + "AUTO");
							log4jParamters_tMap_5.append(" | ");
							log4jParamters_tMap_5.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
							log4jParamters_tMap_5.append(" | ");
							log4jParamters_tMap_5.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
							log4jParamters_tMap_5.append(" | ");
							log4jParamters_tMap_5.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "true");
							log4jParamters_tMap_5.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tMap_5 - " + (log4jParamters_tMap_5));
						}
					}
					new BytesLimit65535_tMap_5().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tMap_5", "tMap_5", "tMap");
					talendJobLogProcess(globalMap);
				}

// ###############################
// # Lookup's keys initialization
				int count_row8_tMap_5 = 0;

// ###############################        

// ###############################
// # Vars initialization
				class Var__tMap_5__Struct {
				}
				Var__tMap_5__Struct Var__tMap_5 = new Var__tMap_5__Struct();
// ###############################

// ###############################
// # Outputs initialization
				int count_NotCoveredByInsurance_tMap_5 = 0;

				NotCoveredByInsuranceStruct NotCoveredByInsurance_tmp = new NotCoveredByInsuranceStruct();
				int count_MaxToBePaidPhysician_tMap_5 = 0;

				MaxToBePaidPhysicianStruct MaxToBePaidPhysician_tmp = new MaxToBePaidPhysicianStruct();
				int count_ThisMonthPayment_tMap_5 = 0;

				ThisMonthPaymentStruct ThisMonthPayment_tmp = new ThisMonthPaymentStruct();
				int count_ActualAmountToBePaid_tMap_5 = 0;

				ActualAmountToBePaidStruct ActualAmountToBePaid_tmp = new ActualAmountToBePaidStruct();
// ###############################

				/**
				 * [tMap_5 begin ] stop
				 */

				/**
				 * [tDBInput_5 begin ] start
				 */

				ok_Hash.put("tDBInput_5", false);
				start_Hash.put("tDBInput_5", System.currentTimeMillis());

				currentComponent = "tDBInput_5";

				cLabel = "Billing";

				int tos_count_tDBInput_5 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBInput_5 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tDBInput_5 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tDBInput_5 = new StringBuilder();
							log4jParamters_tDBInput_5.append("Parameters:");
							log4jParamters_tDBInput_5.append("DB_VERSION" + " = " + "MYSQL_8");
							log4jParamters_tDBInput_5.append(" | ");
							log4jParamters_tDBInput_5.append("USE_EXISTING_CONNECTION" + " = " + "false");
							log4jParamters_tDBInput_5.append(" | ");
							log4jParamters_tDBInput_5.append("HOST" + " = " + "\"localhost\"");
							log4jParamters_tDBInput_5.append(" | ");
							log4jParamters_tDBInput_5.append("PORT" + " = " + "\"3306\"");
							log4jParamters_tDBInput_5.append(" | ");
							log4jParamters_tDBInput_5.append("DBNAME" + " = " + "\"Warehouse\"");
							log4jParamters_tDBInput_5.append(" | ");
							log4jParamters_tDBInput_5.append("USER" + " = " + "\"root\"");
							log4jParamters_tDBInput_5.append(" | ");
							log4jParamters_tDBInput_5.append("PASS" + " = " + String.valueOf(
									"enc:routine.encryption.key.v1:n2Rze3mVvdPTohJQuBfJ8gwy19kxX99SblYV3msHHMg=")
									.substring(0, 4) + "...");
							log4jParamters_tDBInput_5.append(" | ");
							log4jParamters_tDBInput_5.append("TABLE" + " = " + "\"billingdim\"");
							log4jParamters_tDBInput_5.append(" | ");
							log4jParamters_tDBInput_5.append("QUERYSTORE" + " = " + "\"\"");
							log4jParamters_tDBInput_5.append(" | ");
							log4jParamters_tDBInput_5.append("QUERY" + " = "
									+ "\"SELECT    `billingdim`.`PaymentID`,    `billingdim`.`PatientID`,    `billingdim`.`PhysicianID`,    `billingdim`.`AmountToBePaid`,    `billingdim`.`PaymentDate`,    `billingdim`.`InsuranceID`,    `billingdim`.`MaxCoverageAmount`,    `billingdim`.`Billing_SK`,    `billingdim`.`Start_date`,    `billingdim`.`End_date` FROM `billingdim`\"");
							log4jParamters_tDBInput_5.append(" | ");
							log4jParamters_tDBInput_5.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
							log4jParamters_tDBInput_5.append(" | ");
							log4jParamters_tDBInput_5.append("PROPERTIES" + " = "
									+ "\"noDatetimeStringSync=true&enabledTLSProtocols=TLSv1.2,TLSv1.1,TLSv1\"");
							log4jParamters_tDBInput_5.append(" | ");
							log4jParamters_tDBInput_5.append("ENABLE_STREAM" + " = " + "false");
							log4jParamters_tDBInput_5.append(" | ");
							log4jParamters_tDBInput_5.append("TRIM_ALL_COLUMN" + " = " + "false");
							log4jParamters_tDBInput_5.append(" | ");
							log4jParamters_tDBInput_5.append("TRIM_COLUMN" + " = " + "[{TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("PaymentID") + "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN="
									+ ("PatientID") + "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN=" + ("PhysicianID")
									+ "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN=" + ("AmountToBePaid") + "}, {TRIM="
									+ ("false") + ", SCHEMA_COLUMN=" + ("PaymentDate") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("InsuranceID") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("MaxCoverageAmount") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("Billing_SK") + "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN="
									+ ("Start_date") + "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN=" + ("End_date")
									+ "}]");
							log4jParamters_tDBInput_5.append(" | ");
							log4jParamters_tDBInput_5.append("UNIFIED_COMPONENTS" + " = " + "tMysqlInput");
							log4jParamters_tDBInput_5.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tDBInput_5 - " + (log4jParamters_tDBInput_5));
						}
					}
					new BytesLimit65535_tDBInput_5().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tDBInput_5", "Billing", "tMysqlInput");
					talendJobLogProcess(globalMap);
				}

				java.util.Calendar calendar_tDBInput_5 = java.util.Calendar.getInstance();
				calendar_tDBInput_5.set(0, 0, 0, 0, 0, 0);
				java.util.Date year0_tDBInput_5 = calendar_tDBInput_5.getTime();
				int nb_line_tDBInput_5 = 0;
				java.sql.Connection conn_tDBInput_5 = null;
				String driverClass_tDBInput_5 = "com.mysql.cj.jdbc.Driver";
				java.lang.Class jdbcclazz_tDBInput_5 = java.lang.Class.forName(driverClass_tDBInput_5);
				String dbUser_tDBInput_5 = "root";

				final String decryptedPassword_tDBInput_5 = routines.system.PasswordEncryptUtil
						.decryptPassword("enc:routine.encryption.key.v1:FAnMe6CJOXh6gNSNA2VHN92q7HXjv7537iZCpvcOHEI=");

				String dbPwd_tDBInput_5 = decryptedPassword_tDBInput_5;

				String properties_tDBInput_5 = "noDatetimeStringSync=true&enabledTLSProtocols=TLSv1.2,TLSv1.1,TLSv1";
				if (properties_tDBInput_5 == null || properties_tDBInput_5.trim().length() == 0) {
					properties_tDBInput_5 = "";
				}
				String url_tDBInput_5 = "jdbc:mysql://" + "localhost" + ":" + "3306" + "/" + "Warehouse" + "?"
						+ properties_tDBInput_5;

				log.debug("tDBInput_5 - Driver ClassName: " + driverClass_tDBInput_5 + ".");

				log.debug("tDBInput_5 - Connection attempt to '" + url_tDBInput_5 + "' with the username '"
						+ dbUser_tDBInput_5 + "'.");

				conn_tDBInput_5 = java.sql.DriverManager.getConnection(url_tDBInput_5, dbUser_tDBInput_5,
						dbPwd_tDBInput_5);
				log.debug("tDBInput_5 - Connection to '" + url_tDBInput_5 + "' has succeeded.");

				java.sql.Statement stmt_tDBInput_5 = conn_tDBInput_5.createStatement();

				String dbquery_tDBInput_5 = "SELECT \n  `billingdim`.`PaymentID`, \n  `billingdim`.`PatientID`, \n  `billingdim`.`PhysicianID`, \n  `billingdim`.`Amount"
						+ "ToBePaid`, \n  `billingdim`.`PaymentDate`, \n  `billingdim`.`InsuranceID`, \n  `billingdim`.`MaxCoverageAmount`, \n  `billin"
						+ "gdim`.`Billing_SK`, \n  `billingdim`.`Start_date`, \n  `billingdim`.`End_date`\nFROM `billingdim`";

				log.debug("tDBInput_5 - Executing the query: '" + dbquery_tDBInput_5 + "'.");

				globalMap.put("tDBInput_5_QUERY", dbquery_tDBInput_5);

				java.sql.ResultSet rs_tDBInput_5 = null;

				try {
					rs_tDBInput_5 = stmt_tDBInput_5.executeQuery(dbquery_tDBInput_5);
					java.sql.ResultSetMetaData rsmd_tDBInput_5 = rs_tDBInput_5.getMetaData();
					int colQtyInRs_tDBInput_5 = rsmd_tDBInput_5.getColumnCount();

					String tmpContent_tDBInput_5 = null;

					log.debug("tDBInput_5 - Retrieving records from the database.");

					while (rs_tDBInput_5.next()) {
						nb_line_tDBInput_5++;

						if (colQtyInRs_tDBInput_5 < 1) {
							row8.PaymentID = null;
						} else {

							row8.PaymentID = routines.system.JDBCUtil.getString(rs_tDBInput_5, 1, false);
						}
						if (colQtyInRs_tDBInput_5 < 2) {
							row8.PatientID = null;
						} else {

							row8.PatientID = rs_tDBInput_5.getInt(2);
							if (rs_tDBInput_5.wasNull()) {
								row8.PatientID = null;
							}
						}
						if (colQtyInRs_tDBInput_5 < 3) {
							row8.PhysicianID = null;
						} else {

							row8.PhysicianID = rs_tDBInput_5.getInt(3);
							if (rs_tDBInput_5.wasNull()) {
								row8.PhysicianID = null;
							}
						}
						if (colQtyInRs_tDBInput_5 < 4) {
							row8.AmountToBePaid = null;
						} else {

							row8.AmountToBePaid = rs_tDBInput_5.getInt(4);
							if (rs_tDBInput_5.wasNull()) {
								row8.AmountToBePaid = null;
							}
						}
						if (colQtyInRs_tDBInput_5 < 5) {
							row8.PaymentDate = null;
						} else {

							if (rs_tDBInput_5.getString(5) != null) {
								String dateString_tDBInput_5 = rs_tDBInput_5.getString(5);
								if (!("0000-00-00").equals(dateString_tDBInput_5)
										&& !("0000-00-00 00:00:00").equals(dateString_tDBInput_5)) {
									row8.PaymentDate = rs_tDBInput_5.getTimestamp(5);
								} else {
									row8.PaymentDate = (java.util.Date) year0_tDBInput_5.clone();
								}
							} else {
								row8.PaymentDate = null;
							}
						}
						if (colQtyInRs_tDBInput_5 < 6) {
							row8.InsuranceID = null;
						} else {

							row8.InsuranceID = routines.system.JDBCUtil.getString(rs_tDBInput_5, 6, false);
						}
						if (colQtyInRs_tDBInput_5 < 7) {
							row8.MaxCoverageAmount = null;
						} else {

							row8.MaxCoverageAmount = rs_tDBInput_5.getInt(7);
							if (rs_tDBInput_5.wasNull()) {
								row8.MaxCoverageAmount = null;
							}
						}
						if (colQtyInRs_tDBInput_5 < 8) {
							row8.Billing_SK = 0;
						} else {

							row8.Billing_SK = rs_tDBInput_5.getInt(8);
							if (rs_tDBInput_5.wasNull()) {
								throw new RuntimeException("Null value in non-Nullable column");
							}
						}
						if (colQtyInRs_tDBInput_5 < 9) {
							row8.Start_date = null;
						} else {

							if (rs_tDBInput_5.getString(9) != null) {
								String dateString_tDBInput_5 = rs_tDBInput_5.getString(9);
								if (!("0000-00-00").equals(dateString_tDBInput_5)
										&& !("0000-00-00 00:00:00").equals(dateString_tDBInput_5)) {
									row8.Start_date = rs_tDBInput_5.getTimestamp(9);
								} else {
									row8.Start_date = (java.util.Date) year0_tDBInput_5.clone();
								}
							} else {
								row8.Start_date = null;
							}
						}
						if (colQtyInRs_tDBInput_5 < 10) {
							row8.End_date = null;
						} else {

							if (rs_tDBInput_5.getString(10) != null) {
								String dateString_tDBInput_5 = rs_tDBInput_5.getString(10);
								if (!("0000-00-00").equals(dateString_tDBInput_5)
										&& !("0000-00-00 00:00:00").equals(dateString_tDBInput_5)) {
									row8.End_date = rs_tDBInput_5.getTimestamp(10);
								} else {
									row8.End_date = (java.util.Date) year0_tDBInput_5.clone();
								}
							} else {
								row8.End_date = null;
							}
						}

						log.debug("tDBInput_5 - Retrieving the record " + nb_line_tDBInput_5 + ".");

						/**
						 * [tDBInput_5 begin ] stop
						 */

						/**
						 * [tDBInput_5 main ] start
						 */

						currentComponent = "tDBInput_5";

						cLabel = "Billing";

						tos_count_tDBInput_5++;

						/**
						 * [tDBInput_5 main ] stop
						 */

						/**
						 * [tDBInput_5 process_data_begin ] start
						 */

						currentComponent = "tDBInput_5";

						cLabel = "Billing";

						/**
						 * [tDBInput_5 process_data_begin ] stop
						 */

						/**
						 * [tMap_5 main ] start
						 */

						currentComponent = "tMap_5";

						if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

								, "row8", "tDBInput_5", "Billing", "tMysqlInput", "tMap_5", "tMap_5", "tMap"

						)) {
							talendJobLogProcess(globalMap);
						}

						if (log.isTraceEnabled()) {
							log.trace("row8 - " + (row8 == null ? "" : row8.toLogString()));
						}

						boolean hasCasePrimitiveKeyWithNull_tMap_5 = false;

						// ###############################
						// # Input tables (lookups)

						boolean rejectedInnerJoin_tMap_5 = false;
						boolean mainRowRejected_tMap_5 = false;
						// ###############################
						{ // start of Var scope

							// ###############################
							// # Vars tables

							Var__tMap_5__Struct Var = Var__tMap_5;// ###############################
							// ###############################
							// # Output tables

							NotCoveredByInsurance = null;
							MaxToBePaidPhysician = null;
							ThisMonthPayment = null;
							ActualAmountToBePaid = null;

// # Output table : 'NotCoveredByInsurance'
// # Filter conditions 
							if (

							row8.InsuranceID == null

							) {
								count_NotCoveredByInsurance_tMap_5++;

								NotCoveredByInsurance_tmp.PaymentID = row8.PaymentID;
								NotCoveredByInsurance_tmp.PatientID = row8.PatientID;
								NotCoveredByInsurance_tmp.PhysicianID = row8.PhysicianID;
								NotCoveredByInsurance_tmp.AmountToBePaid = row8.AmountToBePaid;
								NotCoveredByInsurance_tmp.PaymentDate = row8.PaymentDate;
								NotCoveredByInsurance_tmp.InsuranceID = row8.InsuranceID;
								NotCoveredByInsurance = NotCoveredByInsurance_tmp;
								log.debug("tMap_5 - Outputting the record " + count_NotCoveredByInsurance_tMap_5
										+ " of the output table 'NotCoveredByInsurance'.");

							} // closing filter/reject

// # Output table : 'MaxToBePaidPhysician'
							count_MaxToBePaidPhysician_tMap_5++;

							MaxToBePaidPhysician_tmp.PaymentID = row8.PaymentID;
							MaxToBePaidPhysician_tmp.PatientID = row8.PatientID;
							MaxToBePaidPhysician_tmp.PhysicianID = row8.PhysicianID;
							MaxToBePaidPhysician_tmp.AmountToBePaid = row8.AmountToBePaid;
							MaxToBePaidPhysician_tmp.PaymentDate = row8.PaymentDate;
							MaxToBePaidPhysician_tmp.InsuranceID = row8.InsuranceID;
							MaxToBePaidPhysician = MaxToBePaidPhysician_tmp;
							log.debug("tMap_5 - Outputting the record " + count_MaxToBePaidPhysician_tMap_5
									+ " of the output table 'MaxToBePaidPhysician'.");

// # Output table : 'ThisMonthPayment'
// # Filter conditions 
							if (

							(row8.PaymentDate.getYear()) == (TalendDate.getCurrentDate().getYear())
									&& (row8.PaymentDate.getMonth()) == (TalendDate.getCurrentDate().getMonth())

							) {
								count_ThisMonthPayment_tMap_5++;

								ThisMonthPayment_tmp.PaymentID = row8.PaymentID;
								ThisMonthPayment_tmp.PatientID = row8.PatientID;
								ThisMonthPayment_tmp.PhysicianID = row8.PhysicianID;
								ThisMonthPayment_tmp.AmountToBePaid = row8.AmountToBePaid;
								ThisMonthPayment_tmp.PaymentDate = row8.PaymentDate;
								ThisMonthPayment_tmp.InsuranceID = row8.InsuranceID;
								ThisMonthPayment = ThisMonthPayment_tmp;
								log.debug("tMap_5 - Outputting the record " + count_ThisMonthPayment_tMap_5
										+ " of the output table 'ThisMonthPayment'.");

							} // closing filter/reject

// # Output table : 'ActualAmountToBePaid'
// # Filter conditions 
							if (

							row8.MaxCoverageAmount != null

							) {
								count_ActualAmountToBePaid_tMap_5++;

								ActualAmountToBePaid_tmp.PatientID = row8.PatientID;
								ActualAmountToBePaid_tmp.ActualAmountToBePaid = row8.MaxCoverageAmount > row8.AmountToBePaid
										? 0
										: (row8.AmountToBePaid - row8.MaxCoverageAmount);
								ActualAmountToBePaid = ActualAmountToBePaid_tmp;
								log.debug("tMap_5 - Outputting the record " + count_ActualAmountToBePaid_tMap_5
										+ " of the output table 'ActualAmountToBePaid'.");

							} // closing filter/reject
// ###############################

						} // end of Var scope

						rejectedInnerJoin_tMap_5 = false;

						tos_count_tMap_5++;

						/**
						 * [tMap_5 main ] stop
						 */

						/**
						 * [tMap_5 process_data_begin ] start
						 */

						currentComponent = "tMap_5";

						/**
						 * [tMap_5 process_data_begin ] stop
						 */
// Start of branch "NotCoveredByInsurance"
						if (NotCoveredByInsurance != null) {

							/**
							 * [tFileOutputExcel_11 main ] start
							 */

							currentComponent = "tFileOutputExcel_11";

							cLabel = "NotCoveredByInsurance";

							if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

									, "NotCoveredByInsurance", "tMap_5", "tMap_5", "tMap", "tFileOutputExcel_11",
									"NotCoveredByInsurance", "tFileOutputExcel"

							)) {
								talendJobLogProcess(globalMap);
							}

							if (log.isTraceEnabled()) {
								log.trace("NotCoveredByInsurance - "
										+ (NotCoveredByInsurance == null ? "" : NotCoveredByInsurance.toLogString()));
							}

							if (NotCoveredByInsurance.PaymentID != null) {

//modif start

								columnIndex_tFileOutputExcel_11 = 0;

								jxl.write.WritableCell cell_0_tFileOutputExcel_11 = new jxl.write.Label(
										columnIndex_tFileOutputExcel_11,
										startRowNum_tFileOutputExcel_11 + nb_line_tFileOutputExcel_11,

//modif end
										NotCoveredByInsurance.PaymentID);
//modif start					
								// If we keep the cell format from the existing cell in sheet

//modif ends							
								writableSheet_tFileOutputExcel_11.addCell(cell_0_tFileOutputExcel_11);
								int currentWith_0_tFileOutputExcel_11 = cell_0_tFileOutputExcel_11.getContents().trim()
										.length();
								fitWidth_tFileOutputExcel_11[0] = fitWidth_tFileOutputExcel_11[0] > currentWith_0_tFileOutputExcel_11
										? fitWidth_tFileOutputExcel_11[0]
										: currentWith_0_tFileOutputExcel_11 + 2;
							}

							if (NotCoveredByInsurance.PatientID != null) {

//modif start

								columnIndex_tFileOutputExcel_11 = 1;

								jxl.write.WritableCell cell_1_tFileOutputExcel_11 = new jxl.write.Number(
										columnIndex_tFileOutputExcel_11,
										startRowNum_tFileOutputExcel_11 + nb_line_tFileOutputExcel_11,

//modif end
										NotCoveredByInsurance.PatientID);
//modif start					
								// If we keep the cell format from the existing cell in sheet

//modif ends							
								writableSheet_tFileOutputExcel_11.addCell(cell_1_tFileOutputExcel_11);
								int currentWith_1_tFileOutputExcel_11 = String
										.valueOf(((jxl.write.Number) cell_1_tFileOutputExcel_11).getValue()).trim()
										.length();
								currentWith_1_tFileOutputExcel_11 = currentWith_1_tFileOutputExcel_11 > 10 ? 10
										: currentWith_1_tFileOutputExcel_11;
								fitWidth_tFileOutputExcel_11[1] = fitWidth_tFileOutputExcel_11[1] > currentWith_1_tFileOutputExcel_11
										? fitWidth_tFileOutputExcel_11[1]
										: currentWith_1_tFileOutputExcel_11 + 2;
							}

							if (NotCoveredByInsurance.PhysicianID != null) {

//modif start

								columnIndex_tFileOutputExcel_11 = 2;

								jxl.write.WritableCell cell_2_tFileOutputExcel_11 = new jxl.write.Number(
										columnIndex_tFileOutputExcel_11,
										startRowNum_tFileOutputExcel_11 + nb_line_tFileOutputExcel_11,

//modif end
										NotCoveredByInsurance.PhysicianID);
//modif start					
								// If we keep the cell format from the existing cell in sheet

//modif ends							
								writableSheet_tFileOutputExcel_11.addCell(cell_2_tFileOutputExcel_11);
								int currentWith_2_tFileOutputExcel_11 = String
										.valueOf(((jxl.write.Number) cell_2_tFileOutputExcel_11).getValue()).trim()
										.length();
								currentWith_2_tFileOutputExcel_11 = currentWith_2_tFileOutputExcel_11 > 10 ? 10
										: currentWith_2_tFileOutputExcel_11;
								fitWidth_tFileOutputExcel_11[2] = fitWidth_tFileOutputExcel_11[2] > currentWith_2_tFileOutputExcel_11
										? fitWidth_tFileOutputExcel_11[2]
										: currentWith_2_tFileOutputExcel_11 + 2;
							}

							if (NotCoveredByInsurance.AmountToBePaid != null) {

//modif start

								columnIndex_tFileOutputExcel_11 = 3;

								jxl.write.WritableCell cell_3_tFileOutputExcel_11 = new jxl.write.Number(
										columnIndex_tFileOutputExcel_11,
										startRowNum_tFileOutputExcel_11 + nb_line_tFileOutputExcel_11,

//modif end
										NotCoveredByInsurance.AmountToBePaid);
//modif start					
								// If we keep the cell format from the existing cell in sheet

//modif ends							
								writableSheet_tFileOutputExcel_11.addCell(cell_3_tFileOutputExcel_11);
								int currentWith_3_tFileOutputExcel_11 = String
										.valueOf(((jxl.write.Number) cell_3_tFileOutputExcel_11).getValue()).trim()
										.length();
								currentWith_3_tFileOutputExcel_11 = currentWith_3_tFileOutputExcel_11 > 10 ? 10
										: currentWith_3_tFileOutputExcel_11;
								fitWidth_tFileOutputExcel_11[3] = fitWidth_tFileOutputExcel_11[3] > currentWith_3_tFileOutputExcel_11
										? fitWidth_tFileOutputExcel_11[3]
										: currentWith_3_tFileOutputExcel_11 + 2;
							}

							if (NotCoveredByInsurance.PaymentDate != null) {

//modif start

								columnIndex_tFileOutputExcel_11 = 4;

								jxl.write.WritableCell cell_4_tFileOutputExcel_11 = new jxl.write.DateTime(
										columnIndex_tFileOutputExcel_11,
										startRowNum_tFileOutputExcel_11 + nb_line_tFileOutputExcel_11,

//modif end
										NotCoveredByInsurance.PaymentDate, cell_format_PaymentDate_tFileOutputExcel_11);
//modif start					
								// If we keep the cell format from the existing cell in sheet

//modif ends							
								writableSheet_tFileOutputExcel_11.addCell(cell_4_tFileOutputExcel_11);
								int currentWith_4_tFileOutputExcel_11 = cell_4_tFileOutputExcel_11.getContents().trim()
										.length();
								currentWith_4_tFileOutputExcel_11 = 12;
								fitWidth_tFileOutputExcel_11[4] = fitWidth_tFileOutputExcel_11[4] > currentWith_4_tFileOutputExcel_11
										? fitWidth_tFileOutputExcel_11[4]
										: currentWith_4_tFileOutputExcel_11 + 2;
							}

							if (NotCoveredByInsurance.InsuranceID != null) {

//modif start

								columnIndex_tFileOutputExcel_11 = 5;

								jxl.write.WritableCell cell_5_tFileOutputExcel_11 = new jxl.write.Label(
										columnIndex_tFileOutputExcel_11,
										startRowNum_tFileOutputExcel_11 + nb_line_tFileOutputExcel_11,

//modif end
										NotCoveredByInsurance.InsuranceID);
//modif start					
								// If we keep the cell format from the existing cell in sheet

//modif ends							
								writableSheet_tFileOutputExcel_11.addCell(cell_5_tFileOutputExcel_11);
								int currentWith_5_tFileOutputExcel_11 = cell_5_tFileOutputExcel_11.getContents().trim()
										.length();
								fitWidth_tFileOutputExcel_11[5] = fitWidth_tFileOutputExcel_11[5] > currentWith_5_tFileOutputExcel_11
										? fitWidth_tFileOutputExcel_11[5]
										: currentWith_5_tFileOutputExcel_11 + 2;
							}

							nb_line_tFileOutputExcel_11++;

							log.debug("tFileOutputExcel_11 - Writing the record " + nb_line_tFileOutputExcel_11
									+ " to the file.");

							tos_count_tFileOutputExcel_11++;

							/**
							 * [tFileOutputExcel_11 main ] stop
							 */

							/**
							 * [tFileOutputExcel_11 process_data_begin ] start
							 */

							currentComponent = "tFileOutputExcel_11";

							cLabel = "NotCoveredByInsurance";

							/**
							 * [tFileOutputExcel_11 process_data_begin ] stop
							 */

							/**
							 * [tFileOutputExcel_11 process_data_end ] start
							 */

							currentComponent = "tFileOutputExcel_11";

							cLabel = "NotCoveredByInsurance";

							/**
							 * [tFileOutputExcel_11 process_data_end ] stop
							 */

						} // End of branch "NotCoveredByInsurance"

// Start of branch "MaxToBePaidPhysician"
						if (MaxToBePaidPhysician != null) {

							/**
							 * [tAggregateRow_2_AGGOUT main ] start
							 */

							currentVirtualComponent = "tAggregateRow_2";

							currentComponent = "tAggregateRow_2_AGGOUT";

							if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

									, "MaxToBePaidPhysician", "tMap_5", "tMap_5", "tMap", "tAggregateRow_2_AGGOUT",
									"tAggregateRow_2_AGGOUT", "tAggregateOut"

							)) {
								talendJobLogProcess(globalMap);
							}

							if (log.isTraceEnabled()) {
								log.trace("MaxToBePaidPhysician - "
										+ (MaxToBePaidPhysician == null ? "" : MaxToBePaidPhysician.toLogString()));
							}

							operation_finder_tAggregateRow_2.PhysicianID = MaxToBePaidPhysician.PhysicianID;

							operation_finder_tAggregateRow_2.hashCodeDirty = true;

							operation_result_tAggregateRow_2 = hash_tAggregateRow_2
									.get(operation_finder_tAggregateRow_2);

							if (operation_result_tAggregateRow_2 == null) { // G_OutMain_AggR_001

								operation_result_tAggregateRow_2 = new AggOperationStruct_tAggregateRow_2();

								operation_result_tAggregateRow_2.PhysicianID = operation_finder_tAggregateRow_2.PhysicianID;

								hash_tAggregateRow_2.put(operation_result_tAggregateRow_2,
										operation_result_tAggregateRow_2);

							} // G_OutMain_AggR_001

							if (operation_result_tAggregateRow_2.TotalAmountPerPhysician_sum == null) {
								operation_result_tAggregateRow_2.TotalAmountPerPhysician_sum = (int) 0;
							}

							if (MaxToBePaidPhysician.AmountToBePaid != null)
								operation_result_tAggregateRow_2.TotalAmountPerPhysician_sum += MaxToBePaidPhysician.AmountToBePaid;

							tos_count_tAggregateRow_2_AGGOUT++;

							/**
							 * [tAggregateRow_2_AGGOUT main ] stop
							 */

							/**
							 * [tAggregateRow_2_AGGOUT process_data_begin ] start
							 */

							currentVirtualComponent = "tAggregateRow_2";

							currentComponent = "tAggregateRow_2_AGGOUT";

							/**
							 * [tAggregateRow_2_AGGOUT process_data_begin ] stop
							 */

							/**
							 * [tAggregateRow_2_AGGOUT process_data_end ] start
							 */

							currentVirtualComponent = "tAggregateRow_2";

							currentComponent = "tAggregateRow_2_AGGOUT";

							/**
							 * [tAggregateRow_2_AGGOUT process_data_end ] stop
							 */

						} // End of branch "MaxToBePaidPhysician"

// Start of branch "ThisMonthPayment"
						if (ThisMonthPayment != null) {

							/**
							 * [tLogRow_3 main ] start
							 */

							currentComponent = "tLogRow_3";

							cLabel = "CurrentMonthPayment";

							if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

									, "ThisMonthPayment", "tMap_5", "tMap_5", "tMap", "tLogRow_3",
									"CurrentMonthPayment", "tLogRow"

							)) {
								talendJobLogProcess(globalMap);
							}

							if (log.isTraceEnabled()) {
								log.trace("ThisMonthPayment - "
										+ (ThisMonthPayment == null ? "" : ThisMonthPayment.toLogString()));
							}

///////////////////////		

							String[] row_tLogRow_3 = new String[6];

							if (ThisMonthPayment.PaymentID != null) { //
								row_tLogRow_3[0] = String.valueOf(ThisMonthPayment.PaymentID);

							} //

							if (ThisMonthPayment.PatientID != null) { //
								row_tLogRow_3[1] = String.valueOf(ThisMonthPayment.PatientID);

							} //

							if (ThisMonthPayment.PhysicianID != null) { //
								row_tLogRow_3[2] = String.valueOf(ThisMonthPayment.PhysicianID);

							} //

							if (ThisMonthPayment.AmountToBePaid != null) { //
								row_tLogRow_3[3] = String.valueOf(ThisMonthPayment.AmountToBePaid);

							} //

							if (ThisMonthPayment.PaymentDate != null) { //
								row_tLogRow_3[4] = FormatterUtils.format_Date(ThisMonthPayment.PaymentDate,
										"dd-MM-yyyy");

							} //

							if (ThisMonthPayment.InsuranceID != null) { //
								row_tLogRow_3[5] = String.valueOf(ThisMonthPayment.InsuranceID);

							} //

							util_tLogRow_3.addRow(row_tLogRow_3);
							nb_line_tLogRow_3++;
							log.info("tLogRow_3 - Content of row " + nb_line_tLogRow_3 + ": "
									+ TalendString.unionString("|", row_tLogRow_3));
//////

//////                    

///////////////////////    			

							tos_count_tLogRow_3++;

							/**
							 * [tLogRow_3 main ] stop
							 */

							/**
							 * [tLogRow_3 process_data_begin ] start
							 */

							currentComponent = "tLogRow_3";

							cLabel = "CurrentMonthPayment";

							/**
							 * [tLogRow_3 process_data_begin ] stop
							 */

							/**
							 * [tLogRow_3 process_data_end ] start
							 */

							currentComponent = "tLogRow_3";

							cLabel = "CurrentMonthPayment";

							/**
							 * [tLogRow_3 process_data_end ] stop
							 */

						} // End of branch "ThisMonthPayment"

// Start of branch "ActualAmountToBePaid"
						if (ActualAmountToBePaid != null) {

							/**
							 * [tLogRow_4 main ] start
							 */

							currentComponent = "tLogRow_4";

							cLabel = "ActualAmount";

							if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

									, "ActualAmountToBePaid", "tMap_5", "tMap_5", "tMap", "tLogRow_4", "ActualAmount",
									"tLogRow"

							)) {
								talendJobLogProcess(globalMap);
							}

							if (log.isTraceEnabled()) {
								log.trace("ActualAmountToBePaid - "
										+ (ActualAmountToBePaid == null ? "" : ActualAmountToBePaid.toLogString()));
							}

///////////////////////		

							String[] row_tLogRow_4 = new String[2];

							if (ActualAmountToBePaid.PatientID != null) { //
								row_tLogRow_4[0] = String.valueOf(ActualAmountToBePaid.PatientID);

							} //

							if (ActualAmountToBePaid.ActualAmountToBePaid != null) { //
								row_tLogRow_4[1] = String.valueOf(ActualAmountToBePaid.ActualAmountToBePaid);

							} //

							util_tLogRow_4.addRow(row_tLogRow_4);
							nb_line_tLogRow_4++;
							log.info("tLogRow_4 - Content of row " + nb_line_tLogRow_4 + ": "
									+ TalendString.unionString("|", row_tLogRow_4));
//////

//////                    

///////////////////////    			

							tos_count_tLogRow_4++;

							/**
							 * [tLogRow_4 main ] stop
							 */

							/**
							 * [tLogRow_4 process_data_begin ] start
							 */

							currentComponent = "tLogRow_4";

							cLabel = "ActualAmount";

							/**
							 * [tLogRow_4 process_data_begin ] stop
							 */

							/**
							 * [tLogRow_4 process_data_end ] start
							 */

							currentComponent = "tLogRow_4";

							cLabel = "ActualAmount";

							/**
							 * [tLogRow_4 process_data_end ] stop
							 */

						} // End of branch "ActualAmountToBePaid"

						/**
						 * [tMap_5 process_data_end ] start
						 */

						currentComponent = "tMap_5";

						/**
						 * [tMap_5 process_data_end ] stop
						 */

						/**
						 * [tDBInput_5 process_data_end ] start
						 */

						currentComponent = "tDBInput_5";

						cLabel = "Billing";

						/**
						 * [tDBInput_5 process_data_end ] stop
						 */

						/**
						 * [tDBInput_5 end ] start
						 */

						currentComponent = "tDBInput_5";

						cLabel = "Billing";

					}
				} finally {
					if (rs_tDBInput_5 != null) {
						rs_tDBInput_5.close();
					}
					if (stmt_tDBInput_5 != null) {
						stmt_tDBInput_5.close();
					}
					if (conn_tDBInput_5 != null && !conn_tDBInput_5.isClosed()) {

						log.debug("tDBInput_5 - Closing the connection to the database.");

						conn_tDBInput_5.close();

						if ("com.mysql.cj.jdbc.Driver".equals((String) globalMap.get("driverClass_"))
								&& routines.system.BundleUtils.inOSGi()) {
							Class.forName("com.mysql.cj.jdbc.AbandonedConnectionCleanupThread")
									.getMethod("checkedShutdown").invoke(null, (Object[]) null);
						}

						log.debug("tDBInput_5 - Connection to the database closed.");

					}

				}
				globalMap.put("tDBInput_5_NB_LINE", nb_line_tDBInput_5);
				log.debug("tDBInput_5 - Retrieved records count: " + nb_line_tDBInput_5 + " .");

				if (log.isDebugEnabled())
					log.debug("tDBInput_5 - " + ("Done."));

				ok_Hash.put("tDBInput_5", true);
				end_Hash.put("tDBInput_5", System.currentTimeMillis());

				/**
				 * [tDBInput_5 end ] stop
				 */

				/**
				 * [tMap_5 end ] start
				 */

				currentComponent = "tMap_5";

// ###############################
// # Lookup hashes releasing
// ###############################      
				log.debug("tMap_5 - Written records count in the table 'NotCoveredByInsurance': "
						+ count_NotCoveredByInsurance_tMap_5 + ".");
				log.debug("tMap_5 - Written records count in the table 'MaxToBePaidPhysician': "
						+ count_MaxToBePaidPhysician_tMap_5 + ".");
				log.debug("tMap_5 - Written records count in the table 'ThisMonthPayment': "
						+ count_ThisMonthPayment_tMap_5 + ".");
				log.debug("tMap_5 - Written records count in the table 'ActualAmountToBePaid': "
						+ count_ActualAmountToBePaid_tMap_5 + ".");

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "row8", 2, 0,
						"tDBInput_5", "Billing", "tMysqlInput", "tMap_5", "tMap_5", "tMap", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tMap_5 - " + ("Done."));

				ok_Hash.put("tMap_5", true);
				end_Hash.put("tMap_5", System.currentTimeMillis());

				/**
				 * [tMap_5 end ] stop
				 */

				/**
				 * [tFileOutputExcel_11 end ] start
				 */

				currentComponent = "tFileOutputExcel_11";

				cLabel = "NotCoveredByInsurance";

				columnIndex_tFileOutputExcel_11 = 0;

				// modif start

				writableSheet_tFileOutputExcel_11.setColumnView(columnIndex_tFileOutputExcel_11,
						fitWidth_tFileOutputExcel_11[0]);

				// modif end

				columnIndex_tFileOutputExcel_11 = 1;

				// modif start

				writableSheet_tFileOutputExcel_11.setColumnView(columnIndex_tFileOutputExcel_11,
						fitWidth_tFileOutputExcel_11[1]);

				// modif end

				columnIndex_tFileOutputExcel_11 = 2;

				// modif start

				writableSheet_tFileOutputExcel_11.setColumnView(columnIndex_tFileOutputExcel_11,
						fitWidth_tFileOutputExcel_11[2]);

				// modif end

				columnIndex_tFileOutputExcel_11 = 3;

				// modif start

				writableSheet_tFileOutputExcel_11.setColumnView(columnIndex_tFileOutputExcel_11,
						fitWidth_tFileOutputExcel_11[3]);

				// modif end

				columnIndex_tFileOutputExcel_11 = 4;

				// modif start

				writableSheet_tFileOutputExcel_11.setColumnView(columnIndex_tFileOutputExcel_11,
						fitWidth_tFileOutputExcel_11[4]);

				// modif end

				columnIndex_tFileOutputExcel_11 = 5;

				// modif start

				writableSheet_tFileOutputExcel_11.setColumnView(columnIndex_tFileOutputExcel_11,
						fitWidth_tFileOutputExcel_11[5]);

				// modif end

				writeableWorkbook_tFileOutputExcel_11.write();
				writeableWorkbook_tFileOutputExcel_11.close();
				if (headerIsInserted_tFileOutputExcel_11 && nb_line_tFileOutputExcel_11 > 0) {
					nb_line_tFileOutputExcel_11 = nb_line_tFileOutputExcel_11 - 1;
				}
				globalMap.put("tFileOutputExcel_11_NB_LINE", nb_line_tFileOutputExcel_11);

				log.debug("tFileOutputExcel_11 - Written records count: " + nb_line_tFileOutputExcel_11 + " .");

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "NotCoveredByInsurance",
						2, 0, "tMap_5", "tMap_5", "tMap", "tFileOutputExcel_11", "NotCoveredByInsurance",
						"tFileOutputExcel", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tFileOutputExcel_11 - " + ("Done."));

				ok_Hash.put("tFileOutputExcel_11", true);
				end_Hash.put("tFileOutputExcel_11", System.currentTimeMillis());

				/**
				 * [tFileOutputExcel_11 end ] stop
				 */

				/**
				 * [tAggregateRow_2_AGGOUT end ] start
				 */

				currentVirtualComponent = "tAggregateRow_2";

				currentComponent = "tAggregateRow_2_AGGOUT";

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "MaxToBePaidPhysician",
						2, 0, "tMap_5", "tMap_5", "tMap", "tAggregateRow_2_AGGOUT", "tAggregateRow_2_AGGOUT",
						"tAggregateOut", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tAggregateRow_2_AGGOUT - " + ("Done."));

				ok_Hash.put("tAggregateRow_2_AGGOUT", true);
				end_Hash.put("tAggregateRow_2_AGGOUT", System.currentTimeMillis());

				/**
				 * [tAggregateRow_2_AGGOUT end ] stop
				 */

				/**
				 * [tSortRow_3_SortOut begin ] start
				 */

				ok_Hash.put("tSortRow_3_SortOut", false);
				start_Hash.put("tSortRow_3_SortOut", System.currentTimeMillis());

				currentVirtualComponent = "tSortRow_3";

				currentComponent = "tSortRow_3_SortOut";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "row9");

				int tos_count_tSortRow_3_SortOut = 0;

				if (log.isDebugEnabled())
					log.debug("tSortRow_3_SortOut - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tSortRow_3_SortOut {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tSortRow_3_SortOut = new StringBuilder();
							log4jParamters_tSortRow_3_SortOut.append("Parameters:");
							log4jParamters_tSortRow_3_SortOut.append("DESTINATION" + " = " + "tSortRow_3");
							log4jParamters_tSortRow_3_SortOut.append(" | ");
							log4jParamters_tSortRow_3_SortOut.append("EXTERNAL" + " = " + "false");
							log4jParamters_tSortRow_3_SortOut.append(" | ");
							log4jParamters_tSortRow_3_SortOut.append("CRITERIA" + " = " + "[{ORDER=" + ("desc")
									+ ", COLNAME=" + ("TotalAmountPerPhysician") + ", SORT=" + ("num") + "}]");
							log4jParamters_tSortRow_3_SortOut.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tSortRow_3_SortOut - " + (log4jParamters_tSortRow_3_SortOut));
						}
					}
					new BytesLimit65535_tSortRow_3_SortOut().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tSortRow_3_SortOut", "tSortRow_3_SortOut", "tSortOut");
					talendJobLogProcess(globalMap);
				}

				class Comparablerow9Struct extends row9Struct implements Comparable<Comparablerow9Struct> {

					public int compareTo(Comparablerow9Struct other) {

						if (this.TotalAmountPerPhysician == null && other.TotalAmountPerPhysician != null) {
							return 1;

						} else if (this.TotalAmountPerPhysician != null && other.TotalAmountPerPhysician == null) {
							return -1;

						} else if (this.TotalAmountPerPhysician != null && other.TotalAmountPerPhysician != null) {
							if (!this.TotalAmountPerPhysician.equals(other.TotalAmountPerPhysician)) {
								return other.TotalAmountPerPhysician.compareTo(this.TotalAmountPerPhysician);
							}
						}
						return 0;
					}
				}

				java.util.List<Comparablerow9Struct> list_tSortRow_3_SortOut = new java.util.ArrayList<Comparablerow9Struct>();

				/**
				 * [tSortRow_3_SortOut begin ] stop
				 */

				/**
				 * [tAggregateRow_2_AGGIN begin ] start
				 */

				ok_Hash.put("tAggregateRow_2_AGGIN", false);
				start_Hash.put("tAggregateRow_2_AGGIN", System.currentTimeMillis());

				currentVirtualComponent = "tAggregateRow_2";

				currentComponent = "tAggregateRow_2_AGGIN";

				int tos_count_tAggregateRow_2_AGGIN = 0;

				if (log.isDebugEnabled())
					log.debug("tAggregateRow_2_AGGIN - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tAggregateRow_2_AGGIN {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tAggregateRow_2_AGGIN = new StringBuilder();
							log4jParamters_tAggregateRow_2_AGGIN.append("Parameters:");
							log4jParamters_tAggregateRow_2_AGGIN.append("ORIGIN" + " = " + "tAggregateRow_2");
							log4jParamters_tAggregateRow_2_AGGIN.append(" | ");
							log4jParamters_tAggregateRow_2_AGGIN.append("GROUPBYS" + " = " + "[{OUTPUT_COLUMN="
									+ ("PhysicianID") + ", INPUT_COLUMN=" + ("PhysicianID") + "}]");
							log4jParamters_tAggregateRow_2_AGGIN.append(" | ");
							log4jParamters_tAggregateRow_2_AGGIN.append("OPERATIONS" + " = " + "[{OUTPUT_COLUMN="
									+ ("TotalAmountPerPhysician") + ", INPUT_COLUMN=" + ("AmountToBePaid")
									+ ", IGNORE_NULL=" + ("false") + ", FUNCTION=" + ("sum") + "}]");
							log4jParamters_tAggregateRow_2_AGGIN.append(" | ");
							log4jParamters_tAggregateRow_2_AGGIN.append("LIST_DELIMITER" + " = " + "\",\"");
							log4jParamters_tAggregateRow_2_AGGIN.append(" | ");
							log4jParamters_tAggregateRow_2_AGGIN.append("USE_FINANCIAL_PRECISION" + " = " + "true");
							log4jParamters_tAggregateRow_2_AGGIN.append(" | ");
							log4jParamters_tAggregateRow_2_AGGIN.append("CHECK_TYPE_OVERFLOW" + " = " + "false");
							log4jParamters_tAggregateRow_2_AGGIN.append(" | ");
							log4jParamters_tAggregateRow_2_AGGIN.append("CHECK_ULP" + " = " + "false");
							log4jParamters_tAggregateRow_2_AGGIN.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tAggregateRow_2_AGGIN - " + (log4jParamters_tAggregateRow_2_AGGIN));
						}
					}
					new BytesLimit65535_tAggregateRow_2_AGGIN().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tAggregateRow_2_AGGIN", "tAggregateRow_2_AGGIN", "tAggregateIn");
					talendJobLogProcess(globalMap);
				}

				java.util.Collection<AggOperationStruct_tAggregateRow_2> values_tAggregateRow_2 = hash_tAggregateRow_2
						.values();

				globalMap.put("tAggregateRow_2_NB_LINE", values_tAggregateRow_2.size());

				if (log.isInfoEnabled())
					log.info("tAggregateRow_2_AGGIN - " + ("Retrieving the aggregation results."));
				for (AggOperationStruct_tAggregateRow_2 aggregated_row_tAggregateRow_2 : values_tAggregateRow_2) { // G_AggR_600

					/**
					 * [tAggregateRow_2_AGGIN begin ] stop
					 */

					/**
					 * [tAggregateRow_2_AGGIN main ] start
					 */

					currentVirtualComponent = "tAggregateRow_2";

					currentComponent = "tAggregateRow_2_AGGIN";

					row9.PhysicianID = aggregated_row_tAggregateRow_2.PhysicianID;
					row9.TotalAmountPerPhysician = aggregated_row_tAggregateRow_2.TotalAmountPerPhysician_sum;

					if (log.isDebugEnabled())
						log.debug("tAggregateRow_2_AGGIN - "
								+ ("Operation function: 'sum' on the column 'AmountToBePaid'."));

					tos_count_tAggregateRow_2_AGGIN++;

					/**
					 * [tAggregateRow_2_AGGIN main ] stop
					 */

					/**
					 * [tAggregateRow_2_AGGIN process_data_begin ] start
					 */

					currentVirtualComponent = "tAggregateRow_2";

					currentComponent = "tAggregateRow_2_AGGIN";

					/**
					 * [tAggregateRow_2_AGGIN process_data_begin ] stop
					 */

					/**
					 * [tSortRow_3_SortOut main ] start
					 */

					currentVirtualComponent = "tSortRow_3";

					currentComponent = "tSortRow_3_SortOut";

					if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

							, "row9", "tAggregateRow_2_AGGIN", "tAggregateRow_2_AGGIN", "tAggregateIn",
							"tSortRow_3_SortOut", "tSortRow_3_SortOut", "tSortOut"

					)) {
						talendJobLogProcess(globalMap);
					}

					if (log.isTraceEnabled()) {
						log.trace("row9 - " + (row9 == null ? "" : row9.toLogString()));
					}

					Comparablerow9Struct arrayRowtSortRow_3_SortOut = new Comparablerow9Struct();

					arrayRowtSortRow_3_SortOut.PhysicianID = row9.PhysicianID;
					arrayRowtSortRow_3_SortOut.TotalAmountPerPhysician = row9.TotalAmountPerPhysician;
					list_tSortRow_3_SortOut.add(arrayRowtSortRow_3_SortOut);

					tos_count_tSortRow_3_SortOut++;

					/**
					 * [tSortRow_3_SortOut main ] stop
					 */

					/**
					 * [tSortRow_3_SortOut process_data_begin ] start
					 */

					currentVirtualComponent = "tSortRow_3";

					currentComponent = "tSortRow_3_SortOut";

					/**
					 * [tSortRow_3_SortOut process_data_begin ] stop
					 */

					/**
					 * [tSortRow_3_SortOut process_data_end ] start
					 */

					currentVirtualComponent = "tSortRow_3";

					currentComponent = "tSortRow_3_SortOut";

					/**
					 * [tSortRow_3_SortOut process_data_end ] stop
					 */

					/**
					 * [tAggregateRow_2_AGGIN process_data_end ] start
					 */

					currentVirtualComponent = "tAggregateRow_2";

					currentComponent = "tAggregateRow_2_AGGIN";

					/**
					 * [tAggregateRow_2_AGGIN process_data_end ] stop
					 */

					/**
					 * [tAggregateRow_2_AGGIN end ] start
					 */

					currentVirtualComponent = "tAggregateRow_2";

					currentComponent = "tAggregateRow_2_AGGIN";

				} // G_AggR_600

				if (log.isDebugEnabled())
					log.debug("tAggregateRow_2_AGGIN - " + ("Done."));

				ok_Hash.put("tAggregateRow_2_AGGIN", true);
				end_Hash.put("tAggregateRow_2_AGGIN", System.currentTimeMillis());

				/**
				 * [tAggregateRow_2_AGGIN end ] stop
				 */

				/**
				 * [tSortRow_3_SortOut end ] start
				 */

				currentVirtualComponent = "tSortRow_3";

				currentComponent = "tSortRow_3_SortOut";

				row9Struct[] array_tSortRow_3_SortOut = list_tSortRow_3_SortOut.toArray(new Comparablerow9Struct[0]);

				java.util.Arrays.sort(array_tSortRow_3_SortOut);

				globalMap.put("tSortRow_3", array_tSortRow_3_SortOut);

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "row9", 2, 0,
						"tAggregateRow_2_AGGIN", "tAggregateRow_2_AGGIN", "tAggregateIn", "tSortRow_3_SortOut",
						"tSortRow_3_SortOut", "tSortOut", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tSortRow_3_SortOut - " + ("Done."));

				ok_Hash.put("tSortRow_3_SortOut", true);
				end_Hash.put("tSortRow_3_SortOut", System.currentTimeMillis());

				/**
				 * [tSortRow_3_SortOut end ] stop
				 */

				/**
				 * [tLogRow_2 begin ] start
				 */

				ok_Hash.put("tLogRow_2", false);
				start_Hash.put("tLogRow_2", System.currentTimeMillis());

				currentComponent = "tLogRow_2";

				cLabel = "MaxPaymentPhysician";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "row13");

				int tos_count_tLogRow_2 = 0;

				if (log.isDebugEnabled())
					log.debug("tLogRow_2 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tLogRow_2 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tLogRow_2 = new StringBuilder();
							log4jParamters_tLogRow_2.append("Parameters:");
							log4jParamters_tLogRow_2.append("BASIC_MODE" + " = " + "false");
							log4jParamters_tLogRow_2.append(" | ");
							log4jParamters_tLogRow_2.append("TABLE_PRINT" + " = " + "true");
							log4jParamters_tLogRow_2.append(" | ");
							log4jParamters_tLogRow_2.append("VERTICAL" + " = " + "false");
							log4jParamters_tLogRow_2.append(" | ");
							log4jParamters_tLogRow_2.append("PRINT_CONTENT_WITH_LOG4J" + " = " + "true");
							log4jParamters_tLogRow_2.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tLogRow_2 - " + (log4jParamters_tLogRow_2));
						}
					}
					new BytesLimit65535_tLogRow_2().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tLogRow_2", "MaxPaymentPhysician", "tLogRow");
					talendJobLogProcess(globalMap);
				}

				///////////////////////

				class Util_tLogRow_2 {

					String[] des_top = { ".", ".", "-", "+" };

					String[] des_head = { "|=", "=|", "-", "+" };

					String[] des_bottom = { "'", "'", "-", "+" };

					String name = "";

					java.util.List<String[]> list = new java.util.ArrayList<String[]>();

					int[] colLengths = new int[2];

					public void addRow(String[] row) {

						for (int i = 0; i < 2; i++) {
							if (row[i] != null) {
								colLengths[i] = Math.max(colLengths[i], row[i].length());
							}
						}
						list.add(row);
					}

					public void setTableName(String name) {

						this.name = name;
					}

					public StringBuilder format() {

						StringBuilder sb = new StringBuilder();

						sb.append(print(des_top));

						int totals = 0;
						for (int i = 0; i < colLengths.length; i++) {
							totals = totals + colLengths[i];
						}

						// name
						sb.append("|");
						int k = 0;
						for (k = 0; k < (totals + 1 - name.length()) / 2; k++) {
							sb.append(' ');
						}
						sb.append(name);
						for (int i = 0; i < totals + 1 - name.length() - k; i++) {
							sb.append(' ');
						}
						sb.append("|\n");

						// head and rows
						sb.append(print(des_head));
						for (int i = 0; i < list.size(); i++) {

							String[] row = list.get(i);

							java.util.Formatter formatter = new java.util.Formatter(new StringBuilder());

							StringBuilder sbformat = new StringBuilder();
							sbformat.append("|%1$-");
							sbformat.append(colLengths[0]);
							sbformat.append("s");

							sbformat.append("|%2$-");
							sbformat.append(colLengths[1]);
							sbformat.append("s");

							sbformat.append("|\n");

							formatter.format(sbformat.toString(), (Object[]) row);

							sb.append(formatter.toString());
							if (i == 0)
								sb.append(print(des_head)); // print the head
						}

						// end
						sb.append(print(des_bottom));
						return sb;
					}

					private StringBuilder print(String[] fillChars) {
						StringBuilder sb = new StringBuilder();
						// first column
						sb.append(fillChars[0]);
						for (int i = 0; i < colLengths[0] - fillChars[0].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);

						// last column
						for (int i = 0; i < colLengths[1] - fillChars[1].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[1]);
						sb.append("\n");
						return sb;
					}

					public boolean isTableEmpty() {
						if (list.size() > 1)
							return false;
						return true;
					}
				}
				Util_tLogRow_2 util_tLogRow_2 = new Util_tLogRow_2();
				util_tLogRow_2.setTableName("MaxPaymentPhysician");
				util_tLogRow_2.addRow(new String[] { "PhysicianID", "TotalAmountPerPhysician", });
				StringBuilder strBuffer_tLogRow_2 = null;
				int nb_line_tLogRow_2 = 0;
///////////////////////    			

				/**
				 * [tLogRow_2 begin ] stop
				 */

				/**
				 * [tJoin_1 begin ] start
				 */

				ok_Hash.put("tJoin_1", false);
				start_Hash.put("tJoin_1", System.currentTimeMillis());

				currentComponent = "tJoin_1";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "row11");

				int tos_count_tJoin_1 = 0;

				if (log.isDebugEnabled())
					log.debug("tJoin_1 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tJoin_1 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tJoin_1 = new StringBuilder();
							log4jParamters_tJoin_1.append("Parameters:");
							log4jParamters_tJoin_1.append("USE_LOOKUP_COLS" + " = " + "false");
							log4jParamters_tJoin_1.append(" | ");
							log4jParamters_tJoin_1.append("JOIN_KEY" + " = " + "[{INPUT_COLUMN=" + ("PhysicianID")
									+ ", LOOKUP_COLUMN=" + ("PhysicianID") + "}]");
							log4jParamters_tJoin_1.append(" | ");
							log4jParamters_tJoin_1.append("USE_INNER_JOIN" + " = " + "false");
							log4jParamters_tJoin_1.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tJoin_1 - " + (log4jParamters_tJoin_1));
						}
					}
					new BytesLimit65535_tJoin_1().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tJoin_1", "tJoin_1", "tJoin");
					talendJobLogProcess(globalMap);
				}

				final java.util.Map<row12Struct, row12Struct> tHash_tJoin_1 = (java.util.Map<row12Struct, row12Struct>) globalMap
						.get("tHash_row12");

				class Util_tJoin_1 {
					row12Struct lookupValue = null;
					row12Struct row12HashKey = new row12Struct();

					public boolean isJoined(row11Struct mainRow) {
						row12HashKey.PhysicianID = mainRow.PhysicianID;

						row12HashKey.hashCodeDirty = true;
						lookupValue = tHash_tJoin_1.get(row12HashKey);
						if (lookupValue != null) {
							return true;
						} else {
						}
						return false;
					}
				}

				Util_tJoin_1 util_tJoin_1 = new Util_tJoin_1();

				int nb_line_tJoin_1 = 0;

				/**
				 * [tJoin_1 begin ] stop
				 */

				/**
				 * [tSampleRow_1 begin ] start
				 */

				ok_Hash.put("tSampleRow_1", false);
				start_Hash.put("tSampleRow_1", System.currentTimeMillis());

				currentComponent = "tSampleRow_1";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "row10");

				int tos_count_tSampleRow_1 = 0;

				if (log.isDebugEnabled())
					log.debug("tSampleRow_1 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tSampleRow_1 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tSampleRow_1 = new StringBuilder();
							log4jParamters_tSampleRow_1.append("Parameters:");
							log4jParamters_tSampleRow_1.append("RANGE" + " = " + "\"1\"");
							log4jParamters_tSampleRow_1.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tSampleRow_1 - " + (log4jParamters_tSampleRow_1));
						}
					}
					new BytesLimit65535_tSampleRow_1().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tSampleRow_1", "tSampleRow_1", "tSampleRow");
					talendJobLogProcess(globalMap);
				}

				String[] rangetSampleRow_1 = "1".split(",");
				java.util.Set rangeSettSampleRow_1 = new java.util.HashSet();

				Integer nb_line_tSampleRow_1 = 0;

				for (int i = 0; i < rangetSampleRow_1.length; i++) {

					if (rangetSampleRow_1[i].matches("\\d+")) {

						rangeSettSampleRow_1.add(Integer.valueOf(rangetSampleRow_1[i]));

					} else if (rangetSampleRow_1[i].matches("\\d+\\.\\.\\d+")) {

						String[] edgetSampleRow_1 = rangetSampleRow_1[i].split("\\.\\.");

						for (int j = Integer.valueOf(edgetSampleRow_1[0]).intValue(); j < Integer
								.valueOf(edgetSampleRow_1[1]).intValue() + 1; j++) {
							rangeSettSampleRow_1.add(Integer.valueOf(j));
						}
					} else {

					}

				}

				/**
				 * [tSampleRow_1 begin ] stop
				 */

				/**
				 * [tSortRow_3_SortIn begin ] start
				 */

				ok_Hash.put("tSortRow_3_SortIn", false);
				start_Hash.put("tSortRow_3_SortIn", System.currentTimeMillis());

				currentVirtualComponent = "tSortRow_3";

				currentComponent = "tSortRow_3_SortIn";

				int tos_count_tSortRow_3_SortIn = 0;

				if (log.isDebugEnabled())
					log.debug("tSortRow_3_SortIn - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tSortRow_3_SortIn {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tSortRow_3_SortIn = new StringBuilder();
							log4jParamters_tSortRow_3_SortIn.append("Parameters:");
							log4jParamters_tSortRow_3_SortIn.append("ORIGIN" + " = " + "tSortRow_3");
							log4jParamters_tSortRow_3_SortIn.append(" | ");
							log4jParamters_tSortRow_3_SortIn.append("EXTERNAL" + " = " + "false");
							log4jParamters_tSortRow_3_SortIn.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tSortRow_3_SortIn - " + (log4jParamters_tSortRow_3_SortIn));
						}
					}
					new BytesLimit65535_tSortRow_3_SortIn().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tSortRow_3_SortIn", "tSortRow_3_SortIn", "tSortIn");
					talendJobLogProcess(globalMap);
				}

				row9Struct[] array_tSortRow_3_SortIn = (row9Struct[]) globalMap.remove("tSortRow_3");

				int nb_line_tSortRow_3_SortIn = 0;

				row9Struct current_tSortRow_3_SortIn = null;

				for (int i_tSortRow_3_SortIn = 0; i_tSortRow_3_SortIn < array_tSortRow_3_SortIn.length; i_tSortRow_3_SortIn++) {
					current_tSortRow_3_SortIn = array_tSortRow_3_SortIn[i_tSortRow_3_SortIn];
					row10.PhysicianID = current_tSortRow_3_SortIn.PhysicianID;
					row10.TotalAmountPerPhysician = current_tSortRow_3_SortIn.TotalAmountPerPhysician;
					// increase number of line sorted
					nb_line_tSortRow_3_SortIn++;

					/**
					 * [tSortRow_3_SortIn begin ] stop
					 */

					/**
					 * [tSortRow_3_SortIn main ] start
					 */

					currentVirtualComponent = "tSortRow_3";

					currentComponent = "tSortRow_3_SortIn";

					tos_count_tSortRow_3_SortIn++;

					/**
					 * [tSortRow_3_SortIn main ] stop
					 */

					/**
					 * [tSortRow_3_SortIn process_data_begin ] start
					 */

					currentVirtualComponent = "tSortRow_3";

					currentComponent = "tSortRow_3_SortIn";

					/**
					 * [tSortRow_3_SortIn process_data_begin ] stop
					 */

					/**
					 * [tSampleRow_1 main ] start
					 */

					currentComponent = "tSampleRow_1";

					if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

							, "row10", "tSortRow_3_SortIn", "tSortRow_3_SortIn", "tSortIn", "tSampleRow_1",
							"tSampleRow_1", "tSampleRow"

					)) {
						talendJobLogProcess(globalMap);
					}

					if (log.isTraceEnabled()) {
						log.trace("row10 - " + (row10 == null ? "" : row10.toLogString()));
					}

					nb_line_tSampleRow_1++;

					if (!rangeSettSampleRow_1.contains(nb_line_tSampleRow_1)) {
						row11 = null;
					} else {
						row11 = new row11Struct();

						row11.PhysicianID = row10.PhysicianID;

						row11.TotalAmountPerPhysician = row10.TotalAmountPerPhysician;

					}

					tos_count_tSampleRow_1++;

					/**
					 * [tSampleRow_1 main ] stop
					 */

					/**
					 * [tSampleRow_1 process_data_begin ] start
					 */

					currentComponent = "tSampleRow_1";

					/**
					 * [tSampleRow_1 process_data_begin ] stop
					 */
// Start of branch "row11"
					if (row11 != null) {

						/**
						 * [tJoin_1 main ] start
						 */

						currentComponent = "tJoin_1";

						if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

								, "row11", "tSampleRow_1", "tSampleRow_1", "tSampleRow", "tJoin_1", "tJoin_1", "tJoin"

						)) {
							talendJobLogProcess(globalMap);
						}

						if (log.isTraceEnabled()) {
							log.trace("row11 - " + (row11 == null ? "" : row11.toLogString()));
						}

						row13 = null;

						row13 = new row13Struct();
						row13.PhysicianID = row11.PhysicianID;
						row13.TotalAmountPerPhysician = row11.TotalAmountPerPhysician;

						if (util_tJoin_1.isJoined(row11)) {
						}

///////////////////////    			

						tos_count_tJoin_1++;

						/**
						 * [tJoin_1 main ] stop
						 */

						/**
						 * [tJoin_1 process_data_begin ] start
						 */

						currentComponent = "tJoin_1";

						/**
						 * [tJoin_1 process_data_begin ] stop
						 */
// Start of branch "row13"
						if (row13 != null) {

							/**
							 * [tLogRow_2 main ] start
							 */

							currentComponent = "tLogRow_2";

							cLabel = "MaxPaymentPhysician";

							if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

									, "row13", "tJoin_1", "tJoin_1", "tJoin", "tLogRow_2", "MaxPaymentPhysician",
									"tLogRow"

							)) {
								talendJobLogProcess(globalMap);
							}

							if (log.isTraceEnabled()) {
								log.trace("row13 - " + (row13 == null ? "" : row13.toLogString()));
							}

///////////////////////		

							String[] row_tLogRow_2 = new String[2];

							if (row13.PhysicianID != null) { //
								row_tLogRow_2[0] = String.valueOf(row13.PhysicianID);

							} //

							if (row13.TotalAmountPerPhysician != null) { //
								row_tLogRow_2[1] = String.valueOf(row13.TotalAmountPerPhysician);

							} //

							util_tLogRow_2.addRow(row_tLogRow_2);
							nb_line_tLogRow_2++;
							log.info("tLogRow_2 - Content of row " + nb_line_tLogRow_2 + ": "
									+ TalendString.unionString("|", row_tLogRow_2));
//////

//////                    

///////////////////////    			

							tos_count_tLogRow_2++;

							/**
							 * [tLogRow_2 main ] stop
							 */

							/**
							 * [tLogRow_2 process_data_begin ] start
							 */

							currentComponent = "tLogRow_2";

							cLabel = "MaxPaymentPhysician";

							/**
							 * [tLogRow_2 process_data_begin ] stop
							 */

							/**
							 * [tLogRow_2 process_data_end ] start
							 */

							currentComponent = "tLogRow_2";

							cLabel = "MaxPaymentPhysician";

							/**
							 * [tLogRow_2 process_data_end ] stop
							 */

						} // End of branch "row13"

						/**
						 * [tJoin_1 process_data_end ] start
						 */

						currentComponent = "tJoin_1";

						/**
						 * [tJoin_1 process_data_end ] stop
						 */

					} // End of branch "row11"

					/**
					 * [tSampleRow_1 process_data_end ] start
					 */

					currentComponent = "tSampleRow_1";

					/**
					 * [tSampleRow_1 process_data_end ] stop
					 */

					/**
					 * [tSortRow_3_SortIn process_data_end ] start
					 */

					currentVirtualComponent = "tSortRow_3";

					currentComponent = "tSortRow_3_SortIn";

					/**
					 * [tSortRow_3_SortIn process_data_end ] stop
					 */

					/**
					 * [tSortRow_3_SortIn end ] start
					 */

					currentVirtualComponent = "tSortRow_3";

					currentComponent = "tSortRow_3_SortIn";

				}

				globalMap.put("tSortRow_3_SortIn_NB_LINE", nb_line_tSortRow_3_SortIn);

				if (log.isDebugEnabled())
					log.debug("tSortRow_3_SortIn - " + ("Done."));

				ok_Hash.put("tSortRow_3_SortIn", true);
				end_Hash.put("tSortRow_3_SortIn", System.currentTimeMillis());

				/**
				 * [tSortRow_3_SortIn end ] stop
				 */

				/**
				 * [tSampleRow_1 end ] start
				 */

				currentComponent = "tSampleRow_1";

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "row10", 2, 0,
						"tSortRow_3_SortIn", "tSortRow_3_SortIn", "tSortIn", "tSampleRow_1", "tSampleRow_1",
						"tSampleRow", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tSampleRow_1 - " + ("Done."));

				ok_Hash.put("tSampleRow_1", true);
				end_Hash.put("tSampleRow_1", System.currentTimeMillis());

				/**
				 * [tSampleRow_1 end ] stop
				 */

				/**
				 * [tJoin_1 end ] start
				 */

				currentComponent = "tJoin_1";

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "row11", 2, 0,
						"tSampleRow_1", "tSampleRow_1", "tSampleRow", "tJoin_1", "tJoin_1", "tJoin", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tJoin_1 - " + ("Done."));

				ok_Hash.put("tJoin_1", true);
				end_Hash.put("tJoin_1", System.currentTimeMillis());

				/**
				 * [tJoin_1 end ] stop
				 */

				/**
				 * [tLogRow_2 end ] start
				 */

				currentComponent = "tLogRow_2";

				cLabel = "MaxPaymentPhysician";

//////

				java.io.PrintStream consoleOut_tLogRow_2 = null;
				if (globalMap.get("tLogRow_CONSOLE") != null) {
					consoleOut_tLogRow_2 = (java.io.PrintStream) globalMap.get("tLogRow_CONSOLE");
				} else {
					consoleOut_tLogRow_2 = new java.io.PrintStream(new java.io.BufferedOutputStream(System.out));
					globalMap.put("tLogRow_CONSOLE", consoleOut_tLogRow_2);
				}

				consoleOut_tLogRow_2.println(util_tLogRow_2.format().toString());
				consoleOut_tLogRow_2.flush();
//////
				globalMap.put("tLogRow_2_NB_LINE", nb_line_tLogRow_2);
				if (log.isInfoEnabled())
					log.info("tLogRow_2 - " + ("Printed row count: ") + (nb_line_tLogRow_2) + ("."));

///////////////////////    			

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "row13", 2, 0, "tJoin_1",
						"tJoin_1", "tJoin", "tLogRow_2", "MaxPaymentPhysician", "tLogRow", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tLogRow_2 - " + ("Done."));

				ok_Hash.put("tLogRow_2", true);
				end_Hash.put("tLogRow_2", System.currentTimeMillis());

				/**
				 * [tLogRow_2 end ] stop
				 */

				/**
				 * [tLogRow_3 end ] start
				 */

				currentComponent = "tLogRow_3";

				cLabel = "CurrentMonthPayment";

//////

				java.io.PrintStream consoleOut_tLogRow_3 = null;
				if (globalMap.get("tLogRow_CONSOLE") != null) {
					consoleOut_tLogRow_3 = (java.io.PrintStream) globalMap.get("tLogRow_CONSOLE");
				} else {
					consoleOut_tLogRow_3 = new java.io.PrintStream(new java.io.BufferedOutputStream(System.out));
					globalMap.put("tLogRow_CONSOLE", consoleOut_tLogRow_3);
				}

				consoleOut_tLogRow_3.println(util_tLogRow_3.format().toString());
				consoleOut_tLogRow_3.flush();
//////
				globalMap.put("tLogRow_3_NB_LINE", nb_line_tLogRow_3);
				if (log.isInfoEnabled())
					log.info("tLogRow_3 - " + ("Printed row count: ") + (nb_line_tLogRow_3) + ("."));

///////////////////////    			

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "ThisMonthPayment", 2, 0,
						"tMap_5", "tMap_5", "tMap", "tLogRow_3", "CurrentMonthPayment", "tLogRow", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tLogRow_3 - " + ("Done."));

				ok_Hash.put("tLogRow_3", true);
				end_Hash.put("tLogRow_3", System.currentTimeMillis());

				/**
				 * [tLogRow_3 end ] stop
				 */

				/**
				 * [tLogRow_4 end ] start
				 */

				currentComponent = "tLogRow_4";

				cLabel = "ActualAmount";

//////

				java.io.PrintStream consoleOut_tLogRow_4 = null;
				if (globalMap.get("tLogRow_CONSOLE") != null) {
					consoleOut_tLogRow_4 = (java.io.PrintStream) globalMap.get("tLogRow_CONSOLE");
				} else {
					consoleOut_tLogRow_4 = new java.io.PrintStream(new java.io.BufferedOutputStream(System.out));
					globalMap.put("tLogRow_CONSOLE", consoleOut_tLogRow_4);
				}

				consoleOut_tLogRow_4.println(util_tLogRow_4.format().toString());
				consoleOut_tLogRow_4.flush();
//////
				globalMap.put("tLogRow_4_NB_LINE", nb_line_tLogRow_4);
				if (log.isInfoEnabled())
					log.info("tLogRow_4 - " + ("Printed row count: ") + (nb_line_tLogRow_4) + ("."));

///////////////////////    			

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "ActualAmountToBePaid",
						2, 0, "tMap_5", "tMap_5", "tMap", "tLogRow_4", "ActualAmount", "tLogRow", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tLogRow_4 - " + ("Done."));

				ok_Hash.put("tLogRow_4", true);
				end_Hash.put("tLogRow_4", System.currentTimeMillis());

				/**
				 * [tLogRow_4 end ] stop
				 */

			} // end the resume

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage(), e);
			}

			TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);

			te.setVirtualComponentName(currentVirtualComponent);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			// free memory for "tJoin_1"
			globalMap.remove("tHash_row12");

			// free memory for "tSortRow_3_SortIn"
			globalMap.remove("tSortRow_3");

			// free memory for "tAggregateRow_2_AGGIN"
			globalMap.remove("tAggregateRow_2");

			try {

				/**
				 * [tDBInput_5 finally ] start
				 */

				currentComponent = "tDBInput_5";

				cLabel = "Billing";

				/**
				 * [tDBInput_5 finally ] stop
				 */

				/**
				 * [tMap_5 finally ] start
				 */

				currentComponent = "tMap_5";

				/**
				 * [tMap_5 finally ] stop
				 */

				/**
				 * [tFileOutputExcel_11 finally ] start
				 */

				currentComponent = "tFileOutputExcel_11";

				cLabel = "NotCoveredByInsurance";

				/**
				 * [tFileOutputExcel_11 finally ] stop
				 */

				/**
				 * [tAggregateRow_2_AGGOUT finally ] start
				 */

				currentVirtualComponent = "tAggregateRow_2";

				currentComponent = "tAggregateRow_2_AGGOUT";

				/**
				 * [tAggregateRow_2_AGGOUT finally ] stop
				 */

				/**
				 * [tAggregateRow_2_AGGIN finally ] start
				 */

				currentVirtualComponent = "tAggregateRow_2";

				currentComponent = "tAggregateRow_2_AGGIN";

				/**
				 * [tAggregateRow_2_AGGIN finally ] stop
				 */

				/**
				 * [tSortRow_3_SortOut finally ] start
				 */

				currentVirtualComponent = "tSortRow_3";

				currentComponent = "tSortRow_3_SortOut";

				/**
				 * [tSortRow_3_SortOut finally ] stop
				 */

				/**
				 * [tSortRow_3_SortIn finally ] start
				 */

				currentVirtualComponent = "tSortRow_3";

				currentComponent = "tSortRow_3_SortIn";

				/**
				 * [tSortRow_3_SortIn finally ] stop
				 */

				/**
				 * [tSampleRow_1 finally ] start
				 */

				currentComponent = "tSampleRow_1";

				/**
				 * [tSampleRow_1 finally ] stop
				 */

				/**
				 * [tJoin_1 finally ] start
				 */

				currentComponent = "tJoin_1";

				/**
				 * [tJoin_1 finally ] stop
				 */

				/**
				 * [tLogRow_2 finally ] start
				 */

				currentComponent = "tLogRow_2";

				cLabel = "MaxPaymentPhysician";

				/**
				 * [tLogRow_2 finally ] stop
				 */

				/**
				 * [tLogRow_3 finally ] start
				 */

				currentComponent = "tLogRow_3";

				cLabel = "CurrentMonthPayment";

				/**
				 * [tLogRow_3 finally ] stop
				 */

				/**
				 * [tLogRow_4 finally ] start
				 */

				currentComponent = "tLogRow_4";

				cLabel = "ActualAmount";

				/**
				 * [tLogRow_4 finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tDBInput_5_SUBPROCESS_STATE", 1);
	}

	public static class row12Struct implements routines.system.IPersistableComparableLookupRow<row12Struct> {
		final static byte[] commonByteArrayLock_HMS_FunctionalRequirement = new byte[0];
		static byte[] commonByteArray_HMS_FunctionalRequirement = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public String PaymentID;

		public String getPaymentID() {
			return this.PaymentID;
		}

		public Boolean PaymentIDIsNullable() {
			return true;
		}

		public Boolean PaymentIDIsKey() {
			return false;
		}

		public Integer PaymentIDLength() {
			return 25;
		}

		public Integer PaymentIDPrecision() {
			return 0;
		}

		public String PaymentIDDefault() {

			return null;

		}

		public String PaymentIDComment() {

			return "";

		}

		public String PaymentIDPattern() {

			return "";

		}

		public String PaymentIDOriginalDbColumnName() {

			return "PaymentID";

		}

		public Integer PatientID;

		public Integer getPatientID() {
			return this.PatientID;
		}

		public Boolean PatientIDIsNullable() {
			return true;
		}

		public Boolean PatientIDIsKey() {
			return false;
		}

		public Integer PatientIDLength() {
			return 10;
		}

		public Integer PatientIDPrecision() {
			return 0;
		}

		public String PatientIDDefault() {

			return null;

		}

		public String PatientIDComment() {

			return "";

		}

		public String PatientIDPattern() {

			return "";

		}

		public String PatientIDOriginalDbColumnName() {

			return "PatientID";

		}

		public Integer PhysicianID;

		public Integer getPhysicianID() {
			return this.PhysicianID;
		}

		public Boolean PhysicianIDIsNullable() {
			return true;
		}

		public Boolean PhysicianIDIsKey() {
			return false;
		}

		public Integer PhysicianIDLength() {
			return 10;
		}

		public Integer PhysicianIDPrecision() {
			return 0;
		}

		public String PhysicianIDDefault() {

			return null;

		}

		public String PhysicianIDComment() {

			return "";

		}

		public String PhysicianIDPattern() {

			return "";

		}

		public String PhysicianIDOriginalDbColumnName() {

			return "PhysicianID";

		}

		public Integer AmountToBePaid;

		public Integer getAmountToBePaid() {
			return this.AmountToBePaid;
		}

		public Boolean AmountToBePaidIsNullable() {
			return true;
		}

		public Boolean AmountToBePaidIsKey() {
			return false;
		}

		public Integer AmountToBePaidLength() {
			return 10;
		}

		public Integer AmountToBePaidPrecision() {
			return 0;
		}

		public String AmountToBePaidDefault() {

			return null;

		}

		public String AmountToBePaidComment() {

			return "";

		}

		public String AmountToBePaidPattern() {

			return "";

		}

		public String AmountToBePaidOriginalDbColumnName() {

			return "AmountToBePaid";

		}

		public java.util.Date PaymentDate;

		public java.util.Date getPaymentDate() {
			return this.PaymentDate;
		}

		public Boolean PaymentDateIsNullable() {
			return true;
		}

		public Boolean PaymentDateIsKey() {
			return false;
		}

		public Integer PaymentDateLength() {
			return 19;
		}

		public Integer PaymentDatePrecision() {
			return 0;
		}

		public String PaymentDateDefault() {

			return null;

		}

		public String PaymentDateComment() {

			return "";

		}

		public String PaymentDatePattern() {

			return "dd-MM-yyyy";

		}

		public String PaymentDateOriginalDbColumnName() {

			return "PaymentDate";

		}

		public String InsuranceID;

		public String getInsuranceID() {
			return this.InsuranceID;
		}

		public Boolean InsuranceIDIsNullable() {
			return true;
		}

		public Boolean InsuranceIDIsKey() {
			return false;
		}

		public Integer InsuranceIDLength() {
			return 25;
		}

		public Integer InsuranceIDPrecision() {
			return 0;
		}

		public String InsuranceIDDefault() {

			return null;

		}

		public String InsuranceIDComment() {

			return "";

		}

		public String InsuranceIDPattern() {

			return "";

		}

		public String InsuranceIDOriginalDbColumnName() {

			return "InsuranceID";

		}

		public Integer MaxCoverageAmount;

		public Integer getMaxCoverageAmount() {
			return this.MaxCoverageAmount;
		}

		public Boolean MaxCoverageAmountIsNullable() {
			return true;
		}

		public Boolean MaxCoverageAmountIsKey() {
			return false;
		}

		public Integer MaxCoverageAmountLength() {
			return 10;
		}

		public Integer MaxCoverageAmountPrecision() {
			return 0;
		}

		public String MaxCoverageAmountDefault() {

			return null;

		}

		public String MaxCoverageAmountComment() {

			return "";

		}

		public String MaxCoverageAmountPattern() {

			return "";

		}

		public String MaxCoverageAmountOriginalDbColumnName() {

			return "MaxCoverageAmount";

		}

		public int Billing_SK;

		public int getBilling_SK() {
			return this.Billing_SK;
		}

		public Boolean Billing_SKIsNullable() {
			return false;
		}

		public Boolean Billing_SKIsKey() {
			return true;
		}

		public Integer Billing_SKLength() {
			return 10;
		}

		public Integer Billing_SKPrecision() {
			return 0;
		}

		public String Billing_SKDefault() {

			return null;

		}

		public String Billing_SKComment() {

			return "";

		}

		public String Billing_SKPattern() {

			return "";

		}

		public String Billing_SKOriginalDbColumnName() {

			return "Billing_SK";

		}

		public java.util.Date Start_date;

		public java.util.Date getStart_date() {
			return this.Start_date;
		}

		public Boolean Start_dateIsNullable() {
			return false;
		}

		public Boolean Start_dateIsKey() {
			return false;
		}

		public Integer Start_dateLength() {
			return 19;
		}

		public Integer Start_datePrecision() {
			return 0;
		}

		public String Start_dateDefault() {

			return null;

		}

		public String Start_dateComment() {

			return "";

		}

		public String Start_datePattern() {

			return "dd-MM-yyyy";

		}

		public String Start_dateOriginalDbColumnName() {

			return "Start_date";

		}

		public java.util.Date End_date;

		public java.util.Date getEnd_date() {
			return this.End_date;
		}

		public Boolean End_dateIsNullable() {
			return true;
		}

		public Boolean End_dateIsKey() {
			return false;
		}

		public Integer End_dateLength() {
			return 19;
		}

		public Integer End_datePrecision() {
			return 0;
		}

		public String End_dateDefault() {

			return null;

		}

		public String End_dateComment() {

			return "";

		}

		public String End_datePattern() {

			return "dd-MM-yyyy";

		}

		public String End_dateOriginalDbColumnName() {

			return "End_date";

		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + ((this.PhysicianID == null) ? 0 : this.PhysicianID.hashCode());

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final row12Struct other = (row12Struct) obj;

			if (this.PhysicianID == null) {
				if (other.PhysicianID != null)
					return false;

			} else if (!this.PhysicianID.equals(other.PhysicianID))

				return false;

			return true;
		}

		public void copyDataTo(row12Struct other) {

			other.PaymentID = this.PaymentID;
			other.PatientID = this.PatientID;
			other.PhysicianID = this.PhysicianID;
			other.AmountToBePaid = this.AmountToBePaid;
			other.PaymentDate = this.PaymentDate;
			other.InsuranceID = this.InsuranceID;
			other.MaxCoverageAmount = this.MaxCoverageAmount;
			other.Billing_SK = this.Billing_SK;
			other.Start_date = this.Start_date;
			other.End_date = this.End_date;

		}

		public void copyKeysDataTo(row12Struct other) {

			other.PhysicianID = this.PhysicianID;

		}

		private String readString(DataInputStream dis, ObjectInputStream ois) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				byte[] byteArray = new byte[length];
				dis.read(byteArray);
				strReturn = new String(byteArray, utf8Charset);
			}
			return strReturn;
		}

		private String readString(DataInputStream dis, org.jboss.marshalling.Unmarshaller unmarshaller)
				throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				byte[] byteArray = new byte[length];
				unmarshaller.read(byteArray);
				strReturn = new String(byteArray, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, DataOutputStream dos, org.jboss.marshalling.Marshaller marshaller)
				throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private void writeString(String str, DataOutputStream dos, ObjectOutputStream oos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private Integer readInteger(DataInputStream dis, ObjectInputStream ois) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(DataInputStream dis, org.jboss.marshalling.Unmarshaller unmarshaller)
				throws IOException {
			Integer intReturn;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = unmarshaller.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, DataOutputStream dos, ObjectOutputStream oos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, DataOutputStream dos, org.jboss.marshalling.Marshaller marshaller)
				throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private java.util.Date readDate(DataInputStream dis, ObjectInputStream ois) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(DataInputStream dis, org.jboss.marshalling.Unmarshaller unmarshaller)
				throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, DataOutputStream dos, ObjectOutputStream oos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, DataOutputStream dos, org.jboss.marshalling.Marshaller marshaller)
				throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readKeysData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_HMS_FunctionalRequirement) {

				try {

					int length = 0;

					this.PhysicianID = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readKeysData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_HMS_FunctionalRequirement) {

				try {

					int length = 0;

					this.PhysicianID = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeKeysData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.PhysicianID, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeKeysData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.PhysicianID, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		/**
		 * Fill Values data by reading ObjectInputStream.
		 */
		public void readValuesData(DataInputStream dis, ObjectInputStream ois) {
			try {

				int length = 0;

				this.PaymentID = readString(dis, ois);

				this.PatientID = readInteger(dis, ois);

				this.AmountToBePaid = readInteger(dis, ois);

				this.PaymentDate = readDate(dis, ois);

				this.InsuranceID = readString(dis, ois);

				this.MaxCoverageAmount = readInteger(dis, ois);

				this.Billing_SK = dis.readInt();

				this.Start_date = readDate(dis, ois);

				this.End_date = readDate(dis, ois);

			} catch (IOException e) {
				throw new RuntimeException(e);

			}

		}

		public void readValuesData(DataInputStream dis, org.jboss.marshalling.Unmarshaller objectIn) {
			try {
				int length = 0;

				this.PaymentID = readString(dis, objectIn);

				this.PatientID = readInteger(dis, objectIn);

				this.AmountToBePaid = readInteger(dis, objectIn);

				this.PaymentDate = readDate(dis, objectIn);

				this.InsuranceID = readString(dis, objectIn);

				this.MaxCoverageAmount = readInteger(dis, objectIn);

				this.Billing_SK = objectIn.readInt();

				this.Start_date = readDate(dis, objectIn);

				this.End_date = readDate(dis, objectIn);

			} catch (IOException e) {
				throw new RuntimeException(e);

			}

		}

		/**
		 * Return a byte array which represents Values data.
		 */
		public void writeValuesData(DataOutputStream dos, ObjectOutputStream oos) {
			try {

				writeString(this.PaymentID, dos, oos);

				writeInteger(this.PatientID, dos, oos);

				writeInteger(this.AmountToBePaid, dos, oos);

				writeDate(this.PaymentDate, dos, oos);

				writeString(this.InsuranceID, dos, oos);

				writeInteger(this.MaxCoverageAmount, dos, oos);

				dos.writeInt(this.Billing_SK);

				writeDate(this.Start_date, dos, oos);

				writeDate(this.End_date, dos, oos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeValuesData(DataOutputStream dos, org.jboss.marshalling.Marshaller objectOut) {
			try {

				writeString(this.PaymentID, dos, objectOut);

				writeInteger(this.PatientID, dos, objectOut);

				writeInteger(this.AmountToBePaid, dos, objectOut);

				writeDate(this.PaymentDate, dos, objectOut);

				writeString(this.InsuranceID, dos, objectOut);

				writeInteger(this.MaxCoverageAmount, dos, objectOut);

				objectOut.writeInt(this.Billing_SK);

				writeDate(this.Start_date, dos, objectOut);

				writeDate(this.End_date, dos, objectOut);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}
		}

		public boolean supportMarshaller() {
			return true;
		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("PaymentID=" + PaymentID);
			sb.append(",PatientID=" + String.valueOf(PatientID));
			sb.append(",PhysicianID=" + String.valueOf(PhysicianID));
			sb.append(",AmountToBePaid=" + String.valueOf(AmountToBePaid));
			sb.append(",PaymentDate=" + String.valueOf(PaymentDate));
			sb.append(",InsuranceID=" + InsuranceID);
			sb.append(",MaxCoverageAmount=" + String.valueOf(MaxCoverageAmount));
			sb.append(",Billing_SK=" + String.valueOf(Billing_SK));
			sb.append(",Start_date=" + String.valueOf(Start_date));
			sb.append(",End_date=" + String.valueOf(End_date));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (PaymentID == null) {
				sb.append("<null>");
			} else {
				sb.append(PaymentID);
			}

			sb.append("|");

			if (PatientID == null) {
				sb.append("<null>");
			} else {
				sb.append(PatientID);
			}

			sb.append("|");

			if (PhysicianID == null) {
				sb.append("<null>");
			} else {
				sb.append(PhysicianID);
			}

			sb.append("|");

			if (AmountToBePaid == null) {
				sb.append("<null>");
			} else {
				sb.append(AmountToBePaid);
			}

			sb.append("|");

			if (PaymentDate == null) {
				sb.append("<null>");
			} else {
				sb.append(PaymentDate);
			}

			sb.append("|");

			if (InsuranceID == null) {
				sb.append("<null>");
			} else {
				sb.append(InsuranceID);
			}

			sb.append("|");

			if (MaxCoverageAmount == null) {
				sb.append("<null>");
			} else {
				sb.append(MaxCoverageAmount);
			}

			sb.append("|");

			sb.append(Billing_SK);

			sb.append("|");

			if (Start_date == null) {
				sb.append("<null>");
			} else {
				sb.append(Start_date);
			}

			sb.append("|");

			if (End_date == null) {
				sb.append("<null>");
			} else {
				sb.append(End_date);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row12Struct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.PhysicianID, other.PhysicianID);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tDBInput_6Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tDBInput_6_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tDBInput_6");
		org.slf4j.MDC.put("_subJobPid", "EPNN9y_" + subJobPidCounter.getAndIncrement());

		String iterateId = "";

		String currentComponent = "";
		String cLabel = null;
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				row12Struct row12 = new row12Struct();

				/**
				 * [tHash_row12 begin ] start
				 */

				ok_Hash.put("tHash_row12", false);
				start_Hash.put("tHash_row12", System.currentTimeMillis());

				currentComponent = "tHash_row12";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "row12");

				int tos_count_tHash_row12 = 0;

				if (enableLogStash) {
					talendJobLog.addCM("tHash_row12", "tHash_row12", "tHash");
					talendJobLogProcess(globalMap);
				}

				java.util.Map<row12Struct, row12Struct> tHash_row12 = new java.util.LinkedHashMap<row12Struct, row12Struct>();
				globalMap.put("tHash_row12", tHash_row12);

				/**
				 * [tHash_row12 begin ] stop
				 */

				/**
				 * [tDBInput_6 begin ] start
				 */

				ok_Hash.put("tDBInput_6", false);
				start_Hash.put("tDBInput_6", System.currentTimeMillis());

				currentComponent = "tDBInput_6";

				cLabel = "BillingLookup";

				int tos_count_tDBInput_6 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBInput_6 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tDBInput_6 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tDBInput_6 = new StringBuilder();
							log4jParamters_tDBInput_6.append("Parameters:");
							log4jParamters_tDBInput_6.append("DB_VERSION" + " = " + "MYSQL_8");
							log4jParamters_tDBInput_6.append(" | ");
							log4jParamters_tDBInput_6.append("USE_EXISTING_CONNECTION" + " = " + "false");
							log4jParamters_tDBInput_6.append(" | ");
							log4jParamters_tDBInput_6.append("HOST" + " = " + "\"localhost\"");
							log4jParamters_tDBInput_6.append(" | ");
							log4jParamters_tDBInput_6.append("PORT" + " = " + "\"3306\"");
							log4jParamters_tDBInput_6.append(" | ");
							log4jParamters_tDBInput_6.append("DBNAME" + " = " + "\"Warehouse\"");
							log4jParamters_tDBInput_6.append(" | ");
							log4jParamters_tDBInput_6.append("USER" + " = " + "\"root\"");
							log4jParamters_tDBInput_6.append(" | ");
							log4jParamters_tDBInput_6.append("PASS" + " = " + String.valueOf(
									"enc:routine.encryption.key.v1:bcOUAdACOhzm801FQgc7YyZddPTim/Ynug7E3r7Fn7w=")
									.substring(0, 4) + "...");
							log4jParamters_tDBInput_6.append(" | ");
							log4jParamters_tDBInput_6.append("TABLE" + " = " + "\"billingdim\"");
							log4jParamters_tDBInput_6.append(" | ");
							log4jParamters_tDBInput_6.append("QUERYSTORE" + " = " + "\"\"");
							log4jParamters_tDBInput_6.append(" | ");
							log4jParamters_tDBInput_6.append("QUERY" + " = "
									+ "\"SELECT    `billingdim`.`PaymentID`,    `billingdim`.`PatientID`,    `billingdim`.`PhysicianID`,    `billingdim`.`AmountToBePaid`,    `billingdim`.`PaymentDate`,    `billingdim`.`InsuranceID`,    `billingdim`.`MaxCoverageAmount`,    `billingdim`.`Billing_SK`,    `billingdim`.`Start_date`,    `billingdim`.`End_date` FROM `billingdim`\"");
							log4jParamters_tDBInput_6.append(" | ");
							log4jParamters_tDBInput_6.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
							log4jParamters_tDBInput_6.append(" | ");
							log4jParamters_tDBInput_6.append("PROPERTIES" + " = "
									+ "\"noDatetimeStringSync=true&enabledTLSProtocols=TLSv1.2,TLSv1.1,TLSv1\"");
							log4jParamters_tDBInput_6.append(" | ");
							log4jParamters_tDBInput_6.append("ENABLE_STREAM" + " = " + "false");
							log4jParamters_tDBInput_6.append(" | ");
							log4jParamters_tDBInput_6.append("TRIM_ALL_COLUMN" + " = " + "false");
							log4jParamters_tDBInput_6.append(" | ");
							log4jParamters_tDBInput_6.append("TRIM_COLUMN" + " = " + "[{TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("PaymentID") + "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN="
									+ ("PatientID") + "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN=" + ("PhysicianID")
									+ "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN=" + ("AmountToBePaid") + "}, {TRIM="
									+ ("false") + ", SCHEMA_COLUMN=" + ("PaymentDate") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("InsuranceID") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("MaxCoverageAmount") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("Billing_SK") + "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN="
									+ ("Start_date") + "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN=" + ("End_date")
									+ "}]");
							log4jParamters_tDBInput_6.append(" | ");
							log4jParamters_tDBInput_6.append("UNIFIED_COMPONENTS" + " = " + "tMysqlInput");
							log4jParamters_tDBInput_6.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tDBInput_6 - " + (log4jParamters_tDBInput_6));
						}
					}
					new BytesLimit65535_tDBInput_6().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tDBInput_6", "BillingLookup", "tMysqlInput");
					talendJobLogProcess(globalMap);
				}

				java.util.Calendar calendar_tDBInput_6 = java.util.Calendar.getInstance();
				calendar_tDBInput_6.set(0, 0, 0, 0, 0, 0);
				java.util.Date year0_tDBInput_6 = calendar_tDBInput_6.getTime();
				int nb_line_tDBInput_6 = 0;
				java.sql.Connection conn_tDBInput_6 = null;
				String driverClass_tDBInput_6 = "com.mysql.cj.jdbc.Driver";
				java.lang.Class jdbcclazz_tDBInput_6 = java.lang.Class.forName(driverClass_tDBInput_6);
				String dbUser_tDBInput_6 = "root";

				final String decryptedPassword_tDBInput_6 = routines.system.PasswordEncryptUtil
						.decryptPassword("enc:routine.encryption.key.v1:3vqw74TYNLngCGXtRTaAGz0FEXXKZi7uEijJPCwVFNk=");

				String dbPwd_tDBInput_6 = decryptedPassword_tDBInput_6;

				String properties_tDBInput_6 = "noDatetimeStringSync=true&enabledTLSProtocols=TLSv1.2,TLSv1.1,TLSv1";
				if (properties_tDBInput_6 == null || properties_tDBInput_6.trim().length() == 0) {
					properties_tDBInput_6 = "";
				}
				String url_tDBInput_6 = "jdbc:mysql://" + "localhost" + ":" + "3306" + "/" + "Warehouse" + "?"
						+ properties_tDBInput_6;

				log.debug("tDBInput_6 - Driver ClassName: " + driverClass_tDBInput_6 + ".");

				log.debug("tDBInput_6 - Connection attempt to '" + url_tDBInput_6 + "' with the username '"
						+ dbUser_tDBInput_6 + "'.");

				conn_tDBInput_6 = java.sql.DriverManager.getConnection(url_tDBInput_6, dbUser_tDBInput_6,
						dbPwd_tDBInput_6);
				log.debug("tDBInput_6 - Connection to '" + url_tDBInput_6 + "' has succeeded.");

				java.sql.Statement stmt_tDBInput_6 = conn_tDBInput_6.createStatement();

				String dbquery_tDBInput_6 = "SELECT \n  `billingdim`.`PaymentID`, \n  `billingdim`.`PatientID`, \n  `billingdim`.`PhysicianID`, \n  `billingdim`.`Amount"
						+ "ToBePaid`, \n  `billingdim`.`PaymentDate`, \n  `billingdim`.`InsuranceID`, \n  `billingdim`.`MaxCoverageAmount`, \n  `billin"
						+ "gdim`.`Billing_SK`, \n  `billingdim`.`Start_date`, \n  `billingdim`.`End_date`\nFROM `billingdim`";

				log.debug("tDBInput_6 - Executing the query: '" + dbquery_tDBInput_6 + "'.");

				globalMap.put("tDBInput_6_QUERY", dbquery_tDBInput_6);

				java.sql.ResultSet rs_tDBInput_6 = null;

				try {
					rs_tDBInput_6 = stmt_tDBInput_6.executeQuery(dbquery_tDBInput_6);
					java.sql.ResultSetMetaData rsmd_tDBInput_6 = rs_tDBInput_6.getMetaData();
					int colQtyInRs_tDBInput_6 = rsmd_tDBInput_6.getColumnCount();

					String tmpContent_tDBInput_6 = null;

					log.debug("tDBInput_6 - Retrieving records from the database.");

					while (rs_tDBInput_6.next()) {
						nb_line_tDBInput_6++;

						if (colQtyInRs_tDBInput_6 < 1) {
							row12.PaymentID = null;
						} else {

							row12.PaymentID = routines.system.JDBCUtil.getString(rs_tDBInput_6, 1, false);
						}
						if (colQtyInRs_tDBInput_6 < 2) {
							row12.PatientID = null;
						} else {

							row12.PatientID = rs_tDBInput_6.getInt(2);
							if (rs_tDBInput_6.wasNull()) {
								row12.PatientID = null;
							}
						}
						if (colQtyInRs_tDBInput_6 < 3) {
							row12.PhysicianID = null;
						} else {

							row12.PhysicianID = rs_tDBInput_6.getInt(3);
							if (rs_tDBInput_6.wasNull()) {
								row12.PhysicianID = null;
							}
						}
						if (colQtyInRs_tDBInput_6 < 4) {
							row12.AmountToBePaid = null;
						} else {

							row12.AmountToBePaid = rs_tDBInput_6.getInt(4);
							if (rs_tDBInput_6.wasNull()) {
								row12.AmountToBePaid = null;
							}
						}
						if (colQtyInRs_tDBInput_6 < 5) {
							row12.PaymentDate = null;
						} else {

							if (rs_tDBInput_6.getString(5) != null) {
								String dateString_tDBInput_6 = rs_tDBInput_6.getString(5);
								if (!("0000-00-00").equals(dateString_tDBInput_6)
										&& !("0000-00-00 00:00:00").equals(dateString_tDBInput_6)) {
									row12.PaymentDate = rs_tDBInput_6.getTimestamp(5);
								} else {
									row12.PaymentDate = (java.util.Date) year0_tDBInput_6.clone();
								}
							} else {
								row12.PaymentDate = null;
							}
						}
						if (colQtyInRs_tDBInput_6 < 6) {
							row12.InsuranceID = null;
						} else {

							row12.InsuranceID = routines.system.JDBCUtil.getString(rs_tDBInput_6, 6, false);
						}
						if (colQtyInRs_tDBInput_6 < 7) {
							row12.MaxCoverageAmount = null;
						} else {

							row12.MaxCoverageAmount = rs_tDBInput_6.getInt(7);
							if (rs_tDBInput_6.wasNull()) {
								row12.MaxCoverageAmount = null;
							}
						}
						if (colQtyInRs_tDBInput_6 < 8) {
							row12.Billing_SK = 0;
						} else {

							row12.Billing_SK = rs_tDBInput_6.getInt(8);
							if (rs_tDBInput_6.wasNull()) {
								throw new RuntimeException("Null value in non-Nullable column");
							}
						}
						if (colQtyInRs_tDBInput_6 < 9) {
							row12.Start_date = null;
						} else {

							if (rs_tDBInput_6.getString(9) != null) {
								String dateString_tDBInput_6 = rs_tDBInput_6.getString(9);
								if (!("0000-00-00").equals(dateString_tDBInput_6)
										&& !("0000-00-00 00:00:00").equals(dateString_tDBInput_6)) {
									row12.Start_date = rs_tDBInput_6.getTimestamp(9);
								} else {
									row12.Start_date = (java.util.Date) year0_tDBInput_6.clone();
								}
							} else {
								row12.Start_date = null;
							}
						}
						if (colQtyInRs_tDBInput_6 < 10) {
							row12.End_date = null;
						} else {

							if (rs_tDBInput_6.getString(10) != null) {
								String dateString_tDBInput_6 = rs_tDBInput_6.getString(10);
								if (!("0000-00-00").equals(dateString_tDBInput_6)
										&& !("0000-00-00 00:00:00").equals(dateString_tDBInput_6)) {
									row12.End_date = rs_tDBInput_6.getTimestamp(10);
								} else {
									row12.End_date = (java.util.Date) year0_tDBInput_6.clone();
								}
							} else {
								row12.End_date = null;
							}
						}

						log.debug("tDBInput_6 - Retrieving the record " + nb_line_tDBInput_6 + ".");

						/**
						 * [tDBInput_6 begin ] stop
						 */

						/**
						 * [tDBInput_6 main ] start
						 */

						currentComponent = "tDBInput_6";

						cLabel = "BillingLookup";

						tos_count_tDBInput_6++;

						/**
						 * [tDBInput_6 main ] stop
						 */

						/**
						 * [tDBInput_6 process_data_begin ] start
						 */

						currentComponent = "tDBInput_6";

						cLabel = "BillingLookup";

						/**
						 * [tDBInput_6 process_data_begin ] stop
						 */

						/**
						 * [tHash_row12 main ] start
						 */

						currentComponent = "tHash_row12";

						if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

								, "row12", "tDBInput_6", "BillingLookup", "tMysqlInput", "tHash_row12", "tHash_row12",
								"tHash"

						)) {
							talendJobLogProcess(globalMap);
						}

						if (log.isTraceEnabled()) {
							log.trace("row12 - " + (row12 == null ? "" : row12.toLogString()));
						}

						row12Struct row12_HashRow = new row12Struct();

						row12_HashRow.PaymentID = row12.PaymentID;
						row12_HashRow.PatientID = row12.PatientID;
						row12_HashRow.PhysicianID = row12.PhysicianID;
						row12_HashRow.AmountToBePaid = row12.AmountToBePaid;
						row12_HashRow.PaymentDate = row12.PaymentDate;
						row12_HashRow.InsuranceID = row12.InsuranceID;
						row12_HashRow.MaxCoverageAmount = row12.MaxCoverageAmount;
						row12_HashRow.Billing_SK = row12.Billing_SK;
						row12_HashRow.Start_date = row12.Start_date;
						row12_HashRow.End_date = row12.End_date;
						tHash_row12.put(row12_HashRow, row12_HashRow);

						tos_count_tHash_row12++;

						/**
						 * [tHash_row12 main ] stop
						 */

						/**
						 * [tHash_row12 process_data_begin ] start
						 */

						currentComponent = "tHash_row12";

						/**
						 * [tHash_row12 process_data_begin ] stop
						 */

						/**
						 * [tHash_row12 process_data_end ] start
						 */

						currentComponent = "tHash_row12";

						/**
						 * [tHash_row12 process_data_end ] stop
						 */

						/**
						 * [tDBInput_6 process_data_end ] start
						 */

						currentComponent = "tDBInput_6";

						cLabel = "BillingLookup";

						/**
						 * [tDBInput_6 process_data_end ] stop
						 */

						/**
						 * [tDBInput_6 end ] start
						 */

						currentComponent = "tDBInput_6";

						cLabel = "BillingLookup";

					}
				} finally {
					if (rs_tDBInput_6 != null) {
						rs_tDBInput_6.close();
					}
					if (stmt_tDBInput_6 != null) {
						stmt_tDBInput_6.close();
					}
					if (conn_tDBInput_6 != null && !conn_tDBInput_6.isClosed()) {

						log.debug("tDBInput_6 - Closing the connection to the database.");

						conn_tDBInput_6.close();

						if ("com.mysql.cj.jdbc.Driver".equals((String) globalMap.get("driverClass_"))
								&& routines.system.BundleUtils.inOSGi()) {
							Class.forName("com.mysql.cj.jdbc.AbandonedConnectionCleanupThread")
									.getMethod("checkedShutdown").invoke(null, (Object[]) null);
						}

						log.debug("tDBInput_6 - Connection to the database closed.");

					}

				}
				globalMap.put("tDBInput_6_NB_LINE", nb_line_tDBInput_6);
				log.debug("tDBInput_6 - Retrieved records count: " + nb_line_tDBInput_6 + " .");

				if (log.isDebugEnabled())
					log.debug("tDBInput_6 - " + ("Done."));

				ok_Hash.put("tDBInput_6", true);
				end_Hash.put("tDBInput_6", System.currentTimeMillis());

				/**
				 * [tDBInput_6 end ] stop
				 */

				/**
				 * [tHash_row12 end ] start
				 */

				currentComponent = "tHash_row12";

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "row12", 2, 0,
						"tDBInput_6", "BillingLookup", "tMysqlInput", "tHash_row12", "tHash_row12", "tHash",
						"output")) {
					talendJobLogProcess(globalMap);
				}

				ok_Hash.put("tHash_row12", true);
				end_Hash.put("tHash_row12", System.currentTimeMillis());

				/**
				 * [tHash_row12 end ] stop
				 */

			} // end the resume

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage(), e);
			}

			TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			try {

				/**
				 * [tDBInput_6 finally ] start
				 */

				currentComponent = "tDBInput_6";

				cLabel = "BillingLookup";

				/**
				 * [tDBInput_6 finally ] stop
				 */

				/**
				 * [tHash_row12 finally ] start
				 */

				currentComponent = "tHash_row12";

				/**
				 * [tHash_row12 finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tDBInput_6_SUBPROCESS_STATE", 1);
	}

	public void talendJobLogProcess(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("talendJobLog_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		String cLabel = null;
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				/**
				 * [talendJobLog begin ] start
				 */

				ok_Hash.put("talendJobLog", false);
				start_Hash.put("talendJobLog", System.currentTimeMillis());

				currentComponent = "talendJobLog";

				int tos_count_talendJobLog = 0;

				for (JobStructureCatcherUtils.JobStructureCatcherMessage jcm : talendJobLog.getMessages()) {
					org.talend.job.audit.JobContextBuilder builder_talendJobLog = org.talend.job.audit.JobContextBuilder
							.create().jobName(jcm.job_name).jobId(jcm.job_id).jobVersion(jcm.job_version)
							.custom("process_id", jcm.pid).custom("thread_id", jcm.tid).custom("pid", pid)
							.custom("father_pid", fatherPid).custom("root_pid", rootPid);
					org.talend.logging.audit.Context log_context_talendJobLog = null;

					if (jcm.log_type == JobStructureCatcherUtils.LogType.PERFORMANCE) {
						long timeMS = jcm.end_time - jcm.start_time;
						String duration = String.valueOf(timeMS);

						log_context_talendJobLog = builder_talendJobLog.sourceId(jcm.sourceId)
								.sourceLabel(jcm.sourceLabel).sourceConnectorType(jcm.sourceComponentName)
								.targetId(jcm.targetId).targetLabel(jcm.targetLabel)
								.targetConnectorType(jcm.targetComponentName).connectionName(jcm.current_connector)
								.rows(jcm.row_count).duration(duration).build();
						auditLogger_talendJobLog.flowExecution(log_context_talendJobLog);
					} else if (jcm.log_type == JobStructureCatcherUtils.LogType.JOBSTART) {
						log_context_talendJobLog = builder_talendJobLog.timestamp(jcm.moment).build();
						auditLogger_talendJobLog.jobstart(log_context_talendJobLog);
					} else if (jcm.log_type == JobStructureCatcherUtils.LogType.JOBEND) {
						long timeMS = jcm.end_time - jcm.start_time;
						String duration = String.valueOf(timeMS);

						log_context_talendJobLog = builder_talendJobLog.timestamp(jcm.moment).duration(duration)
								.status(jcm.status).build();
						auditLogger_talendJobLog.jobstop(log_context_talendJobLog);
					} else if (jcm.log_type == JobStructureCatcherUtils.LogType.RUNCOMPONENT) {
						log_context_talendJobLog = builder_talendJobLog.timestamp(jcm.moment)
								.connectorType(jcm.component_name).connectorId(jcm.component_id)
								.connectorLabel(jcm.component_label).build();
						auditLogger_talendJobLog.runcomponent(log_context_talendJobLog);
					} else if (jcm.log_type == JobStructureCatcherUtils.LogType.FLOWINPUT) {// log current component
																							// input line
						long timeMS = jcm.end_time - jcm.start_time;
						String duration = String.valueOf(timeMS);

						log_context_talendJobLog = builder_talendJobLog.connectorType(jcm.component_name)
								.connectorId(jcm.component_id).connectorLabel(jcm.component_label)
								.connectionName(jcm.current_connector).connectionType(jcm.current_connector_type)
								.rows(jcm.total_row_number).duration(duration).build();
						auditLogger_talendJobLog.flowInput(log_context_talendJobLog);
					} else if (jcm.log_type == JobStructureCatcherUtils.LogType.FLOWOUTPUT) {// log current component
																								// output/reject line
						long timeMS = jcm.end_time - jcm.start_time;
						String duration = String.valueOf(timeMS);

						log_context_talendJobLog = builder_talendJobLog.connectorType(jcm.component_name)
								.connectorId(jcm.component_id).connectorLabel(jcm.component_label)
								.connectionName(jcm.current_connector).connectionType(jcm.current_connector_type)
								.rows(jcm.total_row_number).duration(duration).build();
						auditLogger_talendJobLog.flowOutput(log_context_talendJobLog);
					} else if (jcm.log_type == JobStructureCatcherUtils.LogType.JOBERROR) {
						java.lang.Exception e_talendJobLog = jcm.exception;
						if (e_talendJobLog != null) {
							try (java.io.StringWriter sw_talendJobLog = new java.io.StringWriter();
									java.io.PrintWriter pw_talendJobLog = new java.io.PrintWriter(sw_talendJobLog)) {
								e_talendJobLog.printStackTrace(pw_talendJobLog);
								builder_talendJobLog.custom("stacktrace", sw_talendJobLog.getBuffer().substring(0,
										java.lang.Math.min(sw_talendJobLog.getBuffer().length(), 512)));
							}
						}

						if (jcm.extra_info != null) {
							builder_talendJobLog.connectorId(jcm.component_id).custom("extra_info", jcm.extra_info);
						}

						log_context_talendJobLog = builder_talendJobLog
								.connectorType(jcm.component_id.substring(0, jcm.component_id.lastIndexOf('_')))
								.connectorId(jcm.component_id)
								.connectorLabel(jcm.component_label == null ? jcm.component_id : jcm.component_label)
								.build();

						auditLogger_talendJobLog.exception(log_context_talendJobLog);
					}

				}

				/**
				 * [talendJobLog begin ] stop
				 */

				/**
				 * [talendJobLog main ] start
				 */

				currentComponent = "talendJobLog";

				tos_count_talendJobLog++;

				/**
				 * [talendJobLog main ] stop
				 */

				/**
				 * [talendJobLog process_data_begin ] start
				 */

				currentComponent = "talendJobLog";

				/**
				 * [talendJobLog process_data_begin ] stop
				 */

				/**
				 * [talendJobLog process_data_end ] start
				 */

				currentComponent = "talendJobLog";

				/**
				 * [talendJobLog process_data_end ] stop
				 */

				/**
				 * [talendJobLog end ] start
				 */

				currentComponent = "talendJobLog";

				ok_Hash.put("talendJobLog", true);
				end_Hash.put("talendJobLog", System.currentTimeMillis());

				/**
				 * [talendJobLog end ] stop
				 */
			} // end the resume

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage(), e);
			}

			TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			try {

				/**
				 * [talendJobLog finally ] start
				 */

				currentComponent = "talendJobLog";

				/**
				 * [talendJobLog finally ] stop
				 */
			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("talendJobLog_SUBPROCESS_STATE", 1);
	}

	public String resuming_logs_dir_path = null;
	public String resuming_checkpoint_path = null;
	public String parent_part_launcher = null;
	private String resumeEntryMethodName = null;
	private boolean globalResumeTicket = false;

	public boolean watch = false;
	// portStats is null, it means don't execute the statistics
	public Integer portStats = null;
	public int portTraces = 4334;
	public String clientHost;
	public String defaultClientHost = "localhost";
	public String contextStr = "Default";
	public boolean isDefaultContext = true;
	public String pid = "0";
	public String rootPid = null;
	public String fatherPid = null;
	public String fatherNode = null;
	public long startTime = 0;
	public boolean isChildJob = false;
	public String log4jLevel = "";

	private boolean enableLogStash;

	private boolean execStat = true;

	private ThreadLocal<java.util.Map<String, String>> threadLocal = new ThreadLocal<java.util.Map<String, String>>() {
		protected java.util.Map<String, String> initialValue() {
			java.util.Map<String, String> threadRunResultMap = new java.util.HashMap<String, String>();
			threadRunResultMap.put("errorCode", null);
			threadRunResultMap.put("status", "");
			return threadRunResultMap;
		};
	};

	protected PropertiesWithType context_param = new PropertiesWithType();
	public java.util.Map<String, Object> parentContextMap = new java.util.HashMap<String, Object>();

	public String status = "";

	private final static java.util.Properties jobInfo = new java.util.Properties();
	private final static java.util.Map<String, String> mdcInfo = new java.util.HashMap<>();
	private final static java.util.concurrent.atomic.AtomicLong subJobPidCounter = new java.util.concurrent.atomic.AtomicLong();

	public static void main(String[] args) {
		final FunctionalRequirement FunctionalRequirementClass = new FunctionalRequirement();

		int exitCode = FunctionalRequirementClass.runJobInTOS(args);
		if (exitCode == 0) {
			log.info("TalendJob: 'FunctionalRequirement' - Done.");
		}

		System.exit(exitCode);
	}

	private void getjobInfo() {
		final String TEMPLATE_PATH = "src/main/templates/jobInfo_template.properties";
		final String BUILD_PATH = "../jobInfo.properties";
		final String path = this.getClass().getResource("").getPath();
		if (path.lastIndexOf("target") > 0) {
			final java.io.File templateFile = new java.io.File(
					path.substring(0, path.lastIndexOf("target")).concat(TEMPLATE_PATH));
			if (templateFile.exists()) {
				readJobInfo(templateFile);
				return;
			}
		}
		readJobInfo(new java.io.File(BUILD_PATH));
	}

	private void readJobInfo(java.io.File jobInfoFile) {

		if (jobInfoFile.exists()) {
			try (java.io.InputStream is = new java.io.FileInputStream(jobInfoFile)) {
				jobInfo.load(is);
			} catch (IOException e) {

				log.debug("Read jobInfo.properties file fail: " + e.getMessage());

			}
		}
		log.info(String.format("Project name: %s\tJob name: %s\tGIT Commit ID: %s\tTalend Version: %s", projectName,
				jobName, jobInfo.getProperty("gitCommitId"), "8.0.1.20240524_0800-patch"));

	}

	public String[][] runJob(String[] args) {

		int exitCode = runJobInTOS(args);
		String[][] bufferValue = new String[][] { { Integer.toString(exitCode) } };

		return bufferValue;
	}

	public boolean hastBufferOutputComponent() {
		boolean hastBufferOutput = false;

		return hastBufferOutput;
	}

	public int runJobInTOS(String[] args) {
		// reset status
		status = "";

		String lastStr = "";
		for (String arg : args) {
			if (arg.equalsIgnoreCase("--context_param")) {
				lastStr = arg;
			} else if (lastStr.equals("")) {
				evalParam(arg);
			} else {
				evalParam(lastStr + " " + arg);
				lastStr = "";
			}
		}
		enableLogStash = "true".equalsIgnoreCase(System.getProperty("audit.enabled"));

		if (!"".equals(log4jLevel)) {

			if ("trace".equalsIgnoreCase(log4jLevel)) {
				org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(),
						org.apache.logging.log4j.Level.TRACE);
			} else if ("debug".equalsIgnoreCase(log4jLevel)) {
				org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(),
						org.apache.logging.log4j.Level.DEBUG);
			} else if ("info".equalsIgnoreCase(log4jLevel)) {
				org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(),
						org.apache.logging.log4j.Level.INFO);
			} else if ("warn".equalsIgnoreCase(log4jLevel)) {
				org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(),
						org.apache.logging.log4j.Level.WARN);
			} else if ("error".equalsIgnoreCase(log4jLevel)) {
				org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(),
						org.apache.logging.log4j.Level.ERROR);
			} else if ("fatal".equalsIgnoreCase(log4jLevel)) {
				org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(),
						org.apache.logging.log4j.Level.FATAL);
			} else if ("off".equalsIgnoreCase(log4jLevel)) {
				org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(),
						org.apache.logging.log4j.Level.OFF);
			}
			org.apache.logging.log4j.core.config.Configurator
					.setLevel(org.apache.logging.log4j.LogManager.getRootLogger().getName(), log.getLevel());

		}

		getjobInfo();
		log.info("TalendJob: 'FunctionalRequirement' - Start.");

		java.util.Set<Object> jobInfoKeys = jobInfo.keySet();
		for (Object jobInfoKey : jobInfoKeys) {
			org.slf4j.MDC.put("_" + jobInfoKey.toString(), jobInfo.get(jobInfoKey).toString());
		}
		org.slf4j.MDC.put("_pid", pid);
		org.slf4j.MDC.put("_rootPid", rootPid);
		org.slf4j.MDC.put("_fatherPid", fatherPid);
		org.slf4j.MDC.put("_projectName", projectName);
		org.slf4j.MDC.put("_startTimestamp", java.time.ZonedDateTime.now(java.time.ZoneOffset.UTC)
				.format(java.time.format.DateTimeFormatter.ISO_INSTANT));
		org.slf4j.MDC.put("_jobRepositoryId", "_mc7mYOqIEe-S2IUjnYFGbA");
		org.slf4j.MDC.put("_compiledAtTimestamp", "2025-03-26T06:13:46.914354900Z");

		java.lang.management.RuntimeMXBean mx = java.lang.management.ManagementFactory.getRuntimeMXBean();
		String[] mxNameTable = mx.getName().split("@"); //$NON-NLS-1$
		if (mxNameTable.length == 2) {
			org.slf4j.MDC.put("_systemPid", mxNameTable[0]);
		} else {
			org.slf4j.MDC.put("_systemPid", String.valueOf(java.lang.Thread.currentThread().getId()));
		}

		if (enableLogStash) {
			java.util.Properties properties_talendJobLog = new java.util.Properties();
			properties_talendJobLog.setProperty("root.logger", "audit");
			properties_talendJobLog.setProperty("encoding", "UTF-8");
			properties_talendJobLog.setProperty("application.name", "Talend Studio");
			properties_talendJobLog.setProperty("service.name", "Talend Studio Job");
			properties_talendJobLog.setProperty("instance.name", "Talend Studio Job Instance");
			properties_talendJobLog.setProperty("propagate.appender.exceptions", "none");
			properties_talendJobLog.setProperty("log.appender", "file");
			properties_talendJobLog.setProperty("appender.file.path", "audit.json");
			properties_talendJobLog.setProperty("appender.file.maxsize", "52428800");
			properties_talendJobLog.setProperty("appender.file.maxbackup", "20");
			properties_talendJobLog.setProperty("host", "false");

			System.getProperties().stringPropertyNames().stream().filter(it -> it.startsWith("audit.logger."))
					.forEach(key -> properties_talendJobLog.setProperty(key.substring("audit.logger.".length()),
							System.getProperty(key)));

			org.apache.logging.log4j.core.config.Configurator
					.setLevel(properties_talendJobLog.getProperty("root.logger"), org.apache.logging.log4j.Level.DEBUG);

			auditLogger_talendJobLog = org.talend.job.audit.JobEventAuditLoggerFactory
					.createJobAuditLogger(properties_talendJobLog);
		}

		if (clientHost == null) {
			clientHost = defaultClientHost;
		}

		if (pid == null || "0".equals(pid)) {
			pid = TalendString.getAsciiRandomString(6);
		}

		org.slf4j.MDC.put("_pid", pid);

		if (rootPid == null) {
			rootPid = pid;
		}

		org.slf4j.MDC.put("_rootPid", rootPid);

		if (fatherPid == null) {
			fatherPid = pid;
		} else {
			isChildJob = true;
		}
		org.slf4j.MDC.put("_fatherPid", fatherPid);

		if (portStats != null) {
			// portStats = -1; //for testing
			if (portStats < 0 || portStats > 65535) {
				// issue:10869, the portStats is invalid, so this client socket can't open
				System.err.println("The statistics socket port " + portStats + " is invalid.");
				execStat = false;
			}
		} else {
			execStat = false;
		}
		boolean inOSGi = routines.system.BundleUtils.inOSGi();

		try {
			java.util.Dictionary<String, Object> jobProperties = null;
			if (inOSGi) {
				jobProperties = routines.system.BundleUtils.getJobProperties(jobName);

				if (jobProperties != null && jobProperties.get("context") != null) {
					contextStr = (String) jobProperties.get("context");
				}
			}

			// first load default key-value pairs from application.properties
			if (isStandaloneMS) {
				context.putAll(this.getDefaultProperties());
			}
			// call job/subjob with an existing context, like: --context=production. if
			// without this parameter, there will use the default context instead.
			java.io.InputStream inContext = FunctionalRequirement.class.getClassLoader()
					.getResourceAsStream("hms/functionalrequirement_0_1/contexts/" + contextStr + ".properties");
			if (inContext == null) {
				inContext = FunctionalRequirement.class.getClassLoader()
						.getResourceAsStream("config/contexts/" + contextStr + ".properties");
			}
			if (inContext != null) {
				try {
					// defaultProps is in order to keep the original context value
					if (context != null && context.isEmpty()) {
						defaultProps.load(inContext);
						if (inOSGi && jobProperties != null) {
							java.util.Enumeration<String> keys = jobProperties.keys();
							while (keys.hasMoreElements()) {
								String propKey = keys.nextElement();
								if (defaultProps.containsKey(propKey)) {
									defaultProps.put(propKey, (String) jobProperties.get(propKey));
								}
							}
						}
						context = new ContextProperties(defaultProps);
					}
					if (isStandaloneMS) {
						// override context key-value pairs if provided using --context=contextName
						defaultProps.load(inContext);
						context.putAll(defaultProps);
					}
				} finally {
					inContext.close();
				}
			} else if (!isDefaultContext) {
				// print info and job continue to run, for case: context_param is not empty.
				System.err.println("Could not find the context " + contextStr);
			}
			// override key-value pairs if provided via --config.location=file1.file2 OR
			// --config.additional-location=file1,file2
			if (isStandaloneMS) {
				context.putAll(this.getAdditionalProperties());
			}

			// override key-value pairs if provide via command line like
			// --key1=value1,--key2=value2
			if (!context_param.isEmpty()) {
				context.putAll(context_param);
				// set types for params from parentJobs
				for (Object key : context_param.keySet()) {
					String context_key = key.toString();
					String context_type = context_param.getContextType(context_key);
					context.setContextType(context_key, context_type);

				}
			}
			class ContextProcessing {
				private void processContext_0() {
				}

				public void processAllContext() {
					processContext_0();
				}
			}

			new ContextProcessing().processAllContext();
		} catch (java.io.IOException ie) {
			System.err.println("Could not load context " + contextStr);
			ie.printStackTrace();
		}

		// get context value from parent directly
		if (parentContextMap != null && !parentContextMap.isEmpty()) {
		}

		// Resume: init the resumeUtil
		resumeEntryMethodName = ResumeUtil.getResumeEntryMethodName(resuming_checkpoint_path);
		resumeUtil = new ResumeUtil(resuming_logs_dir_path, isChildJob, rootPid);
		resumeUtil.initCommonInfo(pid, rootPid, fatherPid, projectName, jobName, contextStr, jobVersion);

		List<String> parametersToEncrypt = new java.util.ArrayList<String>();
		// Resume: jobStart
		resumeUtil.addLog("JOB_STARTED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "",
				"", "", "", "", resumeUtil.convertToJsonText(context, ContextProperties.class, parametersToEncrypt));

		org.slf4j.MDC.put("_context", contextStr);
		log.info("TalendJob: 'FunctionalRequirement' - Started.");
		java.util.Optional.ofNullable(org.slf4j.MDC.getCopyOfContextMap()).ifPresent(mdcInfo::putAll);

		if (execStat) {
			try {
				runStat.openSocket(!isChildJob);
				runStat.setAllPID(rootPid, fatherPid, pid, jobName);
				runStat.startThreadStat(clientHost, portStats);
				runStat.updateStatOnJob(RunStat.JOBSTART, fatherNode);
			} catch (java.io.IOException ioException) {
				ioException.printStackTrace();
			}
		}

		java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap = new java.util.concurrent.ConcurrentHashMap<Object, Object>();
		globalMap.put("concurrentHashMap", concurrentHashMap);

		long startUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
		long endUsedMemory = 0;
		long end = 0;

		startTime = System.currentTimeMillis();

		this.globalResumeTicket = true;// to run tPreJob

		if (enableLogStash) {
			talendJobLog.addJobStartMessage();
			try {
				talendJobLogProcess(globalMap);
			} catch (java.lang.Exception e) {
				e.printStackTrace();
			}
		}

		this.globalResumeTicket = false;// to run others jobs

		try {
			errorCode = null;
			tDBInput_1Process(globalMap);
			if (!"failure".equals(status)) {
				status = "end";
			}
		} catch (TalendException e_tDBInput_1) {
			globalMap.put("tDBInput_1_SUBPROCESS_STATE", -1);

			e_tDBInput_1.printStackTrace();

		}

		this.globalResumeTicket = true;// to run tPostJob

		end = System.currentTimeMillis();

		if (watch) {
			System.out.println((end - startTime) + " milliseconds");
		}

		endUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
		if (false) {
			System.out.println(
					(endUsedMemory - startUsedMemory) + " bytes memory increase when running : FunctionalRequirement");
		}
		if (enableLogStash) {
			talendJobLog.addJobEndMessage(startTime, end, status);
			try {
				talendJobLogProcess(globalMap);
			} catch (java.lang.Exception e) {
				e.printStackTrace();
			}
		}

		if (execStat) {
			runStat.updateStatOnJob(RunStat.JOBEND, fatherNode);
			runStat.stopThreadStat();
		}
		int returnCode = 0;

		if (errorCode == null) {
			returnCode = status != null && status.equals("failure") ? 1 : 0;
		} else {
			returnCode = errorCode.intValue();
		}
		resumeUtil.addLog("JOB_ENDED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "",
				"" + returnCode, "", "", "");
		resumeUtil.flush();

		org.slf4j.MDC.remove("_subJobName");
		org.slf4j.MDC.remove("_subJobPid");
		org.slf4j.MDC.remove("_systemPid");
		log.info("TalendJob: 'FunctionalRequirement' - Finished - status: " + status + " returnCode: " + returnCode);

		return returnCode;

	}

	// only for OSGi env
	public void destroy() {

	}

	private java.util.Map<String, Object> getSharedConnections4REST() {
		java.util.Map<String, Object> connections = new java.util.HashMap<String, Object>();

		return connections;
	}

	private void evalParam(String arg) {
		if (arg.startsWith("--resuming_logs_dir_path")) {
			resuming_logs_dir_path = arg.substring(25);
		} else if (arg.startsWith("--resuming_checkpoint_path")) {
			resuming_checkpoint_path = arg.substring(27);
		} else if (arg.startsWith("--parent_part_launcher")) {
			parent_part_launcher = arg.substring(23);
		} else if (arg.startsWith("--watch")) {
			watch = true;
		} else if (arg.startsWith("--stat_port=")) {
			String portStatsStr = arg.substring(12);
			if (portStatsStr != null && !portStatsStr.equals("null")) {
				portStats = Integer.parseInt(portStatsStr);
			}
		} else if (arg.startsWith("--trace_port=")) {
			portTraces = Integer.parseInt(arg.substring(13));
		} else if (arg.startsWith("--client_host=")) {
			clientHost = arg.substring(14);
		} else if (arg.startsWith("--context=")) {
			contextStr = arg.substring(10);
			isDefaultContext = false;
		} else if (arg.startsWith("--father_pid=")) {
			fatherPid = arg.substring(13);
		} else if (arg.startsWith("--root_pid=")) {
			rootPid = arg.substring(11);
		} else if (arg.startsWith("--father_node=")) {
			fatherNode = arg.substring(14);
		} else if (arg.startsWith("--pid=")) {
			pid = arg.substring(6);
		} else if (arg.startsWith("--context_type")) {
			String keyValue = arg.substring(15);
			int index = -1;
			if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
				if (fatherPid == null) {
					context_param.setContextType(keyValue.substring(0, index),
							replaceEscapeChars(keyValue.substring(index + 1)));
				} else { // the subjob won't escape the especial chars
					context_param.setContextType(keyValue.substring(0, index), keyValue.substring(index + 1));
				}

			}

		} else if (arg.startsWith("--context_param")) {
			String keyValue = arg.substring(16);
			int index = -1;
			if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
				if (fatherPid == null) {
					context_param.put(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
				} else { // the subjob won't escape the especial chars
					context_param.put(keyValue.substring(0, index), keyValue.substring(index + 1));
				}
			}
		} else if (arg.startsWith("--context_file")) {
			String keyValue = arg.substring(15);
			String filePath = new String(java.util.Base64.getDecoder().decode(keyValue));
			java.nio.file.Path contextFile = java.nio.file.Paths.get(filePath);
			try (java.io.BufferedReader reader = java.nio.file.Files.newBufferedReader(contextFile)) {
				String line;
				while ((line = reader.readLine()) != null) {
					int index = -1;
					if ((index = line.indexOf('=')) > -1) {
						if (line.startsWith("--context_param")) {
							if ("id_Password".equals(context_param.getContextType(line.substring(16, index)))) {
								context_param.put(line.substring(16, index),
										routines.system.PasswordEncryptUtil.decryptPassword(line.substring(index + 1)));
							} else {
								context_param.put(line.substring(16, index), line.substring(index + 1));
							}
						} else {// --context_type
							context_param.setContextType(line.substring(15, index), line.substring(index + 1));
						}
					}
				}
			} catch (java.io.IOException e) {
				System.err.println("Could not load the context file: " + filePath);
				e.printStackTrace();
			}
		} else if (arg.startsWith("--log4jLevel=")) {
			log4jLevel = arg.substring(13);
		} else if (arg.startsWith("--audit.enabled") && arg.contains("=")) {// for trunjob call
			final int equal = arg.indexOf('=');
			final String key = arg.substring("--".length(), equal);
			System.setProperty(key, arg.substring(equal + 1));
		}
	}

	private static final String NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY = "<TALEND_NULL>";

	private final String[][] escapeChars = { { "\\\\", "\\" }, { "\\n", "\n" }, { "\\'", "\'" }, { "\\r", "\r" },
			{ "\\f", "\f" }, { "\\b", "\b" }, { "\\t", "\t" } };

	private String replaceEscapeChars(String keyValue) {

		if (keyValue == null || ("").equals(keyValue.trim())) {
			return keyValue;
		}

		StringBuilder result = new StringBuilder();
		int currIndex = 0;
		while (currIndex < keyValue.length()) {
			int index = -1;
			// judege if the left string includes escape chars
			for (String[] strArray : escapeChars) {
				index = keyValue.indexOf(strArray[0], currIndex);
				if (index >= 0) {

					result.append(keyValue.substring(currIndex, index + strArray[0].length()).replace(strArray[0],
							strArray[1]));
					currIndex = index + strArray[0].length();
					break;
				}
			}
			// if the left string doesn't include escape chars, append the left into the
			// result
			if (index < 0) {
				result.append(keyValue.substring(currIndex));
				currIndex = currIndex + keyValue.length();
			}
		}

		return result.toString();
	}

	public Integer getErrorCode() {
		return errorCode;
	}

	public String getStatus() {
		return status;
	}

	ResumeUtil resumeUtil = null;
}
/************************************************************************************************
 * 961485 characters generated by Talend Real-time Big Data Platform on the 26
 * March 2025 at 11:43:47 am IST
 ************************************************************************************************/